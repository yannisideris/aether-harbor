from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from .island_bank import active_authored_entry
from .local_model import LocalQwen
from .movement import is_capability_question
from .persistence import CampaignStore


_DECLINE = re.compile(r"\b(?:decline|refuse|ignore|leave\s+it|not\s+my\s+problem|walk\s+away|abandon)\b", re.I)

EMERGENT_SCENARIO_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "create_scenario": {"type": "boolean"},
        "id": {"type": "string"},
        "objective": {"type": "string"},
        "hidden": {"type": "string"},
        "terms": {
            "type": "array",
            "items": {"type": "string"},
            "maxItems": 8,
        },
        "flags": {
            "type": "array",
            "maxItems": 3,
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "counts_when": {
                        "type": "array",
                        "items": {"type": "string"},
                        "minItems": 1,
                        "maxItems": 3,
                    },
                },
                "required": ["id", "counts_when"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["create_scenario", "id", "objective", "hidden", "terms", "flags"],
    "additionalProperties": False,
}

EMERGENT_SCENARIO_SYSTEM = """
You are the private Scenario Kernel Architect for an improvisational fantasy RPG.
Inspect the recent Free Play transcript and current campaign context. Decide whether
the player has just engaged in or uncovered a genuine multi-step undertaking with real
stakes (for example: a heist, infiltration, investigation, rescue, smuggling run,
tracking a target, recovering a contested object, or resolving a local crisis).

Default to create_scenario = false (with empty strings and empty arrays) for casual
conversation, shopping, sightseeing, routine travel, ambient exploration, or a simple
standalone fight.

Set create_scenario = true ONLY when a concrete multi-step situation is actively
underway or agreed to. When create_scenario = true:
- id: short snake_case identifier (e.g. "harbor_ledger_heist").
- objective: ONE concise sentence stating the open-ended situation or goal without
  prescribing a single scripted approach.
- hidden: ONE or TWO sentences of private author-side ground truth behind the situation
  (such as the real culprit, the true complication waiting inside, a concealed motive,
  or what is actually at stake) that respects all established transcript facts and
  gives the GM depth to adjudicate discoveries. Never contradict the transcript.
- terms: 4 to 8 lowercase keywords/nouns from the situation (names, places, target objects)
  so the kernel surfaces whenever those topics are in play.
- flags: 2 or 3 milestone flags in progression order:
  - Flag 1 (and Flag 2 if 3 flags): meaningful intermediate progress (e.g. gaining entry
    or leverage, uncovering the key clue/location, bypassing or confronting the guard/obstacle).
    Each flag's counts_when list (1-3 short clauses) must accept multiple plausible player
    approaches (stealth, social, cleverness, or force). If the player already achieved the
    first step in the supplied transcript, start the flags from what remains ahead.
  - The LAST flag in the list is the terminal resolution flag. Phrase its counts_when so ANY
    decisive resolution of the undertaking satisfies it (e.g. securing the target, settling
    or exposing the matter, completing the job).
Return JSON only.
""".strip()


def ensure_scenario_state(state: dict[str, Any]) -> dict[str, Any]:
    store = state.setdefault("scenario_kernels", {})
    store.setdefault("active", None)
    store.setdefault("records", {})
    store.setdefault("definitions", {})
    store.setdefault("history", [])
    store.setdefault("pending_emergent_candidate", None)
    store.setdefault("last_emergent_check_turn", -999)
    return store


def _digest(state: dict[str, Any], suffix: str) -> bytes:
    material = (
        f"{state.get('campaign_id', '')}:{state.get('rng_seed', 0)}:"
        f"scenario-kernel-v1:{suffix}"
    ).encode("utf-8")
    return hashlib.sha256(material).digest()


def _scenario_by_id(entry: dict[str, Any], scenario_id: str) -> dict[str, Any] | None:
    return next(
        (
            row for row in entry.get("scenarios", [])
            if isinstance(row, dict) and str(row.get("id") or "") == scenario_id
        ),
        None,
    )


def _matching_scenario(entry: dict[str, Any], player_text: str) -> dict[str, Any] | None:
    folded = " ".join(str(player_text or "").casefold().split())
    return next(
        (
            row for row in entry.get("scenarios", [])
            if isinstance(row, dict)
            and any(str(term).casefold() in folded for term in row.get("terms", []))
        ),
        None,
    )


def _active_in_scope(state: dict[str, Any], active: dict[str, Any]) -> bool:
    from .island_context import island_root_id

    current_island = island_root_id(state)
    if str(active.get("source") or "authored") == "emergent":
        active_island = active.get("island_id")
        if active_island:
            return str(current_island or "") == str(active_island)
        return current_island is None
    current_scopes = {str(state.get("current_location_id") or ""), str(current_island or "")}
    if str(active.get("location_id") or "") not in current_scopes:
        return False
    entry = active_authored_entry(state)
    return bool(entry is not None and entry.get("id") == active.get("island_id"))


DORMANT_IDLE_TURNS = 5
SWITCH_IDLE_TURNS = 2


def _scenario_definition_for_record(
    state: dict[str, Any],
    record: dict[str, Any],
) -> dict[str, Any] | None:
    scenario_id = str(record.get("scenario_id") or "")
    if str(record.get("source") or "authored") == "emergent":
        definition = record.get("definition")
        if isinstance(definition, dict):
            return definition
        store = ensure_scenario_state(state)
        stored = store.get("definitions", {}).get(scenario_id)
        return stored if isinstance(stored, dict) else None
    entry = active_authored_entry(state)
    if entry is None:
        return None
    return _scenario_by_id(entry, scenario_id)


def _active_scenario_definition(
    state: dict[str, Any],
    active: dict[str, Any],
) -> dict[str, Any] | None:
    if not _active_in_scope(state, active):
        return None
    return _scenario_definition_for_record(state, active)


def _last_touch_turn(record: dict[str, Any]) -> int:
    return max(
        int(record.get("started_turn", 0) or 0),
        int(record.get("last_update_turn", 0) or 0),
        int(record.get("last_relevant_turn", 0) or 0),
    )


def _terms_match_text(scenario: dict[str, Any], text: str) -> bool:
    folded = " ".join(str(text or "").casefold().split())
    if not folded:
        return False
    return any(str(term).casefold() in folded for term in scenario.get("terms", []) if str(term).strip())


MAX_SCENARIO_PLACES = 8
PLACE_FRESHNESS_TURNS = 3


def _current_place_keys(state: dict[str, Any]) -> set[str]:
    """Stable identities of where the player stands: location, site root, spot."""

    from .movement import active_site_root_id

    keys = {str(state.get("current_location_id") or "")}
    try:
        keys.add(str(active_site_root_id(state) or ""))
    except Exception:
        pass
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    label = " ".join(str(position.get("label") or "").casefold().split())
    if label:
        keys.add("pos:" + label)
    return {key for key in keys if key and key != "opening_threshold"}


def _at_scenario_place(state: dict[str, Any], record: dict[str, Any]) -> bool:
    places = record.get("places") if isinstance(record.get("places"), list) else []
    return bool(places and _current_place_keys(state).intersection(places))


def _remember_scenario_place(state: dict[str, Any], record: dict[str, Any]) -> None:
    """A place the player travels to while an undertaking is engaged belongs to it.

    Players naturally say "the place they mentioned" or "the person who hired
    me"; the undertaking must not depend on them repeating its keywords.
    """

    places = record.setdefault("places", [])
    for key in sorted(_current_place_keys(state)):
        if key not in places:
            places.append(key)
    del places[:-MAX_SCENARIO_PLACES]


def _committed_movement(resolved_event: dict[str, Any] | None) -> bool:
    if not isinstance(resolved_event, dict):
        return False
    if resolved_event.get("type") in {"movement", "local_movement"}:
        return resolved_event.get("committed") is True
    movement = resolved_event.get("movement")
    return isinstance(movement, dict) and movement.get("committed") is True


def _scene_probe(state: dict[str, Any], player_text: str) -> str:
    location = state.get("locations", {}).get(str(state.get("current_location_id") or ""), {})
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    return f"{player_text or ''} {location.get('name') or ''} {position.get('label') or ''}"


def _park_dormant(store: dict[str, Any], active: dict[str, Any], current_turn: int) -> None:
    active["status"] = "dormant"
    active["dormant_turn"] = current_turn
    store["records"][active["scenario_id"]] = dict(active)
    store["history"].append(
        {"scenario_id": active["scenario_id"], "status": "dormant", "turn": current_turn}
    )
    store["history"] = store["history"][-20:]
    if store.get("active") is active or (
        isinstance(store.get("active"), dict)
        and store["active"].get("scenario_id") == active.get("scenario_id")
    ):
        store["active"] = None


def _matching_dormant_record(state: dict[str, Any], player_text: str) -> dict[str, Any] | None:
    store = ensure_scenario_state(state)
    records = store.get("records") if isinstance(store.get("records"), dict) else {}
    for record in records.values():
        if not isinstance(record, dict) or record.get("status") != "dormant":
            continue
        if not _active_in_scope(state, record):
            continue
        scenario = _scenario_definition_for_record(state, record)
        if scenario and (
            _terms_match_text(scenario, _scene_probe(state, player_text))
            or _at_scenario_place(state, record)
        ):
            return record
    return None


def maybe_activate_scenario(state: dict[str, Any], player_text: str) -> dict[str, Any] | None:
    store = ensure_scenario_state(state)
    current_turn = int(state.get("turn_no", 0) or 0)
    active = store.get("active")
    if isinstance(active, dict) and active.get("status") == "engaged":
        if not _active_in_scope(state, active):
            _park_dormant(store, active, current_turn)
            active = None
        else:
            scenario = _active_scenario_definition(state, active)
            if scenario and _DECLINE.search(player_text):
                active["status"] = "declined"
                active["ended_turn"] = current_turn
                store["records"][active["scenario_id"]] = dict(active)
                store["history"].append(
                    {"scenario_id": active["scenario_id"], "status": "declined", "turn": current_turn}
                )
                store["history"] = store["history"][-20:]
                store["active"] = None
                return None
            if scenario and _terms_match_text(scenario, _scene_probe(state, player_text)):
                active["last_relevant_turn"] = current_turn
                store["records"][active["scenario_id"]] = dict(active)
                return active
            if scenario and _at_scenario_place(state, active):
                # Still at the undertaking's place: keep it alive, but do not
                # refresh it, so wandering on from here cannot extend it forever.
                return active
            idle_turns = current_turn - _last_touch_turn(active)
            if idle_turns >= DORMANT_IDLE_TURNS:
                _park_dormant(store, active, current_turn)
                active = None
            elif idle_turns >= SWITCH_IDLE_TURNS:
                # Allow an explicit new hook or a resumed dormant kernel to
                # replace an unmentioned scenario that the player wandered from.
                dormant_hit = _matching_dormant_record(state, player_text)
                entry_probe = active_authored_entry(state)
                authored_hit = _matching_scenario(entry_probe, player_text) if entry_probe else None
                if dormant_hit is not None or (
                    authored_hit is not None
                    and str(authored_hit.get("id") or "") != str(active.get("scenario_id") or "")
                ):
                    _park_dormant(store, active, current_turn)
                    active = None
                else:
                    return active
            else:
                return active

    dormant_record = _matching_dormant_record(state, player_text)
    if dormant_record is not None:
        dormant_record["status"] = "engaged"
        dormant_record["last_relevant_turn"] = current_turn
        store["active"] = dormant_record
        store["records"][dormant_record["scenario_id"]] = dict(dormant_record)
        store["pending_emergent_candidate"] = None
        return dormant_record

    entry = active_authored_entry(state)
    if entry is None:
        return None
    scenario = _matching_scenario(entry, player_text)
    if scenario is None:
        return None
    scenario_id = str(scenario.get("id") or "")
    previous = store["records"].get(scenario_id)
    if isinstance(previous, dict) and previous.get("status") in {"declined", "resolved"}:
        return None
    if isinstance(previous, dict) and previous.get("status") == "dormant":
        previous["status"] = "engaged"
        previous["last_relevant_turn"] = current_turn
        store["active"] = previous
        store["records"][scenario_id] = dict(previous)
        store["pending_emergent_candidate"] = None
        return previous

    variants = [str(value) for value in scenario.get("variants", []) if str(value).strip()]
    hidden_variant = None
    if variants:
        ordered = sorted(
            variants,
            key=lambda value: _digest(state, f"{entry['id']}:{scenario_id}:{value}"),
        )
        hidden_variant = ordered[0]
    from .island_context import island_root_id
    record = {
        "scenario_id": scenario_id,
        "source": "authored",
        "island_id": entry["id"],
        "location_id": island_root_id(state) or str(state.get("current_location_id") or ""),
        "status": "engaged",
        "started_turn": current_turn,
        "last_relevant_turn": current_turn,
        "flags": {flag: False for flag in scenario.get("flags", [])},
        "hidden_variant": hidden_variant,
    }
    store["active"] = record
    store["records"][scenario_id] = dict(record)
    store["pending_emergent_candidate"] = None
    return record


def _failed(resolved_event: dict[str, Any] | None) -> bool:
    if not isinstance(resolved_event, dict):
        return False
    if resolved_event.get("success") is False:
        return True
    if str(resolved_event.get("outcome") or "") in {"failure", "critical_failure"}:
        return True
    roll = resolved_event.get("roll")
    return isinstance(roll, dict) and roll.get("success") is False


def observe_scenario_action(
    state: dict[str, Any],
    player_text: str,
    resolved_event: dict[str, Any] | None,
    *,
    semantic_flags: list[str] | None = None,
) -> list[str]:
    # Asking whether an action is possible can make the scenario relevant, but
    # it is not evidence that the player performed or completed that action.
    if is_capability_question(player_text):
        return []
    store = ensure_scenario_state(state)
    active = store.get("active")
    if not isinstance(active, dict) or active.get("status") != "engaged" or _failed(resolved_event):
        return []
    scenario = _active_scenario_definition(state, active)
    if scenario is None:
        return []
    if (
        _committed_movement(resolved_event)
        and int(state.get("turn_no", 0) or 0) - _last_touch_turn(active) <= PLACE_FRESHNESS_TURNS
    ):
        # Travel soon after the undertaking was last touched is travel for it.
        _remember_scenario_place(state, active)
        store["records"][active["scenario_id"]] = dict(active)
    updates: list[str] = []
    allowed = set(scenario.get("flags", []))
    flags = active.setdefault("flags", {})
    if semantic_flags is not None:
        # A successful semantic judgment owns normal-play progress. Python only
        # validates the exact authored flag ids and locks the resulting state.
        for flag in semantic_flags:
            clean = str(flag or "")
            if clean in allowed and not flags.get(clean):
                flags[clean] = True
                updates.append(clean)
    else:
        # Narrow legacy/technical fallback when the foreground model call
        # failed entirely. It is deliberately not consulted after a valid
        # semantic "no progress" judgment.
        folded = " ".join(str(player_text or "").casefold().split())
        rules = scenario.get("flag_rules") if isinstance(scenario.get("flag_rules"), dict) else {}
        for flag, terms in rules.items():
            if flag not in allowed or flags.get(flag):
                continue
            if not any(str(term).casefold() in folded for term in terms if str(term).strip()):
                continue
            flags[flag] = True
            updates.append(flag)
    terminal_flags = {
        str(flag)
        for flag in scenario.get("terminal_flags", [])
        if str(flag) in allowed
    }
    if not terminal_flags and scenario.get("flags"):
        # Existing compact kernels place their resolving flag last.  New
        # catalog rows can state terminal_flags explicitly.
        terminal_flags = {str(scenario["flags"][-1])}
    if (
        isinstance(resolved_event, dict)
        and resolved_event.get("type") == "active_situation_resolution"
        and resolved_event.get("status") not in {"caught", "resolved"}
    ):
        # A successful chase roll may only reach contact. It cannot satisfy a
        # terminal recovery/capture flag before the situation itself says the
        # quarry was caught. This is a generic state invariant, not a
        # scenario-name or phrase patch.
        for flag in list(updates):
            if flag in terminal_flags:
                flags[flag] = False
                updates.remove(flag)
    if updates:
        active["last_update_turn"] = int(state.get("turn_no", 0) or 0)
        store["records"][active["scenario_id"]] = dict(active)
    if terminal_flags.intersection(updates):
        active["status"] = "resolved"
        active["ended_turn"] = int(state.get("turn_no", 0) or 0)
        store["records"][active["scenario_id"]] = dict(active)
        store["history"].append(
            {"scenario_id": active["scenario_id"], "status": "resolved", "turn": active["ended_turn"]}
        )
        store["history"] = store["history"][-20:]
        store["active"] = None
    return updates


def semantic_scenario_context(state: dict[str, Any]) -> dict[str, Any] | None:
    """Expose only an active kernel's compact progress contract to the judge."""

    store = ensure_scenario_state(state)
    active = store.get("active")
    if not isinstance(active, dict) or active.get("status") != "engaged":
        return None
    scenario = _active_scenario_definition(state, active)
    if scenario is None:
        return None
    rules = scenario.get("flag_rules") if isinstance(scenario.get("flag_rules"), dict) else {}
    flags = active.get("flags") if isinstance(active.get("flags"), dict) else {}
    allowed_updates: list[dict[str, Any]] = []
    for flag in scenario.get("flags", []):
        clean = str(flag or "")
        if not clean or flags.get(clean):
            continue
        meanings = [" ".join(str(value).split())[:90] for value in rules.get(clean, []) if str(value).strip()]
        allowed_updates.append({"flag": clean, "counts_when": meanings[:5]})
    return {
        "objective": str(scenario.get("objective") or "")[:220],
        "current_flags": {str(key): bool(value) for key, value in flags.items()},
        "allowed_updates": allowed_updates[:4],
    }


def private_scenario_context(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> dict[str, Any] | None:
    store = ensure_scenario_state(state)
    active = store.get("active")
    if not isinstance(active, dict) or active.get("status") != "engaged":
        return None
    scenario = _active_scenario_definition(state, active)
    if scenario is None:
        return None

    location = state.get("locations", {}).get(str(state.get("current_location_id") or ""), {})
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    relevance = " ".join(
        [
            str(player_text or ""),
            str(location.get("name") or ""),
            str(location.get("summary") or ""),
            str(location.get("defining_excerpt") or ""),
            str(position.get("label") or ""),
            str(position.get("summary") or ""),
            *[
                str(row.get("text") or "")
                for row in recent_turns[-3:]
                if isinstance(row, dict)
            ],
        ]
    ).casefold()
    terms_match = any(str(term).casefold() in relevance for term in scenario.get("terms", []))
    if not terms_match and not _at_scenario_place(state, active):
        if str(active.get("source") or "authored") == "emergent":
            current_turn = int(state.get("turn_no", 0) or 0)
            last_touch = _last_touch_turn(active)
            if current_turn - last_touch > 4:
                return None
        else:
            return None

    hidden = str(active.get("hidden_variant") or scenario.get("hidden") or "")
    return {
        "instruction": (
            "This is a compact optional situation, not a quest order or scripted route. Keep the objective available "
            "without reminding or steering the player. Treat flags as exact. The hidden relation is private author-side "
            "state: let it shape relevant conduct but never disclose it before earned evidence. Accept plausible solutions "
            "that are absent from the source and do not invent a key-boss-relic chain."
        ),
        "objective": scenario.get("objective"),
        "flags": dict(active.get("flags") or {}),
        "private_hidden_relation": hidden,
    }


def note_scenario_narration(
    state: dict[str, Any],
    player_text: str,
    narration: str,
    resolved_event: dict[str, Any] | None = None,
) -> None:
    """Queue an emergent scenario architect check when Free Play surfaces an undertaking."""

    store = ensure_scenario_state(state)
    active = store.get("active")
    if isinstance(active, dict) and active.get("status") == "engaged":
        store["pending_emergent_candidate"] = None
        return
    if (
        is_capability_question(player_text)
        or _DECLINE.search(player_text)
        or _failed(resolved_event)
        or (isinstance(state.get("combat"), dict) and state["combat"].get("status") == "active")
    ):
        return
    entry = active_authored_entry(state)
    combined = f"{player_text or ''}\n{narration or ''}"
    if entry is not None:
        # Never shadow an unplayed authored island kernel whose hook terms are
        # already present in this beat.
        records = store.get("records") if isinstance(store.get("records"), dict) else {}
        for row in entry.get("scenarios", []):
            if not isinstance(row, dict):
                continue
            sid = str(row.get("id") or "")
            prev = records.get(sid)
            if isinstance(prev, dict) and prev.get("status") in {"declined", "resolved"}:
                continue
            if any(str(term).casefold() in combined.casefold() for term in row.get("terms", [])):
                return
    # No keyword gate: the architect's own default-false judgment decides,
    # at most once per cooldown. A word list made harbour intrigue (ledgers,
    # smuggling) the only stories that could become undertakings.
    store["pending_emergent_candidate"] = {
        "turn": int(state.get("turn_no", 0) or 0),
        "location_id": str(state.get("current_location_id") or ""),
        "player_text": " ".join(str(player_text or "").split())[:320],
        "narration": " ".join(str(narration or "").split())[:900],
    }


def emergent_scenario_due(state: dict[str, Any], *, cooldown: int = 3) -> bool:
    store = ensure_scenario_state(state)
    active = store.get("active")
    if isinstance(active, dict) and active.get("status") == "engaged":
        return False
    candidate = store.get("pending_emergent_candidate")
    if not isinstance(candidate, dict):
        return False
    current_turn = int(state.get("turn_no", 0) or 0)
    last_check = int(store.get("last_emergent_check_turn", -999) or -999)
    return current_turn - last_check >= max(2, int(cooldown))


def _slug_id(value: str, fallback: str = "emergent_undertaking") -> str:
    cleaned = re.sub(r"[^a-z0-9]+", "_", str(value or "").casefold()).strip("_")
    return cleaned[:44] or fallback


def run_emergent_scenario_architect(
    *,
    model: LocalQwen,
    store: CampaignStore | None = None,
    state: dict[str, Any],
    save_state: bool = True,
) -> dict[str, Any]:
    scenario_store = ensure_scenario_state(state)
    current_turn = int(state.get("turn_no", 0) or 0)
    candidate = (
        scenario_store.get("pending_emergent_candidate")
        if isinstance(scenario_store.get("pending_emergent_candidate"), dict)
        else {}
    )
    scenario_store["pending_emergent_candidate"] = None
    scenario_store["last_emergent_check_turn"] = current_turn

    active = scenario_store.get("active")
    if isinstance(active, dict) and active.get("status") == "engaged":
        return {"created": False, "reason": "already_active"}

    rows: list[dict[str, Any]] = []
    if store is not None and state.get("campaign_id"):
        try:
            rows = store.recent_turns(str(state["campaign_id"]), limit=6)
        except Exception:
            rows = []
    if not rows and (candidate.get("player_text") or candidate.get("narration")):
        if candidate.get("player_text"):
            rows.append({"sequence_no": 1, "speaker": "Player", "text": str(candidate["player_text"])})
        if candidate.get("narration"):
            rows.append({"sequence_no": 2, "speaker": "Aether Harbor", "text": str(candidate["narration"])})
    if not rows:
        if save_state and store is not None:
            store.save_state(state)
        return {"created": False, "reason": "no_transcript"}

    location_id = str(state.get("current_location_id") or "")
    location = state.get("locations", {}).get(location_id, {})
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    history_ids = [
        str(item.get("scenario_id") or "")
        for item in scenario_store.get("history", [])[-8:]
        if isinstance(item, dict) and str(item.get("scenario_id") or "")
    ]
    context_payload = {
        "current_location": {
            "id": location_id,
            "name": location.get("name"),
            "summary": location.get("summary"),
            "position": position.get("label"),
        },
        "companions": [
            str(comp.get("name") or "")
            for comp in state.get("player", {}).get("companions", [])
            if isinstance(comp, dict) and str(comp.get("name") or "")
        ],
        "completed_or_declined_scenarios": history_ids,
    }
    transcript = "\n".join(
        f"[{idx}] {str(row.get('speaker') or '').upper()}: {str(row.get('text') or '').strip()}"
        for idx, row in enumerate(rows, start=1)
        if str(row.get("text") or "").strip()
    )
    messages = [
        {"role": "system", "content": EMERGENT_SCENARIO_SYSTEM},
        {
            "role": "user",
            "content": (
                "CURRENT CAMPAIGN CONTEXT:\n"
                f"{json.dumps(context_payload, ensure_ascii=False, indent=2)}\n\n"
                "RECENT TRANSCRIPT:\n"
                f"{transcript}"
            ),
        },
    ]
    raw = model.chat_json(
        messages,
        schema=EMERGENT_SCENARIO_SCHEMA,
        temperature=0.2,
    )
    if not isinstance(raw, dict) or not bool(raw.get("create_scenario")):
        if save_state and store is not None:
            store.save_state(state)
        return {"created": False, "reason": "declined_by_architect"}

    objective = " ".join(str(raw.get("objective") or "").split())[:220]
    hidden = " ".join(str(raw.get("hidden") or "").split())[:360]
    raw_flags = raw.get("flags") if isinstance(raw.get("flags"), list) else []
    flag_ids: list[str] = []
    flag_rules: dict[str, list[str]] = {}
    for idx, item in enumerate(raw_flags[:3], start=1):
        if not isinstance(item, dict):
            continue
        fid = _slug_id(str(item.get("id") or ""), fallback=f"stage_{idx}")
        if fid in flag_ids:
            continue
        counts_when = [
            " ".join(str(clause).split())[:90]
            for clause in (item.get("counts_when") or [])
            if str(clause).strip()
        ][:3]
        if not counts_when:
            continue
        flag_ids.append(fid)
        flag_rules[fid] = counts_when

    if not objective or len(flag_ids) < 2:
        if save_state and store is not None:
            store.save_state(state)
        return {"created": False, "reason": "insufficient_flags"}

    base_id = _slug_id(str(raw.get("id") or ""), fallback="emergent_undertaking")
    if not base_id.startswith("emergent_"):
        base_id = f"emergent_{base_id}"
    scenario_id = base_id
    suffix = 2
    while scenario_id in scenario_store.get("records", {}):
        scenario_id = f"{base_id}_{suffix}"
        suffix += 1

    terms = [
        " ".join(str(term).casefold().split())[:40]
        for term in (raw.get("terms") or [])
        if len(" ".join(str(term).split())) >= 3
    ][:8]
    if not terms:
        terms = [
            token
            for token in re.findall(r"[a-z]{4,}", objective.casefold())
            if token not in {"that", "this", "with", "from", "into", "their", "your"}
        ][:6]

    definition = {
        "id": scenario_id,
        "objective": objective,
        "hidden": hidden,
        "terms": terms,
        "flags": flag_ids,
        "terminal_flags": [flag_ids[-1]],
        "flag_rules": flag_rules,
        "variants": [hidden] if hidden else [],
    }
    from .island_context import island_root_id

    current_island = island_root_id(state)
    record = {
        "scenario_id": scenario_id,
        "source": "emergent",
        "island_id": current_island,
        "location_id": current_island or location_id,
        "status": "engaged",
        "started_turn": current_turn,
        "last_update_turn": current_turn,
        "flags": {flag: False for flag in flag_ids},
        "hidden_variant": hidden,
        "definition": definition,
    }
    scenario_store.setdefault("definitions", {})[scenario_id] = definition
    scenario_store["active"] = record
    scenario_store["records"][scenario_id] = dict(record)
    if save_state and store is not None:
        store.save_state(state)
    return {"created": True, "scenario_id": scenario_id, "record": record}

