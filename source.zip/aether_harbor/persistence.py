from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from .state import ensure_state_defaults


class CampaignStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    @contextmanager
    def _session(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def _initialize(self) -> None:
        with self._session() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS campaigns (
                    id TEXT PRIMARY KEY,
                    created_at INTEGER NOT NULL,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    state_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS turns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    campaign_id TEXT NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
                    sequence_no INTEGER NOT NULL,
                    speaker TEXT NOT NULL,
                    text TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(campaign_id, sequence_no)
                );
                CREATE INDEX IF NOT EXISTS idx_turns_campaign_sequence
                    ON turns(campaign_id, sequence_no);
                CREATE TABLE IF NOT EXISTS memory_evidence (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    campaign_id TEXT NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
                    kind TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    status TEXT NOT NULL,
                    source_turn_ids_json TEXT NOT NULL,
                    excerpt TEXT NOT NULL,
                    priority INTEGER NOT NULL DEFAULT 0,
                    shareable_seed INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS shared_echoes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_campaign_id TEXT,
                    scale TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    text TEXT NOT NULL,
                    tags_json TEXT NOT NULL DEFAULT '[]',
                    weight REAL NOT NULL DEFAULT 1.0,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                """
            )

    def create_campaign(self, state: dict[str, Any]) -> None:
        ensure_state_defaults(state)
        with self._session() as connection:
            connection.execute(
                "INSERT INTO campaigns(id, created_at, state_json) VALUES (?, ?, ?)",
                (
                    state["campaign_id"],
                    int(state.get("created_at", 0) or 0),
                    json.dumps(state, ensure_ascii=False),
                ),
            )

    def save_state(self, state: dict[str, Any]) -> None:
        ensure_state_defaults(state)
        with self._session() as connection:
            self._write_state(connection, state)

    @staticmethod
    def _write_state(connection: sqlite3.Connection, state: dict[str, Any]) -> None:
        cursor = connection.execute(
            """
            UPDATE campaigns
            SET state_json = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (json.dumps(state, ensure_ascii=False), state["campaign_id"]),
        )
        if cursor.rowcount == 0:
            connection.execute(
                """
                INSERT INTO campaigns(id, created_at, state_json)
                VALUES (?, ?, ?)
                """,
                (
                    state["campaign_id"],
                    int(state.get("created_at", 0) or 0),
                    json.dumps(state, ensure_ascii=False),
                ),
            )

    def latest_campaign(self) -> dict[str, Any] | None:
        with self._session() as connection:
            row = connection.execute(
                "SELECT state_json FROM campaigns ORDER BY updated_at DESC, rowid DESC LIMIT 1"
            ).fetchone()
        return ensure_state_defaults(json.loads(row["state_json"])) if row else None

    def clear_all_play_data(self) -> None:
        """Remove development-voyage history while preserving the schema."""

        with self._session() as connection:
            connection.execute("DELETE FROM shared_echoes")
            connection.execute("DELETE FROM campaigns")

    def append_turn(self, campaign_id: str, speaker: str, text: str) -> int:
        with self._session() as connection:
            return self._insert_turn(connection, campaign_id, speaker, text)

    @staticmethod
    def _insert_turn(connection: sqlite3.Connection, campaign_id: str, speaker: str, text: str) -> int:
        sequence = int(
            connection.execute(
                "SELECT COALESCE(MAX(sequence_no), 0) + 1 FROM turns WHERE campaign_id = ?",
                (campaign_id,),
            ).fetchone()[0]
        )
        connection.execute(
            "INSERT INTO turns(campaign_id, sequence_no, speaker, text) VALUES (?, ?, ?, ?)",
            (campaign_id, sequence, speaker, text),
        )
        return sequence

    @contextmanager
    def transcript_turn(self, state: dict[str, Any], speaker: str, text: str) -> Iterator[int]:
        """Commit a transcript row and its source-time state in one checkpoint."""
        with self._session() as connection:
            yield self._insert_turn(connection, state["campaign_id"], speaker, text)
            ensure_state_defaults(state)
            self._write_state(connection, state)

    def recent_turns(self, campaign_id: str, *, limit: int = 24) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, sequence_no, speaker, text
                FROM turns
                WHERE campaign_id = ?
                ORDER BY sequence_no DESC
                LIMIT ?
                """,
                (campaign_id, max(1, int(limit))),
            ).fetchall()
        return [dict(row) for row in reversed(rows)]

    def all_turns(self, campaign_id: str) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, sequence_no, speaker, text
                FROM turns
                WHERE campaign_id = ?
                ORDER BY sequence_no
                """,
                (campaign_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def turns_after(self, campaign_id: str, sequence_no: int, *, limit: int = 40) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, sequence_no, speaker, text
                FROM turns
                WHERE campaign_id = ? AND sequence_no > ?
                ORDER BY sequence_no
                LIMIT ?
                """,
                (campaign_id, int(sequence_no), max(1, int(limit))),
            ).fetchall()
        return [dict(row) for row in rows]

    def add_evidence(
        self,
        campaign_id: str,
        *,
        kind: str,
        subject: str,
        status: str,
        source_turn_ids: list[int],
        excerpt: str,
        priority: int = 0,
        shareable_seed: bool = False,
    ) -> int | None:
        normalized_excerpt = " ".join(str(excerpt).split())
        if not normalized_excerpt:
            return None
        with self._session() as connection:
            duplicate = connection.execute(
                """
                SELECT id FROM memory_evidence
                WHERE campaign_id = ? AND kind = ? AND subject = ? AND excerpt = ?
                LIMIT 1
                """,
                (campaign_id, kind, subject, normalized_excerpt),
            ).fetchone()
            if duplicate:
                return int(duplicate["id"])
            cursor = connection.execute(
                """
                INSERT INTO memory_evidence(
                    campaign_id, kind, subject, status, source_turn_ids_json,
                    excerpt, priority, shareable_seed
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    campaign_id,
                    kind,
                    subject,
                    status,
                    json.dumps(source_turn_ids),
                    normalized_excerpt,
                    int(priority),
                    1 if shareable_seed else 0,
                ),
            )
            return int(cursor.lastrowid)

    def recent_evidence(self, campaign_id: str, *, limit: int = 8) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, kind, subject, status, source_turn_ids_json, excerpt, priority
                FROM memory_evidence
                WHERE campaign_id = ?
                ORDER BY priority DESC, id DESC
                LIMIT ?
                """,
                (campaign_id, max(1, int(limit))),
            ).fetchall()
        result: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["source_turn_ids"] = json.loads(item.pop("source_turn_ids_json"))
            result.append(item)
        return list(reversed(result))

    def evidence_after(
        self,
        campaign_id: str,
        evidence_id: int,
        *,
        limit: int = 8,
    ) -> list[dict[str, Any]]:
        """Return new durable records for the sparse semantic curator."""

        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, kind, subject, status, source_turn_ids_json, excerpt,
                       priority, shareable_seed
                FROM memory_evidence
                WHERE campaign_id = ? AND id > ?
                ORDER BY id
                LIMIT ?
                """,
                (campaign_id, int(evidence_id), max(1, int(limit))),
            ).fetchall()
        result: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["source_turn_ids"] = json.loads(item.pop("source_turn_ids_json"))
            item["shareable_seed"] = bool(item.get("shareable_seed"))
            result.append(item)
        return result

    def curate_evidence(
        self,
        evidence_id: int,
        *,
        keep: bool,
        kind: str,
        subject: str,
        shareable_seed: bool,
    ) -> dict[str, Any] | None:
        """Correct or discard one record and its already-exported shared echo."""

        with self._session() as connection:
            row = connection.execute(
                """
                SELECT id, campaign_id, kind, subject, status, excerpt,
                       shareable_seed
                FROM memory_evidence WHERE id = ?
                """,
                (int(evidence_id),),
            ).fetchone()
            if not row:
                return None
            old = dict(row)
            shared = connection.execute(
                """
                SELECT id FROM shared_echoes
                WHERE COALESCE(source_campaign_id, '') = ? AND subject = ? AND text = ?
                """,
                (old["campaign_id"], old["subject"], old["excerpt"]),
            ).fetchall()
            connection.execute(
                """
                DELETE FROM shared_echoes
                WHERE COALESCE(source_campaign_id, '') = ? AND subject = ? AND text = ?
                """,
                (old["campaign_id"], old["subject"], old["excerpt"]),
            )
            if not keep:
                connection.execute("DELETE FROM memory_evidence WHERE id = ?", (int(evidence_id),))
                return old
            clean_subject = " ".join(str(subject or old["subject"]).split())[:120]
            connection.execute(
                """
                UPDATE memory_evidence
                SET kind = ?, subject = ?, shareable_seed = ?
                WHERE id = ?
                """,
                (kind, clean_subject, 1 if shareable_seed else 0, int(evidence_id)),
            )
            if shared and shareable_seed:
                scale = "person" if kind == "npc_signature" else ("site" if kind == "place" else "shard")
                connection.execute(
                    """
                    INSERT INTO shared_echoes(
                        source_campaign_id, scale, kind, subject, text, tags_json, weight
                    ) VALUES (?, ?, ?, ?, ?, ?, 1.0)
                    """,
                    (
                        old["campaign_id"], scale, kind, clean_subject, old["excerpt"],
                        json.dumps([old["status"]], ensure_ascii=False),
                    ),
                )
            return old

    def add_shared_echo(
        self,
        *,
        source_campaign_id: str,
        scale: str,
        kind: str,
        subject: str,
        text: str,
        tags: list[str] | None = None,
        weight: float = 1.0,
    ) -> int | None:
        normalized_text = " ".join(str(text).split())
        if not normalized_text:
            return None
        with self._session() as connection:
            duplicate = connection.execute(
                "SELECT id FROM shared_echoes WHERE subject = ? AND text = ? LIMIT 1",
                (subject, normalized_text),
            ).fetchone()
            if duplicate:
                return int(duplicate["id"])
            cursor = connection.execute(
                """
                INSERT INTO shared_echoes(
                    source_campaign_id, scale, kind, subject, text, tags_json, weight
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    source_campaign_id,
                    scale,
                    kind,
                    subject,
                    normalized_text,
                    json.dumps(tags or [], ensure_ascii=False),
                    max(0.1, float(weight)),
                ),
            )
            return int(cursor.lastrowid)

    def random_shared_echo(
        self,
        *,
        exclude_campaign_id: str,
        allowed_scales: list[str] | None = None,
    ) -> dict[str, Any] | None:
        scales = allowed_scales or ["shard", "person", "site", "district", "island"]
        placeholders = ",".join("?" for _ in scales)
        with self._session() as connection:
            row = connection.execute(
                f"""
                SELECT id, scale, kind, subject, text, tags_json, weight
                FROM shared_echoes
                WHERE COALESCE(source_campaign_id, '') <> ?
                  AND scale IN ({placeholders})
                ORDER BY (ABS(RANDOM()) / weight)
                LIMIT 1
                """,
                (exclude_campaign_id, *scales),
            ).fetchone()
        if not row:
            return None
        result = dict(row)
        result["tags"] = json.loads(result.pop("tags_json"))
        return result
