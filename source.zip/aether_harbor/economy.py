from __future__ import annotations

import re
from typing import Any


PRICE_ANCHORS: list[dict[str, Any]] = [
    {"name": "Loaf of Bread", "category": "basics", "silver": [2, 2], "tags": ["bread", "food"]},
    {"name": "Tankard of Ale", "category": "basics", "silver": [3, 3], "tags": ["ale", "drink"]},
    {"name": "Simple Meal", "category": "basics", "silver": [4, 4], "tags": ["meal", "food"]},
    {"name": "Inn Stay", "category": "services", "silver": [5, 5], "tags": ["inn", "room", "lodging"]},
    {"name": "Physician Treatment", "category": "services", "silver": [8, 15], "tags": ["physician", "doctor", "healer", "treatment", "clinic"]},
    {"name": "Sea Passage", "category": "services", "silver": [5, 30], "tags": ["passage", "ship", "boat", "sail", "charter", "ferry"]},
    {"name": "Dagger", "category": "melee weapons", "silver": [5, 10], "tags": ["dagger", "weapon", "blade"]},
    {"name": "Club", "category": "melee weapons", "silver": [8, 12], "tags": ["club", "weapon"]},
    {"name": "Spear", "category": "melee weapons", "silver": [12, 18], "tags": ["spear", "weapon"]},
    {"name": "Short Sword", "category": "melee weapons", "silver": [15, 20], "tags": ["short sword", "sword", "weapon"]},
    {"name": "Cutlass", "category": "melee weapons", "silver": [20, 30], "tags": ["cutlass", "weapon", "blade"]},
    {"name": "Rapier", "category": "melee weapons", "silver": [30, 40], "tags": ["rapier", "weapon", "blade"]},
    {"name": "Axe", "category": "melee weapons", "silver": [35, 45], "tags": ["axe", "weapon"]},
    {"name": "Bow", "category": "ranged weapons", "silver": [20, 30], "tags": ["bow", "ranged", "weapon"]},
    {"name": "Crossbow", "category": "ranged weapons", "silver": [30, 40], "tags": ["crossbow", "ranged", "weapon"]},
    {"name": "Pistol", "category": "ranged weapons", "silver": [100, None], "tags": ["pistol", "firearm", "weapon"]},
    {"name": "Musket", "category": "ranged weapons", "silver": [120, None], "tags": ["musket", "firearm", "weapon"]},
    {"name": "Leather Jerkin", "category": "armor", "silver": [10, 15], "tags": ["leather", "jerkin", "armor"]},
    {"name": "Buff Coat", "category": "armor", "silver": [15, 25], "tags": ["buff coat", "coat", "armor"]},
    {"name": "Brigandine", "category": "armor", "silver": [20, 30], "tags": ["brigandine", "armor"]},
    {"name": "Breastplate", "category": "armor", "silver": [35, 45], "tags": ["breastplate", "armor"]},
    {"name": "Plate or Enchanted Armor", "category": "armor", "silver": [100, None], "tags": ["plate", "enchanted armor", "armor"]},
    {"name": "Rope", "category": "miscellaneous", "silver": [5, 5], "tags": ["rope", "climbing"]},
    {"name": "Lantern and Oil", "category": "miscellaneous", "silver": [8, 12], "tags": ["lantern", "lamp", "oil", "light"]},
    {"name": "Healing Potion", "category": "miscellaneous", "silver": [10, 10], "tags": ["healing potion", "potion", "medicine"]},
    {"name": "Rare Alchemical Ingredient", "category": "rare", "silver": [50, 100], "tags": ["alchemy", "alchemical", "ingredient", "rare"]},
    {"name": "Rare Magical Artifact", "category": "rare", "silver": [500, None], "tags": ["magic", "magical", "artifact", "rare"]},
    {"name": "Small Fishing Boat", "category": "assets", "silver": [100, 150], "tags": ["fishing boat", "small boat", "vessel"]},
    {"name": "Merchant's Sloop", "category": "assets", "silver": [500, 750], "tags": ["sloop", "merchant ship", "vessel"]},
    {"name": "Comfortable House", "category": "property", "silver": [1000, None], "tags": ["house", "home", "property"]},
    {"name": "Armed Brigantine", "category": "assets", "silver": [1500, 2500], "tags": ["brigantine", "privateer", "warship", "vessel"]},
    {"name": "Luxurious Villa or Estate", "category": "property", "silver": [5000, None], "tags": ["villa", "estate", "property"]},
]


VALUATION = re.compile(
    r"\b(?:how\s+much|what(?:'s|\s+is)\s+the\s+(?:price|value|cost)|worth|"
    r"apprais(?:e|al)|valuat(?:e|ion)|asking\s+price|market\s+value|buying\s+price|"
    r"quote\s+(?:a\s+)?price|price\s+of|cost\s+of|how\s+expensive)\b",
    re.IGNORECASE,
)
COMMERCE = re.compile(
    r"\b(?:buy|purchase|sell|shop|market|merchant|vendor|stall|wares|goods|"
    r"for\s+sale|haggle|bargain|discount|pay|price|cost|worth|apprais|quote)\w*\b",
    re.IGNORECASE,
)


def is_valuation_intent(text: str) -> bool:
    return bool(VALUATION.search(text))


def is_commerce_intent(text: str) -> bool:
    return bool(COMMERCE.search(text))


def price_bounds_for_item(item_name: str, item_kind: str = "misc") -> tuple[int, int]:
    """Return a compact quote boundary, not a fixed universal price."""

    scored = sorted(
        ((_score(record, item_name, ""), record) for record in PRICE_ANCHORS),
        key=lambda pair: (-pair[0], pair[1]["name"]),
    )
    if scored and scored[0][0] > 0:
        low, high = scored[0][1]["silver"]
        low_value = max(1, int(low))
        return low_value, int(high) if high is not None else max(low_value * 3, low_value + 50)
    defaults = {
        "food": (1, 8),
        "drink": (1, 8),
        "tool": (3, 25),
        "key": (3, 30),
        "document": (1, 30),
        "weapon": (5, 50),
        "armor": (10, 60),
        "consumable": (3, 30),
        "valuable": (10, 150),
        "service": (3, 20),
        "misc": (1, 30),
    }
    return defaults.get(str(item_kind), defaults["misc"])


def service_kind_for_item(item_name: str, *, item_kind: str | None = None) -> str | None:
    folded = " ".join(str(item_name or "").casefold().split())
    if re.search(r"\b(?:inn\s+stay|lodging|room\s+for\s+the\s+night|night'?s\s+room)\b", folded):
        return "lodging"
    if str(item_kind or "").casefold() == "service" and re.search(
        r"\b(?:room|bed|bunk|dorm(?:itory)?)\b", folded
    ):
        return "lodging"
    if re.search(r"\b(?:physician|doctor|healer|medical\s+treatment|physician'?s\s+treatment)\b", folded):
        return "treatment"
    return None


def _score(record: dict[str, Any], text: str, recent: str) -> int:
    folded = text.casefold()
    recent_folded = recent.casefold()
    name = str(record["name"]).casefold()
    score = 30 if name in folded else 0
    for tag in record.get("tags", []):
        needle = str(tag).casefold()
        if re.search(rf"\b{re.escape(needle)}\b", folded):
            score += 8 if " " in needle else 4
        elif re.search(r"\b(?:this|that|it|these|those)\b", folded) and needle in recent_folded:
            score += 2
    return score


def price_reference_context(
    *,
    player_text: str,
    recent_turns: list[dict[str, Any]],
    resolved_event: dict[str, Any] | None,
    limit: int = 6,
) -> dict[str, Any] | None:
    passage_quote = bool(resolved_event and resolved_event.get("type") == "passage_quote_required")
    resource_quote = bool(resolved_event and resolved_event.get("type") == "resource_quote_required")
    commerce = is_commerce_intent(player_text)
    if not passage_quote and not resource_quote and not is_valuation_intent(player_text) and not commerce:
        return None
    recent = " ".join(str(row.get("text") or "") for row in recent_turns[-8:] if isinstance(row, dict))
    lookup_text = player_text
    if resource_quote:
        lookup_text += " " + str(resolved_event.get("item") or "")
    if passage_quote:
        selected = [record for record in PRICE_ANCHORS if record["name"] == "Sea Passage"]
    else:
        scored = sorted(
            ((score, record) for record in PRICE_ANCHORS if (score := _score(record, lookup_text, recent)) > 0),
            key=lambda pair: (-pair[0], pair[1]["name"]),
        )
        selected = [record for _, record in scored[:limit]]
        if selected:
            category = selected[0]["category"]
            neighbors = [record for record in PRICE_ANCHORS if record["category"] == category and record not in selected]
            selected.extend(neighbors[: max(0, limit - len(selected))])
        else:
            selected = [
                record for record in PRICE_ANCHORS
                if record["name"] in {"Loaf of Bread", "Rope", "Pistol", "Small Fishing Boat", "Comfortable House"}
            ][:limit]
    return {
        "intent": (
            "passage_quote"
            if passage_quote
            else "seller_or_buyer_quote"
            if resource_quote
            else "commerce_or_appraisal"
        ),
        "canonical_market_anchors": selected[:limit],
        "currency": "silver",
        "quote_boundary": (
            {
                "item": resolved_event.get("item"),
                "direction": resolved_event.get("direction"),
                "minimum": resolved_event.get("minimum_price"),
                "maximum": resolved_event.get("maximum_price"),
            }
            if resource_quote
            else None
        ),
        "policy": (
            "Treat anchors as indicative fair-value scale. Distinguish fair value, a seller's asking price, "
            "and a buyer's offer. Infer unlisted value from material, workmanship, condition, provenance, "
            "rarity, legality and local demand. This packet is information only unless the resolved event "
            "explicitly commits a transaction. Never imply that the player sees the whole catalog."
        ),
    }
