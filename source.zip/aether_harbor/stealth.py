from __future__ import annotations

import re
from typing import Any

from .items import equipment_assist
from .mechanics import ATTACK_VERBS, resolve_d20


STEALTH_ACTION = re.compile(
    r"\b(?:stealth|sneak|hide|creep|move\s+silently|keep\s+to\s+the\s+shadows|"
    r"slip\s+past|approach\s+unseen|stay\s+unseen|shadow\s+(?:him|her|them|the))\b",
    re.IGNORECASE,
)
QUESTION_OR_HYPOTHETICAL = re.compile(
    r"(?:\?|\b(?:would|could|might|what\s+if|ask\s+whether|tell\s+me)\b)",
    re.IGNORECASE,
)


def _fresh(location_id: str) -> dict[str, Any]:
    return {
        "location_id": location_id,
        "concealed": False,
        "edge": None,
        "suspicion": 0,
        "failed_chain": 0,
        "local_alert": "none",
    }


def sync_stealth_location(state: dict[str, Any]) -> dict[str, Any]:
    location_id = str(state.get("current_location_id") or "commercial_docks")
    stealth = state.get("stealth")
    if not isinstance(stealth, dict) or stealth.get("location_id") != location_id:
        stealth = _fresh(location_id)
        state["stealth"] = stealth
    return stealth


def _magical_concealment_bonus(state: dict[str, Any]) -> tuple[int, str | None]:
    location_id = str(state.get("current_location_id") or "")
    effects = state.get("magic", {}).get("active_effects", [])
    for effect in reversed(effects if isinstance(effects, list) else []):
        if not isinstance(effect, dict) or effect.get("location_id") != location_id:
            continue
        families = {str(value) for value in effect.get("effect_families", [])}
        if families.intersection({"concealment", "darkness", "illusion"}):
            return 2, str(effect.get("spell_name") or "magical concealment")
    return 0, None


def resolve_stealth_action(
    state: dict[str, Any], text: str, *, dc: int = 13,
    manual_roll: int | None = None,
) -> dict[str, Any] | None:
    if not STEALTH_ACTION.search(text) or QUESTION_OR_HYPOTHETICAL.search(text):
        return None
    stealth = sync_stealth_location(state)
    item_bonus, item_source = equipment_assist(state, text, "AGI")
    magic_bonus, magic_source = _magical_concealment_bonus(state)
    situational = max(item_bonus, magic_bonus)
    source = item_source if item_bonus >= magic_bonus else magic_source
    roll = resolve_d20(
        state,
        "AGI",
        dc,
        "approach or remain unseen under meaningful risk",
        situational_modifier=situational,
        situational_source=source,
        manual_roll=manual_roll,
    )
    margin = int(roll["total"]) - int(roll["dc"])
    if roll["success"]:
        if roll["raw"] == 20 or margin >= 10:
            quality = "takedown_opportunity"
        elif margin >= 5:
            quality = "automatic_critical"
        else:
            quality = "surprise"
        stealth["concealed"] = True
        stealth["failed_chain"] = 0
        stealth["edge"] = {
            "quality": quality,
            "margin": margin,
            "raw": roll["raw"],
            "total": roll["total"],
            "dc": roll["dc"],
            "created_turn": int(state.get("turn_no", 0) or 0),
        }
    else:
        quality = "detected"
        stealth["concealed"] = False
        stealth["edge"] = None
        stealth["failed_chain"] = int(stealth.get("failed_chain", 0) or 0) + 1
        stealth["suspicion"] = int(stealth.get("suspicion", 0) or 0) + 1
        suspicion = int(stealth["suspicion"])
        chain = int(stealth["failed_chain"])
        if suspicion >= 3 or chain >= 3:
            stealth["local_alert"] = "high"
        elif suspicion >= 2 or chain >= 2:
            stealth["local_alert"] = "elevated"
        else:
            stealth["local_alert"] = "low"
    return {
        "type": "stealth_resolution",
        "committed": True,
        "roll": roll,
        "quality": quality,
        "margin": margin,
        "concealed": bool(stealth["concealed"]),
        "local_alert": stealth["local_alert"],
        "attack_declared": bool(ATTACK_VERBS.search(text)),
    }


def consume_stealth_edge(state: dict[str, Any]) -> dict[str, Any] | None:
    stealth = sync_stealth_location(state)
    edge = stealth.get("edge") if stealth.get("concealed") else None
    stealth["concealed"] = False
    stealth["edge"] = None
    return dict(edge) if isinstance(edge, dict) else None
