"""Immediate semantic reconciliation after narration, on the shared model lock."""
from __future__ import annotations

import copy
import json

from .party import PARTY_ACTION_SCHEMA, commit_party_action, find_companion, party_advice, roster_context
from .risk_classifier import classify_new_companion_profile

PARTY_REVIEW_SYSTEM = """
Read the exact newest player/narrator exchange and report only a party relationship
change established NOW. Return JSON, never narration.
recruit: a specific NPC agrees to come along and act beside the player now as an
active companion or accomplice, including for one job. An employer, patron or
client who gives the player a task or reward and stays behind is not recruited,
even when the player accepts the job. A share of future loot is
a valid agreement with amount 0 now. No payment or inventory transfer is needed.
An NPC accepting the player's proposal in the newest narration is confirmed now.
An NPC merely offering terms without player acceptance is offered. A question,
wish, hypothetical, future meeting, casual help or refusal is not recruitment.
dismiss: an existing companion actually parts ways now. A past join, mention,
injury or ordinary independent action does not join/dismiss anyone.
Use exact established proper name for target, or the grounded descriptor if unnamed;
a separate profiler will name them. Preserve their identity. Use amount only for an
exact agreed immediate silver fee, never invent payment or convert a future share.
Use timing immediate for an established agreement; on_success only for an unresolved
condition. A failed resolved recruitment roll cannot become a confirmed agreement.
If no new agreement is established, action NONE, status NONE, timing none, amount 0.
Existing membership, capacity (one companion) and committed party events are authoritative.
""".strip()


def prepare_party_profile(*, model, state, recent_turns, player_text, advice):
    prepared = copy.deepcopy(advice)
    if (prepared.get("action") == "recruit" and prepared.get("status") == "confirmed"
            and not find_companion(state, prepared.get("target", ""))
            and not state.get("player", {}).get("companions")):
        prepared["profile"] = classify_new_companion_profile(
            model=model, recent_turns=recent_turns, player_text=player_text,
            companion_name=prepared.get("target", ""),
        )
    return prepared


def review_narrated_party(*, model, state, recent_turns, player_text, narration,
                         semantic_roll=None, resolved_event=None):
    """Prepare advice on a snapshot; caller commits it before enabling input.

    Check each completed narration, because an unplanned acceptance/offer can
    first appear there even when the pre-action judge saw no party transaction.
    This is separate from the periodic memory secretary.
    """
    recent = [{"speaker": str(r.get("speaker") or ""), "text": str(r.get("text") or "")[-1000:]}
              for r in recent_turns[-4:] if isinstance(r, dict)]
    payload = model.chat_json([
        {"role": "system", "content": PARTY_REVIEW_SYSTEM},
        {"role": "user", "content": json.dumps({
            "companions": roster_context(state),
            "recent_scene": recent,
            "player_action": player_text,
            "newest_narration": narration,
            "proposed_party_action": party_advice(semantic_roll),
            "resolved_event": resolved_event,
        }, ensure_ascii=False)},
    ], schema=PARTY_ACTION_SCHEMA, temperature=0.0)
    advice = party_advice({"party_action": payload})
    # Enforce the actual failed die even if the semantic reviewer contradicts it.
    event = resolved_event or {}
    roll = event.get("roll", event)
    if (party_advice(semantic_roll)["action"] == "recruit"
            and isinstance(roll, dict) and roll.get("success") is False
            and roll.get("type") == "d20_resolution" and advice["action"] == "recruit"):
        advice.update(status="refused", timing="none")
    return prepare_party_profile(
        model=model, state=state, recent_turns=[*recent, {"speaker": "Aether Harbor", "text": narration}],
        player_text=player_text, advice=advice,
    )


def finish_party_review(*, model, state, recent_turns, player_text, narration,
                        semantic_roll=None, resolved_event=None):
    """Return a serializable checkpoint on errors, with no invented fallback sheet."""
    checkpoint = dict(recent_turns=copy.deepcopy(recent_turns[-4:]), player_text=player_text,
                      narration=narration, semantic_roll=semantic_roll, resolved_event=resolved_event)
    try:
        advice = review_narrated_party(model=model, state=state, **checkpoint)
        return {"advice": advice, "pending": None, "error": None}
    except Exception as exc:
        return {"advice": None, "pending": checkpoint, "error": str(exc)}


def apply_party_review(state, result):
    """UI-thread commit; a failed review survives save/reload for the next turn."""
    if result.get("pending"):
        state["pending_party_review"] = result["pending"]
        return None
    state.pop("pending_party_review", None)
    advice = result.get("advice")
    return commit_party_action(state, advice) if advice else None

