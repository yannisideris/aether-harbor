from __future__ import annotations

import re
from typing import Any

from .items import equipment_assist
from .mechanics import resolve_d20


_CHASE_ACTION = re.compile(
    r"\b(?:chase|chasing|pursue|pursuing|follow|following|catch|catching|overtake|overtaking|"
    r"close\s+(?:the\s+)?distance|sprint|sprinting|run|running|"
    r"cut\s+(?:him|her|them|it|the\s+\w+)\s+off|intercept|shortcut|block\s+(?:the\s+)?way|"
    r"grab|grapple|tackle|trip|lasso|net|call\s+(?:the\s+)?guards?|raise\s+(?:the\s+)?alarm)\b",
    re.I,
)
_ABANDON = re.compile(
    r"\b(?:stop\s+chasing|give\s+up|abandon\s+(?:the\s+)?chase|let\s+(?:him|her|them|it)\s+go|"
    r"break\s+off|leave\s+(?:him|her|them|it)\s+to\s+go)\b",
    re.I,
)
_FLIGHT = re.compile(
    r"(?P<actor>(?:the\s+)?[A-Z][\w'’ -]{1,55}?)\s+"
    r"(?:bolts|runs|flees|sprints|dashes|breaks\s+away|takes\s+off)\b",
)
_STAKE = re.compile(
    r"\b(?:with|carrying|clutching|holding|tucking\s+away)\s+"
    r"(?P<stake>(?:the|a|an)\s+[^,.;!?]{2,70}?)"
    r"(?=\s+(?:toward|towards|into|through|for)\b|[,.;!?]|$)",
    re.I,
)
_TOWARD = re.compile(r"\b(?:toward|towards|into|through|for)\s+(?P<anchor>[^,.;!?]{2,70})", re.I)
_MOVING_SENTENCE = re.compile(
    r"[^.!?]*(?:street|lane|alley|roof|market|quay|dock|bridge|stairs|gate|door|crowd|boat|ferry)[^.!?]*[.!?]?",
    re.I,
)


RANGE_ORDER = ("far", "near", "contact")


def ensure_active_situation_state(state: dict[str, Any]) -> None:
    state.setdefault("active_situation", None)
    state.setdefault("active_situation_history", [])


def start_chase(
    state: dict[str, Any],
    *,
    quarry: str,
    stake: str,
    escape: str,
    anchor: str,
    initial_range: str = "far",
) -> dict[str, Any]:
    ensure_active_situation_state(state)
    if isinstance(state.get("active_situation"), dict) and state["active_situation"].get("status") == "active":
        return state["active_situation"]
    range_value = initial_range if initial_range in RANGE_ORDER else "far"
    chase = {
        "kind": "chase",
        "quarry": " ".join(str(quarry or "the fugitive").split())[:80],
        "stake": " ".join(str(stake or "the carried object").split())[:100],
        "range": range_value,
        "escape": " ".join(str(escape or "a clear route away").split())[:100],
        "anchor": " ".join(str(anchor or "the current street").split())[:120],
        "escape_clock": 0,
        "status": "active",
        "started_turn": int(state.get("turn_no", 0) or 0),
        "beats": 0,
    }
    state["active_situation"] = chase
    return chase


def start_chase_from_semantic(
    state: dict[str, Any], semantic_roll: dict[str, Any] | None
) -> dict[str, Any] | None:
    """Open a chase from the foreground semantic call, never from noun regexes."""

    if not isinstance(semantic_roll, dict):
        return None
    advice = semantic_roll.get("chase")
    if not isinstance(advice, dict) or advice.get("action") != "start":
        return None
    if isinstance(state.get("active_situation"), dict):
        return None
    quarry = " ".join(str(advice.get("quarry") or "").split())[:80]
    if not quarry:
        return None
    return start_chase(
        state,
        quarry=quarry,
        stake=str(advice.get("stake") or "no known carried stake"),
        escape=str(advice.get("escape") or "a route out of sight"),
        anchor=str(advice.get("anchor") or "the current route"),
        initial_range="far",
    )


def _archive(state: dict[str, Any], situation: dict[str, Any]) -> None:
    history = state.setdefault("active_situation_history", [])
    history.append(
        {
            "kind": situation.get("kind"),
            "quarry": situation.get("quarry"),
            "stake": situation.get("stake"),
            "status": situation.get("status"),
            "started_turn": situation.get("started_turn"),
            "ended_turn": situation.get("ended_turn"),
            "beats": situation.get("beats"),
        }
    )
    state["active_situation_history"] = history[-12:]


def end_active_situation(state: dict[str, Any], status: str) -> dict[str, Any] | None:
    situation = state.get("active_situation")
    if not isinstance(situation, dict) or situation.get("status") != "active":
        return None
    situation["status"] = status
    situation["ended_turn"] = int(state.get("turn_no", 0) or 0)
    _archive(state, situation)
    state["active_situation"] = None
    return situation


def capture_chase_from_narration(
    state: dict[str, Any],
    narration: str,
    player_text: str,
    resolved_event: dict[str, Any] | None,
) -> dict[str, Any] | None:
    ensure_active_situation_state(state)
    if isinstance(state.get("active_situation"), dict):
        return None
    # Never manufacture a chase from a failed player action or from a combat
    # already owned by the combat engine.
    if isinstance(resolved_event, dict):
        if resolved_event.get("success") is False or resolved_event.get("outcome") in {"failure", "critical_failure"}:
            return None
        if resolved_event.get("type") in {"combat_resolution", "active_situation_resolution"}:
            return None
    flight = _FLIGHT.search(str(narration or ""))
    stake_match = _STAKE.search(str(narration or ""))
    if not flight or not stake_match:
        return None
    actor = " ".join(flight.group("actor").split())
    stake = " ".join(stake_match.group("stake").split())
    toward = _TOWARD.search(str(narration or "")[flight.start():])
    escape = " ".join(toward.group("anchor").split()) if toward else "a route out of sight"
    anchor_match = _MOVING_SENTENCE.search(str(narration or ""))
    anchor = " ".join(anchor_match.group(0).split()) if anchor_match else escape
    return start_chase(
        state,
        quarry=actor,
        stake=stake,
        escape=escape,
        anchor=anchor,
        initial_range="far",
    )


def risk_context(state: dict[str, Any]) -> dict[str, Any] | None:
    situation = state.get("active_situation")
    if not isinstance(situation, dict) or situation.get("status") != "active":
        return None
    if situation.get('kind') == 'voyage_incident':
        return {**situation, 'instruction':'The recorded voyage hazard blocks arrival. Judge concrete tactics normally; RESOLVE_INCIDENT only for a tactic that settles this hazard, never waiting alone.'}
    return {
        "kind": situation.get("kind"),
        "quarry": situation.get("quarry"),
        "stake": situation.get("stake"),
        "range": situation.get("range"),
        "escape": situation.get("escape"),
        "instruction": (
            "Immediate chase pressure is active. Set the chase field to PURSUE, INTERCEPT, CAPTURE (when grabbing/tackling at contact), "
            "ABANDON, or YIELD (never NONE while this chase is active). If the quarry is the player, PURSUE means an active escape tactic, "
            "including hiding or breaking line of sight; YIELD is only neglecting that pressure. Judge the player's concrete tactic; do not collapse the whole sequence "
            "into one roll unless the stated tactic genuinely makes the outcome decisive."
        ),
    }


def prompt_context(state: dict[str, Any]) -> dict[str, Any] | None:
    situation = state.get("active_situation")
    if not isinstance(situation, dict) or situation.get("status") != "active":
        return None
    if situation.get('kind') == 'voyage_incident':
        return {**situation, 'instruction':'Keep the recorded storm/ambush active until the engine marks it resolved. Present its concrete pressure aboard the existing ship. An attempt without a successful mechanical resolution is not an accomplished ward, rescue or victory. Describe the attempt and unresolved pressure, not an invented successful effect. No new hazard die or uncommitted arrival.'}
    return {
        "instruction": (
            "This short action situation is authoritative. Preserve holder, relative range and escape opportunity. "
            "Narrate one concrete beat from the resolved event; do not catch or lose the quarry unless the event says so, "
            "and do not turn the scene into combat automatically."
        ),
        "kind": situation.get("kind"),
        "quarry": situation.get("quarry"),
        "stake": situation.get("stake"),
        "range": situation.get("range"),
        "escape": situation.get("escape"),
        "anchor": situation.get("anchor"),
    }


def player_is_quarry(state: dict[str, Any], situation: dict[str, Any]) -> bool:
    quarry = str(situation.get("quarry") or "").strip().casefold()
    name = str(state.get("player", {}).get("name") or "").strip().casefold()
    return quarry in {"visitor", "player", "the player", "you"} or bool(name and quarry == name)


def _roll_failed(resolved: str) -> bool:
    return resolved in {"failure", "critical_failure"}


def resolve_active_situation_action(
    state: dict[str, Any],
    text: str,
    *,
    semantic_roll: dict[str, Any] | None,
    manual_roll: int | None,
    resolved_roll: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    situation = state.get("active_situation")
    if not isinstance(situation, dict) or situation.get("status") != "active":
        return None
    if situation.get("kind") != "chase":
        return None
    chase_advice = (
        semantic_roll.get("chase")
        if isinstance(semantic_roll, dict) and isinstance(semantic_roll.get("chase"), dict)
        else None
    )
    semantic_action = str(chase_advice.get("action") or "NONE").lower() if chase_advice else "none"
    fleeing = player_is_quarry(state, situation)
    if semantic_action == "abandon" and fleeing:
        semantic_action = "yield"
    if semantic_action == "abandon" or (not fleeing and chase_advice is None and _ABANDON.search(text)):
        before = dict(situation)
        ended = end_active_situation(state, "abandoned")
        return {
            "type": "active_situation_resolution",
            "kind": "chase",
            "action": "abandon",
            "status": "abandoned",
            "before": before,
            "after": ended,
            "roll": None,
        }
    if semantic_action == "yield" and fleeing:
        # Yield is time spent on another action, not a free escape for a fugitive.
        before = dict(situation)
        before_range = str(situation.get("range") or "far")
        index = RANGE_ORDER.index(before_range) if before_range in RANGE_ORDER else 0
        situation["range"] = RANGE_ORDER[min(2, index + 1)]
        situation["escape_clock"] = max(0, int(situation.get("escape_clock", 0) or 0) - 1)
        situation["beats"] = int(situation.get("beats", 0) or 0) + 1
        status = "caught" if before_range == "contact" else "active"
        after = dict(situation)
        if status == "caught":
            after = dict(end_active_situation(state, status) or after)
        return {"type": "active_situation_resolution", "kind": "chase",
                "action": "caught" if status == "caught" else "lost_ground",
                "status": status, "before": before, "after": after,
                "before_range": before_range, "after_range": after["range"],
                "escape_clock_before": before.get("escape_clock", 0),
                "escape_clock_after": after["escape_clock"],
                "quarry": situation.get("quarry"), "stake": situation.get("stake"), "roll": None}
    if semantic_action == "yield":
        before = dict(situation)
        clock = int(situation.get("escape_clock", 0) or 0) + 1
        situation["escape_clock"] = clock
        situation["beats"] = int(situation.get("beats", 0) or 0) + 1
        status = "escaped" if clock >= 3 else "active"
        after = dict(situation)
        if status == "escaped":
            after = dict(end_active_situation(state, status) or after)
        return {
            "type": "active_situation_resolution",
            "kind": "chase",
            "action": "yielded_ground" if status == "active" else "escaped",
            "status": status,
            "before": before,
            "after": after,
            "before_range": before.get("range"),
            "after_range": after.get("range"),
            "escape_clock_before": clock - 1,
            "escape_clock_after": clock,
            "quarry": situation.get("quarry"),
            "stake": situation.get("stake"),
            "roll": None,
        }
    semantic_chase_action = semantic_action in {"start", "pursue", "intercept", "capture"}
    if chase_advice is not None and not semantic_chase_action:
        return None
    if chase_advice is None and not _CHASE_ACTION.search(text):
        return None

    before_range = str(situation.get("range") or "far")
    before_clock = int(situation.get("escape_clock", 0) or 0)
    requires_roll = isinstance(semantic_roll, dict) and semantic_roll.get("requires_roll") is True
    if not requires_roll:
        situation["beats"] = int(situation.get("beats", 0) or 0) + 1
        if fleeing:
            # A judged uncontested escape tactic still advances the chase.
            index = RANGE_ORDER.index(before_range) if before_range in RANGE_ORDER else 0
            situation["range"] = RANGE_ORDER[max(0, index - 1)]
            situation["escape_clock"] = before_clock + 1
            status = "escaped" if before_clock + 1 >= 3 else "active"
            after = dict(situation)
            if status == "escaped":
                after = dict(end_active_situation(state, status) or after)
            return {"type": "active_situation_resolution", "kind": "chase",
                    "action": "escaped" if status == "escaped" else "opened_distance",
                    "status": status, "before_range": before_range,
                    "after_range": after["range"], "escape_clock_before": before_clock,
                    "escape_clock_after": after["escape_clock"], "roll": None,
                    "quarry": situation.get("quarry"), "stake": situation.get("stake")}
        return {
            "type": "active_situation_resolution",
            "kind": "chase",
            "action": "continue",
            "status": "active",
            "before_range": before_range,
            "after_range": before_range,
            "escape_clock": before_clock,
            "roll": None,
            "quarry": situation.get("quarry"),
            "stake": situation.get("stake"),
        }

    stat = str(semantic_roll.get("stat") or "AGI")
    dc = int(semantic_roll.get("dc") or 13)
    reason = str(semantic_roll.get("reason") or "change the position in the active chase")
    assist, source = equipment_assist(state, text, stat)
    roll = resolved_roll if resolved_roll is not None else resolve_d20(
        state,
        stat,
        dc,
        reason,
        situational_modifier=assist,
        situational_source=source,
        manual_roll=manual_roll,
    )
    outcome = str(roll.get("outcome") or "")
    index = RANGE_ORDER.index(before_range) if before_range in RANGE_ORDER else 0
    clock = before_clock
    status = "active"
    action = "position_changed"

    if fleeing:
        if not _roll_failed(outcome):
            gain = 2 if outcome in {"strong_success", "critical_success"} else 1
            index = max(0, index - gain)
            clock += 1
            action = "opened_distance"
            if clock >= 3:
                status = action = "escaped"
        else:
            loss = 2 if outcome == "critical_failure" else 1
            index = min(len(RANGE_ORDER) - 1, index + loss)
            clock = max(0, clock - 1)
            action = "lost_ground"
            if before_range == "contact":
                status = action = "caught"
    elif not _roll_failed(outcome):
        gain = 2 if outcome in {"strong_success", "critical_success"} else 1
        capture_attempt = semantic_action == "capture" or chase_advice is None
        if before_range == "contact" and capture_attempt:
            status = "caught"
            action = "caught"
        else:
            index = min(len(RANGE_ORDER) - 1, index + gain)
            action = "contact" if RANGE_ORDER[index] == "contact" else "closed_distance"
            clock = max(0, clock - 1)
    else:
        loss = 2 if outcome == "critical_failure" else 1
        index = max(0, index - 1)
        clock += loss
        action = "lost_ground"
        if clock >= 3:
            status = "escaped"
            action = "escaped"

    situation["range"] = RANGE_ORDER[index]
    situation["escape_clock"] = clock
    situation["beats"] = int(situation.get("beats", 0) or 0) + 1
    after_snapshot = dict(situation)
    if status != "active":
        ended = end_active_situation(state, status)
        after_snapshot = dict(ended or after_snapshot)
    return {
        "type": "active_situation_resolution",
        "kind": "chase",
        "action": action,
        "status": status,
        "quarry": situation.get("quarry"),
        "stake": situation.get("stake"),
        "before_range": before_range,
        "after_range": after_snapshot.get("range"),
        "escape_clock_before": before_clock,
        "escape_clock_after": after_snapshot.get("escape_clock"),
        "roll": roll,
    }


def note_active_situation_narration(
    state: dict[str, Any],
    narration: str,
    resolved_event: dict[str, Any] | None,
) -> None:
    situation = state.get("active_situation")
    if not isinstance(situation, dict) or situation.get("status") != "active":
        return
    if not isinstance(resolved_event, dict) or resolved_event.get("type") != "active_situation_resolution":
        return
    match = _MOVING_SENTENCE.search(str(narration or ""))
    if match:
        anchor = " ".join(match.group(0).split())[:120]
        if anchor:
            situation["anchor"] = anchor
