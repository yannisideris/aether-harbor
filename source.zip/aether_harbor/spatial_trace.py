"""Private diagnostic evidence for the synchronous live-test runner.

Uses the GUI's spatial entry points. It is not a replacement for GUI scheduling.
All model calls still use the supplied LocalQwen client and its inference lock.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import uuid

from . import spatial_adjudication as spatial
from .spatial_secretary import reserve_selected_exterior_site


class RecordingModel:
    def __init__(self, model, calls):
        self.model, self.calls = model, calls

    def __getattr__(self, name):
        return getattr(self.model, name)

    def chat_json(self, messages, **kwargs):
        call = {"messages": copy.deepcopy(messages), "options": copy.deepcopy(kwargs)}
        self.calls.append(call)
        try:
            result = self.model.chat_json(messages, **kwargs)
            # The planner mutates drafts; retain the actual returned JSON.
            call["response"] = copy.deepcopy(result)
            return result
        except Exception as exc:
            call["error"] = f"{type(exc).__name__}: {exc}"
            raise


def run_spatial_step(*, model, state, recent_turns, player_text, narration,
                     resolved_event, trace_dir):
    directory = Path(trace_dir)
    directory.mkdir(parents=True, exist_ok=True)
    trace_path = directory / f"turn_{int(state.get('turn_no', 0)):04d}_{uuid.uuid4().hex}.json"
    trace = {
        "campaign_id": state.get("campaign_id"), "turn_no": state.get("turn_no"),
        "state_before": copy.deepcopy(state), "recent_turns": copy.deepcopy(recent_turns),
        "player_text": player_text, "narration": narration,
        "resolved_event": copy.deepcopy(resolved_event), "calls": [],
        "mode": None, "applied": None, "survey": None,
    }
    try:
        mode = spatial.survey_mode(state=state, player_text=player_text,
                                   narration=narration, resolved_event=resolved_event)
        trace["mode"] = mode
        if mode:
            if mode == "exterior":
                reserve_selected_exterior_site(state, narration)
            anchor = str(state.get("current_location_id") or "")
            position = copy.deepcopy(state.get("scene_position"))
            trace["anchor_location_id"] = anchor
            trace["anchor_scene_position"] = position
            survey = spatial.run(model=RecordingModel(model, trace["calls"]), state=state,
                                 recent_turns=recent_turns, player_text=player_text,
                                 narration=narration, resolved_event=resolved_event,
                                 planning_mode=mode)
            trace["survey"] = copy.deepcopy(survey)
            trace["applied"] = spatial.apply_for_anchor(
                state, survey, anchor_location_id=anchor,
                anchor_scene_position=position, narration=narration)
    except Exception as exc:
        trace["error"] = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        trace["state_after"] = copy.deepcopy(state)
        trace_path.write_text(json.dumps(trace, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"mode": trace["mode"], "applied": trace["applied"],
            "survey": trace["survey"], "trace_path": str(trace_path)}
