from __future__ import annotations

import json
from typing import Any

from .items import _leave_scene_object, _remove_inventory_quantity
from .stealth import sync_stealth_location


GROUNDING_AUDITOR_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "lost_silver": {
            "type": "integer",
            "minimum": 0,
            "maximum": 500,
            "description": "TOTAL silver physically paid/lost this turn, INCLUDING engine deductions, not an additional delta. Omit if no extra loss.",
        },
        "gained_silver": {
            "type": "integer",
            "minimum": 0,
            "maximum": 500,
            "description": "TOTAL silver physically received this turn, INCLUDING engine credits, not an additional delta. Omit if no extra gain.",
        },
        "lost_items": {
            "type": "array",
            "maxItems": 4,
            "items": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "maxLength": 100,
                        "description": "Exact inventory/receipt name. Never a paraphrase such as shattered lantern.",
                    },
                    "quantity": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 20,
                        "description": "Total units removed this turn, including engine removals.",
                    },
                    "disposition": {
                        "type": "string",
                        "enum": ["dropped", "destroyed", "lost"],
                        "description": "dropped only for a recoverable object left at the current position; lost for irretrievable loss.",
                    },
                },
                "required": ["name", "quantity", "disposition"],
                "additionalProperties": False,
            },
        },
        "scene_pressure": {
            "type": "string",
            "maxLength": 100,
            "description": "Concrete ongoing search, alarm, or immediate physical hazard started here, or 'NONE'.",
        },
        "local_alert": {
            "type": "string",
            "enum": ["NONE", "low", "elevated", "high"],
        },
        "new_named_actor": {
            "type": "string",
            "maxLength": 60,
            "description": "Proper personal name of a newly introduced NPC who acts or speaks here, or 'NONE'. Never a generic role like 'dock clerk'.",
        },
    },
    "required": [
        "lost_silver",
        "gained_silver",
        "lost_items",
        "scene_pressure",
        "local_alert",
        "new_named_actor",
    ],
    "additionalProperties": False,
}

GROUNDING_AUDITOR_SYSTEM = """You are the Grounding Auditor for Aether Harbor.
Reconcile explicit physical aftermath in this turn's GM narration with the
authoritative mechanical receipts and CURRENT post-resolution state supplied.
Use 0, [], and "NONE" for any field where no new physical fact was established. No mood meter.
Never overturn a failed/refused transfer, a roll outcome, party ownership, HP,
movement or established geometry. Player intentions and dialogue claims are not
completed facts. Do not interpret fear, atmosphere, omens or adjectives as alarms.
Money fields are TOTALS for this turn, INCLUDING all already committed receipts.
Example: engine paid 2 and narration loses 3 more -> lost_silver=5. Engine received
5 with nothing extra -> gained_silver=5. When narration first counts newly acquired
pouch money, include its exact amount once in this turn's total. Counting money
left in place or recounting money already owned adds nothing. Do not guess an
unspecified amount. Python subtracts receipts once. Separate unexpected loss is
allowed after a failed action.
Items: use exact supplied inventory names and explicit quantities (one singular
object means one). Include engine removals in the quantity. No substring matching.
Use dropped only for a recoverable object left in this CURRENT location, destroyed
for destruction, lost for irretrievable loss. Do not erase reparably damaged gear.
Pressure: only a concrete ongoing search, alarm or physical hazard here; "NONE"
means no new information, never proof that a prior alarm has ended. Do not replace
an authoritative pressure resolution. Alert is an explicit local escalation only.
new_named_actor: only a newly named person with a proper personal name who is
physically present and acts or speaks in this narration (never a generic role like
"dock clerk" or "guard", and not someone merely mentioned or already known); else "NONE".
Return valid JSON matching the schema only."""


def mechanical_receipts(event: dict[str, Any] | None) -> dict[str, Any]:
    """Project actual committed deltas, without counting compound totals twice."""
    result: dict[str, Any] = {
        "lost_silver": 0,
        "gained_silver": 0,
        "removed_items": {},
        "table_money_settled": False,
    }
    seen: set[int] = set()

    def visit(node: Any) -> None:
        if not isinstance(node, dict) or id(node) in seen:
            return
        seen.add(id(node))
        if node.get("type") in {"local_game_start", "local_game_round", "local_game_rules",
                                "local_game_declined", "local_game_forfeit"}:
            result["table_money_settled"] = True
            if node.get("committed") is True:
                result["lost_silver"] += max(0, int(node.get("stake_paid_this_turn", 0) or 0))
        if node.get("committed") is False or node.get("success") is False:
            if node.get("type") == "passage_purchase" or (
                node.get("type") == "resource_transfer" and node.get("kind") in {"pay", "purchase"}
            ):
                # The engine refused this payment; prose claiming coins changed
                # hands must not be charged afterwards.
                result["table_money_settled"] = True
            return
        parts = node.get("parts")
        if isinstance(parts, list):
            for part in parts:
                visit(part)
            return
        committed = node.get("committed") is True or node.get("success") is True
        if committed:
            if node.get("type") == "celestial_spheres_resolution":
                result["table_money_settled"] = True
                net = node.get("net")
                if type(net) is int:
                    result["lost_silver"] += max(0, -net)
                    result["gained_silver"] += max(0, net)
                else:
                    stake = int(node.get("stake", 0) or 0)
                    result["lost_silver"] += max(0, stake)
                return
            delta = node.get("silver_delta")
            if type(delta) is not int and all(type(node.get(k)) is int for k in ("silver_before", "silver_after")):
                delta = node["silver_after"] - node["silver_before"]
            if type(delta) is not int:
                delta = 0
            result["lost_silver"] += max(0, -delta)
            result["gained_silver"] += max(0, delta)
            if node.get("inventory_change") == "removed" and node.get("item"):
                key = str(node["item"]).strip().casefold()
                result["removed_items"][key] = result["removed_items"].get(key, 0) + int(node.get("quantity", 1) or 1)
        elif node.get("committed") is None and node.get("success") is None:
            if node.get("kind") in {"pay", "purchase"}:
                amt = int(node.get("amount", 0) or node.get("cost_silver", 0) or 0)
                result["lost_silver"] += max(0, amt)
            elif node.get("kind") == "receive_money":
                amt = int(node.get("amount", 0) or 0)
                result["gained_silver"] += max(0, amt)
            elif node.get("cost_silver") is not None:
                result["lost_silver"] += max(0, int(node.get("cost_silver", 0) or 0))
        for key in ("resource", "movement", "party", "roll", "voyage"):
            visit(node.get(key))

    visit(event)
    return result


def extract_pre_deducted_silver(resolved_event: dict[str, Any] | None) -> int:
    return mechanical_receipts(resolved_event)["lost_silver"]


def audit_context(state: dict[str, Any], resolved_event: dict[str, Any] | None) -> dict[str, Any]:
    player = state.get("player", {})
    event = resolved_event or {}
    roll = event.get("roll") if isinstance(event.get("roll"), dict) else event
    return {
        "receipts": mechanical_receipts(event),
        "resolution": {k: event[k] for k in ("type", "committed", "success", "reason", "kind", "item", "amount") if k in event},
        "roll": {k: roll[k] for k in ("outcome", "success") if k in roll},
        "foreground_pressure": event.get("foreground_pressure"),
        "inventory": [
            {"name": i.get("name"), "quantity": i.get("quantity", 1)}
            for i in player.get("inventory", [])
            if isinstance(i, dict)
        ][:24],
        "silver": player.get("silver", 0),
        "location_id": state.get("current_location_id"),
        "scene_pressure": state.get("scene_pressure"),
        "local_alert": (state.get("stealth") or {}).get("local_alert", "none"),
        "known_actors": [
            str(card.get("name") or card.get("anchor") or "")
            for card in state.get("npcs", {}).values()
            if isinstance(card, dict)
        ][:24],
    }


def run_grounding_auditor(
    model: Any,
    *,
    player_text: str,
    narration: str,
    pre_deducted_silver: int = 0,
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not narration or not narration.strip():
        return {}
    context = context or {"receipts": {"lost_silver": pre_deducted_silver, "gained_silver": 0, "removed_items": {}}}
    messages = [
        {"role": "system", "content": GROUNDING_AUDITOR_SYSTEM},
        {
            "role": "user",
            "content": (
                "AUTHORITATIVE POST-RESOLUTION CONTEXT: "
                + json.dumps(context, ensure_ascii=False)
                + f"\n\nPLAYER ACTION: {player_text.strip()}\n\nGM NARRATION: {narration.strip()}"
            ),
        },
    ]
    try:
        raw = model.chat_json(messages, schema=GROUNDING_AUDITOR_SCHEMA, temperature=0.0)
        return raw if isinstance(raw, dict) else {"error": "Non-object audit"}
    except Exception as exc:
        return {"error": str(exc)}


def apply_grounding_audit(
    state: dict[str, Any],
    audit: dict[str, Any],
    *,
    job: dict[str, Any],
) -> dict[str, Any] | None:
    """Apply one validated, current audit; replay cannot charge or delete twice."""
    if not isinstance(state, dict) or not isinstance(audit, dict):
        return None
    campaign = str(state.get("campaign_id") or "")
    current_turn = int(state.get("turn_no", 0) or 0)
    if campaign != str(job.get("campaign_id") or "") or current_turn != int(job.get("turn_no", -1)):
        return None
    audit_id = str(job.get("audit_id") or f"{campaign}:{current_turn}")
    history = state.setdefault("grounding_audit_history", [])
    if any(entry.get("audit_id") == audit_id for entry in history if isinstance(entry, dict)):
        return None
    changes: dict[str, Any] = {}
    ignored: list[str] = []

    def finish(error: str = "") -> dict[str, Any] | None:
        entry = {
            "audit_id": audit_id,
            "turn_no": current_turn,
            "status": "error" if error else "applied" if changes else "no_change",
            "changes": changes,
            "raw_audit": audit,
            "ignored": ignored,
        }
        if error:
            entry["error"] = error
        state["last_grounding_audit"] = entry
        history.append(entry)
        del history[:-32]
        return changes or None

    if audit.get("error"):
        return finish(str(audit["error"]))
    # Validate the complete response before any physical mutation.
    for key in ("lost_silver", "gained_silver"):
        if type(audit.get(key, 0)) is not int or not 0 <= audit.get(key, 0) <= 500:
            return finish("Invalid money amount: " + key)
    losses = audit.get("lost_items", [])
    if not isinstance(losses, list) or len(losses) > 4:
        return finish("Invalid lost_items")
    normalized = []
    for value in losses:
        # Legacy saved/test payloads may name a single lost item as a string.
        value = {"name": value, "quantity": 1, "disposition": "lost"} if isinstance(value, str) else value
        if (
            not isinstance(value, dict)
            or not isinstance(value.get("name"), str)
            or not value["name"].strip()
            or len(value["name"]) > 100
            or type(value.get("quantity")) is not int
            or not 1 <= value["quantity"] <= 20
            or value.get("disposition") not in {"dropped", "destroyed", "lost"}
        ):
            return finish("Invalid item loss")
        normalized.append(value)
    for key, maximum in (("scene_pressure", 100), ("new_named_actor", 60)):
        if not isinstance(audit.get(key, ""), str) or len(audit.get(key, "")) > maximum:
            return finish("Invalid " + key)
    if audit.get("local_alert", "NONE") not in {"NONE", "low", "elevated", "high"}:
        return finish("Invalid local_alert")

    receipts = job.get("receipts") or {"lost_silver": job.get("pre_deducted_silver", 0), "gained_silver": 0, "removed_items": {}}
    player = state["player"]
    if receipts.get("table_money_settled"):
        if audit.get("lost_silver", 0) or audit.get("gained_silver", 0):
            ignored.append("Preserved authoritative gambling silver settlement")
    else:
        for key, direction in (("lost_silver", -1), ("gained_silver", 1)):
            delta = max(0, audit.get(key, 0) - int(receipts.get(key, 0) or 0))
            if direction < 0:
                delta = min(delta, int(player.get("silver", 0) or 0))
            if delta:
                player["silver"] = int(player.get("silver", 0) or 0) + direction * delta
                changes[key] = delta

    seen_names: set[str] = set()
    for loss in normalized:
        key = loss["name"].strip().casefold()
        if key in seen_names:
            continue
        seen_names.add(key)
        matches = [
            i
            for i in player.get("inventory", [])
            if isinstance(i, dict) and str(i.get("name") or "").strip().casefold() == key
        ]
        quantity = max(0, loss["quantity"] - int((receipts.get("removed_items") or {}).get(key, 0)))
        if not quantity:
            continue
        if len(matches) != 1 or quantity > int(matches[0].get("quantity", 1) or 1):
            ignored.append("Unmatched, ambiguous or excessive item loss: " + loss["name"])
            continue
        removed, count = _remove_inventory_quantity(state, matches[0]["name"], quantity)
        if removed and count:
            if loss["disposition"] == "dropped":
                _leave_scene_object(state, removed)
            changes.setdefault("lost_items", []).append(
                {
                    "name": removed["name"],
                    "quantity": count,
                    "disposition": loss["disposition"],
                }
            )

    pressure = str(audit.get("scene_pressure") or "NONE").strip()
    existing = state.get("scene_pressure") or {}
    if pressure and pressure.upper() != "NONE":
        if existing.get("resolved_at_turn") == current_turn and existing.get("result"):
            ignored.append("Preserved authoritative pressure resolution")
        else:
            state["scene_pressure"] = {"description": pressure, "resolved_at_turn": current_turn}
            pressure_history = state.setdefault("scene_pressure_history", [])
            pressure_history.append(dict(state["scene_pressure"]))
            del pressure_history[:-8]
            changes["scene_pressure"] = pressure
    alert = audit.get("local_alert", "NONE")
    ranks = {"none": 0, "low": 1, "elevated": 2, "high": 3}
    if alert in ranks:
        stealth = sync_stealth_location(state)
        if ranks[alert] > ranks.get(stealth.get("local_alert", "none"), 0):
            stealth["local_alert"] = alert
            changes["local_alert"] = alert
    actor = str(audit.get("new_named_actor") or "NONE").strip()
    if (
        actor
        and actor.upper() != "NONE"
        and any(ch.isupper() for ch in actor)
    ):
        provisional = state.setdefault("provisional_npc_anchors", [])
        if actor.casefold() not in {str(v).casefold() for v in provisional}:
            provisional.append(actor)
            del provisional[:-24]
            changes["new_named_actor"] = actor
    return finish()
