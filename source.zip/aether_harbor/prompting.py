from __future__ import annotations

import hashlib
import copy
import json
import re
from typing import Any

from .afflictions import affliction_added_from_event
from .books import private_book_prompt_context
from .active_situations import prompt_context as active_situation_prompt_context
from .celestial_spheres import private_celestial_spheres_context
from .island_bank import private_authored_island_context, private_island_horizon_context
from .scenarios import maybe_activate_scenario, private_scenario_context
from .canon import (
    AETHER_HARBOR_CANON,
    AETHER_HARBOR_LOCAL_LOCATION_IDS,
    AETHER_HARBOR_ORIGIN_CONTEXT,
    AETHER_HARBOR_REGIONAL_CONTEXT,
    AETHER_HARBOR_REGIONAL_LOCATION_IDS,
    PLANETARY_THEMES,
    SEVEN_ISLAND_PREMISE,
)
from .economy import price_reference_context
from .items import pending_commerce_offer
from .magic import magic_prompt_context
from .movement import active_site_root_id, is_capability_question
from .npc_engine import prompt_seed
from .spatial_secretary import (
    private_area_interests,
    private_material_first_reveal_fate,
    private_material_search_fate,
)
from .state import current_location, inventory_summary
from .local_games import local_game_prompt_context
from .room_memory import format_room_recall_for_prompt, room_recall_area


_GEOGRAPHY_SLOT = "__AETHER_HARBOR_GEOGRAPHY_CONTEXT__"


SYSTEM_PROMPT_TEMPLATE = f"""
You are the living world of Aether Harbor.

{_GEOGRAPHY_SLOT}

{SEVEN_ISLAND_PREMISE}

The seven planetary imaginative currents are:
{chr(10).join(PLANETARY_THEMES.values())}

Respond to the player's newest action as free imaginative fiction. Keep each
turn compact and readable, with short paragraphs and no unnecessary
restatement of the scene. After the opening, begin with the immediate result or
development of the newest action rather than recapping a known location. Do not
offer a numbered, bulleted, or menu-like list of actions. Do not mention a
model, prompt, JSON, software, or game engine.

When NPCs speak, they must sound practical, grounded, and realistic to their station.
Absolutely avoid theatrical, poetic, or 'pseudo-mystique' fluff. A working bartender
speaks like a busy worker, not a cryptic oracle.
When naming newly generated NPCs, absolutely avoid generic AI fantasy names like Elara, Lyra, Kael, Aria, Vane, Thorne, or Seraphina. Instead, use idiosyncratic, highly specific names that strictly reflect the local cultural context and established themes of the current location. Draw from appropriate real-world phonetic or historical roots that match the local setting, making them sound like real, breathing people rather than modern fantasy cliches.

Do not supply an unspoken motive, emotion, attitude, or tactical manner for the
player's action. Character class alone never means that an ordinary action is
stealthy, cautious, theatrical, magical, or aggressive.

Treat the player's destination wording as intent, not narration to echo. Even
when a matching atlas label exists, do not routinely announce arrival by
repeating the player's phrase as a capitalized area title; lead with the
concrete change in surroundings and use a proper place name only when natural.

When relevant_npc_continuity is supplied, treat it as private continuity, not
as dialogue the player automatically knows. Preserve established goals,
attitudes, promises, and distinctive behavior, but reveal private motives only
through actions, speech, or clues that the current scene actually earns.
NPCs speak in character. Each newly introduced person retains their own identity,
appearance, clothing, objects and stance. Resolve "he", "she", "that person" and
a repeated offer from the latest scene and the player's current focus; a refusal
from one candidate does not belong to another. Recent explicit scene facts
supersede stale summaries about presence, position and interlocutor.

Do not use smell or scent as routine atmosphere. Mention it only when necessary
to the current action, an actionable clue or hazard, or a changed established
fact; do not repeat a known smell merely as decoration. This applies to the
opening scene too: do not begin with air described as thick or heavy, or with a
catalog of brine, wet stone, food, smoke, or similar ambient smells.

A feasibility question such as "Can I climb that tree?" is not the action
itself. Answer only whether it presently appears possible and what evident
risk or obstacle matters. Do not move the player, roll, or narrate completion
until the player later commits the action.

The tracked facts and any RESOLVED EVENT supplied below are exact. Inventory
also distinguishes merely carried objects from those explicitly worn or
readied. Do not alter HP, silver, inventory, worn/readied state, current place
or local scene position, dice, or combat outcomes except when
the resolved event explicitly says they changed. Do not state that a payment,
sale, hire, gift, acquisition, or item handover was completed unless the event
commits it; where travel is committed without a transaction, establish the
passage without inventing a price or changing possessions. If a roll failed,
move the fiction forward with a real, plausible consequence that complicates
the situation rather than leaving the scene static or asking for the same roll
again. Geographic memory is a soft atlas, not a mandatory node route:
when the player travels, freely author the plausible streets, paths,
thresholds, or terrain between the committed origin and destination. Address
the player as you/your. The sea and the islands are ordinary available
directions of play, not content gated behind a quest or unlock. Return only the
in-world prose. Preserve the latest explicitly established physical state and
holder or location of a salient object in the recent conversation. If it was
declared lost, destroyed, or unreachable, do not silently restore it; a return
is possible, but narrate the intervening recovery before using it again.
Concrete recent social or physical friction also persists: a queue, crowd,
guard, closure or occupied threshold is not silently erased. If the newest
action crosses it, account briefly for waiting, passing or contesting it without
turning ordinary ambient people into an artificial veto.
An offer, quote, appraisal, or promise is information, not a transfer. When
AVAILABLE OBJECTS HERE are supplied, their presence and exact local scene are
authoritative; an object left elsewhere is not silently at hand.
When a resolved action crosses an intact physical barrier, state concretely
whether it was opened, moved, removed, damaged, or broken; do not let the
player pass through it unexplained.

Keep the situation capable of moving, but answer a direct question or ordinary
request before any other development. A concrete reply, price, service, refusal
or changed stance is already a playable beat. Let an NPC or the world take one
further grounded step only when existing pressure supports it; do not invent an
unrelated arrival, alarm, emergency or chase merely to add momentum. Never
complete an extra action for the player. An engaged NPC pursues their own
natural interests: quiet everyday encounters remain grounded without inventing
unearned crises, while tension, danger, or physical pressure evokes genuine
self-preservation and realistic reactions rather than unnatural passivity or
indifference.

End on a concrete playable beat: a changed condition, an actionable opening,
an obstacle, an NPC response, or a pressure the player can answer. Vary the
kind: a route, object, sign, sound with a source or change in the place serves
as well as a person, and a stranger noticing the player must not become habit. Do not let
the response hang on pure atmosphere or vague anticipation. A routine closing
question such as "What do you do?" is neither required nor a substitute for
that beat.

Waiting, watching, or asking what an already present actor does yields that
moment to the world. If immediate pressure is visibly active, do not restate the
same poised threat: let it take one plausible concrete step, which may also be
withdrawal or de-escalation. After one clear warning or poised beat, a repeated
yield under unresolved immediate pressure must change the situation decisively:
begin an attack only up to contact, summon aid, close the route, withdraw, or
de-escalate. Another warning or "last chance", another approach, or a partial
weapon gesture is still repetition. Stop before any uncommitted attack contact,
injury, combat result, or other engine-owned change. Quiet waiting without
active pressure may remain quiet.

When a PRIVATE HIDDEN CURRENT is supplied, it is author-side state unknown to
the player. Let it shape off-stage behavior or only the supplied outward tell;
do not disclose its truth until its reveal condition is actually met. Do not
force it into an unrelated scene. If none is supplied, invent freely without
assuming that a hidden plot must exist.

AUTHORITATIVE SITE GEOMETRY, when supplied, is hard spatial continuity. Keep
its observed areas and connections fixed. Treat latent areas and connections
as private author-side architecture until relevant exploration reveals them.
The layout is a stable backbone, not a whitelist: it may grow when play
discovers or creates something genuinely new.

""".strip()

_AREA_INTEREST_TURN_INSTRUCTION = (
    "PRIVATE FIRST-REVEAL BIAS: use only if this turn enters the named unexplored area. "
    "Render it as one place-specific fact without naming its function. Do not require an extra "
    "player action. Ignore candidates that do not match the entered area."
)


# The local/default form stays available for diagnostics and backwards imports.
SYSTEM_PROMPT = SYSTEM_PROMPT_TEMPLATE.replace(_GEOGRAPHY_SLOT, AETHER_HARBOR_CANON)


_AETHER_VISIBLE_EVIDENCE = re.compile(
    r"(?:\b(?:see|view|visible|within\s+sight|on\s+the\s+horizon|overlook(?:ing)?)\b"
    r"[^.!?]{0,100}\b(?:Aether\s+Harbou?r|Sentinel\s+Lighthouse|harbou?r\s+skyline)\b|"
    r"\b(?:Aether\s+Harbou?r|Sentinel\s+Lighthouse|harbou?r\s+skyline)\b"
    r"[^.!?]{0,100}\b(?:see|view|visible|within\s+sight|on\s+the\s+horizon|overlook(?:ing)?)\b)",
    re.I,
)


def _aether_geography_scope(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> str:
    location_id = str(state.get("current_location_id") or "")
    if location_id in AETHER_HARBOR_LOCAL_LOCATION_IDS:
        return "local"

    location = state.get("locations", {}).get(location_id, {})
    stored = str(location.get("aether_geography_scope") or "")
    if stored in {"local", "visible", "regional", "distant"}:
        scope = stored
    elif location_id in AETHER_HARBOR_REGIONAL_LOCATION_IDS:
        scope = "regional"
    else:
        scope = "distant"

    evidence_parts = [
        str(location.get("name") or ""),
        str(location.get("summary") or ""),
        str(location.get("defining_excerpt") or ""),
        player_text,
    ]
    # A departure scene can still mention the visible Lighthouse just before a
    # distant arrival. Do not let that stale view pull the full city canon into
    # the island; remote play needs current-place or current-question evidence.
    if scope != "distant":
        evidence_parts.extend(
            str(row.get("text") or "")
            for row in recent_turns[-3:]
            if isinstance(row, dict)
        )
    visible_evidence = " ".join(evidence_parts)
    if _AETHER_VISIBLE_EVIDENCE.search(visible_evidence):
        return "visible"
    return scope


def _aether_geography_context(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> str:
    scope = _aether_geography_scope(state, recent_turns, player_text)
    if scope in {"local", "visible"}:
        return AETHER_HARBOR_CANON
    if scope == "regional":
        return AETHER_HARBOR_REGIONAL_CONTEXT
    return AETHER_HARBOR_ORIGIN_CONTEXT


def _system_prompt_for_turn(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> str:
    return SYSTEM_PROMPT_TEMPLATE.replace(
        _GEOGRAPHY_SLOT,
        _aether_geography_context(state, recent_turns, player_text),
    )


def event_narration_directive(
    state: dict[str, Any], resolved_event: dict[str, Any] | None
) -> str:
    """Repeat the turn's non-negotiable boundary at the prompt's recency edge."""

    if isinstance(resolved_event, dict) and resolved_event.get("type") == "party_action":
        if resolved_event.get("committed"):
            return (f"Party {resolved_event['action']} is committed for {resolved_event['target']}. "
                    "Use this exact name and recorded membership. Do not request another acceptance or fee.")
        return (f"Party change is not committed: {resolved_event.get('reason')}. "
                "For a proposal, let the NPC respond naturally now; do not assume acceptance. "
                "An already-present companion remains present. Respect a full party or unavailable funds.")
    if isinstance(resolved_event, dict) and resolved_event.get("type") == "party_roll_resolution":
        return event_narration_directive(state, resolved_event.get("roll")) + " " + event_narration_directive(state, resolved_event.get("party"))
    if isinstance(resolved_event, dict) and resolved_event.get("type") == "companion_action":
        return f"{resolved_event.get('actor')} performs this routine action. No die is required."
    if (isinstance(resolved_event, dict) and resolved_event.get("type") == "d20_resolution"
            and resolved_event.get("actor", "Player") != "Player"):
        return (f"{resolved_event['actor']}, not the player, attempts this action. "
                f"The engine resolved {resolved_event.get('stat')} as {resolved_event.get('outcome')}. "
                f"Narrate that outcome and only the recorded harm to {resolved_event['actor']}. "
                "Do not ask the player for a die, reroll, or change the player's position, HP or inventory.")
    if not resolved_event:
        return (
            "Do not invent a mechanical change that is absent from RESOLVED EVENT. Plausible immediate "
            "in-world reactions may still occur, but stop before uncommitted HP, combat, inventory, silver, "
            "or travel changes."
        )
    chase_consequence = resolved_event.get("active_situation_consequence")
    if isinstance(chase_consequence, dict):
        primary = dict(resolved_event)
        primary.pop("active_situation_consequence", None)
        return (
            event_narration_directive(state, primary)
            + " In the same elapsed beat, preserve this separate chase consequence: "
            + event_narration_directive(state, chase_consequence)
        )
    event_type = resolved_event.get("type")
    if event_type == 'voyage_resolution':
        return (f"Committed voyage event: {resolved_event.get('action')}; phase {resolved_event.get('phase')}. "
                f"{resolved_event.get('instruction') or resolved_event.get('reason') or ''} "
                f"Explicit movement this turn: {json.dumps(resolved_event.get('movement'), ensure_ascii=False)}. "
                "Preserve the authoritative ship, geographic mooring and local room. Do not advance another phase.")
    if event_type == "recovery_resolution":
        if not resolved_event.get("success"):
            return (
                f"Rest provides no HP recovery: {resolved_event.get('reason')}. Narrate only the attempted pause "
                "or interruption; do not change HP, conditions, inventory, silver, or location."
            )
        restored = int(resolved_event.get("hp_restored", 0) or 0)
        kind = str(resolved_event.get("kind") or "ordinary_rest")
        if kind == "safe_lodging":
            return (
                f"A previously paid safe lodging rest is now completed. Restore exactly {restored} HP, from "
                f"{resolved_event.get('hp_before')} to {resolved_event.get('hp_after')}; the reserved stay is "
                "consumed. Let meaningful time pass, but clear no condition and invent no further benefit."
            )
        return (
            f"The committed {kind.replace('_', ' ')} restores exactly {restored} HP, from "
            f"{resolved_event.get('hp_before')} to {resolved_event.get('hp_after')}. Let an appropriate pause "
            "pass, but clear no condition and add no other recovery, safety, item, or location change."
        )
    if event_type == "world_pressure_resolution":
        actor = str(resolved_event.get("actor") or "The active figure")
        action = str(resolved_event.get("action") or "").strip()
        interruption = (
            "The declared rest is interrupted before it restores any HP or consumes lodging. "
            if resolved_event.get("interrupted_recovery")
            else ""
        )
        if resolved_event.get("hostile_attack"):
            return (
                interruption
                + f"An already-established pressure now advances: {actor} commits to this immediate hostile "
                f"action: {action} Narrate that initiation as one continuous in-world beat, stopping before "
                "contact, evasion, injury, damage, or the player's response. Combat has begun and the player's "
                "defense roll follows separately; do not decide it in prose. Do not add a second attacker or "
                "another action."
            )
        return (
            interruption
            + f"An already-established pressure changes the situation now: {actor} does this: {action} "
            "Narrate exactly that one world-side advance without inventing a player response, attack contact, "
            "injury, HP, inventory, silver, or travel change."
        )
    if event_type == "active_situation_resolution":
        status = str(resolved_event.get("status") or "active")
        action = str(resolved_event.get("action") or "continue").replace("_", " ")
        quarry = str(resolved_event.get("quarry") or "the quarry")
        stake = str(resolved_event.get("stake") or "the carried object")
        before = str(resolved_event.get("before_range") or "")
        after = str(resolved_event.get("after_range") or before)
        if status == "caught":
            return f"The chase resolves now: {quarry} is caught at contact, still associated with {stake}. Narrate one compact decisive beat; invent no injury, combat result or extra transfer."
        if status == "escaped":
            return f"The chase resolves now: {quarry} escapes with {stake}. Do not restore contact, move the stake to the player or offer another immediate roll."
        if status == "abandoned":
            return f"The player abandons the chase. {quarry} continues away with {stake}; no roll, capture or transfer occurs."
        return (
            f"The active chase remains unresolved. Its exact mechanical beat is {action}; relative range changes "
            f"from {before or after} to {after}. {quarry} still has {stake}. Narrate one concrete action beat and "
            "do not decide capture, escape, injury or another roll in prose."
        )
    if event_type == "celestial_spheres_resolution":
        if not resolved_event.get("committed"):
            return f"No Celestial Spheres wager is committed: {resolved_event.get('reason')}. Do not change silver or roll dice."
        if resolved_event.get("pending_press"):
            stake = resolved_event.get("stake")
            silver_after = resolved_event.get("silver_after")
            return (
                f"The exact Celestial Spheres roll is {resolved_event.get('dice')} for {resolved_event.get('magnitude')}, "
                f"with {resolved_event.get('celestial_face')} uppermost. The winning Mars bet of "
                f"{stake} silver awaits a collect-or-press choice; "
                f"{silver_after} silver are currently held. Do not pay it yet. "
                "Narrate this dramatic turn and have the table-keeper ask whether the player wishes to collect or press."
            )
        if resolved_event.get("action") in {"press", "collect"}:
            return (
                f"The Mars-seven choice resolves as {resolved_event.get('action')}: exact stake "
                f"{resolved_event.get('stake')} silver, payout {resolved_event.get('payout')}, "
                f"net {resolved_event.get('net')}, silver after {resolved_event.get('silver_after')}. "
                "Narrate that table result without inventing another die roll or wager. "
                "Next action: State that the table is cleared for new bets, or the player can step away."
            )
        sel = resolved_event.get("selection")
        face = resolved_event.get("celestial_face")
        dice = resolved_event.get("dice")
        mag = resolved_event.get("magnitude")
        won = resolved_event.get("won")
        stake = resolved_event.get("stake")
        payout = resolved_event.get("payout")
        silver_after = resolved_event.get("silver_after")
        special = resolved_event.get("special")
        special_str = f" Special condition: {special}." if special else ""
        if won:
            outcome_str = f"The bet WINS with a payout of {payout} silver!"
        elif int(payout or 0) > 0:
            outcome_str = f"The bet resulted in a partial refund/aid of {payout} silver ({special})!"
        else:
            outcome_str = f"The bet LOSES; the {stake} silver stake is swept by the house."
        table_summary = resolved_event.get("table_wagers_summary")
        prev_winner = resolved_event.get("previous_winner")
        table_leader = resolved_event.get("table_leader")
        table_notes = []
        if table_summary:
            table_notes.append(f"Table wagers & outcomes this spin: {table_summary}.")
        if prev_winner:
            table_notes.append(f"Previous spin winner: {prev_winner}.")
        if table_leader:
            table_notes.append(f"Current table leader: {table_leader}.")
        table_directive = ""
        if table_notes:
            table_directive = (
                " " + " ".join(table_notes) +
                " Dramatize the other gamblers' specific wagers, their authentic reactions to winning or losing, "
                "and any table banter reflecting who won earlier or who currently leads."
            )
        return (
            f"Resolve exactly this Celestial Spheres spin: The player wagered {stake} silver on {sel}. "
            f"The celestial die stopped on {face}; magnitude dice {dice} total {mag}. "
            f"{outcome_str}{special_str} The player now holds {silver_after} silver."
            f"{table_directive} "
            "Narrate the table-keeper announcing the sphere and sliding the coins, with nearby tavern patrons watching the board. "
            "Next action: Mention naturally that the board is open for another bet (e.g. 'bet [amount] silver on [planet]') or the player may step away."
        )
    if event_type == "passage_quote_required":
        return (
            "This turn stops at the quote. State exactly one total integer price from 5 to 30 silver "
            "for one-way passage to the named destination only; do not include or promise a return. "
            "Identify the vessel and its departure plainly (for example: 'The [name] sails [time]'). "
            "Keep any already quoted vessel/schedule; mention crossing duration only if established. "
            "No coins change hands; do not narrate boarding, departure, travel, or arrival."
        )
    if event_type == "passage_purchase" and not resolved_event.get("success"):
        location = current_location(state)
        return (
            f"The attempted purchase FAILED for {resolved_event.get('reason') or 'insufficient funds'}. The player keeps "
            f"{resolved_event.get('silver_after')} silver and remains at {location.get('name')}. "
            "No coins change hands; do not narrate handover, boarding, departure, travel, or arrival."
        )
    if event_type == "passage_purchase" and resolved_event.get("success"):
        return (
            f"The passage purchase SUCCEEDED for exactly {resolved_event.get('price')} silver; "
            f"{resolved_event.get('silver_after')} silver remain. A berth to "
            f"{resolved_event.get('destination_name')} is booked on {resolved_event.get('vessel_name')} "
            f"for {resolved_event.get('departure_label')}. The player remains exactly where they paid; no travel is committed."
        )
    if event_type == "passage_declined":
        return "The offer was declined. No coins change hands and no travel occurs."
    if event_type == "local_game_rules":
        return "Explain the stored ordinary-dice rules and current score briefly in character. No bet, payment or roll occurs: " + json.dumps(resolved_event.get("rules"), ensure_ascii=False)
    if event_type == "local_game_forfeit":
        return f"The player concedes the ordinary dice match. The already-paid {resolved_event.get('stake')} silver stake is lost; do not charge it again. Silver remains {resolved_event.get('silver_after')}."
    if event_type == "local_game_declined":
        return "The ordinary dice-game offer is declined; no stake is paid and no round is played."
    if event_type == "local_game_start":
        if not resolved_event.get("success"):
            return (
                f"The dice game does not begin: {resolved_event.get('reason')}. "
                "No stake is removed and no dice are rolled."
            )
        opp = str(resolved_event.get("opponent_name") or "").strip()
        desc = str(resolved_event.get("opponent_desc") or "").strip()
        opp_intro = (
            f"against {desc or opp}"
            if opp
            else "against a local tavern gambler. Author their name, appearance, cultural dress, and demeanor naturally to suit this specific island and tavern, alongside 1-2 local onlookers watching the game"
        )
        opp_gesture = opp if opp else "The opponent"
        return (
            f"The player pays the one-time {resolved_event.get('stake')} silver stake, leaving "
            f"{resolved_event.get('silver_after')}. The {resolved_event.get('rounds_total')}-round dice match "
            f"{opp_intro} is now officially started. "
            f"The stake coins sit in the center of the barrel/table. Do not charge the stake again and do not invent a roll this turn. "
            f"Next action: {opp_gesture} gestures or rattles the cup, inviting the player to throw the first roll."
        )
    if event_type == "local_game_round":
        opp = str(resolved_event.get("opponent_name") or "").strip()
        opp_label = opp if opp else "the opponent"
        r_num = resolved_event.get("round")
        r_tot = resolved_event.get("rounds_total")
        p_dice = resolved_event.get("player_dice")
        p_tot = resolved_event.get("player_total")
        o_dice = resolved_event.get("opponent_dice")
        o_tot = resolved_event.get("opponent_total")
        p_sc = resolved_event.get("player_score")
        o_sc = resolved_event.get("opponent_score")
        finished = resolved_event.get("finished")

        if p_tot > o_tot:
            round_verdict = f"The player wins this round ({p_tot} vs {o_tot})."
        elif o_tot > p_tot:
            round_verdict = f"{opp_label} wins this round ({o_tot} vs {p_tot})."
        else:
            round_verdict = f"This round is a tie ({p_tot} vs {o_tot})."

        tally_status = f"Running match score is: Player {p_sc}, {opp_label} {o_sc}."

        directive = (
            (f"The player paid the one-time {resolved_event['stake_paid_this_turn']} silver stake and immediately rolled. " if resolved_event.get("stake_paid_this_turn") else "") +
            f"Ordinary dice round {r_num}/{r_tot} is already rolled by the engine: "
            f"player throws {p_dice} (total {p_tot}); {opp_label} throws {o_dice} (total {o_tot}). "
            f"{round_verdict} {tally_status} "
            f"Narrate these exact rolls, {opp_label}'s reaction, and reactions from any local onlookers present, keeping their demeanor and dialogue authentic to this island's culture. "
            "CRITICAL: NO coins or silver change hands during ongoing rounds; the pot sits untouched on the table until the final round! "
        )
        if not finished:
            directive += (
                f"Next action: Conclude by having {opp_label} ready the cup and prompt the player for Round {r_num + 1} of {r_tot}."
            )
        else:
            res = resolved_event.get("result")
            payout = resolved_event.get("payout")
            silver_after = resolved_event.get("silver_after")
            if res == "win":
                directive += (
                    f" The match concludes with a PLAYER VICTORY (final score {p_sc} to {o_sc})! "
                    f"The full pot of {payout} silver is pushed across to the player, leaving them with {silver_after} silver. "
                    f"Narrate {opp} conceding the pot with good grace or a grimace and handing over the coins. The game is finished."
                )
            elif res == "loss":
                directive += (
                    f" The match concludes in DEFEAT (final score {o_sc} to {p_sc}). "
                    f"{opp} sweeps the pot; player receives 0 silver and has {silver_after} silver. "
                    f"Narrate {opp} claiming their winnings. The game is finished."
                )
            else:
                directive += (
                    f" The match concludes in a TIE (final score {p_sc} each). "
                    f"The original {payout} silver stake is returned to the player, leaving them with {silver_after} silver. "
                    "The game is finished."
                )
        return directive
    if event_type == "resource_quote_required":
        return (
            f"This turn stops at a quote for {resolved_event.get('quantity', 1)} {resolved_event.get('item')}. "
            "State exactly one total integer "
            f"price from {resolved_event.get('minimum_price')} to {resolved_event.get('maximum_price')} silver. "
            "This is only an asking price or buyer's offer: no coins or items change hands, and do not imply "
            "that the player has accepted it."
        )
    if event_type == "resource_negotiation":
        pending = resolved_event.get("pending_offer") if isinstance(resolved_event.get("pending_offer"), dict) else {}
        if resolved_event.get("success") is True:
            return (
                f"The negotiation succeeds. Replace the previous {pending.get('amount')} silver offer for "
                f"{resolved_event.get('item')} with exactly one new integer offer from "
                f"{resolved_event.get('minimum_price')} to {resolved_event.get('maximum_price')} silver. "
                "No payment or item handover occurs yet."
            )
        return (
            f"The negotiation fails and the existing offer of {pending.get('amount')} silver for "
            f"{resolved_event.get('item')} remains available. State no new price; no payment or item "
            "handover occurs."
        )
    if event_type == "resource_movement_resolution":
        resource = resolved_event.get("resource") if isinstance(resolved_event.get("resource"), dict) else {}
        movement = resolved_event.get("movement") if isinstance(resolved_event.get("movement"), dict) else {}
        roll = resolved_event.get("roll") if isinstance(resolved_event.get("roll"), dict) else None
        transfer_boundary = event_narration_directive(state, resource)
        if resource.get("type") == "resource_quote_required":
            return (
                f"Movement to {movement.get('to_name')} is committed first. The player then requests the "
                f"recorded quote there. {transfer_boundary} Preserve the completed arrival as well as the "
                "quote; do not leave the player at the former location."
            )
        roll_note = (
            f"The shared roll resolved as {str(roll.get('outcome') or 'success').replace('_', ' ').upper()}. "
            if roll
            else ""
        )
        return (
            f"{roll_note}{transfer_boundary} Movement to {movement.get('to_name')} is also committed by the "
            "same action. Preserve both the exact acquisition and the completed departure; do not leave the "
            "player in the former room or add another item."
        )
    if event_type == "resource_roll_resolution":
        roll = resolved_event.get("roll") if isinstance(resolved_event.get("roll"), dict) else {}
        resource = resolved_event.get("resource") if isinstance(resolved_event.get("resource"), dict) else None
        outcome = str(roll.get("outcome") or "failure").replace("_", " ").upper()
        resource_boundary = event_narration_directive(state, resource) if resource else (
            "No inventory or silver transfer is committed."
        )
        return (
            f"The contested resource action resolves as {outcome}. Preserve that result and narrate its "
            f"immediate consequence. {resource_boundary}"
        )
    if event_type == "resource_transfer":
        kind = str(resolved_event.get("kind") or "transfer")
        item = str(resolved_event.get("item") or "").strip()
        quantity = int(resolved_event.get("quantity", 1) or 1)
        amount = int(resolved_event.get("amount", 0) or 0)
        if not resolved_event.get("success"):
            pending_note = (
                " The exact pending offer remains available; do not claim that it expires or changes."
                if kind in {"purchase", "sell"}
                else ""
            )
            return (
                f"The attempted {kind} is NOT committed: {resolved_event.get('reason') or 'the exact transfer failed'}. "
                "No item, worn/readied state, or silver changes; do not narrate a handover, acquisition, "
                "payment, sale, consumption, or disposal."
                + pending_note
            )
        if kind == "drop":
            return f"The player drops/discards exactly {quantity} {item} here. It is no longer carried or equipped."
        if kind == "take":
            return f"The player takes and now carries exactly {quantity} {item}; do not add any other object."
        if kind == "receive_item":
            return f"The player receives and now carries exactly {quantity} {item}; no payment occurs."
        if kind == "give_item":
            return f"The player hands over exactly {quantity} {item} and no longer carries it."
        if kind == "consume":
            return f"The player consumes exactly {quantity} {item} and no longer carries that quantity."
        if kind == "equip":
            return f"The player now wears/readies {item}; it remains in inventory."
        if kind == "unequip":
            return f"The player removes/puts away {item} but keeps it in inventory."
        if kind == "purchase":
            if resolved_event.get("service_kind") == "lodging":
                return (
                    f"The player pays exactly {amount} silver for lodging, leaving "
                    f"{resolved_event.get('silver_after')}. A safe rest is now reserved here but has not yet "
                    "happened; add no inventory item and do not heal until the player rests."
                )
            if resolved_event.get("service_kind") == "treatment":
                return (
                    f"The player pays exactly {amount} silver for treatment, leaving "
                    f"{resolved_event.get('silver_after')}. Treatment restores exactly "
                    f"{resolved_event.get('hp_restored')} HP, from {resolved_event.get('hp_before')} to "
                    f"{resolved_event.get('hp_after')}; add no inventory item or further healing."
                )
            return (
                f"The purchase commits exactly {quantity} {item} for {amount} silver total. The exact silver "
                f"change is {resolved_event.get('silver_delta')}; {resolved_event.get('silver_after')} silver remain."
            )
        if kind == "sell":
            return (
                f"The sale commits exactly {quantity} {item} for {amount} silver total. The item leaves inventory "
                f"and the player now has {resolved_event.get('silver_after')} silver."
            )
        if kind == "pay":
            return (
                f"The player pays exactly {amount} silver, leaving {resolved_event.get('silver_after')}. "
                "Do not add an unrecorded item or service completion."
            )
        if kind == "receive_money":
            return f"The player receives exactly {amount} silver and now has {resolved_event.get('silver_after')}."
        return "Narrate exactly the committed resource change and no additional item or silver transfer."
    if event_type == "compound_resource_transfer":
        if not resolved_event.get("success"):
            return (
                f"The attempted bundle transfer is NOT committed: {resolved_event.get('reason')}. "
                "No item or silver changes; do not narrate an acquisition or payment."
            )
        parts = resolved_event.get("parts") if isinstance(resolved_event.get("parts"), list) else []
        exact = []
        for part in parts:
            if not isinstance(part, dict):
                continue
            if part.get("kind") == "receive_money":
                exact.append(f"receive exactly {part.get('amount')} silver")
            elif part.get("kind") in {"take", "receive_item"}:
                exact.append(f"carry exactly {part.get('quantity', 1)} {part.get('item')}")
        return (
            "The grounded loot bundle commits atomically: "
            + "; ".join(exact)
            + f". The player now has exactly {resolved_event.get('silver_after')} silver. "
            "Do not merge currency back into an inventory-item name or add any other loot."
        )
    if event_type == "hidden_access_blocked":
        location_name = str(current_location(state).get("name") or "the current place")
        position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
        exact_position = str(position.get("label") or location_name) if position else location_name
        return (
            f"Access to {resolved_event.get('subject')} remains blocked by the supplied PRIVATE HIDDEN "
            f"CURRENT. Keep the player at {exact_position}, within {location_name}; do not relocate the scene "
            "to a plaza, street, or another part of the site. Describe its outward tell, but do not name "
            "the required item unless the player's action actually satisfies the current's reveal condition. "
            "Do not allow force, luck, or an uncommitted spell to bypass the requirement."
        )
    if event_type == "hidden_access_opened":
        movement = resolved_event.get("movement") if isinstance(resolved_event.get("movement"), dict) else None
        movement_note = (
            f" Arrival at {movement.get('to_name')} is also committed."
            if movement and movement.get("committed")
            else " No further travel is committed."
        )
        return (
            f"The player owns and uses {resolved_event.get('required_item')} to open "
            f"{resolved_event.get('subject')}. The item is not consumed."
            + movement_note
        )
    if event_type in {"movement", "local_movement"}:
        if not resolved_event.get("committed"):
            return "No new movement was committed; continue from the present position."
        arrival_identity = (
            f" For the compact scene description, include one short self-contained sentence about "
            f"{resolved_event.get('to_name')} whose subject is the place, vessel, building, or local "
            "space itself and whose predicate gives stable physical character, not the player's "
            "approach, an arrival beat, or a relative phrase."
        )
        route_note = (
            " This is an end-to-end route-span success: narrate the traversal of the already known "
            "intermediate spaces and finish outside, without stopping the player in an intermediate room."
            if resolved_event.get("route_span")
            else ""
        )
        return (
            f"Movement to {resolved_event.get('to_name')} is committed. Preserve that arrival or local "
            "position throughout this turn; freely author only the immediate route and scene detail."
            + arrival_identity
            + route_note
        )
    if event_type == "d20_resolution":
        outcome = str(resolved_event.get("outcome") or "failure")
        reason = str(resolved_event.get("reason") or "")
        if resolved_event.get("success") and reason.startswith("escape "):
            label = outcome.replace("_", " ").upper()
            return (
                f"The committed escape resolves as {label}. The immediate pursuit or restraint is broken; "
                "all figures from the preceding danger, including anyone reaching for the player, remain "
                "behind and out of physical contact. Do not move them into the arrival scene. Any new "
                "complication must leave the successful escape real."
            )
        location_name = str(current_location(state).get("name") or "the current place")
        position_boundary = (
            f" No travel or departure is committed: the player remains within {location_name}. "
            "Do not complete an additional unrequested action such as escaping, entering another place, "
            "taking an item, or resolving a new confrontation."
        )
        if outcome == "critical_failure":
            defeat = (
                resolved_event.get("defeat_outcome")
                if isinstance(resolved_event.get("defeat_outcome"), dict)
                else None
            )
            if defeat:
                if defeat.get("outcome") == "death":
                    return (
                        "The hazardous action critically fails, its recorded harm defeats the player, and the "
                        "hidden survival result is death. Narrate the death decisively and end the voyage; do not "
                        "invent rescue, survival, or further action."
                    )
                return (
                    "The hazardous action critically fails and its recorded harm defeats the player. They lose "
                    f"consciousness but survive, later recovering at exactly {defeat.get('hp_after')} HP with the "
                    f"committed consequence {str(defeat.get('consequence') or 'left_for_dead').replace('_', ' ')}. "
                    "Narrate the failure, blackout, passage of time, and awakening without extra losses or injuries."
                )
            harm = max(0, int(resolved_event.get("critical_failure_harm", 0) or 0))
            harm_boundary = (
                f" The concrete hazard deals exactly {harm} HP, leaving the player at "
                f"{resolved_event.get('hp_after')} HP; embody that one injury without adding another."
                if harm
                else " Do not change HP or invent a bodily injury."
            )
            return (
                "The committed risky action CRITICALLY FAILS. Give it a sharper concrete consequence, "
                "and keep its intended result unachieved throughout this response; do not grant the same "
                "goal through an NPC, coincidence, accident, or alternate method. "
                "Do not change inventory, silver, combat, or location unless RESOLVED EVENT explicitly "
                "records that change."
                + harm_boundary
                + position_boundary
            )
        if outcome == "failure":
            return (
                "The committed risky action FAILS. Give it an immediate, plausible negative consequence "
                "or realistic complication grounded in the scene. A failure must visibly alter the situation "
                "against the player rather than leaving the scene static or indifferent. "
                "Do not repeat the roll, do not soften it into success, and keep the intended result unachieved."
                + position_boundary
            )
        if outcome == "marginal_success":
            return (
                "The committed action SUCCEEDS narrowly. Grant its core intended result and preserve it; "
                "limited leverage, visibility, or time pressure may remain, but must not negate the success."
                + position_boundary
            )
        if outcome == "strong_success":
            return (
                "The committed action SUCCEEDS strongly. Preserve the intended result and add one useful "
                "scene-supported but nonportable edge, detail, or leverage within that same action. Do not "
                "create, reveal, hand over, drop, or place in the player's possession any new item, currency, "
                "or other mechanical reward."
                + position_boundary
            )
        if outcome == "critical_success":
            return (
                "The committed plausible action is a NATURAL-20 CRITICAL SUCCESS. Make it especially decisive "
                "and preserve the gain, but do not make an impossible action possible or invent unauthorized "
                "HP, wealth, items, travel, quests, or hard canon."
                + position_boundary
            )
        return (
            "The committed action SUCCEEDS cleanly. Preserve its concrete result throughout this turn; "
            "do not immediately reverse, cancel, or nullify it."
            + position_boundary
        )
    if event_type == "resource_movement_resolution":
        roll = resolved_event.get("roll") if isinstance(resolved_event.get("roll"), dict) else None
        movement = resolved_event.get("movement") if isinstance(resolved_event.get("movement"), dict) else {}
        outcome = (
            str(roll.get("outcome") or "success").replace("_", " ").upper()
            if roll
            else "SUCCESS"
        )
        return (
            f"The player commits to this combined take-and-depart action: {player_text}\n"
            f"It has already resolved as {outcome}: the recorded objects are carried and arrival at "
            f"{movement.get('to_name')} is committed."
        )
    if event_type == "compound_resolution":
        roll = resolved_event.get("roll") if isinstance(resolved_event.get("roll"), dict) else {}
        movement = resolved_event.get("movement") if isinstance(resolved_event.get("movement"), dict) else {}
        outcome = str(roll.get("outcome") or "success").replace("_", " ").upper()
        if resolved_event.get("route_span_failure"):
            return (
                f"The end-to-end escape resolves as {outcome}: the requested exit is NOT achieved, but partial "
                f"movement to {movement.get('to_name')} is mechanically committed. Keep the player inside the "
                "same site at that exact intermediate position. Narrate the known route up to that point and one "
                "sharp grounded obstruction or interception there; do not add another roll, relocate them elsewhere, "
                "or let coincidence complete the escape."
            )
        if resolved_event.get("movement_independent") and not roll.get("success"):
            return (
                f"Movement to {movement.get('to_name')} was independently committed before the separate "
                f"risky follow-up, which resolves as {outcome}. Narrate this newest arrival first, then "
                "make the attempted follow-up fail concretely. Preserve the arrival, but do not grant the "
                "failed goal through an NPC, coincidence, or alternate method, and do not resume an older "
                "conversation in place of this action."
            )
        if str(roll.get("reason") or "").startswith("escape "):
            return (
                f"The committed escape resolves as {outcome}, and arrival at {movement.get('to_name')} is "
                "committed. All figures from the preceding danger, including anyone reaching for the player, "
                "remain behind and out of physical contact; do not move them into the arrival scene. Any new "
                "complication must preserve the successful escape and arrival."
            )
        return (
            f"The committed risky action resolves as {outcome} and movement to {movement.get('to_name')} "
            "is committed. Narrate this newest resolved action and achieved arrival before any reaction; do "
            "not replace it with continuation of an older conversation. Preserve the arrival and its concrete "
            "advantage throughout this turn; do not immediately reverse it."
        )
    if event_type == "magic_resolution":
        outcome = str(resolved_event.get("outcome") or "failure").replace("_", " ").upper()
        defeat = resolved_event.get("defeat_outcome") if isinstance(resolved_event.get("defeat_outcome"), dict) else None
        if defeat:
            if defeat.get("outcome") == "death":
                return (
                    f"The spell resolves as {outcome}, and its recorded toll kills the player. This is final: "
                    "narrate the death decisively and end there. Do not invent rescue, survival, awakening, capture, "
                    "or further action."
                )
            return (
                f"The spell resolves as {outcome}. The player is knocked unconscious but survives; several hours "
                f"pass and they recover at exactly {defeat.get('hp_after')} HP. The committed consequence is "
                f"{str(defeat.get('consequence') or 'left_for_dead').replace('_', ' ')}. "
                "Narrate the collapse and later awakening as one transition. Do not add unrecorded losses or injuries."
            )
        boundary = (
            f"The formal spell resolves exactly as {outcome}, with only the recorded toll, damage, and scene "
            "effect. Do not alter HP, target condition, inventory, or location beyond this event. "
        )
        resource = resolved_event.get("resource")
        if isinstance(resource, dict):
            boundary += " " + event_narration_directive(state, resource)
        movement = resolved_event.get("movement")
        if isinstance(movement, dict):
            if movement.get("committed"):
                boundary += (
                    f" Movement to {movement.get('to_name')} is also committed; preserve that arrival. "
                    "Any recorded pickup occurs at its source before departure. "
                )
                if resolved_event.get("movement_independent") and outcome not in {"SUCCESS", "STRONG SUCCESS"}:
                    boundary += "The movement is independent; it does not make the failed spell succeed. "
            else:
                boundary += f" Movement is NOT committed: {movement.get('reason')}. Preserve the current position. "
        if resolved_event.get("counterattack_pending"):
            boundary += (
                "The opponent remains active and an answering attack is pending. Do not narrate that attack "
                "landing, missing, or causing harm yet."
            )
        return boundary
    if event_type == "combat_resolution":
        action = str(resolved_event.get("action") or "combat")
        status = str(resolved_event.get("combat_status") or "active")
        exchanges = resolved_event.get("exchanges") if isinstance(resolved_event.get("exchanges"), list) else []
        if action == "unavailable_ranged_attack":
            return (
                "The attempted ranged attack is not committed: the player has no ranged weapon ready or carried. "
                "State that practical obstacle briefly. Do not invent a shot, projectile, hit, enemy counterattack, "
                "weapon, ammunition, damage, or location change."
            )
        defeat = resolved_event.get("defeat_outcome") if isinstance(resolved_event.get("defeat_outcome"), dict) else None
        if defeat:
            opponent = str(defeat.get("opponent") or "the opponent")
            if defeat.get("outcome") == "death":
                return (
                    f"The recorded combat beat defeats the player and the hidden survival check resolves as death. "
                    f"{opponent} has dealt the final defeat. Narrate the player's death decisively as the end of this "
                    "voyage. Do not invent rescue, survival, awakening, capture, or another action. Do not mention HP, "
                    "dice, the survival check, or game mechanics."
                )
            consequence = str(defeat.get("consequence") or "left_for_dead").replace("_", " ")
            relocation = str(defeat.get("relocated_to") or "")
            confiscated = [str(x) for x in defeat.get("confiscated_items", []) if str(x).strip()]
            silver_lost = int(defeat.get("silver_lost", 0) or 0)
            details = [
                f"The player loses consciousness but survives and wakes several hours later at exactly {defeat.get('hp_after')} HP.",
                f"The committed consequence is {consequence}.",
            ]
            if relocation:
                details.append(f"The committed awakening location is {relocation}.")
            if confiscated:
                details.append("The following carried weapons were confiscated and are no longer in inventory: " + ", ".join(confiscated) + ".")
            if silver_lost:
                details.append(f"Exactly {silver_lost} silver was lost while unconscious.")
            details.append(
                "Narrate the defeat, blackout, passage of time, and awakening as one transition. Do not add any "
                "other injury, item loss, silver loss, rescue, relocation, or punishment. Do not mention mechanics."
            )
            return " ".join(details)
        movement = resolved_event.get("movement") if isinstance(resolved_event.get("movement"), dict) else None
        movement_boundary = (
            f" The same committed action also ends at {movement.get('to_name')}; preserve that position change exactly."
            if movement and movement.get("committed")
            else ""
        )
        common = (
            "Narrate exactly this one committed combat beat. Do not add a second attack, counterattack, "
            "defense, extra wound, disarm, capture, escape, or unrecorded position change. Translate the result "
            "into fiction without mentioning dice, totals, modifiers, HP, rounds, or game mechanics. "
            "Neither participant retreats, stumbles to another position, falls, or is driven back unless this "
            "event explicitly records it. End at the immediate result instead of setting up another action."
            + movement_boundary + " "
        )
        if action == "surrender":
            return common + "The player surrenders; no attack or injury is committed in this beat."
        if action == "condition_denied":
            return common + str(resolved_event.get("reason") or "The condition prevents this action.") + " The enemy response is still pending."
        flee_roll = resolved_event.get("flee_roll")
        if isinstance(flee_roll, dict):
            if flee_roll.get("success"):
                return common + "The escape succeeds and the active combat ends; preserve that separation."
            return common + (
                "The escape attempt fails and combat remains active. The opponent's answering attack is only "
                "pending: do not narrate it landing, missing, or causing harm yet."
            )
        if not exchanges:
            return common + "No strike or injury is mechanically committed in this beat."
            
        results = []
        player_defeated = False
        enemies_defeated = not active_opponents if 'active_opponents' in locals() else (status == "won")
        
        for exchange in exchanges:
            attacker = str(exchange.get("attacker") or "The attacker")
            defender = str(exchange.get("defender") or "the defender")
            damage = int(exchange.get("damage", 0) or 0)
            hit = bool(exchange.get("hit"))
            raw_hp_after = exchange.get("defender_hp_after")
            if raw_hp_after is not None:
                defender_hp_after = int(raw_hp_after)
            elif exchange.get("attacker_is_player"):
                defender_hp_after = 0
            else:
                defender_hp_after = int(state.get("player", {}).get("hp", 0))
            weapon = str(exchange.get("weapon") or "their weapon")
            if exchange.get("mode") == "magic" or exchange.get("denied"):
                results.append(str(exchange.get("reason") or "The recorded spell effect resolves."))
                if damage:
                    results.append(f"{defender} takes the recorded damage; their remaining HP is {defender_hp_after} (translate into fiction).")
                continue
            
            if exchange.get("attacker_is_player"):
                if defender_hp_after <= 0:
                    results.append(f"{attacker}'s use of {weapon} takes {defender} out of the fight.")
                elif hit and damage > 0:
                    results.append(f"{attacker}'s use of {weapon} harms {defender}, but the opponent remains active.")
                elif hit:
                    results.append(f"{attacker}'s use of {weapon} makes contact but causes no harm to {defender}.")
                else:
                    results.append(f"{attacker}'s attack with {weapon} misses or causes no harm to {defender}.")
            else:
                is_player = not exchange.get("defender_is_companion") and (
                    str(defender).casefold() == str(state.get("player", {}).get("name", "")).casefold()
                    or defender.lower() in {"the player", "the defender", "player"}
                )
                if (defender_hp_after <= 0 or status == "defeated") and is_player and int(state.get("player", {}).get("hp", 1)) <= 0:
                    player_defeated = True
                    results.append(f"{attacker}'s attack with {weapon} defeats {defender} at zero HP.")
                elif defender_hp_after <= 0:
                    results.append(f"{attacker}'s attack with {weapon} takes {defender} out of the fight.")
                elif hit and damage > 0:
                    results.append(f"AUTHORITATIVE: {attacker}'s attack with {weapon} hits and wounds {defender}, who remains active. The declared defense fails.")
                else:
                    results.append(f"{attacker}'s attack with {weapon} causes no harm to {defender}.")

        combined_result = " ".join(results)
        if len(exchanges) > 1 and not any(ex.get("attacker_is_player") for ex in exchanges):
            combined_result += " Multiple attackers strike together in this round: weave their simultaneous attacks and specific outcomes (hits, parries, wounds) into a single fluid narrative sequence without dropping any combatant."
        if player_defeated:
            combined_result += " Narrate the defeat decisively."
        elif enemies_defeated:
            combined_result += " Treat the opponents as incapacitated, not automatically dead. No answering enemy attack follows."
        elif action == "attack":
            combined_result += " The answering enemy attack remains pending and must not occur in this narration."
        else:
            combined_result += " Do not add another enemy attack or automatic retaliation."
            
        return common + combined_result
    if event_type == "fate_resolution":
        result = str(resolved_event.get("result") or "").upper()
        effect = resolved_event.get("effect") if isinstance(resolved_event.get("effect"), dict) else {}
        common = (
            "The Wheel dictates a 'Deus Ex Machina' intervention. Interrupt the current narrative immediately. "
            "This overrides normal logic/RNG. This is an arbitrary intervention of fate. Make it dramatic. "
            "Do not add unrecorded HP, silver, inventory, condition, injury, death, or combat changes. "
        )
        boon = "Wheel description: Grant a miraculous benefit, find treasure, or solve a problem via extreme luck. "
        if result == "AMBUSH":
            enemy_count = int(effect.get("enemy_count", 1) or 1)
            count_phrase = (
                "a trio of ambushers" if enemy_count == 3
                else "a pair of ambushers" if enemy_count == 2
                else "one immediate enemy"
            )
            return common + (
                f"Wheel description — Ambush: Immediate enemies ({count_phrase}). Begin the committed hostile encounter now, "
                "but stop before any attack lands. "
                "The player is not wounded and loses no HP in this turn."
            )
        if result == "MIRACLE":
            hp_before = int(effect.get("hp_before") or 0)
            hp_after = int(effect.get("hp_after") or 0)
            hp_gained = max(0, hp_after - hp_before)
            ward_msg = " A divine ward envelops the player with protective power." if effect.get("ward_granted") else ""
            return common + boon + (
                f"Restore the player exactly from {hp_before} to {hp_after} HP: this is a gain of exactly "
                f"{hp_gained} HP, not {hp_before} HP"
                + (" and remove only the recorded condition." if effect.get("removed_condition") else ".")
                + ward_msg
            )
        if result == "RUIN":
            if effect.get("kind") == "ruin_breakage":
                return common + (
                    "Wheel description — Ruin: Loss of gear/money. Calamity strikes player belongings and gear, "
                    "damaging equipment and shaking confidence. Destroy no item and inflict no injury."
                )
            return common + (
                f"Wheel description — Ruin: Loss of gear/money. This spin commits exactly "
                f"{effect.get('silver_lost')} silver lost, leaving {effect.get('silver_after')}; "
                "destroy no item and inflict no injury."
            )
        if result == "EPIPHANY":
            return common + boon + "The only committed mechanical change is the recorded one-roll insight condition."
        if result == "CURSE":
            return common + (
                "Wheel description — Curse: Inflict a lasting status penalty (e.g., -Stat), magical burden, or sickness. "
                "The only committed mechanic is the recorded bounded condition; inflict no additional HP loss "
                "or permanent stat change."
            )
        if result == "FORTUNE":
            return common + boon + (
                f"Grant exactly {effect.get('silver_gained')} silver, leaving {effect.get('silver_after')}; "
                "do not mechanically add any other item, access, or wealth."
            )
        if result == "DESPAIR":
            return common + (
                "Wheel description — Despair: Psychological horror or bad news. The only committed mechanic is "
                "the recorded temporary condition; do not impose a permanent stat change."
            )
        if result == "DELIVERANCE":
            hp_before = int(effect.get("hp_before") or 0)
            hp_after = int(effect.get("hp_after") or 0)
            hp_gained = max(0, hp_after - hp_before)
            if effect.get("combat_ended"):
                return common + boon + (
                    f"The combat is committed as ended. Restore the player exactly from {hp_before} to {hp_after} "
                    f"HP, a gain of exactly {hp_gained}. Do not wound or kill the opponent as part of this Wheel event."
                )
            ward_msg = " A sanctuary shroud shields the player with protective power." if effect.get("ward_granted") else ""
            return common + boon + (
                f"There was no active combat. Restore the player exactly from {hp_before} to {hp_after} HP, "
                f"a gain of exactly {hp_gained}, and do not create a combat state, injury, or opponent as a "
                f"committed consequence.{ward_msg}"
            )
        return common
    return "Narrate only the mechanical changes explicitly committed by RESOLVED EVENT."


def _foreground_pressure_directive(resolved_event: dict[str, Any] | None) -> str:
    if not isinstance(resolved_event, dict):
        return ""
    pieces: list[str] = []
    attention = resolved_event.get("attention_consequence")
    if isinstance(attention, dict):
        kind = str(attention.get("kind") or "noise")
        pieces.append(
            f" The critical failure commits a real {kind} attention consequence: local alert is now "
            f"{attention.get('local_alert')} with suspicion {attention.get('suspicion')}. Embody that "
            "disturbance without inventing damage or a full-city alarm."
        )
    pressure = resolved_event.get("foreground_pressure")
    if isinstance(pressure, dict):
        action = str(pressure.get("action") or "").strip()
        if pressure.get("result") == "interrupted":
            pieces.append(
                " The player's resolved action interrupts the already-poised world action before "
                f"its immediate outcome (source cue: {action}). Do not complete it and do not leave "
                "it poised for another beat."
            )
        else:
            pieces.append(
                " In the same beat, the already-poised world action reaches its immediate concrete "
                f"outcome now (source completion: {action}). Advance beyond any preparatory wording "
                "in that cue, using only the direct completion established by the exact recent scene. "
                "Do not describe another preparation, reach, hesitation, warning, or near-action. "
                "Preserve every committed player success; a parallel world action may complete behind "
                "the player but cannot pull them back or cancel their arrival."
            )
    return "".join(pieces)


def turn_narration_directive(
    state: dict[str, Any],
    resolved_event: dict[str, Any] | None,
    player_text: str,
) -> str:
    affliction_boundary = _affliction_narration_directive(resolved_event)
    if (
        str(state.get("current_location_id") or "") == "opening_threshold"
        and "begin the voyage" in player_text.casefold()
    ):
        return event_narration_directive(state, resolved_event) + (
            " OPENING-SPECIFIC: Use visual, spatial, audible, social, or tactile detail, but mention no "
            "smell, scent, odor, aroma, brine, or ambient fragrance. Do not describe what the air carries "
            "or characterize the air as salty, clean, sharp, crisp, heavy, or thick."
        ) + _foreground_pressure_directive(resolved_event) + affliction_boundary
    if is_capability_question(player_text):
        return (
            "This is a FEASIBILITY QUESTION ONLY, not a committed action. Answer whether the proposed "
            "action appears possible from presently visible facts and mention a concrete evident risk or "
            "obstacle only if one exists. Keep the player exactly where they are. Do not narrate attempting "
            "or completing it, do not move them, and do not invent or resolve a roll."
        ) + _foreground_pressure_directive(resolved_event) + affliction_boundary

    skirmish_dir = ""
    if isinstance(resolved_event, dict) and "skirmish_resolution" in resolved_event:
        skirmish_dir = " " + resolved_event["skirmish_resolution"].get("directive", "")

    return (
        event_narration_directive(state, resolved_event)
        + _foreground_pressure_directive(resolved_event)
        + affliction_boundary
        + skirmish_dir
    )


def _affliction_narration_directive(event: dict[str, Any] | None) -> str:
    if not isinstance(event, dict):
        return ""
    pieces: list[str] = []
    removed = event.get("conditions_removed")
    if isinstance(removed, list) and removed:
        names = ", ".join(str(name) for name in removed if str(name).strip())
        if names:
            pieces.append(
                f" CURE COMMITTED: these conditions are no longer active: {names}. "
                "Narrate their relief without continuing their symptoms or former anatomical detail as "
                "a current wound, and do not remove any condition not listed."
            )
    added = affliction_added_from_event(event)
    if isinstance(added, dict):
        name = str(added.get("name") or "Affliction")
        source = str(added.get("source") or "the resolved harm")
        if added.get("affliction_kind") == "untreated_wound":
            pieces.append(
                f" ACTIVE CONDITION: {name} is now mechanically committed from {source}. "
                "In one short ordinary-prose sentence, state exactly what this single wound is and where. "
                "Name exactly one wounded body area, but add no "
                "extra HP loss or second injury. The condition persists after this response."
            )
        else:
            pieces.append(
                f" ACTIVE CONDITION: {name} is now mechanically committed from {source}. "
                "Make its onset perceptible without adding unrecorded HP loss or another condition."
            )
    tick = event.get("affliction_tick")
    if isinstance(tick, dict):
        loss = int(tick.get("hp_lost", 0) or 0)
        pieces.append(
            f" AFFLICTION PROGRESSION: {tick.get('name') or 'The condition'} now costs exactly {loss} HP, "
            f"from {tick.get('hp_before')} to {tick.get('hp_after')}. "
            + (
                "Its damaging course ends after this beat."
                if tick.get("expired")
                else "It remains active and is not cured by this progression."
            )
            + " Do not add another tick, condition, or consequence."
        )
    return "".join(pieces)


def moored_vessel_invariant(state: dict[str, Any], resolved_event: dict[str, Any] | None) -> str:
    """A ship the player merely walked aboard does not sail on its own.

    Without a booked voyage the engine keeps the player at the quay; the
    narrator must not supply a crossing or an arrival that play never made.
    """

    location = state.get("locations", {}).get(str(state.get("current_location_id") or ""), {})
    if not isinstance(location, dict) or location.get("kind") != "vessel":
        return ""
    mooring = location.get("vessel_location") if isinstance(location.get("vessel_location"), dict) else {}
    if mooring.get("status") != "moored":
        return ""
    voyage = state.get("voyage") if isinstance(state.get("voyage"), dict) else None
    if voyage and voyage.get("phase") != "completed":
        return ""
    if isinstance(resolved_event, dict) and str(resolved_event.get("type") or "").startswith(("voyage", "passage")):
        return ""
    name = str(location.get("name") or "This ship")
    return (
        f"\nMOORED VESSEL: {name} is tied up at the quay and no passage aboard it is booked or under way. "
        "Do not narrate casting off, a crossing, days at sea or an arrival anywhere; the ship stays moored. "
        "Passage must first be agreed and paid with the harbourmaster or the captain."
    )


def location_narration_invariant(resolved_event: dict[str, Any] | None) -> str:
    """Keep cinematic follow-through from silently becoming travel."""

    event = resolved_event if isinstance(resolved_event, dict) else {}
    event_type = event.get("type")
    if event_type == 'voyage_resolution':
        return '\nVOYAGE INVARIANT: Narrate only the returned movement and voyage transition. Without a committed movement subevent, keep the exact local position. Arrival alone is a mooring change, not disembarkation. Do not invent intermediate moves, boarding or sleep recovery.'
    movement_committed = bool(
        (event_type in {"movement", "local_movement"} and event.get("committed"))
        or (event_type == "compound_resolution" and isinstance(event.get("movement"), dict))
        or (event_type == "resource_movement_resolution" and isinstance(event.get("movement"), dict))
        or (event_type == "hidden_access_opened" and isinstance(event.get("movement"), dict))
    )
    if movement_committed:
        return ""
    return (
        "\nLOCATION INVARIANT: No movement is committed this turn. Keep the player in the exact current "
        "place and local scene position; do not enter or leave a site, board, depart, travel, or arrive elsewhere."
    )


def turn_format_instruction(state: dict[str, Any]) -> str:
    """Vary compact response shape without consuming the mechanical RNG."""

    material = (
        f"{state.get('campaign_id', '')}:{int(state.get('turn_no', 0) or 0)}:turn-format"
    ).encode("utf-8")
    selector = hashlib.sha256(material).digest()[0]
    if selector < 192:  # 75%: a single compact paragraph.
        return "For this turn, use one compact paragraph."
    return (
        "For this turn, use no more than two short paragraphs; use the second "
        "only for a distinct new beat."
    )


def action_for_narrator(player_text: str, resolved_event: dict[str, Any] | None) -> str:
    """Remove a small model's strongest contradiction on rejected transactions."""

    if not resolved_event:
        return player_text
    event_type = resolved_event.get("type")
    if event_type == 'voyage_resolution':
        return f"Resolve only this committed voyage action: {resolved_event}. No further time skip or extra hazard roll."
    if event_type == "passage_purchase":
        if not resolved_event.get("success"):
            return (
                f"The player attempts to accept passage costing {resolved_event.get('price')} silver, "
                f"but it is rejected: {resolved_event.get('reason') or 'insufficient funds'}; the payment and departure fail."
            )
        else:
            return (
                f"Passage purchased for {resolved_event.get('price')} silver. "
                f"The booking is for {resolved_event.get('destination_name')}, "
                f"{resolved_event.get('departure_label')}, aboard {resolved_event.get('vessel_name')}. "
                "Record the paid entitlement. Keep the player at the payment location; departure and arrival have not occurred."
            )
    if event_type in {"resource_transfer", "compound_resource_transfer"} and not resolved_event.get("success"):
        return (
            f"The player attempts this resource action: {player_text}\n"
            f"It does not commit because {resolved_event.get('reason') or 'the transfer is not established'}."
        )
    if event_type == "resource_roll_resolution":
        roll = resolved_event.get("roll") if isinstance(resolved_event.get("roll"), dict) else {}
        resource = resolved_event.get("resource") if isinstance(resolved_event.get("resource"), dict) else {}
        outcome = str(roll.get("outcome") or "failure").replace("_", " ").upper()
        if resource.get("type") == "resource_negotiation":
            if resource.get("success") is True:
                return (
                    f"The player's negotiation attempt resolves as {outcome}. It succeeds only in winning "
                    "one replacement offer inside the recorded range. No offer is accepted; no item or "
                    "silver changes hands."
                )
            return (
                f"The player's negotiation attempt resolves as {outcome}. The existing offer remains "
                "unchanged; no item or silver changes hands."
            )
        return (
            f"The player commits to this resource action: {player_text}\n"
            f"Its roll has already resolved as {outcome}; narrate only the recorded transfer result."
        )
    if event_type == "resource_movement_resolution":
        roll = resolved_event.get("roll") if isinstance(resolved_event.get("roll"), dict) else None
        resource = resolved_event.get("resource") if isinstance(resolved_event.get("resource"), dict) else {}
        movement = resolved_event.get("movement") if isinstance(resolved_event.get("movement"), dict) else {}
        if resource.get("type") == "resource_quote_required":
            return (
                f"The player travels to {movement.get('to_name')} and, after arriving, requests the price "
                f"for {resource.get('quantity', 1)} {resource.get('item')}. The arrival is committed, but "
                "the resulting quote is not accepted and nothing is transferred."
            )
        outcome = (
            str(roll.get("outcome") or "success").replace("_", " ").upper()
            if roll
            else "SUCCESS"
        )
        return (
            f"The player commits to this combined take-and-depart action: {player_text}\n"
            f"It has already resolved as {outcome}: the recorded objects are carried and arrival at "
            f"{movement.get('to_name')} is committed."
        )
    if event_type == "compound_resolution":
        roll = resolved_event.get("roll") if isinstance(resolved_event.get("roll"), dict) else {}
        movement = resolved_event.get("movement") if isinstance(resolved_event.get("movement"), dict) else {}
        outcome = str(roll.get("outcome") or "success").replace("_", " ").upper()
        if str(roll.get("reason") or "").startswith("escape "):
            return (
                f"The player's committed escape has already resolved as {outcome}. The player has broken "
                f"the immediate pursuit and arrived at {movement.get('to_name')}; narrate what follows from "
                "that completed result. Every figure from the preceding danger remains behind, off-stage, "
                "and out of physical contact for this response."
            )
        return (
            f"The player commits to this action: {player_text}\n"
            f"It has already resolved as {outcome}, including committed arrival at {movement.get('to_name')}. "
            "This newest action is the foreground beat; do not substitute an unfinished earlier exchange."
        )
    if event_type in {"movement", "local_movement"} and resolved_event.get("committed"):
        if "voyage" in player_text.casefold() or "journey" in player_text.casefold() or "fast" in player_text.casefold() or "wait" in player_text.casefold() or "skip" in player_text.casefold():
            return (
                f"The player's travel action commits mechanically. They are now arriving at {resolved_event.get('to_name')}. "
                "FAST-FORWARD THE TRANSITION: Summarize any intervening time or travel smoothly and narrate "
                "their arrival at the destination now. Do not leave them hanging mid-journey."
            )
        return player_text
    if event_type == "d20_resolution":
        outcome = str(resolved_event.get("outcome") or "failure").replace("_", " ").upper()
        return (
            f"The player commits to this action: {player_text}\n"
            f"The roll has already resolved as {outcome}; narrate its immediate aftermath."
        )
    return player_text


def _alternating_history(recent_turns: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Produce a chat-template-compatible sequence from stored turns.

    Opening narration is intentionally not shown as a fake player message in
    the UI, so the persisted transcript can begin with an assistant turn. A
    failed generation can also leave two player turns adjacent. The model's chat
    template rejects both shapes before inference; a small synthetic opening
    cue and same-role coalescing preserve the content without inventing events.
    """

    history: list[dict[str, str]] = []
    for row in recent_turns[-12:]:
        speaker = str(row.get("speaker") or "").casefold()
        role = "assistant" if speaker in {"gm", "aether harbor", "assistant"} else "user"
        content = str(row.get("text") or "").strip()
        if not content:
            continue
        if not history and role == "assistant":
            history.append(
                {
                    "role": "user",
                    "content": "Open the current voyage at the established starting place.",
                }
            )
        if history and history[-1]["role"] == role:
            history[-1]["content"] += "\n\n" + content
        else:
            history.append({"role": role, "content": content})
    return history


def _location_memory_for_prompt(
    location: dict[str, Any], recent_turns: list[dict[str, Any]]
) -> tuple[str | None, str | None]:
    """Avoid repeating a location excerpt that is already in live dialogue.

    The excerpt remains stored verbatim and returns to the prompt after its
    defining narration ages out of the short transcript window.  While that
    narration is still present, the transcript is the single source so a small
    model is not encouraged to restart the scene.
    """

    assistant_text = "\n\n".join(
        str(row.get("text") or "")
        for row in recent_turns[-12:]
        if str(row.get("speaker") or "").casefold()
        in {"gm", "aether harbor", "assistant"}
    )

    def folded(value: Any) -> str:
        # Summary text removes Markdown emphasis for the compact UI strip, so
        # ignore those marks when comparing it with the verbatim transcript.
        return " ".join(str(value or "").replace("*", "").replace("_", "").split()).casefold()

    recent_folded = folded(assistant_text)
    summary = location.get("summary")
    excerpt = location.get("defining_excerpt")
    prompt_summary = None if folded(summary) and folded(summary) in recent_folded else summary
    prompt_excerpt = None if folded(excerpt) and folded(excerpt) in recent_folded else excerpt
    return prompt_summary, prompt_excerpt


def _compact_site_geometry(
    memory: dict[str, Any] | None,
    current_position: str | None,
    *,
    observed_only: bool = False,
    recall_area: str | None = None,
    recall_text: str = "",
    overview_turn: int = 0,
    overview_seed: str = "",
) -> dict[str, Any] | None:
    """Private GM view of the complete stored site, including allocation state."""

    if not isinstance(memory, dict):
        return None

    def key(value: Any) -> str:
        return re.sub(r"[^a-z0-9]+", " ", str(value or "").casefold()).strip()

    all_areas = [row for row in memory.get("areas", []) if isinstance(row, dict)]
    all_connections = [row for row in memory.get("connections", []) if isinstance(row, dict)]
    areas = (
        [row for row in all_areas if row.get("status") == "observed"]
        if observed_only
        else all_areas
    )
    connections = (
        [row for row in all_connections if row.get("status") == "observed"]
        if observed_only
        else all_connections
    )
    by_name = {key(row.get("name")): row for row in areas if key(row.get("name"))}
    focus = key(current_position or memory.get("current_position") or memory.get("site_name"))
    selected: list[str] = []

    def take(name_key: str) -> None:
        if name_key in by_name and name_key not in selected:
            selected.append(name_key)

    take(focus)
    for row in connections:
        left, right = key(row.get("from")), key(row.get("to"))
        if focus and focus in {left, right}:
            take(left)
            take(right)
    for row in areas:
        if row.get("status") == "observed":
            take(key(row.get("name")))
    for row in areas:
        take(key(row.get("name")))

    selected_set = set(selected)
    visible_connections = [
        {
            "from": row.get("from"),
            "to": row.get("to"),
            "via": row.get("via"),
            "status": row.get("status"),
            **({"unlocked": row["unlocked"]} if "unlocked" in row else {}),
        }
        for row in connections
        if key(row.get("from")) in selected_set and (
            key(row.get("to")) in selected_set
            or key(row.get("to")).startswith("unresolved beyond")
        )
    ]
    # Relevance precedes recency: returning to an old sub-area must recall
    # its buildings even after eight newer sites were discovered elsewhere.
    children = [row for row in memory.get("child_sites", []) if isinstance(row, dict)]
    focus_keys = {focus, key(recall_area)} - {""}
    local_children = [row for row in children if key(row.get("at_area")) in focus_keys]
    other_children = [row for row in children if key(row.get("at_area")) not in focus_keys]
    archived = [row for row in memory.get("archived_child_sites", []) if isinstance(row, dict)]
    # An explicitly named older building remains retrievable inside the same budget.
    mentioned = [row for row in children + archived if key(row.get("site_name"))
                 and f" {key(row['site_name'])} " in f" {key(recall_text)} "]
    # Shuffle once per campaign, then rotate per turn: every nonlocal landmark
    # gets a chance without consuming game RNG or changing repeated previews.
    regional = other_children + [row for row in archived if key(row.get("at_area")) not in focus_keys]
    regional.sort(key=lambda row: hashlib.sha256(
        f"{overview_seed}:{row.get('site_id')}".encode("utf-8")).digest())
    if regional:
        offset = int(overview_turn) % len(regional)
        regional = regional[offset:] + regional[:offset]
    visible_children, seen_sites, per_area = [], set(), {}
    for row in mentioned + list(reversed(local_children)) + regional:
        area_key = key(row.get("at_area"))
        if row.get("site_id") in seen_sites or per_area.get(area_key, 0) >= 3:
            continue
        visible_children.append(row)
        seen_sites.add(row.get("site_id"))
        per_area[area_key] = per_area.get(area_key, 0) + 1
        if len(visible_children) == 5:
            break

    salient_keys = {focus, key(recall_area)} - {""}
    for row in visible_connections:
        left, right = key(row.get("from")), key(row.get("to"))
        if focus and focus in {left, right}:
            if left:
                salient_keys.add(left)
            if right:
                salient_keys.add(right)
    if recall_text:
        recalled_text_folded = f" {key(recall_text)} "
        for name_key in by_name:
            if f" {name_key} " in recalled_text_folded:
                salient_keys.add(name_key)

    internal_engine_flags = {
        "defining_excerpt", "room_memory", "interest_decided",
        "interest_realized_at_turn", "observed_at_turn",
    }

    allocation = copy.deepcopy(memory.get("interest_allocation"))

    plan_lock_raw = memory.get("plan_lock")
    plan_lock_prompt = None
    if isinstance(plan_lock_raw, dict):
        plan_lock_prompt = {
            "locked": True,
            "entry_area": plan_lock_raw.get("entry_area"),
        }

    return {
        "complete_private_overview": True,
        "interest_allocation": allocation,
        "material_baseline": memory.get("material_baseline"),
        "private_contents_rule": "Full stored allocations for GM continuity, not player knowledge. Realize existing seeds only under the original first-reveal rules; do not reroll, grant loot or force activity.",
        "plan_lock": plan_lock_prompt,
        "topology_rule": "Sealed: reveal existing structure only. Omitted areas are not absent; never invent rooms or doors. Connections describe access constraints, not permission to cross." if memory.get("plan_lock") else None,
        "site_name": memory.get("site_name"),
        "site_summary": memory.get("site_summary"),
        "site_scale": memory.get("site_scale"),
        "current_position": current_position or memory.get("current_position"),
        "known_area_count": len(areas),
        "entry_relations": list(
            memory.get("entry_relations")
            or ([memory.get("entry_relation")] if memory.get("entry_relation") else [])
        )[-4:],
        "exterior_facts": list(memory.get("exterior_facts") or []),
        "areas": [
            {
                **{
                    k: copy.deepcopy(v)
                    for k, v in by_name[name_key].items()
                    if k not in internal_engine_flags and (name_key in salient_keys or k != "physical_character")
                },
                "name": by_name[name_key].get("name"),
                "placement": by_name[name_key].get("placement"),
                "status": by_name[name_key].get("status"),
                **(
                    {"physical_character": by_name[name_key].get("physical_character")}
                    if (name_key in salient_keys or by_name[name_key].get("status") == "observed")
                    and by_name[name_key].get("physical_character")
                    else {}
                ),
                "room_recall": (
                    format_room_recall_for_prompt(by_name[name_key])
                    if memory.get("plan_lock") and recall_area and name_key == key(recall_area)
                    and by_name[name_key].get("status") == "observed"
                    else None
                ),
            }
            for name_key in selected
        ],
        "connections": visible_connections,
        "child_sites": visible_children,
        "child_sites_rule": "Each child site stays at its established sub-area. Entry relations describe access; omitted sites still exist. Do not invent precise bearings or distances." if children else None,
        "uncertainties": list(memory.get("uncertainties") or []),
    }


def _local_movement_event(event: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(event, dict):
        return None
    if event.get("type") == "local_movement":
        return event if event.get("committed") else None
    movement = event.get("movement")
    return (
        movement
        if isinstance(movement, dict)
        and movement.get("type") == "local_movement"
        and movement.get("committed")
        else None
    )


def _hidden_current_for_prompt(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> dict[str, str] | None:
    """Inject at most one private current, relevantly or on a sparse deterministic beat."""

    root_id = active_site_root_id(state)
    location = state.get("locations", {}).get(root_id) or current_location(state)
    site = location.get("site_memory") if isinstance(location.get("site_memory"), dict) else {}
    structured_names = (
        {
            " ".join(str(value).casefold().split())
            for value in [location.get("name"), *(location.get("aliases") or []), site.get("site_name")]
            if str(value or "").strip()
        }
        if site
        else set()
    )

    def superseded_layout(current: dict[str, Any]) -> bool:
        if str(current.get("kind") or "") != "site_layout" or not structured_names:
            return False
        subjects = [current.get("subject"), *(current.get("target_aliases") or [])]
        return any(
            " ".join(str(subject).casefold().split()) in structured_names
            for subject in subjects
            if str(subject or "").strip()
        )

    currents = [
        current
        for current in state.get("hidden_currents", [])[:2]
        if isinstance(current, dict)
        and str(current.get("subject") or "").strip()
        and str(current.get("truth") or "").strip()
        and not superseded_layout(current)
    ]
    from .world_clock import prompt_current as _clock_current

    clock = _clock_current(state)
    if clock is not None:
        clock_text = " ".join(
            str(row.get("text") or "") for row in recent_turns[-4:] if isinstance(row, dict)
        )
        clock_position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
        clock_haystack = (
            f"{location.get('name', '')} {clock_position.get('label', '')} {clock_text} {player_text}"
        ).casefold()
        clock_digest = hashlib.sha256(
            f"{state.get('campaign_id', '')}:{int(state.get('turn_no', 0) or 0)}:world-clock".encode("utf-8")
        ).digest()
        fresh = int(state.get("turn_no", 0) or 0) == int(clock.get("updated_at_turn", -999) or -999) + 1
        subject = str(clock.get("subject") or "")
        names = [
            word.casefold() for word in re.findall(r"\b[A-Z][a-z]{2,}\b", subject)
            if word.casefold() not in {"the", "old", "young", "his", "her", "their", "one", "two"}
        ]
        on_stage = subject.casefold() in clock_haystack or any(
            re.search(rf"\b{re.escape(name)}\b", clock_haystack) for name in names
        )
        # Someone already in the scene acts through the narration itself; a
        # stale off-screen step about them once undid a player's success.
        if not on_stage and (
            fresh  # offered once right after it is created or advanced
            or clock_digest[0] < 64  # otherwise roughly one quiet beat in four
        ):
            return {
                "kind": "world_pressure",
                "subject": str(clock.get("subject") or "")[:100],
                "target_aliases": [],
                "truth": str(clock.get("truth") or "")[:360],
                "outward_tell": str(clock.get("outward_tell") or "")[:240],
                "reveal_if": str(clock.get("reveal_if") or "")[:240],
                "required_item": "",
                "urgency": str(clock.get("urgency") or "stirring"),
            }
    if not currents:
        return None
    recent_text = " ".join(
        str(row.get("text") or "")
        for row in recent_turns[-4:]
        if isinstance(row, dict)
    )
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    haystack = (
        f"{location.get('name', '')} {position.get('label', '')} {recent_text} {player_text}"
    ).casefold()
    selected = next(
        (
            current
            for current in currents
            if str(current.get("subject") or "").casefold() in haystack
        ),
        None,
    )
    if selected is None:
        selected = next(
            (current for current in currents if current.get("urgency") == "imminent"),
            None,
        )
    if selected is None:
        material = (
            f"{state.get('campaign_id', '')}:{int(state.get('turn_no', 0) or 0)}:hidden-current"
        ).encode("utf-8")
        digest = hashlib.sha256(material).digest()
        if digest[0] >= 32:  # roughly one quiet background beat in eight
            return None
        selected = currents[digest[1] % len(currents)]
    return {
        "kind": str(selected.get("kind") or "world_pressure"),
        "subject": str(selected.get("subject") or "")[:100],
        "target_aliases": list(selected.get("target_aliases") or [])[:3],
        "truth": str(selected.get("truth") or "")[:360],
        "outward_tell": str(selected.get("outward_tell") or "")[:240],
        "reveal_if": str(selected.get("reveal_if") or "")[:240],
        "required_item": str(selected.get("required_item") or "")[:100],
        "urgency": str(selected.get("urgency") or "dormant"),
    }


def _memory_evidence_for_prompt(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
    memory_evidence: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Retrieve a few relevant verbatim shards; the rolling recap carries the rest."""

    if not memory_evidence:
        return []
    root_id = active_site_root_id(state)
    location = state.get("locations", {}).get(root_id) or current_location(state)
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    recent_text = " ".join(
        str(row.get("text") or "")
        for row in recent_turns[-4:]
        if isinstance(row, dict)
    )
    haystack = (
        f"{location.get('name', '')} {position.get('label', '')} {recent_text} {player_text}"
    ).casefold()
    scored: list[tuple[int, int, dict[str, Any]]] = []
    for index, row in enumerate(memory_evidence):
        if not isinstance(row, dict):
            continue
        subject = " ".join(str(row.get("subject") or "").split()).casefold()
        tokens = [token for token in subject.replace("'", " ").split() if len(token) >= 4]
        score = 0
        if subject and subject in haystack:
            score += 12
        elif any(token in haystack for token in tokens):
            score += 5
        if score:
            score += min(3, int(row.get("priority", 0) or 0))
            if row.get("status") in {"open", "rumor"}:
                score += 1
            scored.append((score, index, row))
    scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
    selected = [row for _score, _index, row in scored[:3]]

    # On a sparse deterministic beat, one unrelated exact shard may texture the
    # scene. This is retrieval, not a fallback and not a mandatory complication.
    if len(selected) < 3:
        material = (
            f"{state.get('campaign_id', '')}:{int(state.get('turn_no', 0) or 0)}:memory-texture"
        ).encode("utf-8")
        digest = hashlib.sha256(material).digest()
        if digest[0] < 32:
            remaining = [row for row in memory_evidence if row not in selected]
            if remaining:
                selected.append(remaining[digest[1] % len(remaining)])
    return selected[:3]


_GENERIC_NPC_LABELS = {
    "man", "woman", "person", "figure", "young man", "young woman",
    "older man", "older woman", "middle aged man", "middle aged woman",
    "servant", "guard", "soldier", "worker", "clerk", "merchant", "sailor",
    "porter", "patrolman", "attendant",
}
_NPC_MATCH_STOP = {
    "the", "and", "with", "from", "into", "room", "floor", "hallway",
    "corridor", "young", "older", "middle", "aged", "man", "woman",
    "person", "figure", "emerging",
}


def _npc_match_tokens(value: Any) -> list[str]:
    folded = re.sub(r"[^a-z0-9 ]+", " ", str(value or "").casefold())
    return [
        token for token in folded.split()
        if len(token) >= 4 and token not in _NPC_MATCH_STOP
    ]


def _relevant_npc_profiles(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> list[dict[str, Any]]:
    """Expose compact NPC continuity only while that person is in narrative focus.

    Full hidden cards remain in state. Off-screen NPCs therefore cost zero
    prompt tokens until a name/anchor or very recent interaction makes them
    relevant again. Provisional latent_seed material is deliberately not sent
    to the narrator; it stays private until a later subsystem earns it.
    """
    npcs = state.get("npcs") if isinstance(state.get("npcs"), dict) else {}
    if not npcs:
        return []
    recent_rows = [row for row in recent_turns[-8:] if isinstance(row, dict)]
    recent_text = " ".join(str(row.get("text") or "") for row in recent_rows)
    location = current_location(state)
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    current_root = active_site_root_id(state)
    player_folded = str(player_text or "").casefold()
    haystack = " ".join([
        str(location.get("name") or ""),
        str(position.get("label") or ""),
        recent_text,
        str(player_text or ""),
    ]).casefold()
    latest_sequence = max([int(row.get("sequence_no", 0) or 0) for row in recent_rows] or [0])
    scored: list[tuple[int, str, dict[str, Any]]] = []
    for npc_id, card in npcs.items():
        if not isinstance(card, dict):
            continue
        profile = card.get("hidden_profile") if isinstance(card.get("hidden_profile"), dict) else {}
        if not profile:
            continue
        name = " ".join(str(card.get("name") or "").split())[:120]
        anchor = " ".join(str(card.get("anchor") or name).split())[:120]
        name_folded = re.sub(r"[^a-z0-9 ]+", " ", name.casefold()).strip()
        anchor_folded = re.sub(r"[^a-z0-9 ]+", " ", anchor.casefold()).strip()
        anchor_tokens = _npc_match_tokens(anchor)
        explicit_reference = bool(
            (name_folded and name_folded not in _GENERIC_NPC_LABELS and name_folded in player_folded)
            or (anchor_folded and anchor_folded in player_folded)
            or (
                anchor_tokens
                and sum(1 for token in anchor_tokens if token in player_folded)
                >= min(2, len(anchor_tokens))
            )
        )
        card_scope = str(card.get("site_root_id") or "")
        if card_scope and card_scope != current_root and not explicit_reference:
            continue
        score = 0
        if name_folded and name_folded not in _GENERIC_NPC_LABELS and name_folded in haystack:
            score += 14
        if anchor_folded and anchor_folded in haystack:
            score += 14
        else:
            hits = sum(1 for token in anchor_tokens if token in haystack)
            if hits >= min(2, len(anchor_tokens)) and hits > 0:
                score += 8 + min(3, hits)
        role_tokens = _npc_match_tokens(profile.get("role"))
        role_hits = sum(1 for token in role_tokens if token in haystack)
        if role_hits >= 2:
            score += 4
        last_sequence = int(card.get("last_profile_sequence", 0) or 0)
        if latest_sequence and last_sequence and 0 <= latest_sequence - last_sequence <= 4:
            score += 6
        if score < 6:
            continue
        compact = {
            "id": str(npc_id),
            "identity": anchor or name,
            "tier": str(card.get("profile_tier") or "encountered"),
            "role": str(profile.get("role") or "")[:180],
            "demeanor": str(profile.get("demeanor") or "")[:180],
            "current_goal": str(profile.get("current_goal") or "")[:220],
            "current_pressure": str(profile.get("current_pressure") or "")[:220],
            "attitude_to_player": str(profile.get("attitude_to_player") or "")[:180],
            "promise_or_debt": str(profile.get("promise_or_debt") or "")[:220],
            "signature": str((list(card.get("signature_shards") or [])[-1:] or [""])[0])[:260],
            "relations": [str(value)[:260] for value in list(card.get("relations") or [])[-2:]],
        }
        scored.append((score, str(npc_id), compact))
    scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
    selected = [item[2] for item in scored[:2]]
    turn_no = int(state.get("turn_no", 0) or 0)
    for compact in selected:
        card = npcs[compact["id"]]
        profile = card.get("hidden_profile") if isinstance(card.get("hidden_profile"), dict) else {}
        appearance = str(profile.get("appearance") or card.get("appearance") or "")[:220]
        if not appearance:
            continue
        requested = _npc_appearance_requested(player_text, card, allow_pronoun=len(selected) == 1)
        # 30% deterministic mechanical gate for general narration
        material = f"{state.get('campaign_id', '')}:{turn_no}:{compact['id']}:appearance_cue".encode("utf-8")
        digest = hashlib.sha256(material).digest()
        random_cue = (digest[0] < 77)  # 77/256 ≈ 30%
        if requested or random_cue:
            compact["appearance"] = appearance
    return selected


def _npc_appearance_requested(
    player_text: str, card: dict[str, Any], *, allow_pronoun: bool,
) -> bool:
    """Recall stored looks for a directed observation, not any 'look' verb.

    This is prompt retrieval only: it changes neither the card nor action
    classification. Ambiguous pronouns with multiple active people do not
    expose everybody's appearance.
    """
    profile = card.get("hidden_profile") or {}
    aliases = [str(card.get(key) or "").strip() for key in ("name", "anchor")]
    role = str(profile.get("role") or "").strip()
    if role and len(role.split()) == 1:
        aliases.append(role)
    targets = [re.escape(alias) for alias in aliases if alias]
    observed_targets = list(targets)
    if allow_pronoun:
        targets.extend(["him", "her", "them", "he", "she", "they", "his", "their"])
        observed_targets.append(r"(?:him|her|them)(?=\s*(?:[.!?,;:]|$)|\s+(?:closely|carefully)\b)")
    if not targets:
        return False
    target = r"\b(?:the\s+)?(?:" + "|".join(targets) + r")\b"
    observed_target = r"\b(?:the\s+)?(?:" + "|".join(observed_targets) + r")\b"
    observation = (
        r"\b(?:look\s+(?:closely\s+)?at|examine|inspect|study|describe|recognize|recognise)\s+"
        + observed_target
        + r"(?!['’]s\b)"
    )
    description = r"\bwhat\s+(?:does|do|did)\s+" + target + r"\s+look\s+like\b"
    features = (
        target + r"(?:['’]s)?\s+(?:face|eyes|hair|scar|scars|clothes|clothing|appearance|build|physique)\b"
        + "|" + r"\b(?:appearance|description)\s+of\s+" + target
    )
    return bool(re.search("|".join((observation, description, features)), player_text, re.I))


_CONTEXT_JSON_CHAR_BUDGET = 12_500


def _combat_episode_for_prompt(state: dict[str, Any]) -> dict[str, Any] | None:
    """Keep one fight legible without retaining every raw combat turn forever."""

    episode = state.get("combat_episode")
    if not isinstance(episode, dict):
        return None
    active = episode.get("status") == "active"
    ended_turn = int(episode.get("ended_turn", -999) or -999)
    if not active and int(state.get("turn_no", 0) or 0) - ended_turn > 8:
        return None
    return {
        "status": episode.get("status"),
        "opponents": episode.get("opponents"),
        "location": episode.get("location"),
        "scene_position": episode.get("scene_position"),
        "started_turn": episode.get("started_turn"),
        "ended_turn": episode.get("ended_turn"),
        "resolved_beats": episode.get("resolved_beats"),
        "rounds": episode.get("rounds"),
        "outcome": episode.get("outcome"),
        "player_hp_before": episode.get("player_hp_before"),
        "player_hp_after": episode.get("player_hp_after"),
        "opponent_hp_before": episode.get("opponent_hp_before"),
        "opponent_hp_after": episode.get("opponent_hp_after"),
        "pre_combat_excerpt": list(episode.get("prelude") or [])[-2:],
        "opening_excerpt": str(episode.get("opening_excerpt") or "")[:650],
        "ending_excerpt": str(episode.get("ending_excerpt") or "")[:650],
    }


def _clip_context_text(value: Any, limit: int) -> Any:
    if not isinstance(value, str) or len(value) <= limit:
        return value
    clipped = value[:limit].rsplit(" ", 1)[0].rstrip(" ,;:-")
    return clipped + "…"


def _clip_recap_text(value: Any, limit: int) -> Any:
    """Preserve both the opening anchor and the latest developments when clipping a recap."""

    if not isinstance(value, str) or len(value) <= limit:
        return value
    head_len = max(120, limit // 3)
    tail_len = max(120, limit - head_len - 3)
    if head_len + tail_len + 3 > limit:
        clipped_tail = value[-(limit - 1):]
        if " " in clipped_tail:
            clipped_tail = clipped_tail.split(" ", 1)[1]
        return "…" + clipped_tail
    head = value[:head_len].rsplit(" ", 1)[0].rstrip(" ,;:-")
    tail = value[-tail_len:]
    if " " in tail:
        tail = tail.split(" ", 1)[1]
    return f"{head} … {tail}"


def _fit_context_budget(context: dict[str, Any], *, maximum_chars: int = _CONTEXT_JSON_CHAR_BUDGET) -> bool:
    """Protect world/site authority; trim older redundant context around it."""
    protected = {}
    place = context.get('current_place') or {}
    geometry = place.get('authoritative_site_geometry')
    if isinstance(geometry, dict) and geometry.get('complete_private_overview'):
        protected['geometry'] = place.pop('authoritative_site_geometry')
    for key in ('private_island_overview', 'private_voyage_destination',
                'recent_mechanical_ledger', 'recent_resource_outcomes'):
        if context.get(key) is not None: protected[key] = context.pop(key)
    protected_size = len(json.dumps(protected, ensure_ascii=False, separators=(',', ':')))
    try:
        changed = _fit_redundant_context(context, maximum_chars=max(0, maximum_chars-protected_size))
    finally:
        for key,value in protected.items():
            if key == 'geometry': place['authoritative_site_geometry'] = value
            else: context[key] = value
    if len(json.dumps(context, ensure_ascii=False, separators=(',', ':'))) > maximum_chars:
        context['context_budget_preserved_authority'] = True
    return changed


def _fit_redundant_context(
    context: dict[str, Any], *, maximum_chars: int = _CONTEXT_JSON_CHAR_BUDGET
) -> bool:
    """Trim redundant/old prompt texture only in an unusually saturated scene.

    Current player state, resolved mechanics, combat episode memory and recent
    dialogue live outside the removable tiers. The authoritative site plan
    remains complete in saved state; only its narrator-facing redundant view is
    reduced for this turn.
    """

    def size() -> int:
        return len(json.dumps(context, ensure_ascii=False, separators=(",", ":")))

    def clip_nested(value: Any, string_limit: int) -> Any:
        if isinstance(value, str):
            return _clip_context_text(value, string_limit)
        if isinstance(value, list):
            return [clip_nested(item, string_limit) for item in value]
        if isinstance(value, dict):
            return {
                key: clip_nested(item, string_limit)
                for key, item in value.items()
            }
        return value

    if size() <= maximum_chars:
        return False
    context["context_budget_compacted"] = True
    current = context.get("current_place") if isinstance(context.get("current_place"), dict) else {}
    geometry = (
        current.get("authoritative_site_geometry")
        if isinstance(current.get("authoritative_site_geometry"), dict)
        else {}
    )
    spine = geometry.get("site_spine") if isinstance(geometry.get("site_spine"), dict) else {}

    tiers = (
        (18, 18, 8, 10, 6, 3, 2, 2200),
        (12, 12, 6, 8, 4, 2, 2, 1600),
        (8, 8, 4, 6, 3, 2, 1, 1100),
    )
    for names, links, areas, connections, exterior, entries, uncertainties, recap_limit in tiers:
        if spine:
            spine["area_names"] = list(spine.get("area_names") or [])[:names]
            spine["links"] = list(spine.get("links") or [])[:links]
        if geometry:
            geometry["areas"] = list(geometry.get("areas") or [])[:areas]
            geometry["connections"] = list(geometry.get("connections") or [])[:connections]
            geometry["exterior_facts"] = list(geometry.get("exterior_facts") or [])[:exterior]
            geometry["entry_relations"] = list(geometry.get("entry_relations") or [])[-entries:]
            geometry["uncertainties"] = list(geometry.get("uncertainties") or [])[:uncertainties]
        context["rolling_campaign_recap"] = _clip_recap_text(
            context.get("rolling_campaign_recap"), recap_limit
        )
        if size() <= maximum_chars:
            return True

    # Final rare tier: remove the redundant full-site spine, retaining the
    # focused areas, visible connections and current position above.
    if geometry:
        geometry.pop("site_spine", None)
        geometry["site_summary"] = _clip_context_text(geometry.get("site_summary"), 700)
    current["summary"] = _clip_context_text(current.get("summary"), 500)
    current["defining_excerpt"] = _clip_context_text(current.get("defining_excerpt"), 700)
    position = current.get("local_scene_position")
    if isinstance(position, dict):
        position["summary"] = _clip_context_text(position.get("summary"), 450)
        position["defining_excerpt"] = _clip_context_text(position.get("defining_excerpt"), 600)
    context["relevant_campaign_memory"] = list(context.get("relevant_campaign_memory") or [])[-2:]
    context["recent_resource_outcomes"] = list(context.get("recent_resource_outcomes") or [])[-4:]
    context["recent_mechanical_ledger"] = list(context.get("recent_mechanical_ledger") or [])[-4:]
    context["available_objects_here"] = list(context.get("available_objects_here") or [])[:24]
    if size() > maximum_chars:
        if geometry:
            for key in (
                "site_summary", "entry_relations", "exterior_facts", "areas",
                "connections", "uncertainties",
            ):
                geometry[key] = clip_nested(geometry.get(key), 220)
        context["relevant_campaign_memory"] = clip_nested(
            list(context.get("relevant_campaign_memory") or [])[-1:], 260
        )
        context["recent_resource_outcomes"] = clip_nested(
            list(context.get("recent_resource_outcomes") or [])[-3:], 220
        )
        context["recent_mechanical_ledger"] = clip_nested(
            list(context.get("recent_mechanical_ledger") or [])[-4:], 220
        )
        context["available_objects_here"] = clip_nested(
            list(context.get("available_objects_here") or [])[:16], 160
        )
        context["rolling_campaign_recap"] = _clip_recap_text(
            context.get("rolling_campaign_recap"), 700
        )
    return True


def build_messages(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
    resolved_event: dict[str, Any] | None,
    memory_evidence: list[dict[str, Any]] | None = None,
    shared_echo: dict[str, Any] | None = None,
    npc_seed: dict[str, Any] | None = None,
) -> list[dict[str, str]]:
    location_id = active_site_root_id(state)
    location = state.get("locations", {}).get(location_id) or current_location(state)
    location_summary, location_excerpt = _location_memory_for_prompt(location, recent_turns)
    scene_position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    geometry_location = location
    geometry_position = str(scene_position.get("label") or "") if scene_position else None
    geometry_relation: dict[str, Any] | None = None
    exterior_site_id = (
        str(scene_position.get("exterior_of_site_id") or "")
        if scene_position
        else ""
    )
    exterior_site = state.get("locations", {}).get(exterior_site_id, {})
    if exterior_site_id and isinstance(exterior_site, dict) and isinstance(
        exterior_site.get("site_memory"), dict
    ):
        # Keep the broad atlas anchor while restoring the immediately adjacent
        # site's hard topology.  This is the missing Outside Window -> Palazzo
        # retrieval path from the playtest.
        geometry_location = exterior_site
        geometry_position = str(
            exterior_site.get("site_memory", {}).get("current_position") or ""
        ) or None
        geometry_relation = {
            "kind": "immediately_outside_site",
            "site_id": exterior_site_id,
            "site_name": exterior_site.get("name"),
        }
    position_summary, position_excerpt = (
        _location_memory_for_prompt(scene_position, recent_turns)
        if scene_position
        else (None, None)
    )
    player = state["player"]
    location_id = str(location_id or state.get("current_location_id") or "")
    scene_position_id = str(scene_position.get("id")) if scene_position else None
    available_objects_here = [
        {
            "name": row.get("name"),
            "quantity": int(row.get("quantity", 1) or 1),
            "left_at_turn": row.get("left_at_turn"),
        }
        for row in state.get("scene_objects", [])
        if isinstance(row, dict)
        and row.get("status") == "available"
        and row.get("location_id") == location_id
        and row.get("scene_position_id") == scene_position_id
    ]
    connected_names: list[str] = []
    current_id = location_id
    for edge in state.get("edges", []):
        if not isinstance(edge, (list, tuple)) or len(edge) != 2:
            continue
        left, right = str(edge[0]), str(edge[1])
        other = right if left == current_id else left if right == current_id else None
        if other and other in state.get("locations", {}):
            connected_names.append(str(state["locations"][other].get("name") or other))
    hidden_current = _hidden_current_for_prompt(state, recent_turns, player_text)
    local_movement = _local_movement_event(resolved_event)
    ambiguous_local_destination = bool(
        local_movement
        and (
            local_movement.get("awaiting_spatial_position")
            or not scene_position
            or not scene_position.get("site_area")
        )
    )
    first_reveal_interests = private_area_interests(
        location.get("site_memory"),
        str(scene_position.get("label") or "") if scene_position else None,
        include_site_candidates=ambiguous_local_destination,
    )
    material_search_fate = private_material_search_fate(state, player_text, resolved_event)
    book_context = private_book_prompt_context(
        state, recent_turns, player_text, resolved_event
    )
    improvised_binding = state.get("island_bank", {}).get("bindings", {}).get(location_id, {})
    authored_island_context = private_authored_island_context(
        state, recent_turns, player_text, resolved_event
    )
    island_horizon_context = private_island_horizon_context(
        state, recent_turns, player_text
    )
    maybe_activate_scenario(state, player_text)
    scenario_context = private_scenario_context(state, recent_turns, player_text)
    active_situation_context = active_situation_prompt_context(state)
    celestial_spheres_context = private_celestial_spheres_context(
        state, recent_turns, player_text
    )
    material_reveal_fate = (
        private_material_first_reveal_fate(
            location.get("site_memory"),
            str(scene_position.get("label") or "") if scene_position else None,
        )
        if not ambiguous_local_destination
        else None
    )
    active_combat = bool(
        isinstance(state.get("combat"), dict)
        and state.get("combat", {}).get("status") == "active"
    )
    combat_history_limit = 12 if active_combat else 4
    combat_episode_context = _combat_episode_for_prompt(state)
    prompt_conditions: list[dict[str, Any]] = []
    for condition in player.get("conditions", []):
        if not isinstance(condition, dict):
            continue
        if condition.get("condition_type") != "affliction":
            prompt_conditions.append(condition)
            continue
        compact_condition = {
            "name": condition.get("name"),
            "kind": condition.get("affliction_kind"),
        }
        if condition.get("injury_detail"):
            compact_condition["injury_detail"] = condition.get("injury_detail")
        elif condition.get("source"):
            compact_condition["source"] = condition.get("source")
        prompt_conditions.append(compact_condition)
    context = {
        "current_place": {
            "id": location_id,
            "name": location.get("name"),
            "region": location.get("region"),
            "summary": location_summary,
            "defining_excerpt": location_excerpt,
            "provisional_first_arrival": bool(location.get("provisional")),
            "authoritative_site_geometry": _compact_site_geometry(
                geometry_location.get("site_memory"),
                geometry_position,
                observed_only=False,
                recall_area=room_recall_area(state, resolved_event),
                recall_text=player_text,
                overview_turn=int(state.get("turn_no", 0) or 0),
                overview_seed=str(state.get("campaign_id") or state.get("rng_seed") or ""),
            ),
            "authoritative_site_geometry_relation": geometry_relation,
            "previously_observed_connections": connected_names[-8:],
            "local_scene_position": (
                {
                    "id": scene_position.get("id"),
                    "label": scene_position.get("label"),
                    "summary": position_summary,
                    "defining_excerpt": position_excerpt,
                }
                if scene_position
                else None
            ),
        },
        "player": {
            "name": player.get("name"),
            "appearance": player.get("appearance"),
            "class": player.get("class_label"),
            "hp": player.get("hp"),
            "max_hp": player.get("max_hp"),
            "silver": player.get("silver"),
            "conditions": prompt_conditions,
            "inventory": inventory_summary(state),
            "known_spells": player.get("known_spells", []),
            "companions": player.get("companions", []),
        },
        "combat": state.get("combat"),
        "recent_combat_outcomes": list(state.get("combat_history") or [])[-combat_history_limit:],
        "available_objects_here": available_objects_here,
        "pending_commerce_offer": pending_commerce_offer(state),
        "recent_resource_outcomes": list(state.get("resource_history") or [])[-6:],
        "active_local_game": local_game_prompt_context(state),
        "recent_mechanical_ledger": [
            {
                "turn": int(row.get("turn_no", 0) or 0),
                "text": str(row.get("text") or "")[:300],
            }
            for row in list(state.get("mechanics_history") or [])[-6:]
            if isinstance(row, dict) and str(row.get("text") or "").strip()
        ],
        "stealth_and_local_alert": state.get("stealth"),
        "magic": magic_prompt_context(state, player_text),
        "economy_reference": price_reference_context(
            player_text=player_text,
            recent_turns=recent_turns,
            resolved_event=resolved_event,
        ),
        "resolved_event": resolved_event,
        "rolling_campaign_recap": (
            str(state.get("campaign_recap", {}).get("text") or "").strip() or None
        ),
        "private_hidden_current": hidden_current,
        "relevant_campaign_memory": _memory_evidence_for_prompt(
            state,
            recent_turns,
            player_text,
            list(memory_evidence or []),
        ),
        "shared_echo": (
            {
                "instruction": "A faint inherited seed from another voyage. It may surface, transform locally, or remain only a rumor; do not force it.",
                "scale": shared_echo.get("scale"),
                "kind": shared_echo.get("kind"),
                "subject": shared_echo.get("subject"),
                "text": shared_echo.get("text"),
            }
            if shared_echo
            else None
        ),
    }
    if combat_episode_context:
        context["recent_combat_episode"] = combat_episode_context
    from .voyage import context as voyage_context
    context['private_voyage'] = voyage_context(state)
    from .island_context import private_island_overview
    context['private_island_overview'] = private_island_overview(state)
    voyage = state.get('voyage') or {}
    if voyage.get('phase') in {'in_transit','interrupted','arrived'} and voyage.get('destination_id'):
        context['private_voyage_destination'] = private_island_overview(state, voyage['destination_id'])
    npc_continuity = _relevant_npc_profiles(state, recent_turns, player_text)
    if npc_continuity:
        context["relevant_npc_continuity"] = npc_continuity
    if first_reveal_interests:
        context["private_first_reveal_area_interest"] = first_reveal_interests
    if book_context:
        context["private_decorative_book"] = book_context
    if improvised_binding.get("ownership") == "improvised":
        context["private_improvised_island"] = {
            "planet": improvised_binding.get("planet"),
            "instruction": "This island is improvised within its planetary current. Preserve all established identity and geography; do not substitute an authored catalog island. Plan only relevant bounded sites with the same rules as other islands.",
        }
    if authored_island_context:
        context["private_authored_island"] = authored_island_context
    if island_horizon_context:
        context["private_known_island_horizon"] = island_horizon_context
    if scenario_context:
        context["private_active_scenario"] = scenario_context
    if active_situation_context:
        context["active_situation"] = active_situation_context
    if celestial_spheres_context:
        context["private_celestial_spheres"] = celestial_spheres_context
    # If a full material excerpt is already supplied in the authoritative turn
    # boundary, omit only its duplicate copy. Never truncate evidence mid-claim.
    material_boundary = material_search_fate or material_reveal_fate or {}
    geometry = context["current_place"].get("authoritative_site_geometry")
    allocation = geometry.get("interest_allocation") if isinstance(geometry, dict) else None
    if isinstance(allocation, dict):
        for key in ("material_realization_excerpt", "material_resolution_excerpt"):
            excerpt = allocation.get(key)
            if isinstance(excerpt, str) and excerpt and excerpt in str(material_boundary.get("rule") or ""):
                allocation.pop(key)
                allocation["material_evidence_source"] = "PRIVATE MATERIAL BOUNDARY below"
    _fit_context_budget(context)
    messages: list[dict[str, str]] = [
        {
            "role": "system",
            "content": _system_prompt_for_turn(state, recent_turns, player_text),
        },
        *_alternating_history(recent_turns),
    ]
    format_instruction = (
        "For this action beat, use one compact paragraph and end on its immediate resolved result."
        if isinstance(resolved_event, dict) and resolved_event.get("type") in {"combat_resolution", "active_situation_resolution"}
        else turn_format_instruction(state)
    )
    current_content = (
        "AUTHORITATIVE CURRENT TURN:\n"
        + json.dumps(context, ensure_ascii=False, separators=(",", ": "))
        + (
            "\n\n" + prompt_seed(npc_seed)
            if npc_seed
            else ""
        )
        + (
            "\n\nPRIVATE FIRST-REVEAL RULE:\n" + _AREA_INTEREST_TURN_INSTRUCTION
            if first_reveal_interests
            else ""
        )
        + "\n\nPLAYER ACTION, EXPRESSED AFTER MECHANICAL RESOLUTION:\n"
        + action_for_narrator(player_text, resolved_event)
        + (
            "\n\nPRIVATE MATERIAL SEARCH BOUNDARY:\n" + material_search_fate["rule"]
            if material_search_fate
            else ""
        )
        + (
            "\n\nPRIVATE MATERIAL FIRST-REVEAL BOUNDARY:\n" + material_reveal_fate["rule"]
            if material_reveal_fate and not material_search_fate
            else ""
        )
        + "\n\nNON-NEGOTIABLE NARRATION BOUNDARY:\n"
        + turn_narration_directive(state, resolved_event, player_text)
        + location_narration_invariant(resolved_event)
        + moored_vessel_invariant(state, resolved_event)
        + "\n\nTURN FORMAT FOR THIS RESPONSE:\n"
        + format_instruction
    )
    if messages[-1]["role"] == "user":
        messages[-1]["content"] += "\n\n" + current_content
    else:
        messages.append({"role": "user", "content": current_content})
    return messages


def _base_event_ledger_line(event: dict[str, Any] | None) -> str | None:
    if not event:
        return None
    event_type = event.get("type")
    if event_type == "active_situation_resolution":
        action_word = str(event.get("action") or "continue").capitalize()
        status = str(event.get("status") or "active").upper()
        before = str(event.get("before_range") or "far").lower()
        after = str(event.get("after_range") or before).lower()
        roll = event.get("roll") if isinstance(event.get("roll"), dict) else None
        roll_note = (f" · D20 {roll.get('raw')} -> {str(roll.get('outcome') or '').replace('_', ' ').upper()}" if roll else "")
        distance_str = f"Distance: {after.capitalize()}" if before == after else f"{before.capitalize()} -> {after.capitalize()}"
        return f"Chase: {action_word} · {distance_str} · {status}{roll_note}"
    if event_type == "celestial_spheres_resolution":
        if not event.get("committed"):
            return f"CELESTIAL SPHERES · not committed · {event.get('reason')}"
        if event.get("pending_press"):
            return (
                f"CELESTIAL SPHERES · MARS SEVEN (Rolled Mars 7) · Won! · Stake {event.get('stake')} · "
                f"Pending Choice: 'collect' or 'press'"
            )
        action = event.get("action")
        if action in {"press", "collect"}:
            return (
                f"CELESTIAL SPHERES · Mars Seven {str(action).upper()} · Payout {event.get('payout')} · Silver {event.get('silver_after')}"
            )
        sel = event.get("selection")
        face = event.get("celestial_face")
        mag = event.get("magnitude")
        won = event.get("won")
        payout = int(event.get("payout", 0) or 0)
        status = "WIN" if won else ("REFUND" if payout > 0 else "LOSS")
        special_str = f" · {event.get('special')}" if event.get("special") else ""
        return (
            f"CELESTIAL SPHERES · Bet: {sel} · Rolled: {face} ({mag}) · {status}{special_str} · "
            f"Payout: {payout} · Silver: {event.get('silver_after')}"
        )
    if event_type == "local_game_rules":
        return "HOUSE DICE · rules/score · no wager or roll"
    if event_type == "local_game_forfeit":
        return f"HOUSE DICE · forfeited · paid stake lost · Silver: {event.get('silver_after')}"
    if event_type == "local_game_declined":
        return "HOUSE DICE · declined · no stake"
    if event_type == "local_game_start":
        if not event.get("success"):
            return f"HOUSE DICE · not started · {event.get('reason')}"
        opp = str(event.get("opponent_name") or "").strip()
        vs_str = f" vs {opp}" if opp else ""
        return (
            f"HOUSE DICE{vs_str} · Stake {event.get('stake')} paid · "
            f"Silver: {event.get('silver_after')} · {event.get('rounds_total')} rounds"
        )
    if event_type == "local_game_round":
        opp = str(event.get("opponent_name") or "").strip()
        vs_str = f" vs {opp}" if opp else ""
        opp_tag = opp if opp else "Opponent"
        r_num = event.get("round")
        r_tot = event.get("rounds_total")
        p_tot = event.get("player_total")
        o_tot = event.get("opponent_total")
        p_sc = event.get("player_score")
        o_sc = event.get("opponent_score")
        if event.get("finished"):
            res = str(event.get("result", "")).upper()
            return (
                f"HOUSE DICE{vs_str} · Final Round {r_num}/{r_tot} · Player [{p_tot}] vs {opp_tag} [{o_tot}] · "
                f"MATCH {res} ({p_sc}-{o_sc}) · Payout: {event.get('payout')} silver · Silver: {event.get('silver_after')}"
            )
        round_res = "Round Won" if p_tot > o_tot else ("Round Lost" if o_tot > p_tot else "Round Tied")
        return (
            f"HOUSE DICE{vs_str} · Round {r_num}/{r_tot} · Player {event.get('player_dice')}={p_tot} vs {opp_tag} {event.get('opponent_dice')}={o_tot} · "
            f"{round_res} (Match Tally: {p_sc}-{o_sc}) · Next: Roll Round {int(r_num or 0) + 1}"
        )
    if event_type == "movement" and event.get("committed"):
        base_travel = f"Travel committed: {event['from_name']} → {event['to_name']}."
        if event.get("travel_hazard"):
            return f"TRAVEL INTERRUPTED BY HAZARD ({event['travel_hazard']}): Forced arrival at {event['to_name']}."
        return base_travel
    if event_type == "local_movement" and event.get("committed"):
        return f"Local position committed: {event.get('from_name')} → {event.get('to_name')}."
    if event_type == "hidden_access_blocked":
        return f"Access remains blocked: {event.get('subject')}."
    if event_type == "hidden_access_opened":
        return f"Access opened: {event.get('subject')} · {event.get('required_item')} retained."
    if event_type == "party_action":
        if event.get("committed"):
            verb = "joins the party" if event.get("action") == "recruit" else "leaves the party"
            fee = f" · {-event['silver_delta']} silver paid" if event.get("silver_delta") else ""
            hp = f" · HP {event['hp']}/{event['max_hp']}" if event.get("hp") else ""
            return f"{event['target']} {verb}{hp}{fee}."
        if event.get("profile_pending") or event.get("reason") in {"Insufficient silver to recruit.", "The party is full (maximum 1 companion)."}:
            return str(event.get("reason"))
        return None
    if event_type == "party_roll_resolution":
        return " · ".join(x for x in (event_ledger_line(event.get("roll")), event_ledger_line(event.get("party"))) if x)
    if event_type == "d20_resolution":
        label = str(event.get("outcome") or ("success" if event["success"] else "failure")).replace("_", " ").upper()
        harm = (
            f" · {event.get('critical_failure_harm')} HP lost · {event.get('hp_after')} HP remain"
            if event.get("critical_failure_harm")
            else ""
        )
        actor = event.get("actor", "Player")
        prefix = f"{actor.upper()} · " if actor != "Player" else ""
        return f"{prefix}D20 {event['raw']} {event['modifier']:+d} = {event['total']} vs DC {event['dc']} · {event['stat']} · {label}{harm}"
    if event_type == "recovery_resolution":
        if not event.get("success"):
            return f"Rest gives no recovery: {event.get('reason')}"
        return (
            f"{str(event.get('kind') or 'rest').replace('_', ' ').title()} · "
            f"{event.get('hp_restored')} HP restored · {event.get('hp_after')} HP"
        )
    if event_type == "compound_resolution":
        roll = event["roll"]
        movement = event["movement"]
        label = str(roll.get("outcome") or "success").replace("_", " ").upper()
        stealth = event.get("stealth") if isinstance(event.get("stealth"), dict) else None
        prefix = (
            f"STEALTH · {str(stealth.get('quality') or 'resolved').replace('_', ' ').upper()} · "
            if stealth else ""
        )
        return (
            prefix
            + f"D20 {roll['raw']} {roll['modifier']:+d} = {roll['total']} vs DC {roll['dc']} · {roll['stat']} · {label} · "
            f"travel committed to {movement.get('to_name') or movement.get('location_name') or movement.get('anchor_name') or 'resolved local position'}"
        )
    if event_type == "resource_movement_resolution":
        roll = event.get("roll") if isinstance(event.get("roll"), dict) else None
        resource = event.get("resource") if isinstance(event.get("resource"), dict) else {}
        movement = event.get("movement") if isinstance(event.get("movement"), dict) else {}
        if resource.get("type") == "resource_quote_required":
            return (
                f"Travel committed to {movement.get('to_name') or 'resolved destination'} · "
                f"quote requested for {resource.get('item') or 'the service'} · no transfer."
            )
        parts = resource.get("parts") if isinstance(resource.get("parts"), list) else []
        labels = [
            str(part.get("item") or f"{part.get('amount')} silver")
            for part in parts
            if isinstance(part, dict) and (part.get("item") or part.get("amount"))
        ]
        if not labels and resource.get("item"):
            labels = [str(resource.get("item"))]
        prefix = ""
        if roll:
            prefix = (
                f"D20 {roll['raw']} {roll['modifier']:+d} = {roll['total']} vs DC {roll['dc']} · "
                f"{str(roll.get('outcome') or 'success').replace('_', ' ').upper()} · "
            )
        return (
            prefix
            + "take committed: "
            + " + ".join(labels)
            + f" · travel committed to {movement.get('to_name') or 'resolved destination'}"
        )
    if event_type == "stealth_resolution":
        roll = event["roll"]
        label = str(event.get("quality") or "resolved").replace("_", " ").upper()
        return (
            f"STEALTH · D20 {roll['raw']} {roll['modifier']:+d} = {roll['total']} "
            f"vs DC {roll['dc']} · {label} · local alert {event.get('local_alert')}"
        )
    if event_type == "magic_resolution":
        roll = event["roll"]
        pieces = [
            f"{event['spell_name']} ({event['power_tier']})",
            f"D20 {roll['raw']} {roll['modifier']:+d} = {roll['total']} vs DC {roll['dc']}",
            str(event["outcome"]).replace("_", " ").upper(),
        ]
        if event.get("hp_toll"):
            pieces.append(f"{event['hp_toll']} HP toll")
        if event.get("damage"):
            pieces.append(f"{event['damage']} damage")
        return "MAGIC · " + " · ".join(pieces)
    if event_type == "magic_learning":
        roll = event["roll"]
        msg = f"LEARNING · {event['spell_name']} · D20 {roll['raw']} {roll['modifier']:+d} = {roll['total']} vs DC {roll['dc']} · {event['outcome'].replace('_', ' ').upper()}"
        if event.get("hp_toll"):
            msg += f" · {event['hp_toll']} HP strain"
        if event.get("backfire"):
            msg += " · Arcane Backfire"
        if event.get("source_destroyed"):
            msg += " · source destroyed"
        return msg
    if event_type == "magic_rejected":
        return f"No spell was committed: {event.get('reason')}"
    if event_type == "passage_quote_required":
        return None
    if event_type == "passage_purchase":
        if event.get("success"):
            return (
                f"Passage purchased for {event.get('price', 0)} silver · {event.get('silver_after', 0)} remain · "
                f"berth booked to {event.get('destination_name')} · no travel yet"
            )
        if event.get("reason"):
            return f"Passage not booked: {event['reason']}"
        return f"Passage costs {event.get('price', 0)} silver; only {event.get('silver_before', 0)} available · no travel committed."
    if event_type == "passage_declined":
        return None
    if event_type == "resource_quote_required":
        return None
    if event_type == "resource_negotiation":
        return None
    if event_type == "resource_roll_resolution":
        roll = event.get("roll") if isinstance(event.get("roll"), dict) else {}
        resource = event.get("resource") if isinstance(event.get("resource"), dict) else {}
        label = str(roll.get("outcome") or "failure").replace("_", " ").upper()
        transfer = str(resource.get("kind") or "resource action")
        committed = "committed" if resource.get("success") else "not committed"
        return (
            f"D20 {roll.get('raw')} {int(roll.get('modifier', 0) or 0):+d} = {roll.get('total')} "
            f"vs DC {roll.get('dc')} · {label} · {transfer} {committed}"
        )
    if event_type == "resource_transfer":
        if not event.get("success"):
            return None
        item = f" {event.get('quantity')} {event.get('item')}" if event.get("item") else ""
        silver = f" · silver {int(event.get('silver_delta', 0) or 0):+d}" if event.get("silver_delta") else ""
        return f"{str(event.get('kind') or 'Transfer').replace('_', ' ').title()} committed:{item}{silver}"
    if event_type == "compound_resource_transfer":
        if not event.get("success"):
            return None
        parts = event.get("parts") if isinstance(event.get("parts"), list) else []
        labels = []
        for part in parts:
            if not isinstance(part, dict):
                continue
            if part.get("kind") == "receive_money":
                labels.append(f"{part.get('amount')} silver")
            elif part.get("item"):
                labels.append(str(part.get("item")))
        return "Take committed: " + " + ".join(labels)
    if event_type in {"item_use", "item_prepared", "strict_item_use"}:
        return f"Item use committed: {event.get('item')} · {event.get('effect') or ', '.join(event.get('affordances', []))}"
    if event_type == "combat_resolution":
        pieces: list[str] = []
        stealth_setup = event.get("stealth_setup") if isinstance(event.get("stealth_setup"), dict) else None
        if stealth_setup and isinstance(stealth_setup.get("roll"), dict):
            s_roll = stealth_setup["roll"]
            s_label = str(stealth_setup.get("quality") or "resolved").replace("_", " ").upper()
            pieces.append(
                f"STEALTH · D20 {s_roll['raw']} {s_roll['modifier']:+d} = {s_roll['total']} "
                f"vs DC {s_roll['dc']} · {s_label}"
            )
        pieces.append(f"Combat round {event.get('round')} · {str(event.get('action')).upper()}")
        for exchange in event.get("exchanges", []):
            outcome = "hit" if exchange.get("hit") else "miss"
            if exchange.get("mode") == "magic":
                pieces.append(f"{exchange.get('attacker')} · {exchange.get('spell_name')} · "
                              f"D20 {exchange.get('attacker_raw')} = {exchange.get('attacker_total')} · "
                              f"{exchange.get('caster_outcome')} · {exchange.get('reason')}")
                if exchange.get("defender_raw") is not None:
                    pieces.append(f"{exchange.get('defender')} · {exchange.get('stat')} · "
                                  f"D20 {exchange['defender_raw']} = {exchange.get('defender_total')} · "
                                  f"{exchange.get('damage', 0)} damage")
                continue
            if exchange.get("attacker_is_companion") or exchange.get("defender_is_companion"):
                pieces.append(
                    f"{exchange.get('attacker')} → {exchange.get('defender')} · {exchange.get('stat')} · "
                    f"D10 {exchange.get('attacker_raw')} {int(exchange.get('attacker_modifier', 0)):+d} = {exchange.get('attacker_total')} "
                    f"vs D10 {exchange.get('defender_raw')} {int(exchange.get('defender_modifier', 0)):+d} = {exchange.get('defender_total')} "
                    f"(opposed, no fixed DC) · {outcome}, {exchange.get('damage')} damage")
                continue
            pieces.append(
                f"{exchange.get('attacker')} → {exchange.get('defender')}: "
                f"{exchange.get('attacker_total')} vs {exchange.get('defender_total')}, "
                f"{outcome}, {exchange.get('damage')} damage"
            )
        movement = event.get("movement") if isinstance(event.get("movement"), dict) else None
        if movement and movement.get("committed"):
            pieces.append(f"position → {movement.get('to_name')}")
        defeat = event.get("defeat_outcome") if isinstance(event.get("defeat_outcome"), dict) else None
        if defeat:
            if defeat.get("outcome") == "death":
                pieces.append("DEATH · GAME OVER")
            else:
                pieces.append(
                    f"SURVIVED · {str(defeat.get('consequence') or 'unconscious').replace('_', ' ').upper()} · "
                    f"HP {defeat.get('hp_after')}"
                )
        pieces.append(f"Status: {event.get('combat_status')}")
        return " | ".join(pieces)
    if event_type == "fate_resolution":
        return f"WHEEL OF FATE · {event['result']} ({event['polarity']}) · consequence committed"
    if event_type == "fate_cooldown":
        return f"The Wheel is quiet for another {event['remaining_seconds']} seconds."
    return None


def event_ledger_line(event: dict[str, Any] | None) -> str | None:
    base = _base_event_ledger_line(event)
    if not isinstance(event, dict):
        return base
    suffixes: list[str] = []
    if event.get("type") == "magic_resolution":
        for key in ("resource", "movement"):
            part = event.get(key)
            if isinstance(part, dict):
                line = _base_event_ledger_line(part)
                if not line and part.get("committed") is False:
                    line = f"{key.capitalize()} not committed: {part.get('reason') or 'unresolved'}"
                if line:
                    suffixes.append(line)
    chase = event.get("active_situation_consequence")
    if isinstance(chase, dict):
        chase_line = _base_event_ledger_line(chase)
        if chase_line:
            suffixes.append(chase_line)
    removed = event.get("conditions_removed")
    if isinstance(removed, list) and removed:
        names = ", ".join(str(name) for name in removed if str(name).strip())
        if names:
            suffixes.append(f"Conditions cleared: {names}")
    added = affliction_added_from_event(event)
    if isinstance(added, dict):
        suffixes.append(f"Condition added: {added.get('name') or 'Affliction'}")
    tick = event.get("affliction_tick")
    if isinstance(tick, dict):
        suffixes.append(
            f"{tick.get('name') or 'Affliction'} · {int(tick.get('hp_lost', 0) or 0)} HP lost · "
            f"{tick.get('hp_after')} HP remain"
        )
    if not suffixes:
        return base
    return " · ".join([part for part in [base, *suffixes] if part])

_ROLL_LEDGER_EVENT_TYPES = frozenset({
    "d20_resolution",
    "compound_resolution",
    "stealth_resolution",
    "magic_resolution",
    "magic_learning",
    "resource_roll_resolution",
    "party_action",
    "party_roll_resolution",
    "combat_resolution",
    "active_situation_resolution",
})


def record_mechanical_ledger(
    state: dict[str, Any],
    event: dict[str, Any] | None,
    ledger_line: str | None = None,
) -> bool:
    """Persist only resolved die/mechanical lines exactly as shown in the UI.

    This is deliberately data, not a new semantic rule: later model calls can
    see the same recent roll outcomes the human player saw.
    """

    if not isinstance(event, dict):
        return False
    event_type = str(event.get("type") or "")
    has_roll = event_type in _ROLL_LEDGER_EVENT_TYPES
    if event_type == "resource_movement_resolution":
        has_roll = isinstance(event.get("roll"), dict)
    has_roll = has_roll or isinstance(event.get("active_situation_consequence"), dict)
    if not has_roll:
        return False
    text = str(ledger_line or event_ledger_line(event) or "").strip()
    if not text:
        return False
    history = state.setdefault("mechanics_history", [])
    if not isinstance(history, list):
        history = []
        state["mechanics_history"] = history
    entry = {"turn_no": int(state.get("turn_no", 0) or 0), "text": text}
    if history and isinstance(history[-1], dict) and history[-1] == entry:
        return False
    history.append(entry)
    del history[:-24]
    return True
