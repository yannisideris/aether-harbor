from __future__ import annotations

import random
import re
from typing import Any, Sequence, TypeVar


NPC_SEED_CHANCE = 0.22
NPC_SEED_SPARSE_CHANCE = 0.06
NPC_SEED_COOLDOWN_TURNS = 5
NPC_SEED_MISS_STEPS = (0.0, 0.08, 0.16, 0.22)
NPC_SEED_MAX_CHANCE = 0.44

T = TypeVar("T")
Weighted = Sequence[tuple[T, int]]


PRESENTATION: Weighted[str] = (("male", 60), ("female", 40))
AGE_BAND: Weighted[str] = (
    ("child", 1),
    ("adolescent", 3),
    ("young adult", 25),
    ("adult", 34),
    ("middle-aged", 22),
    ("older", 12),
    ("very old", 3),
)
BUILD: Weighted[str] = (
    ("slight", 13),
    ("lean", 18),
    ("wiry", 13),
    ("compact", 11),
    ("sturdy", 17),
    ("broad", 10),
    ("tall", 10),
    ("heavyset", 8),
)
ADULT_PRESENCE: Weighted[str] = (
    ("unassuming", 16),
    ("pleasant", 10),
    ("attractive", 13),
    ("striking", 12),
    ("weathered", 11),
    ("severe", 8),
    ("elegant", 10),
    ("imposing", 8),
    ("delicate", 6),
    ("eccentric", 6),
)
YOUNG_PRESENCE: Weighted[str] = (
    ("unassuming", 24),
    ("pleasant", 18),
    ("bright", 14),
    ("striking", 11),
    ("untidy", 10),
    ("severe", 6),
    ("elegant", 7),
    ("delicate", 6),
    ("eccentric", 4),
)
OLDER_PRESENCE: Weighted[str] = (
    ("unassuming", 14),
    ("pleasant", 9),
    ("attractive", 7),
    ("striking", 10),
    ("weathered", 18),
    ("severe", 11),
    ("elegant", 12),
    ("imposing", 8),
    ("delicate", 6),
    ("eccentric", 5),
)
TEMPERAMENT: Weighted[str] = (
    ("warm", 6),
    ("guarded", 7),
    ("proud", 5),
    ("vain", 4),
    ("curious", 6),
    ("methodical", 5),
    ("devout", 4),
    ("wry", 5),
    ("anxious", 4),
    ("impulsive", 4),
    ("resentful", 4),
    ("opportunistic", 5),
    ("theatrical", 4),
    ("patient", 5),
    ("mercurial", 4),
    ("ironic", 5),
    ("candid", 4),
    ("protective", 5),
    ("suspicious", 5),
    ("aloof", 4),
    ("playful", 4),
    ("dutiful", 5),
    ("stubborn", 5),
    ("generous", 5),
)
RELEVANCE: Weighted[str] = (
    ("ambient", 50),
    ("outsider", 16),
    ("useful", 19),
    ("entangled", 11),
    ("pressing", 4),
)
INITIATIVE: dict[str, Weighted[str]] = {
    "ambient": (("peripheral", 65), ("reactive", 30), ("approaching", 5)),
    "outsider": (("peripheral", 35), ("reactive", 45), ("approaching", 20)),
    "contextual": (("peripheral", 35), ("reactive", 45), ("approaching", 20)),
    "useful": (("peripheral", 20), ("reactive", 45), ("approaching", 35)),
    "entangled": (("peripheral", 10), ("reactive", 40), ("approaching", 50)),
    "pressing": (("reactive", 20), ("approaching", 80)),
    "malicious": (("peripheral", 15), ("reactive", 35), ("approaching", 50)),
    "hostile": (("approaching", 75), ("reactive", 20), ("peripheral", 5)),
}
RELEVANCE_CUE: dict[str, str] = {
    "ambient": "Natural local fixture here.",
    "outsider": "Outsider/passerby, not a regular here.",
    "contextual": "Outsider/passerby, not a regular here.",
    "useful": "Has useful local skill, trade, or info.",
    "entangled": "Tied to a local secret, debt, or dispute.",
    "pressing": "Brings an urgent need or warning.",
    "malicious": "Antagonistic, extortive, corrupt, or deceitful local looking to exploit or confront the player socially.",
    "hostile": "Actively aggressive, predatory, or extortive threat looking for trouble or a violent clash.",
}
_EXPLICIT_NPC_TARGET = re.compile(
    r"\b(?:man|men|woman|women|person|people|figure|stranger|sailors?|patrons?|"
    r"gamblers?|barkeep|bartender|innkeeper|keeper|server|maid|servant|clerk|"
    r"guard|watchman|sentinel|captain|mate|merchant|vendor|seller|smith|priest|"
    r"monk|beggar|child|boy|girl|master|mistress|host|hostess)\b",
    re.I,
)

_WILDERNESS_KEYWORDS = re.compile(
    r"\b(?:forest|woodland|woods|slopes|hinterland|wilderness|wild|mountain|hills?|"
    r"rocks?|cliffs?|caves?|caverns?|ruins?|swamp|marsh|marshland|shores?|beach|"
    r"scrubland|desert|wasteland)\b",
    re.I,
)
_URBAN_OVERRIDE = re.compile(
    r"\b(?:docks?|wharf|harbour?|palazzo|palace|inn|tavern|shop|office|bank|"
    r"street|plaza|square|estate|villa|mansion|quarters?|district|building|house)\b",
    re.I,
)


def detect_environment(
    location: dict[str, Any] | None,
    position: dict[str, Any] | None = None,
) -> str:
    """Classify the current scene as 'wilderness' or 'urban'."""
    if not isinstance(location, dict):
        return "urban"
    name = str(location.get("name") or "")
    summary = str(location.get("summary") or "")
    aliases = " ".join(str(a) for a in (location.get("aliases") or []))
    pos_text = ""
    if isinstance(position, dict):
        pos_text = f"{position.get('label', '')} {position.get('summary', '')}"
    full_text = f"{name} {summary} {aliases} {pos_text}"
    if _URBAN_OVERRIDE.search(name):
        return "urban"
    if _WILDERNESS_KEYWORDS.search(full_text):
        return "wilderness"
    return "urban"


def _weighted_choice(rng: random.Random, values: Weighted[T]) -> T:
    total = sum(weight for _value, weight in values)
    target = rng.randrange(total)
    for value, weight in values:
        if target < weight:
            return value
        target -= weight
    return values[-1][0]


def generate_seed(
    rng: random.Random,
    *,
    allow_malicious: bool = False,
    environment: str = "urban",
) -> dict[str, Any]:
    """Create one compact figure cue; Qwen authors specifics."""

    age = _weighted_choice(rng, AGE_BAND)
    if age in {"child", "adolescent"}:
        presence_pool = YOUNG_PRESENCE
    elif age in {"older", "very old"}:
        presence_pool = OLDER_PRESENCE
    else:
        presence_pool = ADULT_PRESENCE

    if allow_malicious:
        relevance_pool: Weighted[str] = (
            ("ambient", 45),
            ("outsider", 15),
            ("useful", 18),
            ("entangled", 10),
            ("malicious", 8),
            ("pressing", 4),
        )
        relevance = _weighted_choice(rng, relevance_pool)
    else:
        relevance = _weighted_choice(rng, RELEVANCE)

    initiative = _weighted_choice(rng, INITIATIVE[relevance])
    if age == "child" and initiative == "peripheral":
        initiative = "reactive"
    return {
        "presentation": _weighted_choice(rng, PRESENTATION),
        "age": age,
        "build": _weighted_choice(rng, BUILD),
        "presence": _weighted_choice(rng, presence_pool),
        "temperament": _weighted_choice(rng, TEMPERAMENT),
        "relevance": relevance,
        "initiative": initiative,
        "encounter_kind": "social",
        "environment": environment,
        "face_cue": "yes" if rng.random() < 0.30 else "",
    }


def generate_hostile_seed(
    rng: random.Random,
    environment: str = "urban",
) -> dict[str, Any]:
    """Create a hostile encounter seed (human cutpurse/thug or wilderness beast/creature)."""
    enemy_count = _weighted_choice(rng, ((1, 60), (2, 30), (3, 10)))

    if environment == "wilderness":
        is_creature = rng.random() < 0.75
        if is_creature:
            if enemy_count == 1:
                archetype = _weighted_choice(
                    rng,
                    (
                        ("prowling grey wolf", 30),
                        ("territorial mountain cat", 25),
                        ("feral wild boar", 20),
                        ("coastal cliff serpent", 15),
                        ("creature of the old ruins", 10),
                    ),
                )
            elif enemy_count == 2:
                archetype = _weighted_choice(
                    rng,
                    (
                        ("pair of hunting wolves", 40),
                        ("two feral hounds", 30),
                        ("pair of cliff predators", 30),
                    ),
                )
            else:
                archetype = _weighted_choice(
                    rng,
                    (
                        ("pack of three grey wolves", 50),
                        ("trio of starving wild hounds", 30),
                        ("three ruin-stalking beasts", 20),
                    ),
                )
            build = _weighted_choice(rng, (("lean", 30), ("wiry", 30), ("sturdy", 25), ("heavyset", 15)))
            presence = _weighted_choice(rng, (("feral", 40), ("imposing", 30), ("severe", 30)))
            temperament = _weighted_choice(rng, (("predatory", 45), ("territorial", 35), ("mercurial", 20)))
            initiative = _weighted_choice(rng, (("approaching", 70), ("reactive", 20), ("peripheral", 10)))
            return {
                "presentation": "beast",
                "age": "adult",
                "build": build,
                "presence": presence,
                "temperament": temperament,
                "relevance": "hostile",
                "initiative": initiative,
                "enemy_count": enemy_count,
                "archetype": archetype,
                "encounter_kind": "hostile",
                "environment": "wilderness",
                "face_cue": "yes" if rng.random() < 0.35 else "",
            }

    # Human hostile (Urban or Wilderness bandit)
    # Strictly filtered demographics: only young adult or adult, ~85% male, no middle-aged women
    presentation = _weighted_choice(rng, (("male", 85), ("female", 15)))
    age = _weighted_choice(rng, (("young adult", 45), ("adult", 55)))
    build = _weighted_choice(
        rng,
        (("sturdy", 25), ("wiry", 25), ("broad", 20), ("heavyset", 15), ("lean", 15)),
    )
    presence = _weighted_choice(
        rng,
        (("severe", 30), ("imposing", 25), ("weathered", 20), ("striking", 15), ("unassuming", 10)),
    )
    temperament = _weighted_choice(
        rng,
        (
            ("opportunistic", 25),
            ("resentful", 20),
            ("mercurial", 15),
            ("suspicious", 15),
            ("impulsive", 15),
            ("proud", 10),
        ),
    )
    if enemy_count == 1:
        archetype = _weighted_choice(
            rng,
            (
                ("cornering street thug", 30),
                ("armed cutpurse", 30),
                ("belligerent dock brawler", 20),
                ("extortionist enforcer", 20),
            )
            if environment == "urban"
            else (
                ("lone highwayman", 35),
                ("armed wilderness poacher", 35),
                ("hinterland bandit scout", 30),
            ),
        )
    elif enemy_count == 2:
        archetype = _weighted_choice(
            rng,
            (
                ("pair of armed cutpurses", 40),
                ("duo of street enforcers", 35),
                ("two aggressive dock brawlers", 25),
            )
            if environment == "urban"
            else (
                ("pair of mountain bandits", 50),
                ("two armed poachers", 50),
            ),
        )
    else:
        archetype = _weighted_choice(
            rng,
            (
                ("trio of dock footpads", 45),
                ("gang of three street thugs", 35),
                ("three armed alley prowlers", 20),
            )
            if environment == "urban"
            else (
                ("band of three rough outlaws", 55),
                ("trio of armed ambushers", 45),
            ),
        )
    initiative = _weighted_choice(rng, (("approaching", 75), ("reactive", 20), ("peripheral", 5)))
    return {
        "presentation": presentation,
        "age": age,
        "build": build,
        "presence": presence,
        "temperament": temperament,
        "relevance": "hostile",
        "initiative": initiative,
        "enemy_count": enemy_count,
        "archetype": archetype,
        "encounter_kind": "hostile",
        "environment": environment,
        "face_cue": "yes" if rng.random() < 0.35 else "",
    }


def compact_seed(seed: dict[str, Any]) -> str:
    fields = (
        "presentation", "age", "build", "presence", "temperament",
        "relevance", "initiative",
    )
    return " | ".join(str(seed.get(field) or "").strip() for field in fields if seed.get(field))


def prompt_seed(seed: dict[str, Any]) -> str:
    encounter_kind = str(seed.get("encounter_kind") or "").strip()
    enemy_count = int(seed.get("enemy_count", 1) or 1)
    relevance = str(seed.get("relevance") or "ambient").strip()

    if encounter_kind == "hostile" or relevance == "hostile":
        archetype = str(seed.get("archetype") or "hostile threat").strip()
        face_note = (
            " Include one brief, natural physical detail or weapon."
            if str(seed.get("face_cue") or "") == "yes"
            else ""
        )
        if seed.get("presentation") == "beast":
            count_desc = f"{enemy_count} beasts" if enemy_count > 1 else "a wild beast"
            return (
                f"PRIVATE ENCOUNTER BEAT: Hostile wilderness threat. Introduce {count_desc} ({archetype}); "
                f"embody predatory menace, never list labels. Bring immediate friction, territorial snarling, or stalking threat.{face_note} "
                f"Grain: {compact_seed(seed)}"
            )
        else:
            count_desc = f"{enemy_count} hostile figures" if enemy_count > 1 else "one hostile figure"
            return (
                f"PRIVATE ENCOUNTER BEAT: Active hostile confrontation. Introduce {count_desc} ({archetype}); "
                f"embody grain, never list labels. Bring immediate danger, confrontation, shakedown, or armed challenge.{face_note} "
                f"If approaching, initiate aggressive contact. Grain: {compact_seed(seed)}"
            )

    cue = RELEVANCE_CUE.get(relevance, RELEVANCE_CUE["ambient"])
    face_note = (
        " Include one brief, natural facial or physical detail."
        if str(seed.get("face_cue") or "") == "yes"
        else ""
    )
    return (
        "PRIVATE NPC CASTING BEAT: No NPC is active. Introduce one person; embody "
        f"grain, never list labels. {cue} Give a grounded activity/want.{face_note} "
        f"If approaching, start contact. Grain: {compact_seed(seed)}"
    )


def _committed_arrival(event: dict[str, Any] | None) -> bool:
    if not isinstance(event, dict):
        return False
    event_type = str(event.get("type") or "")
    return event_type in {"movement", "local_movement"} and event.get("committed") is True


def arrival_scene_occupied(
    state: dict[str, Any],
    resolved_event: dict[str, Any] | None,
    semantic_roll: dict[str, Any] | None,
    player_text: str = "",
) -> bool:
    """Determine if the destination scene is already occupied by a known NPC."""

    if not isinstance(semantic_roll, dict):
        return True
    if semantic_roll.get("npc_scene_occupied") is False:
        return False
    if not _committed_arrival(resolved_event):
        return True
    if not bool(resolved_event.get("emergent")):
        return True
    player = state.get("player") if isinstance(state.get("player"), dict) else {}
    if player.get("companions"):
        return True
    if state.get("active_situation") or (
        isinstance(state.get("combat"), dict) and state["combat"].get("status") == "active"
    ):
        return True
    combat_advice = semantic_roll.get("combat") if isinstance(semantic_roll.get("combat"), dict) else {}
    chase_advice = semantic_roll.get("chase") if isinstance(semantic_roll.get("chase"), dict) else {}
    resource_advice = (
        semantic_roll.get("resource_action")
        if isinstance(semantic_roll.get("resource_action"), dict)
        else {}
    )
    party_advice = (
        semantic_roll.get("party_action")
        if isinstance(semantic_roll.get("party_action"), dict)
        else {}
    )
    if (
        str(combat_advice.get("action") or "NONE") != "NONE"
        or str(chase_advice.get("action") or "NONE") != "NONE"
        or str(resource_advice.get("kind") or "NONE") != "NONE"
        or str(party_advice.get("action") or "NONE") != "NONE"
    ):
        return True
    to_name = str(resolved_event.get("to_name") or "")
    if _EXPLICIT_NPC_TARGET.search(f"{player_text} {to_name}"):
        return True
    return False


def eligible(state: dict[str, Any], resolved_event: dict[str, Any] | None) -> bool:
    turn_no = int(state.get("turn_no", 0) or 0)
    if turn_no <= 0 or not _committed_arrival(resolved_event):
        return False
    combat = state.get("combat")
    if isinstance(combat, dict) and combat.get("status") == "active":
        return False
    engine = state.setdefault(
        "npc_engine", {"last_seed_turn": -999, "seed_count": 0, "eligible_misses": 0}
    )
    engine.setdefault("eligible_misses", 0)
    last_turn = int(engine.get("last_seed_turn", -999) or -999)
    return turn_no - last_turn >= NPC_SEED_COOLDOWN_TURNS


def maybe_seed(
    state: dict[str, Any],
    resolved_event: dict[str, Any] | None,
    *,
    chance: float = NPC_SEED_CHANCE,
    scene_occupied: bool = False,
    density: str = "ordinary",
) -> dict[str, Any] | None:
    """Rarely cue one arrival encounter without registering a phantom persistent card."""

    if scene_occupied:
        return None
    if not eligible(state, resolved_event):
        return None
    turn_no = int(state.get("turn_no", 0) or 0)
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    material = ":".join(
        (
            str(state.get("rng_seed", 0)),
            str(turn_no),
            str(state.get("current_location_id") or ""),
            str(position.get("id") or ""),
            "npc-seed",
        )
    )
    rng = random.Random(material)
    engine = state.setdefault(
        "npc_engine", {"last_seed_turn": -999, "seed_count": 0, "eligible_misses": 0}
    )
    misses = max(0, int(engine.get("eligible_misses", 0) or 0))
    sparse = density == "sparse"
    requested_chance = NPC_SEED_SPARSE_CHANCE if sparse and chance == NPC_SEED_CHANCE else chance
    base_chance = max(0.0, min(1.0, float(requested_chance)))
    if base_chance <= 0.0:
        effective_chance = 0.0
    elif base_chance >= 1.0:
        effective_chance = 1.0
    elif sparse:
        effective_chance = base_chance
    else:
        pity_index = min(misses, len(NPC_SEED_MISS_STEPS) - 1)
        effective_chance = min(
            NPC_SEED_MAX_CHANCE,
            base_chance + NPC_SEED_MISS_STEPS[pity_index],
        )
    if rng.random() >= effective_chance:
        engine["eligible_misses"] = misses + 1 if not sparse else misses
        return None

    location_id = state.get("current_location_id") or (
        resolved_event.get("to_id") if isinstance(resolved_event, dict) else ""
    )
    location = (state.get("locations", {}) or {}).get(str(location_id))
    env = detect_environment(location, position)

    # Environment-first encounter split:
    # Urban: 85% social, 15% hostile
    # Wilderness: 30% social, 70% hostile
    hostile_chance = 0.70 if env == "wilderness" else 0.15
    if rng.random() < hostile_chance:
        seed = generate_hostile_seed(rng, environment=env)
    else:
        seed = generate_seed(rng, allow_malicious=True, environment=env)

    engine["last_seed_turn"] = turn_no
    engine["seed_count"] = int(engine.get("seed_count", 0) or 0) + 1
    engine["eligible_misses"] = 0
    return seed
