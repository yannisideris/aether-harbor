"""Party membership is a committed character relationship, never inventory."""
from __future__ import annotations

import copy
import hashlib
from typing import Any

STATS = ("STR", "AGI", "SOC", "ARC", "PER")
PARTY_ACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "action": {"type": "string", "enum": ["NONE", "recruit", "dismiss"]},
        "target": {"type": "string", "maxLength": 80},
        "status": {"type": "string", "enum": ["NONE", "inquiry", "offered", "confirmed", "refused", "ambiguous"]},
        "timing": {"type": "string", "enum": ["none", "immediate", "on_success"]},
        "amount": {"type": "integer", "minimum": 0, "maximum": 10000},
        "reason": {"type": "string", "maxLength": 180},
    },
    "required": ["action", "target", "status", "timing", "amount", "reason"],
    "additionalProperties": False,
}


def key(value: Any) -> str:
    return " ".join(str(value or "").casefold().split())


DESCRIPTOR_WORDS = {
    "dockworker", "worker", "sailor", "guard", "watchman", "soldier", "sentinel", "officer",
    "bandit", "thug", "scribe", "clerk", "acolyte", "apprentice", "servant", "assistant",
    "retainer", "porter", "innkeeper", "bartender", "merchant", "beggar", "citizen", "thief",
    "brawler", "mercenary", "stranger", "traveler", "patron", "figure", "man", "woman", "person", "boy", "girl",
    "he", "she", "him", "her",
}


def is_descriptor(val: str) -> bool:
    return bool(set(key(val).split()) & DESCRIPTOR_WORDS)


def party_advice(semantic: dict | None) -> dict:
    semantic = semantic or {}
    row = semantic.get("party_action")
    if not isinstance(row, dict) or row.get("action") not in {"recruit", "dismiss"}:
        legacy = semantic.get("resource_action") or {}
        row = {
            "action": legacy.get("kind"), "target": legacy.get("item"),
            "status": legacy.get("status"), "timing": legacy.get("timing"),
            "amount": legacy.get("amount"), "profile": legacy.get("item_profile"),
            "reason": legacy.get("reason"),
        } if legacy.get("kind") in {"recruit", "dismiss"} else {}
    try:
        amount = max(0, min(10000, int(row.get("amount") or 0)))
    except (ValueError, TypeError):
        amount = 0
    target = " ".join(str(row.get("target") or "").split())[:80]
    status = row.get("status") if row.get("status") in PARTY_ACTION_SCHEMA["properties"]["status"]["enum"] else "ambiguous"
    action = row.get("action") if (row.get("action") in {"recruit", "dismiss"} and target and status != "NONE") else "NONE"
    return {
        "action": action,
        "target": target if action != "NONE" else "",
        "status": status,
        "timing": row.get("timing") if row.get("timing") in {"immediate", "on_success"} else "none",
        "amount": amount,
        "reason": str(row.get("reason") or "")[:180],
        "profile": copy.deepcopy(row.get("profile")) if isinstance(row.get("profile"), dict) else None,
    }


def find_companion(state: dict, target: str) -> dict | None:
    rows = [c for c in state.get("player", {}).get("companions", []) if isinstance(c, dict)]
    wanted = key(target)
    if not wanted:
        return None
    exact = [c for c in rows if wanted in {
        key(c.get("name")), key(c.get("descriptor")), key(c.get("anchor")),
    }]
    matches = exact or [c for c in rows if key(c.get("name")).split()[:1] == [wanted]]
    return matches[0] if len(matches) == 1 else None


def roster_context(state: dict) -> list[dict]:
    return [
        {k: c.get(k) for k in ("name", "descriptor", "anchor", "hp", "max_hp", *STATS)}
        for c in state.get("player", {}).get("companions", []) if isinstance(c, dict)
    ]


def valid_profile(profile: Any) -> bool:
    return (
        isinstance(profile, dict) and bool(key(profile.get("name")))
        and all(isinstance(profile.get(s), int) and 6 <= profile[s] <= 20 for s in STATS)
        and isinstance(profile.get("max_hp"), int) and 6 <= profile["max_hp"] <= 20
        and isinstance(profile.get("weapon"), dict)
        and isinstance(profile.get("armor_value"), int)
    )


def commit_party_action(state: dict, advice: dict, *, roll_success: bool | None = None) -> dict | None:
    action = advice.get("action")
    if action not in {"recruit", "dismiss"}:
        return None
    event = {
        "type": "party_action", "action": action, "target": advice.get("target", ""),
        "committed": False, "success": False, "silver_delta": 0,
        "reason": advice.get("reason", ""),
    }
    if advice.get("timing") == "on_success" and roll_success is not True:
        event["reason"] = "The required roll did not succeed."
        return event
    if advice.get("status") != "confirmed":
        event["reason"] = "Party agreement is not confirmed."
        return event
    player = state["player"]
    companions = player.setdefault("companions", [])
    target = str(advice.get("target") or "")
    existing = find_companion(state, target)
    profile = advice.get("profile")
    if not existing and isinstance(profile, dict):
        existing = find_companion(state, str(profile.get("name") or ""))
    if not target:
        event["reason"] = "No companion identity supplied."
    elif action == "dismiss":
        if existing is None:
            event["reason"] = "Companion is not in the party."
        else:
            companions.remove(existing)
            event.update(committed=True, success=True, target=existing["name"])
            card = state.get("npcs", {}).get(existing.get("npc_id"))
            if isinstance(card, dict):
                card["party_status"] = "dismissed"
    elif existing:
        # Repeated acceptance or a retry must not charge twice or reset HP.
        event.update(success=True, target=existing["name"], reason="Already in the party.")
    elif len(companions) >= 1:
        event["reason"] = "The party is full (maximum 1 companion)."
    elif int(player.get("silver", 0)) < int(advice.get("amount") or 0):
        event["reason"] = "Insufficient silver to recruit."
    elif not valid_profile(profile):
        event["reason"] = "Companion profile is pending; no membership or payment committed."
        event["profile_pending"] = True
    else:
        name = str(profile["name"]).strip()
        comp = copy.deepcopy(profile)
        comp.update(
            name=name, descriptor=target if key(target) != key(name) else "",
            hp=profile["max_hp"], armor=profile["armor_value"], inventory=[], conditions=[],
        )
        # Use the NPC store consumed by both narrator and memory secretaries.
        cards = state.setdefault("npcs", {})
        matches = [(nid, card) for nid, card in cards.items() if isinstance(card, dict)
                   and ({key(card.get("name")), key(card.get("anchor"))} & {key(name), key(target)} - {""})]
        if len(matches) == 1:
            npc_id, card = matches[0]
            # Never rename an established proper-named NPC just because a profiler drifted.
            established = str(card.get("name") or "")
            if established and key(established) == key(target) and not is_descriptor(established):
                name = established
                comp["name"] = name
            else:
                card["name"] = name
                card["anchor"] = card.get("anchor") or target
        else:
            npc_id = "npc_" + hashlib.sha256(key(name).encode()).hexdigest()[:12]
            card = cards.setdefault(npc_id, {"signature_shards": [], "relations": []})
        comp["npc_id"] = npc_id
        card.update(name=name, anchor=card.get("anchor") or target, party_status="active",
                    profile_tier="entangled", role=card.get("role") or profile.get("character_trait"),
                    last_turn=state.get("turn_no", 0))
        hidden = card.setdefault("hidden_profile", {})
        comp_app = " ".join(str(comp.get("appearance") or "").split())[:220]
        card_app = " ".join(str(hidden.get("appearance") or card.get("appearance") or "").split())[:220]
        if comp_app:
            comp["appearance"] = comp_app
            hidden["appearance"] = comp_app
        elif card_app:
            comp["appearance"] = card_app
        if profile.get("character_trait") and not hidden.get("role"):
            hidden["role"] = str(profile.get("character_trait"))[:180]
        amount = int(advice.get("amount") or 0)
        if amount > 0:
            comp["silver"] = int(comp.get("silver", 0) or 0) + amount
        companions.append(comp)
        player["silver"] = int(player.get("silver", 0)) - amount
        event.update(committed=True, success=True, target=name, silver_delta=-amount,
                     hp=comp["hp"], max_hp=comp["max_hp"])
    if event["committed"]:
        history = state.setdefault("party_history", [])
        history.append({**event, "turn_no": state.get("turn_no", 0)})
        del history[:-20]
    return event

