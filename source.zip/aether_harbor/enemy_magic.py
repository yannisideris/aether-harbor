"""Enemy spell beats using the existing spell catalogue, tiers and engine RNG."""
from __future__ import annotations

from typing import Any


def choose_enemy_action(state: dict, opponent: dict) -> dict:
    from .magic import SPELLS

    action = {"attack_mode": str((opponent.get("weapon") or {}).get("mode", "melee"))}
    if not opponent.get("is_caster"):
        return action
    spells = [s for s in opponent.get("known_spells", [])
              if str(s).lower().replace(" ", "_") in SPELLS]
    if not spells:
        return action
    hp = int(opponent.get("hp", 0))
    if hp <= 4 and "Aegis" in spells and not (opponent.get("ward") or {}).get("remaining"):
        spell = "Aegis"
    elif hp <= int(opponent.get("max_hp", 10)) - 3 and "Vitae Drain" in spells:
        spell = "Vitae Drain"
    elif any(s in spells for s in ("Metus", "Caligo")) and not any(
        c.get("kind") in {"fear", "confusion"}
        for c in state.get("player", {}).get("conditions", []) if isinstance(c, dict)
    ):
        spell = "Metus" if "Metus" in spells else "Caligo"
    else:
        spell = spells[0]
    category = SPELLS[spell.lower().replace(" ", "_")]["category"]
    tier = SPELLS[spell.lower().replace(" ", "_")].get("minimum_tier", "standard")
    return {"attack_mode": "magic", "spell_name": spell, "power_tier": tier,
            "caster_name": opponent.get("name"),
            "defense_stat": "ARC" if category in {"mental", "necromantic", "divination"} else "AGI"}


def resolve_enemy_spell(state: dict, caster: dict, defender: dict, action: dict, *,
                        manual_roll: int | None = None, defense_bonus: int = 0,
                        text: str = "", defense_path: str | None = None) -> dict[str, Any]:
    from .magic import SPELLS, POWER_TIERS, magic_outcome
    from .mechanics import _manual_or_random_roll, stat_modifier, absorb_ward

    spell_name = action["spell_name"]
    spell_id = spell_name.lower().replace(" ", "_")
    spell = SPELLS[spell_id]
    tier = action.get("power_tier") or "standard"
    rules = POWER_TIERS[tier]
    raw = action.get("caster_raw")
    if raw is None:  # Previously saved pending defenses have no reserved die.
        raw = _manual_or_random_roll(state, 20)
    penalty = sum(int(c.get("penalty", 0)) for c in caster.get("conditions", []) if isinstance(c, dict))
    total = raw + stat_modifier("D20", int(caster.get("ARC", 15))) + penalty
    outcome = magic_outcome(raw, total, rules["dc"])
    toll = rules[{"critical_failure": "critical_toll", "failure": "failure_toll",
                  "success": "success_toll", "strong_success": "strong_toll"}[outcome]]
    caster["hp"] = max(0, int(caster["hp"]) - toll)
    strong = outcome == "strong_success"
    effect_amount = rules["strong_damage"] if strong else rules["damage"]
    before = int(defender["hp"])
    event = {"attacker": caster["name"], "defender": defender["name"],
             "attack_mode": "magic", "mode": "magic", "spell_name": spell_name,
             "power_tier": tier, "weapon": f"Spell: {spell_name}",
             "attacker_raw": raw, "attacker_total": total, "caster_outcome": outcome,
             "hp_toll": toll, "defender_raw": None, "defender_total": None,
             "stat": action.get("defense_stat", "AGI"), "defense_path": None,
             "hit": False, "critical": strong, "damage": 0, "ward_absorbed": 0,
             "reflected": False, "reflected_damage": 0,
             "defender_hp_before": before, "defender_hp_after": before,
             "attacker_is_player": False, "attacker_is_companion": False,
             "defender_is_companion": bool(defender.get("is_companion")),
             "manual_roll_owner": "Companion" if defender.get("is_companion") else "Player",
             "automatic": True}
    if outcome in {"failure", "critical_failure"}:
        event["reason"] = f"{caster['name']}'s {spell_name} fails; only the caster pays its toll."
        return event

    # Support spells act on the caster; they never become damaging projectiles.
    if spell_id in {"aegis", "sanus", "restituo", "purifico", "firmitas", "celeritas"}:
        if spell_id == "aegis":
            capacity = {"minor": 3, "standard": 6, "major": 9, "extreme": 14}[tier] + (3 if strong else 0)
            caster["ward"] = {"name": "Aegis", "spell_id": "aegis", "capacity": capacity,
                              "remaining": capacity, "tier": tier, "turns": 5}
            event["ward_created"] = dict(caster["ward"])
        elif spell_id in {"sanus", "restituo", "purifico"}:
            hp = int(caster["hp"])
            caster["hp"] = min(int(caster["max_hp"]), hp + effect_amount)
            event["healed"] = caster["hp"] - hp
            if spell_id == "purifico":
                from .afflictions import cure_afflictions
                event["conditions_removed"] = cure_afflictions({"player": caster}, families={"physical", "toxic", "arcane"})
        else:
            condition = ({"name": "Hastened", "kind": "celeritas", "turns": 3, "bonus": 2}
                         if spell_id == "celeritas" else
                         {"name": "Fortified", "kind": "firmitas", "turns": 3, "armor_bonus": 1})
            caster.setdefault("conditions", []).append(condition)
            event["applied_condition"] = condition
        event.update(effect_target=caster["name"], reason=f"{caster['name']} uses {spell_name} on themselves; no attack on {defender['name']}.")
        return event

    damaging = "damage" in spell["families"]
    controlling = spell_id in {"metus", "caligo"}
    if not damaging and not controlling:
        effect = {"spell_name": spell_name, "caster": caster["name"], "location_id": state.get("current_location_id"),
                  "duration": "scene", "description": spell["description"]}
        state.setdefault("magic", {}).setdefault("active_effects", []).append(effect)
        state["magic"]["active_effects"] = state["magic"]["active_effects"][-12:]
        event.update(scene_effect=effect, reason=f"{caster['name']} uses {spell_name}: {spell['description']} No direct damage is committed.")
        return event

    path = defense_path or ""
    low = text.casefold()
    if not path:
        if any(w in low for w in ("reflecto", "reflect", "deflect")):
            path = "reflecto"
        elif any(w in low for w in ("arc", "will", "mind", "endure", "brace", "grit", "resist")):
            path = "arc"
        elif any(w in low for w in ("dodge", "evade", "dive", "roll", "cover", "agi")):
            path = "agi"
        else:
            path = str(action.get("defense_stat", "AGI")).lower()
    if path == "reflecto" and "reflecto" not in {str(s).casefold() for s in defender.get("known_spells", [])}:
        path = str(action.get("defense_stat", "AGI")).lower()
    if path not in {"reflecto", "arc", "agi"}:
        path = str(action.get("defense_stat", "AGI")).lower()
    stat = "ARC" if path in {"reflecto", "arc"} else "AGI"
    defender_raw = _manual_or_random_roll(state, 20, manual_roll)
    modifier = stat_modifier("D20", int(defender.get(stat, 10))) + defense_bonus
    defender_total = defender_raw + modifier
    dc = rules["dc"]
    reflected = path == "reflecto" and (defender_raw == 20 or defender_total >= dc + 8)
    blocked = ((defender_raw == 20 or defender_total >= dc + 8) if path == "arc" else
               defender_total >= dc if path == "reflecto" else defender_total >= max(dc, total))
    if reflected:
        blocked = True
    partial = path == "arc" and not blocked and defender_total >= dc
    impact_target = caster if reflected else defender
    applied_condition = None
    damage = 0
    if not blocked or reflected:
        if spell_id == "metus":
            applied_condition = ({"name": "Panicked", "kind": "fear", "turns": 2, "denies_action": True}
                                 if strong and not partial else {"name": "Shaken", "kind": "fear", "turns": 2, "penalty": -3})
        elif spell_id == "caligo":
            applied_condition = {"name": "Disoriented", "kind": "confusion", "turns": 2, "penalty": -4 if strong else -3}
        elif damaging:
            damage = effect_amount
            if spell_id == "terra":
                damage = rules["damage"] if strong else max(1, rules["damage"] // 2)
                applied_condition = {"name": "Immobilized", "kind": "immobilized", "turns": 2}
            if partial:
                damage = max(1, damage // 2)
        if applied_condition:
            impact_target.setdefault("conditions", []).append(applied_condition)
    absorbed = absorb_ward(impact_target, damage)
    damage -= absorbed
    impact_hp = int(impact_target["hp"])
    impact_target["hp"] = max(0, impact_hp - damage)
    if spell_id == "vitae_drain" and damage:
        beneficiary = defender if reflected else caster
        hp = int(beneficiary["hp"])
        beneficiary["hp"] = min(int(beneficiary["max_hp"]), hp + (min(impact_hp, damage) + 1) // 2)
        event["siphon_healed"] = beneficiary["hp"] - hp
    if reflected:
        reason = f"Reflected {spell_name} back at {caster['name']} with Reflecto!"
    elif blocked:
        reason = f"Dodged {spell_name}." if path == "agi" else f"Resisted {spell_name}; no effect reaches {defender['name']}."
    elif applied_condition:
        reason = f"{spell_name} leaves {defender['name']} {applied_condition['name'].lower()}."
    elif path == "arc":
        reason = f"Braced through {spell_name}, halving its impact." if partial else f"Failed to endure the full brunt of {spell_name}."
    else:
        reason = f"Caught in the blast of {spell_name}."
    event.update(automatic=False, defender_raw=defender_raw, defender_total=defender_total,
                 stat=stat, defense_path=path, hit=not blocked and bool(damage or applied_condition),
                 damage=0 if reflected else damage, ward_absorbed=absorbed,
                 reflected=reflected, reflected_damage=damage if reflected else 0,
                 applied_condition=applied_condition, effect_target=impact_target["name"],
                 defender_hp_after=defender["hp"], reason=reason)
    return event
