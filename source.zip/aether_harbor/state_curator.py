from __future__ import annotations

import json
from typing import Any

from .local_model import LocalQwen
from .movement import _concise_location_summary
from .persistence import CampaignStore
from .secretary import _remove_soft_card, _update_soft_cards


CURATOR_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "place_cards": {
            "type": "array",
            "maxItems": 2,
            "items": {
                "type": "object",
                "properties": {
                    "location_id": {"type": "string"},
                    "summary": {"type": "string"},
                },
                "required": ["location_id", "summary"],
                "additionalProperties": False,
            },
        },
        "hidden_current_judgments": {
            "type": "array",
            "maxItems": 2,
            "items": {
                "type": "object",
                "properties": {
                    "index": {"type": "integer", "minimum": 0, "maximum": 1},
                    "state": {
                        "type": "string",
                        "enum": ["keep", "partially_revealed", "revealed", "resolved", "irrelevant"],
                    },
                },
                "required": ["index", "state"],
                "additionalProperties": False,
            },
        },
        "evidence_judgments": {
            "type": "array",
            "maxItems": 8,
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "integer"},
                    "action": {"type": "string", "enum": ["keep", "reclassify", "discard"]},
                    "kind": {
                        "type": "string",
                        "enum": [
                            "npc_signature", "relationship", "promise", "place", "clue",
                            "rumor", "thread", "resolution", "world_texture",
                        ],
                    },
                    "subject": {"type": "string"},
                    "shareable_seed": {"type": "boolean"},
                },
                "required": ["id", "action", "kind", "subject", "shareable_seed"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["place_cards", "hidden_current_judgments", "evidence_judgments"],
    "additionalProperties": False,
}


SYSTEM = """
You are a sparse state curator for an improvisational fantasy RPG, not a
narrator and not an editor of its style. Inspect only the supplied persistent
metadata against the exact transcript.

For each requested place card, write one short stable sentence describing the
place itself. Compress only established spatial or physical character. Do not
make a temporary person, object, weather event, discovery, or current action
the identity of the place; do not add facts. An empty summary means there is
not enough evidence yet.

For each private hidden current, say keep or partially_revealed while its
concealed truth can still matter. Mark revealed, resolved, or irrelevant only
when the transcript actually supports that lifecycle change. Never replace it
with a new secret and never sanitize surreal facts.

For each evidence record, classify its literal entity type. npc_signature is
only a named person and distinctive traits or behavior. place is only a
returnable physical location. A named vessel, token, tool, container, or other
object is world_texture, never a person. Discard only generic, hypothetical,
contradicted, or non-durable material. For evidence already proposed as a
shareable seed, favor concrete, distinctive, memorable world elements over
merely plot-important ones. An ordinary or local place, person, vessel,
architectural feature, object, or incidental detail can deserve to remain
shareable when it has a specific identity and could enrich a later voyage by
recurring or transforming; turn shareable_seed off when the material is generic
or interchangeable instead. You may turn shareable_seed off, but do not turn it
on when it was false. Preserve the exact proper subject rather than inventing a
better one. Return JSON only.
""".strip()


def _curator_state(state: dict[str, Any]) -> dict[str, Any]:
    return state.setdefault(
        "state_curator",
        {
            "last_campaign_turn": -999,
            "last_hidden_review_turn": -999,
            "last_evidence_id": 0,
            "pending_location_ids": [],
            "pending_hidden_review": False,
            "pending_evidence_review": False,
        },
    )


def queue_after_narration(state: dict[str, Any], *, allow_place_card: bool) -> None:
    curator = _curator_state(state)
    location_id = str(state.get("current_location_id") or "")
    location = state.get("locations", {}).get(location_id)
    if (
        allow_place_card
        and isinstance(location, dict)
        and not isinstance(location.get("site_memory"), dict)
        and str(location.get("summary_source") or "") != "curator"
        and (location_id.startswith("emergent_") or location_id == "opening_threshold")
    ):
        pending = curator.setdefault("pending_location_ids", [])
        if location_id not in pending:
            pending.append(location_id)
        del pending[:-2]

    current_turn = int(state.get("turn_no", 0) or 0)
    currents = [row for row in state.get("hidden_currents", [])[:2] if isinstance(row, dict)]
    old_enough = any(
        current_turn - int(row.get("created_at_turn", current_turn) or current_turn) >= 2
        for row in currents
    )
    if currents and old_enough and current_turn - int(curator.get("last_hidden_review_turn", -999) or -999) >= 4:
        curator["pending_hidden_review"] = True


def queue_evidence_review(state: dict[str, Any]) -> None:
    _curator_state(state)["pending_evidence_review"] = True


def due(state: dict[str, Any], *, cooldown: int = 3) -> bool:
    curator = _curator_state(state)
    pending = bool(curator.get("pending_location_ids")) or bool(curator.get("pending_hidden_review")) or bool(curator.get("pending_evidence_review"))
    if not pending:
        return False
    current_turn = int(state.get("turn_no", 0) or 0)
    last_turn = int(curator.get("last_campaign_turn", -999) or -999)
    return current_turn - last_turn >= max(2, int(cooldown))


def _place_payload(state: dict[str, Any], ids: list[str]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for location_id in ids[-2:]:
        location = state.get("locations", {}).get(location_id)
        if not isinstance(location, dict):
            continue
        result.append(
            {
                "location_id": location_id,
                "name": location.get("name"),
                "region": location.get("region"),
                "current_summary": location.get("summary"),
                "defining_excerpt": str(location.get("defining_excerpt") or "")[:1400],
            }
        )
    return result


def run(
    *,
    model: LocalQwen,
    store: CampaignStore,
    state: dict[str, Any],
    save_state: bool = True,
) -> dict[str, Any]:
    curator = _curator_state(state)
    queued_place_ids = list(curator.get("pending_location_ids") or [])[-2:]
    place_ids = [
        location_id
        for location_id in queued_place_ids
        if not isinstance(
            (state.get("locations", {}).get(location_id) or {}).get("site_memory"),
            dict,
        )
    ]
    if place_ids != queued_place_ids:
        curator["pending_location_ids"] = list(place_ids)
    evidence = (
        store.evidence_after(
            state["campaign_id"],
            int(curator.get("last_evidence_id", 0) or 0),
            limit=8,
        )
        if curator.get("pending_evidence_review")
        else []
    )
    currents = (
        [row for row in state.get("hidden_currents", [])[:2] if isinstance(row, dict)]
        if curator.get("pending_hidden_review")
        else []
    )
    recent = store.recent_turns(state["campaign_id"], limit=12)
    request = {
        "requested_place_cards": _place_payload(state, place_ids),
        "private_hidden_currents": [dict(row, index=index) for index, row in enumerate(currents)],
        "new_persistent_evidence": evidence,
        "exact_recent_transcript": [
            {"speaker": row.get("speaker"), "text": str(row.get("text") or "")[:1000]}
            for row in recent
        ],
    }
    payload = model.chat_json(
        [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": json.dumps(request, ensure_ascii=False)},
        ],
        schema=CURATOR_SCHEMA,
        temperature=0.1,
    )

    applied_cards = 0
    completed_place_ids: set[str] = set()
    allowed_place_ids = set(place_ids)
    for card in payload.get("place_cards", [])[:2]:
        if not isinstance(card, dict):
            continue
        location_id = str(card.get("location_id") or "")
        if location_id not in allowed_place_ids:
            continue
        summary = _concise_location_summary(str(card.get("summary") or ""), max_chars=260)
        location = state.get("locations", {}).get(location_id)
        if isinstance(location, dict) and isinstance(location.get("site_memory"), dict):
            completed_place_ids.add(location_id)
        # Once a bounded place has real site_memory, the Spatial Secretary owns
        # its site-level identity.  A delayed curator pass may contain recent
        # room/corridor narration and must not promote that local observation
        # into the summary of the whole building.
        if (
            isinstance(location, dict)
            and not isinstance(location.get("site_memory"), dict)
            and 35 <= len(summary) <= 260
        ):
            location["summary"] = summary
            location["summary_source"] = "curator"
            location["summary_curated_at_turn"] = int(state.get("turn_no", 0) or 0)
            applied_cards += 1
            completed_place_ids.add(location_id)
    curator["pending_location_ids"] = [
        value for value in place_ids if value not in completed_place_ids
    ]

    current_judgments = {
        int(row.get("index")): str(row.get("state") or "keep")
        for row in payload.get("hidden_current_judgments", [])
        if isinstance(row, dict) and isinstance(row.get("index"), int)
    }
    if currents and all(index in current_judgments for index in range(len(currents))):
        state["hidden_currents"] = [
            current
            for index, current in enumerate(currents)
            if current_judgments.get(index) in {"keep", "partially_revealed"}
        ]
        curator["pending_hidden_review"] = False
        curator["last_hidden_review_turn"] = int(state.get("turn_no", 0) or 0)

    evidence_by_id = {int(row["id"]): row for row in evidence}
    evidence_judgments = {
        int(row.get("id")): row
        for row in payload.get("evidence_judgments", [])
        if isinstance(row, dict) and isinstance(row.get("id"), int)
    }
    curated_evidence = 0
    if evidence and all(evidence_id in evidence_judgments for evidence_id in evidence_by_id):
        for evidence_id, old in evidence_by_id.items():
            judgment = evidence_judgments[evidence_id]
            action = str(judgment.get("action") or "keep")
            kind = str(judgment.get("kind") or old.get("kind") or "world_texture")
            subject = " ".join(str(judgment.get("subject") or old.get("subject") or "").split())[:120]
            shareable = bool(judgment.get("shareable_seed")) and bool(old.get("shareable_seed"))
            _remove_soft_card(
                state,
                kind=str(old.get("kind") or ""),
                subject=str(old.get("subject") or ""),
                excerpt=str(old.get("excerpt") or ""),
            )
            updated = store.curate_evidence(
                evidence_id,
                keep=action != "discard",
                kind=kind,
                subject=subject,
                shareable_seed=shareable,
            )
            if updated and action != "discard":
                _update_soft_cards(
                    state,
                    kind=kind,
                    subject=subject,
                    status=str(old.get("status") or "confirmed"),
                    excerpt=str(old.get("excerpt") or ""),
                )
            curated_evidence += 1
        curator["last_evidence_id"] = max(evidence_by_id)
        curator["pending_evidence_review"] = False
    elif not evidence:
        curator["pending_evidence_review"] = False

    curator["last_campaign_turn"] = int(state.get("turn_no", 0) or 0)
    if save_state:
        store.save_state(state)
    return {
        "place_cards": applied_cards,
        "hidden_removed": len(currents) - len(state.get("hidden_currents", [])) if currents else 0,
        "evidence_curated": curated_evidence,
    }
