from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any


_CATALOG_PATH = Path(__file__).resolve().parent.parent / "data" / "aether_books.json"
_BOOK_NOUN = re.compile(
    r"\b(?:book(?:s)?|volume(?:s)?|codex|codices|manuscript(?:s)?|scroll(?:s)?|"
    r"folio(?:s)?|treatise(?:s)?|pamphlet(?:s)?|journal(?:s)?|letters|shelf|shelves|library)\b",
    re.I,
)
_BOOK_DISCOVERY_INTENT = re.compile(
    r"\b(?:browse|browsing|read|open|inspect|examine|look(?:ing)?\s+(?:at|through|for|inside)|"
    r"search(?:ing)?\s+(?:for|through)|find|pull\s+(?:out|down)|take\s+down|what\s+(?:book|volume)|"
    r"any\s+(?:book|volume|manuscript))",
    re.I,
)
_READING_INTENT = re.compile(
    r"\b(?:read|open|continue|leaf|turn\s+(?:the\s+)?page|look\s+inside|what\s+does\s+it\s+say|"
    r"what\s+is\s+it\s+about|another\s+passage|next\s+passage|margin(?:s|alia)?|annotation(?:s)?|"
    r"handwritten\s+(?:note|notes|writing))\b",
    re.I,
)
_MARGINALIA_INTENT = re.compile(
    r"\b(?:margin(?:s|alia)?|annotation(?:s)?|handwritten\s+(?:note|notes|writing)|"
    r"note(?:s)?\s+in\s+the\s+margin)\b",
    re.I,
)
_CLOSE_OR_SWITCH_BOOK = re.compile(
    r"\b(?:(?:close|shut|shelve|return|put|set|lay)\b.{0,28}\b(?:book|volume|codex|manuscript|it)|"
    r"(?:another|different)\s+(?:book|volume|codex|manuscript))\b",
    re.I,
)
_LOOT_INTENT = re.compile(
    r"\b(?:loot|valuable|valuables|money|silver|gold|weapon|useful\s+item|sell|steal)\b",
    re.I,
)
_LIBRARY_SCENE = re.compile(
    r"\b(?:library|archive|scriptorium|bookshop|bookseller|reading\s+room|private\s+collection|"
    r"wall(?:s)?\s+of\s+books|rows?\s+of\s+shelves|book\s+stacks)\b",
    re.I,
)
_STUDY_SCENE = re.compile(
    r"\b(?:study|scholar(?:'s)?\s+(?:room|chamber)|office|writing\s+room|cabinet\s+room|schoolroom)\b",
    re.I,
)
_MARITIME_SCENE = re.compile(
    r"\b(?:captain(?:'s)?\s+cabin|chart\s+room|pilot\s+house|harbou?rmaster(?:'s)?\s+office|"
    r"ship(?:'s)?\s+cabin|navigation\s+room)\b",
    re.I,
)
_RELIGIOUS_SCENE = re.compile(
    r"\b(?:temple|monastery|monastic|chapel|sanctum|priests?'?\s+quarters|shrine\s+library)\b",
    re.I,
)
_HOUSEHOLD_SCENE = re.compile(
    r"\b(?:villa|townhouse|bedchamber|sitting\s+room|drawing\s+room|parlo(?:u)?r|private\s+room)\b",
    re.I,
)
_BOOKISH_SCENE = re.compile(
    r"\b(?:book(?:s)?|volume(?:s)?|codex|codices|manuscript(?:s)?|scroll(?:s)?|folio(?:s)?|"
    r"treatise(?:s)?|journal(?:s)?|shelf|shelves|bookcase|writing\s+desk)\b",
    re.I,
)

_PROFILE_THRESHOLDS = {
    "library": 196,   # 76.6% after the player deliberately browses there
    "study": 82,      # 32.0%
    "maritime": 58,   # 22.7%
    "religious": 68,  # 26.6%
    "household": 36,  # 14.1%
    "bookish": 48,    # 18.8%
}


def _load_catalog() -> dict[str, dict[str, Any]]:
    try:
        raw = json.loads(_CATALOG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(raw, list):
        return {}
    result: dict[str, dict[str, Any]] = {}
    for row in raw:
        if not isinstance(row, dict):
            continue
        book_id = str(row.get("id") or "").strip()
        title = str(row.get("title") or "").strip()
        if book_id and title:
            result[book_id] = row
    return result


BOOK_CATALOG = _load_catalog()


def _normalized(value: Any) -> str:
    return " ".join(str(value or "").casefold().split())


def _current_locus(state: dict[str, Any]) -> tuple[str, str]:
    location_id = str(state.get("current_location_id") or "unknown")
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    position_id = str(position.get("id") or position.get("label") or "whole-place")
    return f"{location_id}|{_normalized(position_id)}", location_id


def _scene_text(
    state: dict[str, Any], recent_turns: list[dict[str, Any]], player_text: str = ""
) -> str:
    location_id = str(state.get("current_location_id") or "")
    location = state.get("locations", {}).get(location_id, {})
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    fragments = [
        location.get("name"),
        location.get("region"),
        location.get("summary"),
        location.get("defining_excerpt"),
        position.get("label"),
        position.get("summary"),
        position.get("defining_excerpt"),
        player_text,
    ]
    for row in recent_turns[-4:]:
        if isinstance(row, dict):
            fragments.append(row.get("text"))
    return " ".join(str(fragment) for fragment in fragments if str(fragment or "").strip())


def _scene_profile(scene_text: str) -> str | None:
    if _LIBRARY_SCENE.search(scene_text):
        return "library"
    if _STUDY_SCENE.search(scene_text):
        return "study"
    if _MARITIME_SCENE.search(scene_text):
        return "maritime"
    if _RELIGIOUS_SCENE.search(scene_text):
        return "religious"
    if _HOUSEHOLD_SCENE.search(scene_text) and _BOOKISH_SCENE.search(scene_text):
        return "household"
    if _BOOKISH_SCENE.search(scene_text):
        return "bookish"
    return None


def _digest(state: dict[str, Any], locus: str, suffix: str) -> bytes:
    seed = int(state.get("rng_seed", 0) or 0)
    return hashlib.sha256(f"{seed}:{locus}:decorative-books-v1:{suffix}".encode("utf-8")).digest()


def _book_store(state: dict[str, Any]) -> dict[str, Any]:
    store = state.setdefault("book_seeds", {})
    store.setdefault("loci", {})
    store.setdefault("revealed", {})
    store.setdefault("active_reading", None)
    return store


def _visible_candidate(book: dict[str, Any]) -> dict[str, str]:
    return {
        "id": str(book.get("id") or ""),
        "title": str(book.get("title") or ""),
        "author": str(book.get("author") or "Anonymous"),
        "physical": str(book.get("physical") or "A bound volume."),
    }


def _choose_candidates(
    state: dict[str, Any], locus: str, profile: str
) -> list[dict[str, Any]]:
    eligible = [
        book
        for book in BOOK_CATALOG.values()
        if profile == "library"
        or profile == "bookish"
        or profile in {str(value) for value in book.get("habitats", [])}
    ]
    eligible.sort(
        key=lambda book: _digest(state, locus, str(book.get("id") or ""))[:12]
    )
    count = 3 if profile == "library" else 1
    if count == 1:
        return eligible[:1]
    # Select stable families first so a larger library cannot surface three
    # near-identical scholarly allegories merely because their hashes cluster.
    chosen: list[dict[str, Any]] = []
    used_families: set[str] = set()
    for book in eligible:
        family = str(book.get("family") or book.get("mode") or "misc")
        if family in used_families:
            continue
        chosen.append(book)
        used_families.add(family)
        if len(chosen) >= count:
            return chosen
    for book in eligible:
        if book not in chosen:
            chosen.append(book)
        if len(chosen) >= count:
            break
    return chosen


def _failed_resolution(resolved_event: dict[str, Any] | None) -> bool:
    if not isinstance(resolved_event, dict):
        return False
    if resolved_event.get("success") is False:
        return True
    outcome = _normalized(resolved_event.get("outcome"))
    return outcome in {"failure", "critical failure"}


def _reading_target(
    state: dict[str, Any], recent_turns: list[dict[str, Any]], player_text: str
) -> dict[str, Any] | None:
    store = state.get("book_seeds") if isinstance(state.get("book_seeds"), dict) else {}
    revealed = store.get("revealed") if isinstance(store.get("revealed"), dict) else {}
    if not revealed or not _READING_INTENT.search(player_text):
        return None
    locus, _ = _current_locus(state)
    local_ids = [
        book_id
        for book_id, record in revealed.items()
        if isinstance(record, dict) and str(record.get("locus") or "") == locus
    ]
    folded_action = _normalized(player_text)
    exact = [
        BOOK_CATALOG[book_id]
        for book_id in local_ids
        if book_id in BOOK_CATALOG
        and _normalized(BOOK_CATALOG[book_id].get("title")) in folded_action
    ]
    if exact:
        return exact[0]

    recent_text = " ".join(
        str(row.get("text") or "")
        for row in recent_turns[-4:]
        if isinstance(row, dict)
    ).casefold()
    mentioned = [
        BOOK_CATALOG[book_id]
        for book_id in local_ids
        if book_id in BOOK_CATALOG
        and BOOK_CATALOG[book_id]["title"].casefold() in recent_text
    ]
    if len(mentioned) == 1:
        return mentioned[0]
    if len(local_ids) == 1 and _BOOK_NOUN.search(player_text):
        return BOOK_CATALOG.get(local_ids[0])
    return None


def _reading_context(
    book: dict[str, Any], player_text: str, active: dict[str, Any] | None = None
) -> dict[str, Any]:
    allegory = str(book.get("mode") or "") == "allegory_only"
    instruction = (
        "This fixed decorative in-world volume is not a clue, quest, spell, mechanical benefit, or authoritative "
        "account of the game world. Render the reading in this book's own voice: a passage, a few quoted lines "
        "within close narration, or a natural blend. The specimens are a reservoir, not a checklist; quote, condense "
        "or extend them as the moment warrants. Do not answer like an assistant, dump every specimen, or substitute "
        "only the binding or copy annotation when the player asked for an actual passage. Other books remain freely "
        "generative."
    )
    if allegory:
        instruction += (
            " The attributed Bacon work must remain ALLEGORY ONLY: continue through concrete rooms, people, "
            "rituals, transformations and consequences. Never decode it, name the hidden theories, use the "
            "Oracle Lexicon's terminology, or append an interpretive gloss. Even when the player asks why, answer "
            "through another concrete event, observation or consequence inside the fable rather than abstract explanation."
        )
    book_context = {
        "id": book.get("id"),
        "title": book.get("title"),
        "author": book.get("author"),
        "author_note": book.get("author_note"),
        "card": book.get("card"),
        "voice_and_thought_specimens": list(book.get("seed") or []),
    }
    if _MARGINALIA_INTENT.search(player_text):
        book_context["copy_annotation"] = book.get("annotation")
    prior_passages = (
        [str(value) for value in active.get("passages", []) if str(value).strip()]
        if isinstance(active, dict)
        else []
    )
    if prior_passages:
        book_context["earlier_passages_from_this_reading"] = prior_passages[-4:]
    return {
        "mode": "reading",
        "instruction": instruction + (
            " This is an ongoing encounter with the same physical copy. Preserve the work's authorship, voice, "
            "argument, figures, imagery and facts across any follow-up question or reading action. If the player's "
            "new action clearly turns away from the open book, ignore this private capsule."
            if isinstance(active, dict)
            else ""
        ),
        "book": book_context,
    }


def _event_breaks_reading(resolved_event: dict[str, Any] | None) -> bool:
    if not isinstance(resolved_event, dict) or resolved_event.get("committed") is False:
        return False
    return _normalized(resolved_event.get("type")) in {
        "movement",
        "local_movement",
        "resource_movement_resolution",
        "combat_resolution",
    }


def private_book_prompt_context(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
    resolved_event: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Return rare, opt-in decorative book context with zero ordinary-turn cost."""

    locus, _ = _current_locus(state)
    store_view = (
        state.get("book_seeds") if isinstance(state.get("book_seeds"), dict) else {}
    )
    active = (
        store_view.get("active_reading")
        if isinstance(store_view.get("active_reading"), dict)
        else None
    )
    if active and (
        str(active.get("locus") or "") != locus
        or _event_breaks_reading(resolved_event)
        or _CLOSE_OR_SWITCH_BOOK.search(player_text)
    ):
        store_view["active_reading"] = None
        active = None

    reading = _reading_target(state, recent_turns, player_text)
    if reading:
        store = _book_store(state)
        book_id = str(reading.get("id") or "")
        if not active or str(active.get("book_id") or "") != book_id:
            active = {
                "book_id": book_id,
                "locus": locus,
                "opened_at_turn": int(state.get("turn_no", 0) or 0),
                "passages": [],
            }
            store["active_reading"] = active
        active["last_prompted_turn"] = int(state.get("turn_no", 0) or 0)
        return _reading_context(reading, player_text, active)

    if active:
        book_id = str(active.get("book_id") or "")
        book = BOOK_CATALOG.get(book_id)
        if book:
            active["last_prompted_turn"] = int(state.get("turn_no", 0) or 0)
            return _reading_context(book, player_text, active)
        store_view["active_reading"] = None

    if (
        _failed_resolution(resolved_event)
        or _LOOT_INTENT.search(player_text)
        or not _BOOK_NOUN.search(player_text)
        or not _BOOK_DISCOVERY_INTENT.search(player_text)
    ):
        return None
    scene = _scene_text(state, recent_turns, player_text)
    profile = _scene_profile(scene)
    if not profile:
        return None

    locus, location_id = _current_locus(state)
    store = _book_store(state)
    loci = store["loci"]
    existing = loci.get(locus) if isinstance(loci.get(locus), dict) else None
    if existing and str(existing.get("status") or "") != "pending":
        return None
    if existing:
        candidate_ids = [
            str(value) for value in existing.get("candidate_ids", [])
            if str(value) in BOOK_CATALOG
        ]
        candidates = [BOOK_CATALOG[book_id] for book_id in candidate_ids]
    else:
        fortune = _digest(state, locus, profile)
        if fortune[0] >= _PROFILE_THRESHOLDS[profile]:
            loci[locus] = {
                "status": "declined",
                "profile": profile,
                "location_id": location_id,
                "decided_at_turn": int(state.get("turn_no", 0) or 0),
                "candidate_ids": [],
            }
            return None
        candidates = _choose_candidates(state, locus, profile)
        if not candidates:
            return None
        loci[locus] = {
            "status": "pending",
            "profile": profile,
            "location_id": location_id,
            "offered_at_turn": int(state.get("turn_no", 0) or 0),
            "candidate_ids": [str(book.get("id") or "") for book in candidates],
        }

    return {
        "mode": "optional_discovery",
        "instruction": (
            "These are optional decorative easter-egg candidates, not established objects. They carry no clue, "
            "quest, spell, mechanical benefit, supernatural authority, or privileged truth. Surface at most one, only "
            "if this exact place and action make them natural; otherwise ignore them and let the collection contain "
            "only your own invented works or no relevant book. A library may contain these among many freely "
            "invented volumes. If using one, reproduce its exact title and author and show only its physical presence; "
            "do not reveal or summarize its contents until the player actually reads it."
        ),
        "scene_profile": profile,
        "candidates": [_visible_candidate(book) for book in candidates],
    }


def note_book_seed_narration(
    state: dict[str, Any],
    narration: str,
    player_text: str = "",
    resolved_event: dict[str, Any] | None = None,
) -> None:
    """Commit only candidates that visibly appeared; an ignored offer never rerolls."""

    store = state.get("book_seeds") if isinstance(state.get("book_seeds"), dict) else None
    if not store:
        return
    locus, location_id = _current_locus(state)
    active = store.get("active_reading") if isinstance(store.get("active_reading"), dict) else None
    if active:
        if (
            str(active.get("locus") or "") != locus
            or _event_breaks_reading(resolved_event)
            or _CLOSE_OR_SWITCH_BOOK.search(player_text)
        ):
            store["active_reading"] = None
        elif narration.strip():
            passages = active.setdefault("passages", [])
            passages.append(" ".join(narration.split())[:650])
            if len(passages) > 4:
                active["passages"] = [passages[0], *passages[-3:]]
            active["last_read_turn"] = int(state.get("turn_no", 0) or 0)
    loci = store.get("loci") if isinstance(store.get("loci"), dict) else {}
    record = loci.get(locus) if isinstance(loci.get(locus), dict) else None
    if not record or str(record.get("status") or "") != "pending":
        return
    folded = narration.casefold()
    revealed_ids = [
        book_id
        for book_id in record.get("candidate_ids", [])
        if book_id in BOOK_CATALOG
        and str(BOOK_CATALOG[book_id].get("title") or "").casefold() in folded
    ]
    record["resolved_at_turn"] = int(state.get("turn_no", 0) or 0)
    record["status"] = "revealed" if revealed_ids else "declined"
    record["revealed_ids"] = revealed_ids
    if not revealed_ids:
        return
    record["narrated_excerpt"] = " ".join(narration.split())[:650]
    revealed = store.setdefault("revealed", {})
    for book_id in revealed_ids:
        revealed[book_id] = {
            "locus": locus,
            "location_id": location_id,
            "revealed_at_turn": int(state.get("turn_no", 0) or 0),
            "excerpt": record["narrated_excerpt"],
        }
