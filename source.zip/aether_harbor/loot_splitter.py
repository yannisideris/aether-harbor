from __future__ import annotations

import json
import re
from typing import Any

from .items import silver_amounts
from .local_model import LocalQwen


LOOT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "components": {
            "type": "array",
            "maxItems": 4,
            "items": {
                "type": "object",
                "properties": {
                    "kind": {"type": "string", "enum": ["silver", "item"]},
                    "name": {"type": "string"},
                    "item_kind": {
                        "type": "string",
                        "enum": [
                            "misc", "food", "drink", "tool", "key", "document",
                            "weapon", "armor", "clothing", "consumable", "valuable",
                        ],
                    },
                    "quantity": {"type": "integer", "minimum": 1, "maximum": 20},
                    "amount": {"type": "integer", "minimum": 0, "maximum": 100000},
                },
                "required": ["kind", "name", "item_kind", "quantity", "amount"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["components"],
    "additionalProperties": False,
}


SYSTEM = """
You are a literal resource-bundle splitter for a tabletop RPG, not a narrator.
The player is taking a small explicitly established bundle containing two or
more distinct objects, or objects plus an exact quantity of silver. Split only
what the supplied scene text clearly says is physically present AND what the
player is explicitly taking now. Do not infer contents, value, ownership,
magic, or extra treasure.

This helper is called only after the main judge has confirmed a collective
take. In player_action, "all", "those", "these", "them", or "contents" means
all concrete contents of the supplied visible bundle; do not reject that
ordinary reference merely because it is a pronoun.

Use kind silver only for loose silver currency and copy its exact integer into
amount; name must be "Silver" and quantity must be 1. Use kind item for each
distinct carried object, with amount 0. Preserve a title or proper object name
from the scene even when the player makes a small spelling error. A pouch, box,
or other container is an item only when the player is plainly taking the
container itself, not merely its contents. Return an empty components list
unless at least two distinct requested physical components are grounded, or
if the requested bundle remains ambiguous. Return JSON only.
""".strip()


_COLLECTIVE_TAKE = re.compile(
    r"\b(?:all|both|everything|those|these|them|contents|whole\s+(?:lot|bundle))\b",
    re.I,
)
_COMPOUND_WORDING = re.compile(r"\b(?:silver|coins?)\b.*\b(?:and|with|alongside|plus)\b|\b(?:and|with|alongside|plus)\b.*\b(?:silver|coins?)\b", re.I | re.S)
_QUOTED_OBJECT = re.compile(r"[\"“”][^\"“”]{2,100}[\"“”]")
_MULTI_OBJECT_WORDING = re.compile(r"\b(?:and|plus|alongside|together\s+with)\b", re.I)
_COUNTED_COLLECTIVE = re.compile(
    r"\b(?:all\s+)?(?:two|three|four|2|3|4)|\bboth\b", re.I
)
_VISIBLE_LIST = re.compile(r",.{1,120}(?:,|\band\b)|\b\w+.{0,80}\band\b.{1,80}\b\w+", re.I | re.S)
_WORDS = re.compile(r"[a-z0-9]+", re.I)


def _resource_action(semantic_roll: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(semantic_roll, dict):
        return {}
    value = semantic_roll.get("resource_action")
    return value if isinstance(value, dict) else {}


def _latest_world_text(recent_turns: list[dict[str, Any]]) -> str:
    for row in reversed(recent_turns):
        if not isinstance(row, dict):
            continue
        if str(row.get("speaker") or "").casefold() in {"visitor", "player", "user"}:
            continue
        text = str(row.get("text") or "").strip()
        if text:
            return text
    return ""


def should_split(
    semantic_roll: dict[str, Any] | None,
    *,
    player_text: str,
    recent_turns: list[dict[str, Any]],
) -> bool:
    advice = _resource_action(semantic_roll)
    if str(advice.get("kind") or "") not in {"take", "receive_item"}:
        return False
    if str(advice.get("status") or "") not in {"confirmed", "ambiguous"}:
        return False
    scene = _latest_world_text(recent_turns)
    if not scene:
        return False
    item = str(advice.get("item") or "")
    collective = bool(_COLLECTIVE_TAKE.search(player_text))
    multiple_quoted = len(_QUOTED_OBJECT.findall(player_text)) >= 2
    plural_advice = int(advice.get("quantity", 1) or 1) >= 2
    separate_wording = bool(
        _MULTI_OBJECT_WORDING.search(item)
        or (multiple_quoted and _MULTI_OBJECT_WORDING.search(player_text))
    )
    mixed_currency = bool(silver_amounts(scene) and _COMPOUND_WORDING.search(f"{item} {scene}"))
    counted_visible_bundle = bool(
        collective
        and _COUNTED_COLLECTIVE.search(player_text)
        and _VISIBLE_LIST.search(scene)
    )
    return bool(
        (collective and (separate_wording or mixed_currency))
        or counted_visible_bundle
        or multiple_quoted
        or (plural_advice and separate_wording)
    )


def _grounded_item(name: str, scene: str) -> bool:
    wanted = {word for word in _WORDS.findall(name.casefold()) if len(word) >= 4}
    available = set(_WORDS.findall(scene.casefold()))
    return bool(wanted and wanted.intersection(available))


def _known_detail(name: str, scene: str) -> str:
    wanted = {word for word in _WORDS.findall(name.casefold()) if len(word) >= 4}
    for sentence in re.split(r"(?<=[.!?])\s+", scene):
        available = set(_WORDS.findall(sentence.casefold()))
        if wanted and wanted.intersection(available):
            return " ".join(sentence.split())[:180]
    return ""


def split_compound_loot(
    *,
    model: LocalQwen,
    semantic_roll: dict[str, Any],
    player_text: str,
    recent_turns: list[dict[str, Any]],
) -> dict[str, Any]:
    """Attach a validated multi-transfer bundle, or leave Qwen's advice alone."""

    if not should_split(
        semantic_roll,
        player_text=player_text,
        recent_turns=recent_turns,
    ):
        return semantic_roll
    advice = _resource_action(semantic_roll)
    scene = _latest_world_text(recent_turns)
    payload = model.chat_json(
        [
            {"role": "system", "content": SYSTEM},
            {
                "role": "user",
                "content": json.dumps(
                    {
                        "scene_text": scene,
                        "player_action": player_text,
                    },
                    ensure_ascii=False,
                ),
            },
        ],
        schema=LOOT_SCHEMA,
        temperature=0.1,
    )
    exact_silver = set(silver_amounts(scene))
    components: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    raw_components = [
        row for row in payload.get("components", [])[:4] if isinstance(row, dict)
    ]
    for raw in raw_components:
        if not isinstance(raw, dict):
            continue
        kind = str(raw.get("kind") or "")
        if kind == "silver":
            amount = int(raw.get("amount", 0) or 0)
            if amount <= 0 or amount not in exact_silver:
                continue
            component = {
                "kind": "receive_money",
                "status": "confirmed",
                "item": "",
                "item_kind": "misc",
                "quantity": 1,
                "amount": amount,
                "counterparty": "",
                "timing": "on_success" if semantic_roll.get("requires_roll") is True else "immediate",
                "reason": "Exact silver inside the grounded loot bundle.",
            }
            key = ("silver", str(amount))
        elif kind == "item":
            name = " ".join(str(raw.get("name") or "").split())[:100]
            if not name or not _grounded_item(name, scene):
                continue
            component = {
                "kind": str(advice.get("kind") or "take"),
                "status": "confirmed",
                "item": name,
                "item_kind": str(raw.get("item_kind") or "misc"),
                "quantity": max(1, min(20, int(raw.get("quantity", 1) or 1))),
                "amount": 0,
                "counterparty": "",
                "timing": "on_success" if semantic_roll.get("requires_roll") is True else "immediate",
                "reason": "Distinct object inside the grounded loot bundle.",
                "known_detail": _known_detail(name, scene),
            }
            key = ("item", name.casefold())
        else:
            continue
        if key not in seen:
            seen.add(key)
            components.append(component)
    has_money = any(row["kind"] == "receive_money" for row in components)
    has_item = any(row["kind"] in {"take", "receive_item"} for row in components)
    # When Qwen did identify a real multi-object bundle but accidentally typed
    # the explicit coins as an item, the one exact scene amount is sufficient
    # to normalize that currency without guessing. An empty/uncertain helper
    # result is still respected and never receives this repair.
    if raw_components and has_item and not has_money and len(exact_silver) == 1:
        amount = next(iter(exact_silver))
        components.append(
            {
                "kind": "receive_money",
                "status": "confirmed",
                "item": "",
                "item_kind": "misc",
                "quantity": 1,
                "amount": amount,
                "counterparty": "",
                "timing": "on_success" if semantic_roll.get("requires_roll") is True else "immediate",
                "reason": "The sole exact silver amount in the grounded loot bundle.",
            }
        )
        has_money = True
    if len(components) < 2:
        return semantic_roll
    return {**semantic_roll, "resource_bundle": components}
