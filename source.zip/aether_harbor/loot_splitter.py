from __future__ import annotations

import json
import re
from typing import Any

from .items import silver_amounts
from .local_model import LocalQwen


LOOT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "components": {
            "type": "array",
            "maxItems": 4,
            "items": {
                "type": "object",
                "properties": {
                    "kind": {"type": "string", "enum": ["silver", "item"]},
                    "name": {"type": "string"},
                    "item_kind": {
                        "type": "string",
                        "enum": [
                            "misc", "food", "drink", "tool", "key", "document",
                            "weapon", "armor", "clothing", "consumable", "valuable",
                        ],
                    },
                    "quantity": {"type": "integer", "minimum": 1, "maximum": 20},
                    "amount": {"type": "integer", "minimum": 0, "maximum": 100000},
                },
                "required": ["kind", "name", "item_kind", "quantity", "amount"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["components"],
    "additionalProperties": False,
}


SYSTEM = """
You are a literal resource-bundle splitter for a tabletop RPG, not a narrator.
Determine which physical objects or silver the player takes. List only
what the supplied scene text clearly says is physically present AND what the
player is explicitly taking now. Do not infer contents, value, ownership,
magic, or extra treasure.

This helper is called when the main judge or referee indicates a multi-item
or collective take (or an item taken alongside coins). In player_action, "all", "those", "these", "them", or "contents" means
all concrete contents of the supplied visible bundle; do not reject that
ordinary reference merely because it is a pronoun.

Use kind silver only for loose silver currency and copy its exact integer into
amount; name must be "Silver" and quantity must be 1. Use kind item for each
distinct carried object, with amount 0. Preserve a title or proper object name
from the scene even when the player makes a small spelling error. A pouch, box,
or other container is an item only when the player is plainly taking the
container itself, not merely its contents. Counting coins left in place is not a transfer.
For identical objects return one item component with their actual quantity (three candles -> one row, quantity 3).
Use a scene noun as its name, without the count. One requested object gets one row even if other objects are only inspected.
If a requested transfer is ambiguous, return an empty list. Return JSON only.
""".strip()


_WORDS = re.compile(r"[^\W_]+")


def _resource_action(semantic_roll: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(semantic_roll, dict):
        return {}
    value = semantic_roll.get("resource_action")
    return value if isinstance(value, dict) else {}


def _latest_world_text(recent_turns: list[dict[str, Any]]) -> str:
    for row in reversed(recent_turns):
        if not isinstance(row, dict):
            continue
        if str(row.get("speaker") or "").casefold() in {"visitor", "player", "user"}:
            continue
        text = str(row.get("text") or "").strip()
        if text:
            return text
    return ""


def should_split(
    semantic_roll: dict[str, Any] | None,
    *,
    player_text: str,
    recent_turns: list[dict[str, Any]],
) -> bool:
    advice = _resource_action(semantic_roll)
    if str(advice.get("kind") or "") not in {"take", "receive_item"}:
        return False
    if str(advice.get("status") or "") not in {"confirmed", "ambiguous"}:
        return False
    # Legacy judgments had no separate component field.
    other = advice.get("other_pickup")
    if not isinstance(other, str):
        return True
    return other.strip().casefold() not in {"", "none"} or bool(advice.get("item") and advice.get("amount"))


def _grounded_item(name: str, scene: str) -> bool:
    tokens = _WORDS.findall(name.casefold())
    wanted = {word for word in tokens if len(word) >= 4}
    if len(tokens) == 1:
        wanted.update(tokens)
    available = set(_WORDS.findall(scene.casefold()))
    return any(word in available or word + "s" in available for word in wanted)


def _known_detail(name: str, scene: str) -> str:
    wanted = {word for word in _WORDS.findall(name.casefold()) if len(word) >= 4}
    for sentence in re.split(r"(?<=[.!?])\s+", scene):
        available = set(_WORDS.findall(sentence.casefold()))
        if wanted and wanted.intersection(available):
            return " ".join(sentence.split())[:180]
    return ""


def split_compound_loot(
    *,
    model: LocalQwen,
    semantic_roll: dict[str, Any],
    player_text: str,
    recent_turns: list[dict[str, Any]],
) -> dict[str, Any]:
    """Resolve a suspected bundle from the scene before the engine commits it."""

    if not should_split(
        semantic_roll,
        player_text=player_text,
        recent_turns=recent_turns,
    ):
        return semantic_roll
    advice = _resource_action(semantic_roll)
    scene = _latest_world_text(recent_turns)
    timing = "on_success" if semantic_roll.get("requires_roll") is True else "immediate"
    unresolved = {
        **semantic_roll,
        "resource_action": {**advice, "status": "ambiguous", "timing": timing},
    }
    if not scene:
        return unresolved if "other_pickup" in advice else semantic_roll
    try:
        payload = model.chat_json(
            [
                {"role": "system", "content": SYSTEM},
                {
                    "role": "user",
                    "content": json.dumps(
                        {
                            "scene_text": scene,
                            "player_action": player_text,
                        },
                        ensure_ascii=False,
                    ),
                },
            ],
            schema=LOOT_SCHEMA,
            temperature=0.1,
        )
    except Exception:
        return unresolved
    exact_silver = set(silver_amounts(scene))
    components: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    rows = payload.get("components") if isinstance(payload, dict) else None
    if not isinstance(rows, list) or len(rows) > 4:
        return unresolved
    for raw in rows:
        if not isinstance(raw, dict):
            return unresolved
        kind = str(raw.get("kind") or "")
        if kind == "silver":
            amount = raw.get("amount")
            if type(amount) is not int or amount <= 0 or amount not in exact_silver:
                return unresolved
            component = {
                "kind": "receive_money",
                "status": "confirmed",
                "item": "",
                "item_kind": "misc",
                "quantity": 1,
                "amount": amount,
                "counterparty": "",
                "timing": timing,
                "reason": "Exact silver inside the grounded loot bundle.",
            }
            key = ("silver", str(amount))
        elif kind == "item":
            name = " ".join(str(raw.get("name") or "").split())[:100]
            quantity = raw.get("quantity", 1)
            if type(quantity) is not int or not 1 <= quantity <= 20 or not name or not _grounded_item(name, scene):
                return unresolved
            component = {
                "kind": str(advice.get("kind") or "take"),
                "status": "confirmed",
                "item": name,
                "item_kind": str(raw.get("item_kind") or "misc"),
                "quantity": quantity,
                "amount": 0,
                "counterparty": advice.get("counterparty", ""),
                "timing": timing,
                "reason": "Distinct object inside the grounded loot bundle.",
                "known_detail": _known_detail(name, scene),
            }
            key = ("item", name.casefold())
        else:
            return unresolved
        if key not in seen:
            seen.add(key)
            components.append(component)
    if not components:
        return unresolved
    if len(components) == 1:
        return {**semantic_roll, "resource_action": components[0]}
    return {**semantic_roll, "resource_bundle": components}
