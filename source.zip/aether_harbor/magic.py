from __future__ import annotations

import re
from typing import Any

from .mechanics import (
    ensure_magic_combat_target,
    queue_enemy_defense_phase,
    record_combat_digest,
    resolve_d20,
    resolve_zero_hp,
    roll_actor,
    absorb_ward,
)



SPELLS: dict[str, dict[str, Any]] = {
    "flamma": {"name": "Flamma", "category": "elemental", "description": "Shape fire from a small flame to forceful or obstructing fire.", "families": ["damage", "environment", "area_denial"]},
    "aqua": {"name": "Aqua", "category": "elemental", "description": "Shape water or cold into force, control, or defense.", "families": ["damage", "control", "defense", "environment"]},
    "terra": {"name": "Terra", "category": "elemental", "description": "Move or shape earth for force, obstruction, defense, or control.", "families": ["damage", "control", "defense", "environment"]},
    "aero": {"name": "Aero", "category": "elemental", "description": "Generate and shape moving air.", "families": ["damage", "control", "mobility", "environment"]},
    "praecognitio": {"name": "Praecognitio", "category": "divination", "description": "Glimpse one possible future rather than an infallible prophecy.", "families": ["revelation"]},
    "retrocognitio": {"name": "Retrocognitio", "category": "divination", "description": "Receive a vision of a past event.", "families": ["revelation"]},
    "revelatio": {"name": "Revelatio", "category": "divination", "description": "Detect hidden objects, illusions, or the true nature of something.", "families": ["detection", "revelation"]},
    "communico": {"name": "Communico", "category": "divination", "description": "Briefly communicate with a spirit or entity.", "families": ["communication", "revelation"]},
    "firmitas": {"name": "Firmitas", "category": "enchantment", "description": "Temporarily fortify the strength or durability of an object or person.", "families": ["enhancement", "defense"]},
    "celeritas": {"name": "Celeritas", "category": "enchantment", "description": "Temporarily hasten a person or creature.", "families": ["enhancement", "mobility"]},
    "lucis": {"name": "Lucis", "category": "enchantment", "description": "Cause an object to glow with magical light.", "families": ["light", "utility"]},
    "umbra": {"name": "Umbra", "category": "enchantment", "description": "Shroud an object or area in magical darkness.", "families": ["darkness", "control", "concealment"]},
    "sanus": {"name": "Sanus", "category": "healing", "description": "Restore a small amount of health.", "families": ["healing"]},
    "purifico": {"name": "Purifico", "category": "healing", "description": "Cure a disease or neutralize a poison.", "families": ["purification", "healing"]},
    "restituo": {"name": "Restituo", "category": "healing", "description": "Mend a broken bone or damaged organ; difficult and costly.", "families": ["restoration", "healing"], "minimum_tier": "major"},
    "fallacia": {"name": "Fallacia", "category": "mental", "description": "Create a visual or auditory illusion.", "families": ["illusion", "control"]},
    "persuadeo": {"name": "Persuadeo", "category": "mental", "description": "Subtly influence thoughts or actions without absolute mind control.", "families": ["influence"]},
    "metus": {"name": "Metus", "category": "mental", "description": "Induce fear or panic.", "families": ["fear", "control"]},
    "caligo": {"name": "Caligo", "category": "mental", "description": "Cloud a mind and cause disorientation.", "families": ["confusion", "control"]},
    "umbrae": {"name": "Umbrae", "category": "necromantic", "description": "Conjure sinister shadowy creatures.", "families": ["summoning", "control"], "taboo": True},
    "exanimus": {"name": "Exanimus", "category": "necromantic", "description": "Temporarily reanimate a corpse.", "families": ["animation", "control"], "taboo": True},
    "spiritus": {"name": "Spiritus", "category": "necromantic", "description": "Speak with a dead spirit for information, not control.", "families": ["communication", "revelation"]},
    "vitae_drain": {"name": "Vitae Drain", "category": "necromantic", "description": "Drain a target's life force.", "families": ["damage", "drain", "healing"], "taboo": True, "minimum_tier": "standard"},
    "aegis": {"name": "Aegis", "category": "protection", "description": "Create a magical shield that absorbs harm.", "families": ["defense", "protection"]},
    "warda": {"name": "Warda", "category": "protection", "description": "Ward an area or object against entry or disturbance.", "families": ["ward", "protection", "alarm"]},
    "reflecto": {"name": "Reflecto", "category": "protection", "description": "Attempt to reflect an incoming spell.", "families": ["reflection", "defense"]},
    "virentia": {"name": "Virentia", "category": "nature", "description": "Accelerate the growth of plants.", "families": ["growth", "environment"]},
    "loquor_bestia": {"name": "Loquor Bestia", "category": "nature", "description": "Understand and communicate with animals.", "families": ["communication", "nature"]},
    "dominus_naturae": {"name": "Dominus Naturae", "category": "nature", "description": "Exert limited control over a small natural area or take an animal form.", "families": ["control", "nature", "transformation"]},
}


POWER_TIERS: dict[str, dict[str, int]] = {
    "minor": {"dc": 10, "success_toll": 0, "strong_toll": 0, "failure_toll": 1, "critical_toll": 2, "damage": 2, "strong_damage": 3},
    "standard": {"dc": 14, "success_toll": 0, "strong_toll": 0, "failure_toll": 2, "critical_toll": 4, "damage": 4, "strong_damage": 6},
    "major": {"dc": 18, "success_toll": 1, "strong_toll": 0, "failure_toll": 3, "critical_toll": 6, "damage": 6, "strong_damage": 9},
    "extreme": {"dc": 22, "success_toll": 2, "strong_toll": 1, "failure_toll": 5, "critical_toll": 8, "damage": 9, "strong_damage": 13},
}
TIER_ORDER = {"minor": 0, "standard": 1, "major": 2, "extreme": 3}


def magic_outcome(raw: int, total: int, dc: int) -> str:
    if raw == 1 or total <= 5:
        return "critical_failure"
    if raw == 20 or total >= dc + 8:
        return "strong_success"
    return "success" if total >= dc else "failure"

CAST_WORDS = re.compile(r"\b(?:cast|invoke|conjure|weave|work|release|shape)\b", re.I)
LEARN_WORDS = re.compile(r"\b(?:learn|study|master|memorize|decipher|translate|comprehend|read\s+through|meditate\s+on)\b", re.I)
QUESTION_OR_HYPOTHETICAL = re.compile(r"(?:\?|\b(?:would|could|might|what\s+if|ask\s+whether)\b)", re.I)
HOSTILE_WORDS = re.compile(r"\b(?:attack|harm|hurt|burn|blast|strike|kill|drain|smite|against|at)\b", re.I)


def mentioned_spell(
    text: str,
    semantic_magic: dict[str, Any] | None = None,
    allow_regex: bool = True,
) -> tuple[str, dict[str, Any]] | None:
    if isinstance(semantic_magic, dict) and semantic_magic.get("spell_name"):
        requested = str(semantic_magic["spell_name"]).strip().casefold()
        if requested not in {"none", ""}:
            for spell_id, spell in SPELLS.items():
                if requested in (spell_id, str(spell["name"]).casefold()):
                    return spell_id, spell
            return None
        return None

    if not allow_regex:
        return None

    matches: list[tuple[int, str, dict[str, Any]]] = []
    for spell_id, spell in SPELLS.items():
        name = str(spell["name"])
        if re.search(rf"\b{re.escape(name)}\b", text, re.I):
            matches.append((len(name), spell_id, spell))
    if not matches:
        return None
    _, spell_id, spell = max(matches, key=lambda row: row[0])
    return spell_id, spell


def _tier(
    text: str,
    spell: dict[str, Any],
    semantic_magic: dict[str, Any] | None = None,
    allow_regex: bool = True,
) -> str:
    if isinstance(semantic_magic, dict):
        sem_tier = str(semantic_magic.get("power_tier") or "").strip().lower()
        if sem_tier in TIER_ORDER:
            minimum = str(spell.get("minimum_tier") or "minor")
            return minimum if TIER_ORDER[sem_tier] < TIER_ORDER[minimum] else sem_tier
    if not allow_regex:
        return str(spell.get("minimum_tier") or "standard")
    if re.search(r"\b(?:extreme|entire\s+island|cataclysmic|vast|hurricane|inferno)\b", text, re.I):
        proposed = "extreme"
    elif re.search(r"\b(?:major|powerful|great|large|broad|lasting|wall|wave|group)\b", text, re.I):
        proposed = "major"
    elif re.search(r"\b(?:minor|small|tiny|brief|gentle|candle|spark|faint)\b", text, re.I):
        proposed = "minor"
    else:
        proposed = "standard"
    minimum = str(spell.get("minimum_tier") or "minor")
    return minimum if TIER_ORDER[proposed] < TIER_ORDER[minimum] else proposed


def _target(text: str, allow_regex: bool = True) -> str | None:
    if not allow_regex:
        return None
    match = re.search(r"\b(?:at|against|towards?|on|upon)\s+(?:the\s+)?([^,.!?;]{1,70})", text, re.I)
    if not match:
        return None
    target = re.split(r"\b(?:with|using|while|so\s+that)\b", match.group(1), maxsplit=1, flags=re.I)[0]
    return " ".join(target.split())[:70] or None


def _effect_family(
    text: str,
    spell: dict[str, Any],
    hostile: bool,
    semantic_magic: dict[str, Any] | None = None,
    allow_regex: bool = True,
) -> str:
    families = [str(value) for value in spell.get("families", [])]
    if hostile and "damage" in families:
        return "damage"
    if allow_regex:
        cues = [
            (r"\b(?:hide|conceal|shadow|dark)\b", ["concealment", "darkness", "illusion"]),
            (r"\b(?:reveal|detect|find|true|hidden)\b", ["detection", "revelation"]),
            (r"\b(?:protect|shield|fortify|defend)\b", ["protection", "defense", "ward"]),
            (r"\b(?:heal|mend|cure|poison)\b", ["healing", "restoration", "purification"]),
            (r"\b(?:move|speed|swift|hasten)\b", ["mobility", "enhancement"]),
            (r"\b(?:speak|communicate|question)\b", ["communication"]),
        ]
        for pattern, choices in cues:
            if re.search(pattern, text, re.I):
                for choice in choices:
                    if choice in families:
                        return choice
    for family in families:
        if family != "damage":
            return family
    return families[0] if families else "utility"


def _known_spell_ids(state: dict[str, Any], actor: str = "NONE") -> set[str]:
    caster = roll_actor(state, actor)
    known_names = {str(value).casefold() for value in caster.get("known_spells", [])}
    return {spell_id for spell_id, spell in SPELLS.items() if str(spell["name"]).casefold() in known_names}



def _learning_source(
    state: dict[str, Any],
    spell_id: str,
    spell: dict[str, Any],
    target_hint: str = "",
) -> dict[str, Any] | None:
    # 1. Search player inventory
    inventory = state.get("player", {}).get("inventory", [])
    for item in inventory:
        if not isinstance(item, dict):
            continue
        teaches = str(item.get("teaches_spell") or "").casefold()
        name = str(item.get("name") or "")
        if teaches == spell_id or (
            str(spell["name"]).casefold() in name.casefold()
            and re.search(r"\b(?:scroll|text|grimoire|tablets?|notes?|parchment|vellum|tome|codex|manuscript|book)\b", name, re.I)
        ):
            return item

    if target_hint:
        hint_low = target_hint.casefold()
        for item in inventory:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").casefold()
            if hint_low in name or name in hint_low:
                teaches = str(item.get("teaches_spell") or "").casefold()
                if teaches in {spell_id, ""} or str(spell["name"]).casefold() in name:
                    return item

    # 2. Search scene / room inscriptions, steles, murals, altars
    scene_objects = state.get("scene_objects") or state.get("room_objects") or state.get("scene_inscriptions") or []
    if isinstance(scene_objects, list):
        for obj in scene_objects:
            if not isinstance(obj, dict):
                continue
            teaches = str(obj.get("teaches_spell") or "").casefold()
            name = str(obj.get("name") or "")
            if teaches == spell_id or (
                str(spell["name"]).casefold() in name.casefold()
                and re.search(r"\b(?:inscription|stele|mural|carving|altar|pillar|monolith|fresco|runes?|relief)\b", name, re.I)
            ):
                return obj

    current_loc = state.get("current_location") or {}
    if isinstance(current_loc, dict):
        loc_inscriptions = current_loc.get("inscriptions") or []
        for insc in loc_inscriptions:
            if isinstance(insc, dict):
                teaches = str(insc.get("teaches_spell") or "").casefold()
                if teaches == spell_id or str(spell["name"]).casefold() in str(insc.get("name", "")).casefold():
                    return insc

    # 3. Search present NPCs / tutors
    for npc in state.get("present_npcs", []):
        if not isinstance(npc, dict):
            continue
        npc_spells = [str(s).casefold() for s in npc.get("known_spells", [])]
        if spell_id in npc_spells or str(spell["name"]).casefold() in npc_spells:
            return {
                "name": f"{npc.get('name', 'Tutor')} (Tutor)",
                "kind": "tutor",
                "source_key": f"tutor_{npc.get('name', 'unknown')}",
            }

    return None


def _record_effect(state: dict[str, Any], event: dict[str, Any], spell: dict[str, Any]) -> None:
    if event["duration"] == "instant" or event["outcome"] not in {"success", "strong_success"}:
        return
    effects = state.setdefault("magic", {}).setdefault("active_effects", [])
    effects.append(
        {
            "spell_id": event["spell_id"],
            "spell_name": event["spell_name"],
            "effect_family": event["effect_family"],
            "effect_families": list(spell.get("families", [])),
            "intended_effect": event["intended_effect"],
            "strength": event["effect_strength"],
            "location_id": str(state.get("current_location_id") or ""),
            "duration": event["duration"],
            "created_turn": int(state.get("turn_no", 0) or 0),
        }
    )
    state["magic"]["active_effects"] = effects[-12:]


def resolve_magic_action(
    state: dict[str, Any],
    text: str,
    *,
    semantic_roll: dict[str, Any] | None = None,
    manual_roll: int | None = None,
    allow_regex_fallback: bool | None = None,
) -> dict[str, Any] | None:
    if allow_regex_fallback is None:
        allow_regex_fallback = (semantic_roll is None)

    semantic_magic = (
        semantic_roll.get("magic")
        if isinstance(semantic_roll, dict) and isinstance(semantic_roll.get("magic"), dict)
        else None
    )

    # STRICT SEMANTIC GOVERNANCE:
    # When semantic adjudication is active (live gameplay with Gemma), the model is authoritative.
    # If the model explicitly judged that the action is NOT magic, never allow regex to auto-trigger.
    if semantic_magic is not None and not semantic_magic.get("is_magic"):
        return None

    mentioned = mentioned_spell(text, semantic_magic=semantic_magic, allow_regex=allow_regex_fallback)
    if not mentioned or QUESTION_OR_HYPOTHETICAL.search(text):
        return None
    spell_id, spell = mentioned
    is_learning = False
    is_casting = False
    if semantic_magic is not None:
        intent = str(semantic_magic.get("intent") or "").casefold()
        if intent == "learn":
            is_learning = True
            is_casting = False
        elif intent == "cast":
            is_casting = True
            is_learning = False
        else:
            is_casting = bool(semantic_magic.get("is_magic"))
            effect_text = str(semantic_magic.get("intended_effect") or "").casefold()
            target_text = str(semantic_magic.get("target") or "").casefold()
            if not semantic_magic.get("hostile") and any(w in effect_text for w in ("learn", "study", "decipher", "read", "memorize", "comprehend", "translate", "grasp", "master", "understand", "inscribe")):
                is_learning = True
                is_casting = False
            elif not semantic_magic.get("hostile") and any(w in target_text for w in ("scroll", "text", "grimoire", "tome", "inscription", "stele", "tablet", "mural", "altar", "book", "vellum", "parchment", "tutor")):
                if any(w in effect_text for w in ("read", "look", "examine", "trace", "study", "decipher", "consult", "listen")):
                    is_learning = True
                    is_casting = False
    elif allow_regex_fallback:
        is_learning = bool(LEARN_WORDS.search(text))
        is_casting = (
            bool(CAST_WORDS.search(text))
            or bool(re.match(rf"\s*{re.escape(str(spell['name']))}\b", text, re.I))
        )
    else:
        is_casting = False

    if not is_learning and not is_casting:
        return None

    actor_name = "NONE"
    if isinstance(semantic_magic, dict) and semantic_magic.get("actor") and str(semantic_magic["actor"]).strip().upper() not in {"NONE", "PLAYER", ""}:
        actor_name = str(semantic_magic["actor"]).strip()
    elif isinstance(semantic_roll, dict) and semantic_roll.get("acting_companion") and str(semantic_roll["acting_companion"]).strip().upper() not in {"NONE", "PLAYER", ""}:
        actor_name = str(semantic_roll["acting_companion"]).strip()

    player = state["player"]
    caster = roll_actor(state, actor_name)
    if int(caster.get("hp", 0)) <= 0:
        return {"type": "magic_rejected", "committed": False, "reason": f"{caster.get('name', 'Caster')} cannot cast at 0 HP."}
    if actor_name in {"NONE", None, ""}:
        if str(player.get("class_id") or "").casefold() != "mage":
            return {"type": "magic_rejected", "committed": False, "spell_name": spell["name"], "reason": "Formal spellcasting requires Mage training."}
    else:
        caster_spells = {str(x).casefold() for x in caster.get("known_spells", [])}
        if str(caster.get("class_id") or "").casefold() != "mage" and str(spell["name"]).casefold() not in caster_spells and not is_learning:
            return {"type": "magic_rejected", "committed": False, "spell_name": spell["name"], "reason": f"{caster.get('name', 'Companion')} has not learned that spell."}

    known_ids = _known_spell_ids(state, actor=actor_name)
    if is_learning:
        if spell_id in known_ids:
            return {"type": "magic_rejected", "committed": False, "spell_name": spell["name"], "reason": "The spell is already known."}
        target_hint = ""
        if isinstance(semantic_magic, dict) and semantic_magic.get("target"):
            target_hint = str(semantic_magic["target"])
        source = _learning_source(state, spell_id, spell, target_hint=target_hint)
        if source is None:
            return {"type": "magic_rejected", "committed": False, "spell_name": spell["name"], "reason": "Learning requires a concrete scroll, text, or grimoire in inventory."}
        source_key = str(source.get("source_key") or source.get("name") or spell_id).casefold()
        
        strained = state.setdefault("magic", {}).setdefault("strained_learning_sources", {}).get(source_key, [])
        if spell_id in strained:
            return {
                "type": "magic_rejected",
                "committed": False,
                "spell_name": spell["name"],
                "reason": "Your mind is still strained from studying this source. You must rest before attempting to decipher it again.",
            }

        tier = max("standard", str(spell.get("minimum_tier") or "minor"), key=lambda value: TIER_ORDER[value])
        rules = POWER_TIERS[tier]
        roll = resolve_d20(
            state, "ARC", rules["dc"], f"learn {spell['name']} from {source.get('name')}",
            manual_roll=manual_roll,
            actor=actor_name,
        )
        is_crit_fail = roll["raw"] == 1 or roll["total"] <= 5
        is_strong = roll["raw"] == 20 or roll["total"] >= roll["dc"] + 8
        if is_crit_fail:
            outcome = "critical_failure"
        elif is_strong:
            outcome = "strong_success"
        elif roll["success"]:
            outcome = "success"
        else:
            outcome = "failure"

        hp_toll = 0
        backfire = False
        source_destroyed = False

        if outcome in {"success", "strong_success"}:
            caster.setdefault("known_spells", []).append(spell["name"])
            learned = True
            if source.get("single_use"):
                inventory = state.get("player", {}).get("inventory", [])
                if source in inventory:
                    inventory.remove(source)
                    source_destroyed = True
        elif outcome == "failure":
            learned = False
            hp_toll = 1
            caster["hp"] = max(1, int(caster.get("hp", 1)) - hp_toll)
            state["magic"].setdefault("strained_learning_sources", {}).setdefault(source_key, []).append(spell_id)
            state["magic"].setdefault("failed_learning_sources", {}).setdefault(source_key, []).append(spell_id)
        else:
            learned = False
            backfire = True
            hp_toll = 2
            caster["hp"] = max(0, int(caster.get("hp", 0)) - hp_toll)
            is_durable = bool(source.get("durable") or any(w in str(source.get("name", "")).casefold() for w in ("grimoire", "tome", "codex", "monolith", "altar", "inscription", "stele", "mural", "tutor")))
            if not is_durable:
                inventory = state.get("player", {}).get("inventory", [])
                if source in inventory:
                    inventory.remove(source)
                    source_destroyed = True
            state["magic"].setdefault("strained_learning_sources", {}).setdefault(source_key, []).append(spell_id)
            state["magic"].setdefault("failed_learning_sources", {}).setdefault(source_key, []).append(spell_id)

        return {
            "type": "magic_learning",
            "committed": True,
            "actor": actor_name,
            "spell_id": spell_id,
            "spell_name": spell["name"],
            "source": source.get("name"),
            "roll": roll,
            "outcome": outcome,
            "learned": learned,
            "hp_toll": hp_toll,
            "backfire": backfire,
            "source_destroyed": source_destroyed,
        }

    if spell_id not in known_ids:
        return {"type": "magic_rejected", "committed": False, "spell_name": spell["name"], "reason": "The spell has not been learned from a scroll, text, or mage."}

    combat_advice = (
        semantic_roll.get("combat")
        if isinstance(semantic_roll, dict)
        and isinstance(semantic_roll.get("combat"), dict)
        else {}
    )
    semantic_target = " ".join(str(combat_advice.get("target") or "").split())[:70]
    if isinstance(semantic_magic, dict) and semantic_magic.get("target") and str(semantic_magic["target"]).strip().upper() not in {"NONE", ""}:
        target_name = " ".join(str(semantic_magic["target"]).split())[:70]
    elif combat_advice.get("action") == "attack" and semantic_target:
        target_name = semantic_target
    else:
        target_name = _target(text, allow_regex=allow_regex_fallback)

    active_opponent = state.get("combat", {}).get("opponent") if isinstance(state.get("combat"), dict) else None
    combat_was_active = bool(
        isinstance(state.get("combat"), dict)
        and state["combat"].get("status") == "active"
    )
    hostile_capable = bool(
        {"damage", "drain", "fear", "confusion", "control", "influence"}.intersection(spell.get("families", []))
    )
    if isinstance(semantic_magic, dict) and "hostile" in semantic_magic and isinstance(semantic_magic["hostile"], bool):
        hostile = semantic_magic["hostile"] and hostile_capable
    elif isinstance(semantic_roll, dict):
        hostile = combat_advice.get("action") == "attack" and hostile_capable
    else:
        hostile = bool(HOSTILE_WORDS.search(text)) and hostile_capable

    if (
        not isinstance(semantic_roll, dict)
        and active_opponent
        and target_name
        and str(active_opponent.get("name") or "").casefold() in target_name.casefold()
    ):
        hostile = True
    if hostile and not target_name and active_opponent:
        target_name = str(active_opponent.get("name") or "opponent")

    tier = _tier(text, spell, semantic_magic=semantic_magic, allow_regex=allow_regex_fallback)
    rules = POWER_TIERS[tier]
    family = _effect_family(text, spell, hostile, semantic_magic=semantic_magic, allow_regex=allow_regex_fallback)
    intended = (
        " ".join(str(semantic_magic["intended_effect"]).split())[:420]
        if isinstance(semantic_magic, dict) and semantic_magic.get("intended_effect")
        else " ".join(text.split())[:420]
    )
    roll = resolve_d20(
        state, "ARC", rules["dc"], f"cast {spell['name']}: {intended}",
        manual_roll=manual_roll,
        actor=actor_name,
    )
    outcome = magic_outcome(roll["raw"], roll["total"], roll["dc"])
    toll_key = {"critical_failure": "critical_toll", "failure": "failure_toll", "success": "success_toll", "strong_success": "strong_toll"}[outcome]
    hp_before = int(caster.get("hp", 0) or 0)
    hp_toll = int(rules[toll_key])
    caster["hp"] = max(0, hp_before - hp_toll)
    if actor_name in {"NONE", None, ""}:
        player["hp"] = caster["hp"]

    damage = 0
    target_hp_after = None
    defeat_outcome = None
    applied_condition = None
    siphon_healed = 0
    ward_created = None

    if outcome in {"success", "strong_success"}:
        if spell_id == "aegis":
            base_caps = {"minor": 3, "standard": 6, "major": 9, "extreme": 14}
            capacity = base_caps.get(tier, 6) + (3 if outcome == "strong_success" else 0)
            ward_created = {
                "name": "Aegis",
                "spell_id": "aegis",
                "capacity": capacity,
                "remaining": capacity,
                "tier": tier,
                "turns": 5,
            }
            if actor_name in {"NONE", None, ""}:
                player["ward"] = ward_created
            else:
                caster["ward"] = ward_created

        elif spell_id == "celeritas":
            haste_cond = {"name": "Hastened", "kind": "celeritas", "turns": 3, "bonus": 2}
            caster.setdefault("conditions", []).append(haste_cond)

        elif spell_id == "firmitas":
            fort_cond = {"name": "Fortified", "kind": "firmitas", "turns": 3, "armor_bonus": 1}
            caster.setdefault("conditions", []).append(fort_cond)

        if family in {"healing", "restoration"} or spell_id in {"sanus", "restituo", "purifico"}:
            from .afflictions import cure_afflictions
            heal_amount = int(rules["strong_damage"] if outcome == "strong_success" else rules["damage"])
            if not target_name or re.search(r"\b(?:myself|me)\b", target_name, re.I):
                caster["hp"] = min(int(caster.get("max_hp", 1)), int(caster.get("hp", 0)) + heal_amount)
                if actor_name in {"NONE", None, ""}:
                    player["hp"] = caster["hp"]
            else:
                target_companion = None
                for companion in state.get("player", {}).get("companions", []):
                    if isinstance(companion, dict) and companion.get("name") and companion.get("name").casefold() in target_name.casefold():
                        target_companion = companion
                        break
                if target_companion:
                    target_companion["hp"] = min(int(target_companion.get("max_hp", 1)), int(target_companion.get("hp", 0)) + heal_amount)
                else:
                    player["hp"] = min(int(player.get("max_hp", 1)), int(player.get("hp", 0)) + heal_amount)
            if "purification" in spell.get("families", []) or spell_id == "purifico":
                cure_afflictions(state, families={"physical", "toxic", "arcane"})

    if hostile and target_name:
        opponent = ensure_magic_combat_target(state, target_name, combat_advice)
        
        if outcome in {"success", "strong_success"} and spell_id == "vitae_drain":
            damage = int(rules["strong_damage"] if outcome == "strong_success" else rules["damage"])
            damage -= absorb_ward(opponent, damage)
            opponent["hp"] = max(0, int(opponent.get("hp", 0) or 0) - damage)
            siphon_healed = (damage + 1) // 2
            caster["hp"] = min(int(caster.get("max_hp", 1)), int(caster.get("hp", 0)) + siphon_healed)
            if actor_name in {"NONE", None, ""}:
                player["hp"] = caster["hp"]

        elif outcome in {"success", "strong_success"} and spell_id == "metus":
            opp_conditions = opponent.setdefault("conditions", [])
            if outcome == "strong_success":
                applied_condition = {"name": "Panicked", "kind": "fear", "turns": 2, "denies_action": True}
            else:
                applied_condition = {"name": "Shaken", "kind": "fear", "turns": 2, "penalty": -3}
            opp_conditions.append(applied_condition)

        elif outcome in {"success", "strong_success"} and spell_id == "caligo":
            opp_conditions = opponent.setdefault("conditions", [])
            penalty = -4 if outcome == "strong_success" else -3
            applied_condition = {"name": "Disoriented", "kind": "confusion", "turns": 2, "penalty": penalty}
            opp_conditions.append(applied_condition)

        elif outcome in {"success", "strong_success"} and spell_id == "terra":
            opp_conditions = opponent.setdefault("conditions", [])
            applied_condition = {"name": "Immobilized", "kind": "immobilized", "turns": 2}
            opp_conditions.append(applied_condition)
            damage = max(1, rules["damage"] // 2) if outcome == "success" else rules["damage"]
            damage -= absorb_ward(opponent, damage)
            opponent["hp"] = max(0, int(opponent.get("hp", 0) or 0) - damage)

        elif outcome in {"success", "strong_success"} and family == "damage":
            damage = int(rules["strong_damage"] if outcome == "strong_success" else rules["damage"])
            damage -= absorb_ward(opponent, damage)
            opponent["hp"] = max(0, int(opponent.get("hp", 0) or 0) - damage)

        target_hp_after = int(opponent.get("hp", 0) or 0)
        
        active_opponents = [opp for opp in state.get("combat", {}).get("opponents", []) if int(opp.get("hp", 0) or 0) > 0]
        if not active_opponents:
            state["combat"]["status"] = "won"
            state["combat"]["phase"] = "complete"
        elif int(player.get("hp", 0) or 0) <= 0:
            state["combat"]["status"] = "defeated"
            state["combat"]["phase"] = "complete"
            defeat_outcome = resolve_zero_hp(
                state,
                cause=f"spell toll while facing {opponent.get('name') or 'an opponent'}",
                opponent=opponent,
            )
        elif int(caster.get("hp", 0) or 0) <= 0:
            defeat_outcome = {"outcome": "unconscious", "actor": caster.get("name", "Companion")}
        else:
            opponent_weapon_mode = str(opponent.get("weapon", {}).get("mode", "melee"))
            if outcome == "strong_success" and spell_id == "metus":
                state["combat"]["phase"] = "player_action"
                state["combat"]["pending_defense"] = None
            elif outcome == "strong_success" and spell_id == "terra" and opponent_weapon_mode == "melee":
                state["combat"]["phase"] = "player_action"
                state["combat"]["pending_defense"] = None
            else:
                defense_bonus = 0
                defense_source = None
                if outcome in {"success", "strong_success"}:
                    if spell_id == "metus":
                        defense_bonus = 3
                        defense_source = "Opponent is shaken by Metus"
                    elif spell_id == "caligo":
                        defense_bonus = 4 if outcome == "strong_success" else 2
                        defense_source = "Opponent is disoriented by Caligo"
                    elif spell_id == "aegis":
                        defense_bonus = 2
                        defense_source = "Aegis ward"
                queue_enemy_defense_phase(state, defense_bonus=defense_bonus, defense_source=defense_source, originating_action="magic")
    elif combat_was_active and int(player.get("hp", 0) or 0) > 0:
        defense_bonus = 2 if spell_id == "aegis" else 0
        defense_source = "Aegis ward" if spell_id == "aegis" else None
        queue_enemy_defense_phase(state, defense_bonus=defense_bonus, defense_source=defense_source, originating_action="magic")
    if int(player.get("hp", 0) or 0) <= 0 and defeat_outcome is None:
        defeat_outcome = resolve_zero_hp(state, cause=f"the toll of {spell['name']}")
    elif int(caster.get("hp", 0) or 0) <= 0 and defeat_outcome is None:
        defeat_outcome = {"outcome": "unconscious", "actor": caster.get("name", "Companion")}
    duration = "instant" if (family in {"damage", "healing", "purification", "restoration"} and spell_id not in {"aegis"}) else "scene"
    event = {
        "type": "magic_resolution",
        "committed": True,
        "actor": actor_name if actor_name not in {"NONE", None, ""} else "player",
        "spell_id": spell_id,
        "spell_name": spell["name"],
        "category": spell["category"],
        "effect_family": family,
        "effect_families": list(spell.get("families", [])),
        "intended_effect": intended,
        "target_name": target_name,
        "hostile": hostile,
        "power_tier": tier,
        "duration": duration,
        "roll": roll,
        "outcome": outcome,
        "effect_strength": {"critical_failure": "backfire", "failure": "none", "success": "full", "strong_success": "heightened"}[outcome],
        "hp_before": hp_before,
        "hp_toll": hp_toll,
        "hp_after": caster["hp"],
        "defeat_outcome": defeat_outcome,
        "damage": damage,
        "siphon_healed": siphon_healed,
        "applied_condition": applied_condition,
        "ward_created": ward_created,
        "target_hp_after": target_hp_after,
        "counterattack_pending": bool(
            isinstance(state.get("combat"), dict)
            and state["combat"].get("status") == "active"
            and state["combat"].get("phase") == "player_defense"
        ),
        "combat_status": state.get("combat", {}).get("status") if isinstance(state.get("combat"), dict) else None,
    }
    if event["combat_status"] is not None:
        record_combat_digest(state, event)
    _record_effect(state, event, spell)
    history = state.setdefault("magic", {}).setdefault("history", [])
    history.append({key: event[key] for key in ("spell_id", "spell_name", "outcome", "power_tier", "effect_family", "hp_toll", "damage")})
    state["magic"]["history"] = history[-30:]
    return event



def magic_prompt_context(state: dict[str, Any], player_text: str) -> dict[str, Any]:
    location_id = str(state.get("current_location_id") or "")
    active = [
        effect for effect in state.get("magic", {}).get("active_effects", [])
        if isinstance(effect, dict) and effect.get("location_id") == location_id
    ]
    mentioned = mentioned_spell(player_text)
    reference = None
    if mentioned:
        spell_id, spell = mentioned
        reference = {"id": spell_id, **spell}
        
    spell_glosses = []
    for s_id, s in sorted(SPELLS.items(), key=lambda r: r[1]["name"]):
        short_desc = s.get("description", "").split(";")[0].split(".")[0].strip()
        spell_glosses.append(f"{s['name']} ({short_desc})")
    all_spells = "; ".join(spell_glosses)
    companion_spells = {
        str(comp.get("name") or "Companion"): list(comp["known_spells"])
        for comp in state.get("player", {}).get("companions", [])
        if isinstance(comp, dict) and comp.get("known_spells")
    }
        
    return {
        "known_spells": list(state.get("player", {}).get("known_spells", [])),
        "companion_spells": companion_spells,
        "active_scene_effects": active[-6:],
        "mentioned_spell_reference": reference,

        "rules": (
            "Formal named spells are Mage-only and use D20 + ARC. There is no mana. "
            "The exact named domain is stable, while its appearance and contextual manifestation remain free. "
            "If an NPC uses magic, they MUST cast these official spells by name. "
            f"Official spells: {all_spells}. "
            "INVOCATIONS: Anyone can seek divine favor (D20+ARC, Mages have advantage). "
            "Minor Boon (situational), Divine Guidance (cryptic vision), Direct Intervention (Mage-only, extreme aid). "
            "ARCANE IMBUEMENT: Mage-only. Requires a vessel, concept, and catalysts. "
            "Ritual ends in D20+ARC. Outcomes: Critical failure (catastrophe/curse/destruction), Failure below DC (Flawed: works but significant curse), "
            "Success (Success with a Quirk: works with a distinctive, non-detrimental quirk), Nat 20 (Perfect: flawless, minor secondary benefit)."
        ),
    }
