"""Structural validation and immutable identities for newly planned bounded sites.

Observation and encounter realization remain mutable. Architecture does not.
Existing unsealed saves retain their previous additive behavior.
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any


def key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").casefold()).strip()


def structure(plan: dict) -> dict:
    return {
        "areas": sorted([
            {k: row.get(k, "") for k in ("name", "placement", "physical_character")}
            for row in plan.get("areas", [])
        ], key=lambda row: key(row["name"])),
        "connections": sorted([
            {k: row.get(k, "") for k in ("from", "to", "via")}
            for row in plan.get("connections", [])
        ], key=lambda row: (key(row["from"]), key(row["to"]), key(row["via"]))),
    }


def topology_hash(plan: dict) -> str:
    return hashlib.sha256(json.dumps(structure(plan), sort_keys=True).encode()).hexdigest()


def planned_route(memory: dict, source: str, target: str, *, edge_allowed=None) -> list[dict] | None:
    """Return the existing physical route, with its barriers still explicit."""
    source, target = key(source), key(target)
    todo, seen = [(source, [])], {source}
    for current, route in todo:
        if current == target: return route
        for edge in memory.get("connections", []):
            if edge_allowed is not None and not edge_allowed(edge):
                continue
            left, right = key(edge.get("from")), key(edge.get("to"))
            other = right if left == current else left if right == current else None
            if other and other not in seen:
                seen.add(other); todo.append((other, route + [dict(edge)]))
    return None


def validate_complete_plan(plan: dict) -> list[str]:
    errors = []
    areas, edges = plan.get("areas", []), plan.get("connections", [])
    if plan.get("plan_complete") is not True:
        errors.append("Confirm plan_complete only after planning the entire meaningful bounded site.")
    if not isinstance(areas, list) or not 1 <= len(areas) <= 24:
        return errors + ["Use 1–24 meaningful areas; no partial wing or interior stub."]
    if not isinstance(edges, list) or len(edges) > 40:
        return errors + ["Use at most 40 physical connections."]
    names = [key(row.get("name")) for row in areas if isinstance(row, dict)]
    if len(names) != len(areas) or not all(names) or len(set(names)) != len(names):
        return errors + ["Area names must be nonempty and unique."]
    # Scale describes the property, not a quota of rooms. A large open hall
    # can be complete with fewer areas than a small subdivided house.
    for row in areas:
        if not row.get("placement") or not row.get("physical_character"):
            errors.append("Every area needs a definite relative placement and physical character.")
        if len(areas) > 2 and re.fullmatch(r"(?:(?:main|site|building|villa) )?interior", key(row["name"])):
            errors.append("Replace generic interior stubs with the actual rooms and circulation.")
    if key(plan.get("position_name")) not in names:
        errors.append("The current position must be an exact planned area.")
    neighbours = {name: set() for name in names}
    pairs = set()
    for row in edges:
        if not isinstance(row, dict):
            errors.append("Each connection must be a record."); continue
        left, right = key(row.get("from")), key(row.get("to"))
        pair = tuple(sorted((left, right)))
        if left not in neighbours or right not in neighbours or left == right:
            errors.append("Every connection needs two distinct planned endpoints; no unresolved placeholders.")
            continue
        if not str(row.get("via") or "").strip():
            errors.append("Every connection needs its physical route and access constraints.")
        if (pair, key(row.get("via"))) in pairs:
            errors.append("Duplicate connection.")
        pairs.add((pair, key(row.get("via"))))
        neighbours[left].add(right); neighbours[right].add(left)
    reached, todo = set(), [names[0]]
    while todo:
        name = todo.pop()
        if name in reached: continue
        reached.add(name); todo.extend(neighbours[name] - reached)
    if reached != set(names):
        errors.append("All areas must form one physically connected graph, including exterior access surfaces.")
    return list(dict.fromkeys(errors))


def reveal_delta(memory: dict, delta: dict) -> bool:
    """Reject new/rewritten topology atomically; accept observation promotions."""
    by_name = {key(a["name"]): a for a in memory.get("areas", [])}
    edges = {(key(e["from"]), key(e["to"]), key(e["via"])): e for e in memory.get("connections", [])}
    for row in delta.get("areas", []):
        old = by_name.get(key(row.get("name")))
        if old is None: return False
        if any(row.get(field) and row[field] != old.get(field) for field in ("placement", "physical_character")):
            return False
    for row in delta.get("connections", []):
        if (key(row.get("from")), key(row.get("to")), key(row.get("via"))) not in edges:
            return False
    position = key(delta.get("position_name"))
    if position and position not in by_name: return False
    for row in delta.get("areas", []):
        if row.get("status") == "observed": by_name[key(row["name"])]["status"] = "observed"
    for row in delta.get("connections", []):
        if row.get("status") == "observed":
            edges[(key(row["from"]), key(row["to"]), key(row["via"]))]["status"] = "observed"
    return True
