// Aether Harbor — Client Application Logic (web port of the v.39 Tkinter UI)

const FATE_SEGMENTS = [
  { label: "AMBUSH", color: "#273BE2" },
  { label: "MIRACLE", color: "#F8DE7E" },
  { label: "RUIN", color: "#273BE2" },
  { label: "EPIPHANY", color: "#00A29E" },
  { label: "CURSE", color: "#273BE2" },
  { label: "FORTUNE", color: "#F8DE7E" },
  { label: "DESPAIR", color: "#273BE2" },
  { label: "DELIVERANCE", color: "#00A29E" }
];

let gameState = null;
let currentEventSource = null;
let wheelAngle = 0;
let isSpinningWheel = false;
let pendingRoll = null;
let rollCloseTimer = null;
let busyPoll = null;
let wheelTimer = null;

document.addEventListener("DOMContentLoaded", () => {
  setupUIEvents();
  initCanvasWheel();
  refreshState(true);
  setInterval(refreshSaveStatus, 15000);
});

function showSaveStatus(status) {
  const el = $("save-status");
  if (!el) return;
  const cloud = status && status.mode === "cloud";
  const saved = status && status.saved;
  el.textContent = saved ? (cloud ? "Voyage saved online" : "Voyage saved on this server")
    : status && status.error ? "Save pending · Keep this page open; retrying…" : "Saving voyage…";
  el.classList.toggle("status-error", !!(status && status.error));
  el.title = "Return using this browser and keep this site's cookies. Restart Campaign begins a new voyage.";
}

async function refreshSaveStatus() {
  if (!gameState || !gameState.active || document.hidden) return;
  try {
    const response = await fetch("/api/save/status", { credentials: "same-origin" });
    if (!response.ok) throw new Error("Save status unavailable");
    showSaveStatus(await response.json());
  } catch (_) {
    const el = $("save-status");
    if (el) {
      el.textContent = "Save status unavailable · Reconnecting…";
      el.classList.add("status-error");
    }
  }
}

function $(id) { return document.getElementById(id); }

function setStatus(text, isError = false) {
  const el = $("model-status");
  el.textContent = text;
  el.classList.toggle("status-error", !!isError);
}

function setInputEnabled(enabled) {
  const input = $("player-input");
  const gameOver = !!(gameState && gameState.game_over);
  input.disabled = !enabled || gameOver || !!pendingRoll;
  if (!input.disabled) input.focus();
}

function setupUIEvents() {
  $("player-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submitPlayerText();
    }
  });
  $("btn-submit-roll").addEventListener("click", submitRoll);
  $("roll-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      submitRoll();
    }
  });
  $("btn-auto-roll").addEventListener("click", () => {
    if (!pendingRoll) return;
    const dice = pendingRoll.roll_dice && pendingRoll.roll_dice.length
      ? pendingRoll.roll_dice
      : [pendingRoll.maximum || 20];
    $("roll-input").value = dice.map(s => Math.floor(Math.random() * s) + 1).join(", ");
    submitRoll();
  });

  $("btn-restart").addEventListener("click", () => {
    if (gameState && gameState.busy) {
      setStatus("Wait for the current narration to finish before restarting.", true);
      return;
    }
    const ok = confirm("Are you sure you want to start a new voyage? Current campaign progress will be reset.");
    if (ok) $("modal-character").classList.remove("hidden");
  });
  $("btn-inventory").addEventListener("click", openInventory);
  $("btn-close-inventory").addEventListener("click", closeInventory);
  if ($("btn-close-inventory-bottom")) $("btn-close-inventory-bottom").addEventListener("click", closeInventory);
  $("btn-wheel").addEventListener("click", openWheelModal);
  $("btn-close-wheel").addEventListener("click", closeWheelModal);
  $("btn-spin-now").addEventListener("click", spinWheelAction);

  const classBtns = document.querySelectorAll(".class-btn");
  classBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      classBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });
  $("btn-start-voyage").addEventListener("click", submitNewCampaign);
}

async function refreshState(loadHistory = false) {
  try {
    const res = await fetch("/api/state", { credentials: "same-origin" });
    if (!res.ok) throw new Error(`State request failed (${res.status})`);
    const data = await res.json();
    gameState = data;
    showSaveStatus(data.save_status);
    if (!data.active) {
      $("modal-character").classList.remove("hidden");
      return;
    }
    $("modal-character").classList.add("hidden");
    updateUIElements(data);
    if (loadHistory) await loadTranscriptHistory();
    if (data.busy && !currentEventSource) {
      // A narration is still running from before a reload: wait for it.
      setStatus("Gemma 26B is writing…");
      setInputEnabled(false);
      if (!busyPoll) {
        busyPoll = setInterval(async () => {
          try {
            const r = await fetch("/api/state", { credentials: "same-origin" });
            if (!r.ok) throw new Error(`State request failed (${r.status})`);
            const s = await r.json();
            if (!s.busy) {
              clearInterval(busyPoll);
              busyPoll = null;
              refreshState(true);
            }
          } catch (err) {
            setStatus("Connection error · Retrying…", true);
          }
        }, 2000);
      }
    }
  } catch (err) {
    console.error("Failed to load game state:", err);
    setStatus("Connection error · Retrying…", true);
    setTimeout(() => refreshState(loadHistory), 3000);
  }
}

function updateUIElements(state) {
  $("place-status").textContent = state.location.place_text || state.location.name || "Aether Harbor";
  const p = state.player;
  let status = `${p.name} · ${p.class} · HP ${p.hp}/${p.max_hp} · ${p.silver} silver`;
  if (p.companions && p.companions.length) {
    status += " | " + p.companions.map(c => `${c.name} HP ${c.hp}/${c.max_hp}`).join(" · ");
  }
  if (state.game_over) status += " · GAME OVER";
  $("player-status").textContent = status;
  $("player-status").classList.toggle("status-error", !!state.game_over);
  $("scene-title").textContent = state.location.name;
  $("scene-summary").textContent = state.location.summary;

  if (state.pending_roll) {
    showRollPanel(state.pending_roll);
  } else {
    hideRollPanel(false);
  }

  if (!currentEventSource && !state.busy) {
    if (state.game_over) {
      setStatus("GAME OVER · restart Aether Harbor for a new voyage", true);
    } else if (state.pending_roll) {
      setStatus(rollStatusText(state.pending_roll));
    } else {
      setStatus("Ready · Gemma 26B");
    }
    setInputEnabled(true);
  }
  updateWheelCooldownButton(state.wheel_cooldown);
}

function rollStatusText(prompt) {
  if ((prompt.roll_count || 1) > 1) {
    return "Action committed · enter " + prompt.roll_dice.map(s => `D${s}`).join(", ");
  }
  return `Action committed · enter your D${prompt.maximum} result`;
}

function showRollPanel(prompt) {
  if (rollCloseTimer) {
    clearTimeout(rollCloseTimer);
    rollCloseTimer = null;
  }
  pendingRoll = prompt;
  $("roll-detail").textContent = prompt.detail || "";
  const instr = $("roll-instruction");
  instr.textContent = prompt.instruction || `Enter your physical result (1–${prompt.maximum})`;
  instr.classList.remove("roll-rolled-flash");
  const input = $("roll-input");
  input.placeholder = (prompt.roll_count || 1) > 1 ? "e.g. 7, 4" : `1–${prompt.maximum}`;
  $("btn-auto-roll").title = "Roll virtual " + (prompt.roll_dice || [prompt.maximum]).map(s => `d${s}`).join(" + ");
  $("btn-auto-roll").disabled = false;
  $("roll-error").textContent = "";
  $("roll-error").classList.add("hidden");
  $("roll-panel").classList.remove("hidden");
  $("btn-submit-roll").disabled = false;
  input.disabled = false;
  $("player-input").disabled = true;
  input.focus();
  setStatus(rollStatusText(prompt));
}

function hideRollPanel(immediate = true) {
  pendingRoll = null;
  $("roll-error").classList.add("hidden");
  if (rollCloseTimer && !immediate) {
    return;
  }
  if (rollCloseTimer) {
    clearTimeout(rollCloseTimer);
    rollCloseTimer = null;
  }
  $("roll-instruction").classList.remove("roll-rolled-flash");
  $("roll-panel").classList.add("hidden");
}

async function loadTranscriptHistory() {
  try {
    const res = await fetch("/api/history", { credentials: "same-origin" });
    const data = await res.json();
    const container = $("transcript");
    container.innerHTML = "";
    data.turns.forEach(turn => appendTurnToTranscript(turn.speaker, turn.text, turn.is_player));
    scrollTranscriptToBottom();
  } catch (err) {
    console.error("Failed to load history:", err);
  }
}

function appendTurnToTranscript(speaker, text, isPlayer) {
  const container = $("transcript");
  const block = document.createElement("div");
  block.className = "turn-block";
  const heading = document.createElement("div");
  heading.className = `speaker-heading ${isPlayer ? "speaker-visitor" : "speaker-gm"}`;
  heading.textContent = speaker;
  const body = document.createElement("div");
  body.className = `turn-body ${isPlayer ? "body-visitor" : "body-gm"}`;
  body.textContent = text;
  block.appendChild(heading);
  block.appendChild(body);
  container.appendChild(block);
  return body;
}

function appendLedgerLine(line) {
  const block = document.createElement("div");
  block.className = "ledger-line";
  block.textContent = line;
  $("transcript").appendChild(block);
  scrollTranscriptToBottom();
}

function appendErrorLine(line) {
  const block = document.createElement("div");
  block.className = "ledger-line error-line";
  block.textContent = line;
  $("transcript").appendChild(block);
  scrollTranscriptToBottom();
}

function scrollTranscriptToBottom() {
  const wrapper = document.querySelector(".transcript-wrapper");
  wrapper.scrollTop = wrapper.scrollHeight;
}

async function postJSON(url, payload) {
  const res = await fetch(url, {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload || {}),
  });
  let data = {};
  try { data = await res.json(); } catch (e) {}
  return { ok: res.ok, status: res.status, data };
}

async function submitPlayerText() {
  const input = $("player-input");
  const text = input.value.trim();
  if (!text || input.disabled || currentEventSource) return;
  input.value = "";
  input.disabled = true;
  setStatus("Gemma 26B is judging the action…");
  const playerName = (gameState && gameState.player && gameState.player.name) || "Visitor";
  appendTurnToTranscript(playerName, text, true);
  scrollTranscriptToBottom();

  try {
    const { status, data } = await postJSON("/api/action/submit", { text });
    if (status === 409) {
      setStatus(data.error || "Still answering your last action…", true);
      await refreshState(true);
      return;
    }
    if (data.stream_id) startEventStream(data.stream_id);
    else {
      setStatus(data.error || data.detail || "Could not submit the action. Please retry.", true);
      input.value = text;
      setInputEnabled(true);
    }
  } catch (err) {
    console.error("Action error:", err);
    setStatus("Connection error · try again", true);
    setInputEnabled(true);
  }
}

async function submitRoll() {
  if (!pendingRoll || currentEventSource) return;
  const rollInput = $("roll-input");
  const submitted = rollInput.value.trim();
  if (!submitted) {
    showRollError(pendingRoll.instruction);
    return;
  }
  $("btn-submit-roll").disabled = true;
  $("btn-auto-roll").disabled = true;
  rollInput.disabled = true;
  setStatus("Resolving submitted roll…");
  try {
    const { status, data } = await postJSON("/api/roll/submit", { roll: submitted });
    if (data.status === "invalid" || status === 400) {
      $("btn-submit-roll").disabled = false;
      $("btn-auto-roll").disabled = false;
      rollInput.disabled = false;
      showRollError(data.error || "Enter a valid roll result.");
      if (data.status === "no_pending_roll") { hideRollPanel(true); refreshState(); }
      return;
    }
    if (status === 409) {
      $("btn-submit-roll").disabled = false;
      $("btn-auto-roll").disabled = false;
      rollInput.disabled = false;
      setStatus(data.error || "Still answering…", true);
      return;
    }
    if (status >= 400 || !data.stream_id) {
      $("btn-submit-roll").disabled = false;
      $("btn-auto-roll").disabled = false;
      rollInput.disabled = false;
      showRollError(data.detail || data.error || "Could not submit the roll. Please retry.");
      return;
    }
    pendingRoll = null;
    rollInput.value = "";
    $("roll-error").classList.add("hidden");
    const instr = $("roll-instruction");
    instr.textContent = `🎲 You rolled ${submitted}`;
    instr.classList.add("roll-rolled-flash");
    if (rollCloseTimer) clearTimeout(rollCloseTimer);
    rollCloseTimer = setTimeout(() => {
      rollCloseTimer = null;
      hideRollPanel(true);
    }, 850);
    if (data.stream_id) startEventStream(data.stream_id);
  } catch (err) {
    console.error("Roll error:", err);
    $("btn-submit-roll").disabled = false;
    $("btn-auto-roll").disabled = false;
    rollInput.disabled = false;
    setStatus("Connection error · try again", true);
  }
}

function showRollError(text) {
  const el = $("roll-error");
  el.textContent = text;
  el.classList.remove("hidden");
  setStatus("Waiting for a valid roll result", true);
  $("roll-input").focus();
  $("roll-input").select();
}

function startEventStream(streamId) {
  if (currentEventSource) currentEventSource.close();
  $("player-input").disabled = true;
  let gmBody = null;
  let reloadHistory = false;
  const es = new EventSource(`/api/stream/${streamId}`, { withCredentials: true });
  currentEventSource = es;

  const on = (name, fn) => es.addEventListener(name, (e) => {
    let payload = null;
    try { payload = JSON.parse(e.data); } catch (err) {}
    fn(payload);
  });

  on("status", (text) => setStatus(text));
  on("ledger", (line) => appendLedgerLine(line));
  on("gm_start", () => {
    gmBody = appendTurnToTranscript("Aether Harbor", "", false);
    gmBody.classList.add("streaming-active");
    scrollTranscriptToBottom();
  });
  on("token", (token) => {
    if (!gmBody) {
      gmBody = appendTurnToTranscript("Aether Harbor", "", false);
      gmBody.classList.add("streaming-active");
    }
    gmBody.textContent += token;
    scrollTranscriptToBottom();
  });
  on("gm_reset", () => { if (gmBody) gmBody.textContent = ""; });
  on("gm_end", (info) => {
    if (gmBody) {
      gmBody.classList.remove("streaming-active");
      if (info && info.failed && !gmBody.textContent.trim()) gmBody.parentElement.remove();
    }
    gmBody = null;
  });
  on("state", () => refreshState(false));
  on("roll_prompt", (prompt) => { if (prompt) showRollPanel(prompt); });
  on("error", (text) => { appendErrorLine(text); setStatus(text, true); });
  on("game_over", (text) => { setStatus(text, true); });
  on("resync", () => { reloadHistory = true; });

  const finish = () => {
    if (gmBody) gmBody.classList.remove("streaming-active");
    es.close();
    if (currentEventSource === es) currentEventSource = null;
    refreshState(reloadHistory);
  };
  es.addEventListener("done", finish);
  es.onerror = () => {
    // Stream interrupted (network/proxy): reload the persisted transcript.
    es.close();
    if (currentEventSource === es) currentEventSource = null;
    refreshState(true);
  };
}

async function submitNewCampaign() {
  const name = $("char-name").value.trim() || "Visitor";
  const activeClassBtn = document.querySelector(".class-btn.active");
  const charClass = activeClassBtn ? activeClassBtn.dataset.class : "fighter";
  const appearance = $("char-appearance").value.trim();

  $("modal-character").classList.add("hidden");
  setStatus("Gemma 26B is setting the harbor scene…");
  $("transcript").innerHTML = "";
  hideRollPanel(true);
  $("player-status").textContent = name;
  $("place-status").textContent = "Aether Harbor";
  $("scene-title").textContent = "The Opening Threshold";
  $("scene-summary").textContent = "The first narration will establish the voyage's immediate place.";

  try {
    const { status, data } = await postJSON("/api/campaign/new", { name, class: charClass, appearance });
    if (status === 409) {
      setStatus(data.error || "Still answering…", true);
      refreshState(true);
      return;
    }
    if (status >= 400 || !data.stream_id) {
      await refreshState(true);
      setStatus(data.detail || data.error || "Could not start the voyage. Please retry.", true);
      $("modal-character").classList.remove("hidden");
      return;
    }
    if (data.stream_id) startEventStream(data.stream_id);
  } catch (err) {
    console.error("New campaign error:", err);
    setStatus("Connection error · try again", true);
    $("modal-character").classList.remove("hidden");
  }
}

// Wheel of Fate Canvas
function initCanvasWheel() {
  if ($("wheel-canvas")) drawWheel(wheelAngle);
}

function drawWheel(angle) {
  const canvas = $("wheel-canvas");
  const ctx = canvas.getContext("2d");
  const cx = canvas.width / 2;
  const cy = canvas.height / 2;
  const radius = cx - 10;
  const numSlices = FATE_SEGMENTS.length;
  const sliceAngle = (2 * Math.PI) / numSlices;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let i = 0; i < numSlices; i++) {
    const start = angle + i * sliceAngle;
    const end = start + sliceAngle;
    const seg = FATE_SEGMENTS[i];
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, radius, start, end);
    ctx.closePath();
    ctx.fillStyle = seg.color;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#1F1C3A";
    ctx.stroke();
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(start + sliceAngle / 2);
    ctx.textAlign = "right";
    ctx.fillStyle = (seg.color === "#F8DE7E") ? "#1F1C3A" : "#FFFFE0";
    ctx.font = "bold 13px Constantia";
    ctx.fillText(seg.label, radius - 18, 5);
    ctx.restore();
  }
  ctx.beginPath();
  ctx.arc(cx, cy, 24, 0, 2 * Math.PI);
  ctx.fillStyle = "#302B57";
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = "#FAF0BE";
  ctx.stroke();
}

function openWheelModal() {
  $("modal-wheel").classList.remove("hidden");
  if (gameState) updateWheelCooldownButton(gameState.wheel_cooldown, gameState.last_fate);
}

function closeWheelModal() {
  if (isSpinningWheel) return;
  $("modal-wheel").classList.add("hidden");
}

function updateWheelCooldownButton(cooldown, lastFate) {
  const spinBtn = $("btn-spin-now");
  const notice = $("wheel-cooldown-notice");
  if (wheelTimer) { clearInterval(wheelTimer); wheelTimer = null; }
  let remaining = Math.max(0, parseInt(cooldown || 0, 10));
  const render = () => {
    if (remaining > 0) {
      spinBtn.disabled = true;
      notice.classList.remove("hidden");
      const mins = Math.floor(remaining / 60);
      const secs = String(remaining % 60).padStart(2, "0");
      const last = lastFate && lastFate.result ? `${lastFate.result} · ${String(lastFate.polarity || "").toUpperCase()} · ` : "";
      notice.textContent = `${last}RECHARGING · ${mins}:${secs} REMAIN`;
    } else {
      spinBtn.disabled = isSpinningWheel;
      notice.classList.add("hidden");
    }
  };
  render();
  if (remaining > 0) {
    wheelTimer = setInterval(() => {
      remaining -= 1;
      render();
      if (remaining <= 0) { clearInterval(wheelTimer); wheelTimer = null; }
    }, 1000);
  }
}

async function spinWheelAction() {
  if (isSpinningWheel || currentEventSource || pendingRoll) return;
  isSpinningWheel = true;
  $("btn-spin-now").disabled = true;
  try {
    const { status, data } = await postJSON("/api/fate/spin", {});
    if (status === 409 || data.status !== "spinning") {
      isSpinningWheel = false;
      if (data.status === "cooldown") updateWheelCooldownButton(data.remaining, gameState && gameState.last_fate);
      else {
        $("btn-spin-now").disabled = false;
        if (data.error || data.detail) setStatus(data.error || data.detail, true);
      }
      return;
    }
    setStatus("The Wheel is turning…");
    const targetIdx = FATE_SEGMENTS.findIndex(s => s.label === data.outcome);
    animateWheelSpin(targetIdx >= 0 ? targetIdx : 0, () => {
      isSpinningWheel = false;
      updateWheelCooldownButton(data.remaining, { result: data.outcome, polarity: data.polarity });
      closeWheelModal();
      if (data.stream_id) startEventStream(data.stream_id);
    });
  } catch (err) {
    console.error("Spin error:", err);
    isSpinningWheel = false;
    $("btn-spin-now").disabled = false;
  }
}

function animateWheelSpin(targetIndex, onDone) {
  const sliceAngle = (2 * Math.PI) / FATE_SEGMENTS.length;
  const targetSectorMid = targetIndex * sliceAngle + sliceAngle / 2;
  const startAngle = wheelAngle % (2 * Math.PI);
  let finalAngle = -Math.PI / 2 - targetSectorMid;
  while (finalAngle < startAngle + 4 * 2 * Math.PI) finalAngle += 2 * Math.PI;
  const startTime = performance.now();
  const duration = 2800;
  function frame(now) {
    const progress = Math.min(1, (now - startTime) / duration);
    const ease = 1 - Math.pow(1 - progress, 4);
    wheelAngle = startAngle + (finalAngle - startAngle) * ease;
    drawWheel(wheelAngle);
    if (progress < 1) requestAnimationFrame(frame);
    else setTimeout(onDone, 300);
  }
  requestAnimationFrame(frame);
}

// Inventory (built with DOM nodes: no HTML injection from names/descriptions; exact v.39 layout)
function openInventory() {
  const container = $("inventory-content");
  container.innerHTML = "";
  if (!gameState || !gameState.player) {
    const p = document.createElement("p");
    p.textContent = "No active campaign.";
    container.appendChild(p);
  } else {
    const p = gameState.player;
    const add = (cls, text) => {
      const el = document.createElement("div");
      el.className = cls;
      el.textContent = text;
      container.appendChild(el);
    };
    add("inv-silver", `Silver: ${p.silver ?? 0}`);
    const items = Array.isArray(p.inventory_items) ? p.inventory_items : [];
    if (!items.length) {
      add("inv-empty", "Empty");
    } else {
      items.forEach(item => {
        const name = item.name || "Unknown Item";
        const qty = item.quantity || 1;
        const eq = item.equipped ? " (Equipped)" : "";
        const qtyStr = qty > 1 ? `${qty}x ` : "";
        add("inv-item-row", `• ${qtyStr}${name}${eq}`);
      });
    }
    const activeCompanions = (p.companions || []).filter(c => (c.hp || 0) > 0);
    activeCompanions.forEach(c => {
      const cName = String(c.name || "Companion").toUpperCase();
      add("inv-comp-title", `${cName}'S INVENTORY`);
      const cSilver = c.silver || 0;
      if (cSilver > 0) {
        add("inv-silver", `Silver: ${cSilver}`);
      }
      let hasItems = false;
      if (c.weapon && c.weapon.name) {
        add("inv-item-row", `• ${c.weapon.name} (Equipped Weapon)`);
        hasItems = true;
      }
      const cItems = Array.isArray(c.inventory) ? c.inventory : [];
      cItems.forEach(item => {
        const iName = item.name || "Unknown Item";
        const qty = item.quantity || 1;
        const eq = item.equipped ? " (Equipped)" : "";
        const qtyStr = qty > 1 ? `${qty}x ` : "";
        add("inv-item-row", `• ${qtyStr}${iName}${eq}`);
        hasItems = true;
      });
      if (!hasItems && cSilver <= 0) {
        add("inv-empty", "Empty");
      }
    });
  }
  $("modal-inventory").classList.remove("hidden");
}

function closeInventory() {
  $("modal-inventory").classList.add("hidden");
}
