from __future__ import annotations

import copy
import hashlib
import random
import re
from typing import Any

from .afflictions import add_affliction
from .canon import AETHER_HARBOR_LOCAL_LOCATION_IDS


D20_BANDS = [(1, 6, -6), (7, 9, -4), (10, 11, 0), (12, 13, 2), (14, 16, 4), (17, 18, 6), (19, 20, 8)]
D10_BANDS = [(1, 6, -3), (7, 9, -2), (10, 11, 0), (12, 13, 2), (14, 17, 3), (18, 20, 4)]
GENERAL_D20_SUCCESS_OUTCOMES = frozenset(
    {"marginal_success", "success", "strong_success", "critical_success"}
)
ROLL_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
    "nineteen": 19, "twenty": 20,
}


RISK_PATTERNS: list[tuple[re.Pattern[str], str, int, str]] = [
    (re.compile(r"\b(?:force|break|lift|hold|pull|wrench|overpower|smash)\b", re.I), "STR", 13, "force something under meaningful resistance"),
    (re.compile(r"\b(?:sneak|climb|balance|dodge|leap|pick\s+(?:the\s+)?lock|slip\s+past)\b", re.I), "AGI", 13, "act precisely under risk"),
    (re.compile(r"\b(?:flee|escape|run\s+away|break\s+away|retreat)\b", re.I), "AGI", 13, "escape an immediate pursuit or restraint"),
    (re.compile(r"\b(?:persuade|convince|deceive|bluff|intimidate|bargain)\b", re.I), "SOC", 13, "change someone's position under pressure"),
    (re.compile(r"\b(?:decipher|interpret|invoke|ritual|occult|arcane|translate)\b", re.I), "ARC", 13, "understand or shape a difficult learned matter"),
    (re.compile(r"\b(?:search|inspect|examine|listen|track|spot|notice|eavesdrop)\b", re.I), "PER", 13, "notice something not freely apparent"),
]

ATTACK_VERBS = re.compile(
    r"\b(?:attack|stab|slash|strike|shoot|fire|hit|club|punch|kick|cut|lunge\s+at)\b",
    re.IGNORECASE,
)
FLEE_VERBS = re.compile(r"\b(?:flee|escape|run\s+away|break\s+away|retreat)\b", re.I)
DEFEND_VERBS = re.compile(r"\b(?:defend|guard|brace|parry|take\s+cover)\b", re.I)
SURRENDER_VERBS = re.compile(r"\b(?:surrender|yield|give\s+up|lay\s+down\s+my\s+weapon)\b", re.I)
TAKEDOWN_VERBS = re.compile(
    r"\b(?:execute|kill|finish|slit\s+(?:his|her|their|the)\s+throat|"
    r"knock\s+(?:him|her|them|the\s+\w+)\s+out|takedown|incapacitate)\b",
    re.I,
)


def stat_modifier(die: str, score: int) -> int:
    bands = D20_BANDS if die.upper() == "D20" else D10_BANDS
    for minimum, maximum, modifier in bands:
        if minimum <= int(score) <= maximum:
            return modifier
    return 0


def _roll(state: dict[str, Any], sides: int) -> int:
    counter = int(state.get("rng_counter", 0) or 0)
    material = f"{state.get('rng_seed', 0)}:{counter}:{sides}".encode("utf-8")
    derived = int.from_bytes(hashlib.sha256(material).digest()[:8], "big")
    state["rng_counter"] = counter + 1
    return random.Random(derived).randint(1, sides)


def parse_manual_roll(text: str, maximum: int) -> int | None:
    """Parse a deliberately submitted physical die result, never prose intent."""

    maximum = int(maximum)
    source = " ".join(str(text or "").casefold().replace("-", " ").split())
    source = source.strip(" \t\r\n\"'“”‘’")
    source = re.sub(r"[.!?,;:]+$", "", source).strip()
    direct = re.fullmatch(rf"(?P<value>\d{{1,2}})(?:\s*/\s*{maximum})?", source)
    spoken = re.fullmatch(
        rf"(?:i\s+)?(?:roll|rolled|got)(?:\s*[:=]\s*|\s+)"
        rf"(?:a\s+)?(?:natural\s+)?"
        rf"(?P<value>\d{{1,2}}|{'|'.join(ROLL_WORDS)})"
        rf"(?:\s+on\s+(?:a\s+)?d?{maximum})?",
        source,
    )
    reported = re.fullmatch(
        rf"(?:(?:my|the)\s+)?(?:roll|result)\s+(?:was|is)"
        rf"(?:\s*[:=]\s*|\s+)(?:a\s+)?(?:natural\s+)?"
        rf"(?P<value>\d{{1,2}}|{'|'.join(ROLL_WORDS)})"
        rf"(?:\s+on\s+(?:a\s+)?d?{maximum})?",
        source,
    )
    word = re.fullmatch(rf"(?P<value>{'|'.join(ROLL_WORDS)})", source)
    match = direct or spoken or reported or word
    if not match:
        return None
    token = match.group("value")
    value = int(token) if token.isdigit() else ROLL_WORDS[token]
    return value if 1 <= value <= maximum else None


def parse_manual_rolls(text: str, maximum: int = 10, expected_count: int | None = None) -> list[int] | None:
    """Parse one or more deliberately submitted physical die results."""
    if not text:
        return None
    source = " ".join(str(text or "").casefold().replace("-", " ").split())
    source = source.strip(" \t\r\n\"'“”‘’")
    tokens = re.split(r"[,;/\s]+", source)
    rolls: list[int] = []
    for token in tokens:
        clean = token.strip().rstrip(".!?,;:")
        if not clean or clean in {"and", "&", "on", "d10", "d20", "rolls", "roll", "i", "got", "my", "the", "a", "natural"}:
            continue
        if re.fullmatch(r"\d{1,2}", clean):
            val = int(clean)
            if 1 <= val <= maximum:
                rolls.append(val)
        elif clean in ROLL_WORDS:
            val = ROLL_WORDS[clean]
            if 1 <= val <= maximum:
                rolls.append(val)
    if rolls:
        if expected_count is not None and len(rolls) > expected_count:
            rolls = rolls[:expected_count]
        return rolls
    return None


def _manual_or_random_roll(
    state: dict[str, Any], sides: int, manual_roll: int | None = None
) -> int:
    if manual_roll is None:
        return _roll(state, sides)
    value = int(manual_roll)
    if not 1 <= value <= int(sides):
        raise ValueError(f"The submitted D{sides} result must be from 1 to {sides}.")
    return value


def recognize_risky_action(text: str) -> tuple[str, int, str] | None:
    if "?" in text or re.search(r"\b(?:would|could|might|what\s+if|ask\s+whether)\b", text, re.I):
        return None
    for pattern, stat, dc, reason in RISK_PATTERNS:
        if pattern.search(text):
            return stat, dc, reason
    if re.search(r"\btry\s+to\b", text, re.I) and re.search(r"\b(?:before|danger|fall|collapse|trapped|resist)\b", text, re.I):
        return "STR", 13, "act before a present danger closes"
    return None


def classify_d20_outcome(*, raw_roll: int, total: int, dc: int) -> str:
    """Use the tested Aiantindus general-roll outcome bands."""

    if int(total) <= 5:
        return "critical_failure"
    if int(raw_roll) == 20:
        return "critical_success"
    if int(total) < int(dc):
        return "failure"
    margin = int(total) - int(dc)
    if margin <= 2:
        return "marginal_success"
    if margin >= 8:
        return "strong_success"
    return "success"


def roll_actor(state: dict[str, Any], actor: str = "NONE") -> dict[str, Any]:
    """Resolve one exact or unambiguous first-name companion; never fall back."""
    if not actor or str(actor).upper() in {"NONE", "PLAYER"}:
        return state["player"]
    from .party import find_companion
    companion = find_companion(state, actor)
    if companion is None:
        raise ValueError(f"Unknown or ambiguous acting companion: {actor}")
    return companion



def resolve_d20(
    state: dict[str, Any],
    stat: str,
    dc: int,
    reason: str,
    *,
    situational_modifier: int = 0,
    situational_source: str | None = None,
    manual_roll: int | None = None,
    actor: str = "NONE",
) -> dict[str, Any]:
    player = roll_actor(state, actor)
    score = int(player.get("stats", player).get(stat, 10))
    actor_name = str(player.get("name") or actor) if actor and actor != "NONE" else "Player"

    raw = _manual_or_random_roll(state, 20, manual_roll if actor in {"", "NONE", None} else None)
    base_modifier = stat_modifier("D20", score)
    condition_modifier = 0
    remaining_conditions: list[dict[str, Any]] = []
    current_turn = state.get("turn_no", 0)
    
    for condition in player.get("conditions", []):
        if not isinstance(condition, dict):
            continue
        if condition.get("condition_type") == "affliction":
            remaining_conditions.append(condition)
            continue
        name = str(condition.get("name") or "")
        applies = False
        if name in ("Epiphany", "Wheel of Fate (Epiphany)"):
            condition_modifier += 4
            applies = True
        elif name in ("Fate's Weight", "Wheel of Fate (Curse)"):
            condition_modifier -= 3
            applies = True
        elif name in ("Dread", "Wheel of Fate (Despair)"):
            condition_modifier -= 2
            applies = True
        elif name == "Wheel of Fate (Lucky Omen)":
            condition_modifier += 2
            applies = True
        elif name == "Wheel of Fate (Miraculous Favor)":
            condition_modifier += 2
            applies = True
        elif name == "Wheel of Fate (Broken Gear)" and stat in {"STR", "AGI", "SOC"}:
            condition_modifier -= 2
            applies = True
        elif condition.get("kind") in {"fear", "confusion"}:
            condition_modifier += int(condition.get("penalty", 0))
            applies = True

        uses = condition.get("uses")
        if uses is not None:
            remaining_uses = int(uses) - (1 if applies else 0)
            if remaining_uses > 0:
                updated = dict(condition)
                updated["uses"] = remaining_uses
                updated["turns"] = remaining_uses
                remaining_conditions.append(updated)
        else:
            last_tick = condition.get("last_tick_turn")
            should_tick = applies and (last_tick != current_turn)
            turns = int(condition.get("turns", 0) or 0) - (1 if should_tick else 0)
            if turns > 0:
                updated = dict(condition)
                updated["turns"] = turns
                if should_tick:
                    updated["last_tick_turn"] = current_turn
                remaining_conditions.append(updated)
    player["conditions"] = remaining_conditions
    modifier = base_modifier + condition_modifier + int(situational_modifier)
    total = raw + modifier
    outcome = classify_d20_outcome(raw_roll=raw, total=total, dc=int(dc))
    success = outcome in GENERAL_D20_SUCCESS_OUTCOMES
    return {
        "type": "d20_resolution",
        "actor": actor_name,
        "die": "D20",
        "stat": stat,
        "score": score,
        "raw": raw,
        "base_modifier": base_modifier,
        "condition_modifier": condition_modifier,
        "situational_modifier": int(situational_modifier),
        "situational_source": situational_source,
        "modifier": modifier,
        "total": total,
        "dc": int(dc),
        "success": success,
        "outcome": outcome,
        "critical_failure": outcome == "critical_failure",
        "critical_success": outcome == "critical_success",
        "reason": reason,
    }


def apply_general_critical_failure_harm(
    state: dict[str, Any],
    roll: dict[str, Any],
    harm: int,
) -> dict[str, Any]:
    """Commit the judge's bounded bodily risk only on a critical failure."""

    amount = max(0, min(2, int(harm or 0)))
    if amount <= 0 or str(roll.get("outcome") or "") != "critical_failure":
        return roll
    player = state.setdefault("player", {})
    before = max(0, int(player.get("hp", 0) or 0))
    impact_after = max(0, before - amount)
    player["hp"] = impact_after
    roll.update(
        {
            "critical_failure_harm": amount,
            "hp_before": before,
            "impact_hp_after": impact_after,
            "hp_after": impact_after,
        }
    )
    if impact_after <= 0:
        defeat = resolve_zero_hp(
            state,
            cause=str(roll.get("reason") or "a hazardous critical failure"),
        )
        roll["defeat_outcome"] = defeat
        roll["hp_after"] = int(state.get("player", {}).get("hp", 0) or 0)
    return roll


def apply_general_failure_affliction(
    state: dict[str, Any],
    roll: dict[str, Any],
    kind: str,
) -> dict[str, Any]:
    """Commit a lingering condition only after its grounded critical failure."""

    if str(roll.get("outcome") or "") != "critical_failure":
        return roll
    wanted = str(kind or "NONE")
    if wanted == "untreated_wound" and int(roll.get("critical_failure_harm", 0) or 0) < 2:
        return roll
    if wanted not in {"untreated_wound", "poisoned", "arcane_drain"}:
        return roll
    added = add_affliction(
        state,
        wanted,
        source=str(roll.get("reason") or "hazardous critical failure"),
    )
    if isinstance(added, dict):
        roll["affliction_added"] = dict(added)
    return roll


def _best_weapon(
    inventory: list[dict[str, Any]],
    requested_mode: str | None = None,
    *,
    allow_thrown_melee: bool = False,
) -> dict[str, Any]:
    primary = []
    fallback_thrown = []
    for item in inventory:
        if not isinstance(item, dict) or item.get("type") != "weapon":
            continue
        if requested_mode is None or item.get("mode") == requested_mode:
            primary.append(item)
        elif requested_mode == "ranged" and allow_thrown_melee and item.get("mode") == "melee":
            name_lower = str(item.get("name") or "").lower()
            if any(w in name_lower for w in ("dagger", "knife", "spear", "axe", "javelin", "dart", "flask")):
                fallback_thrown.append(item)
    weapons = primary or fallback_thrown
    if not weapons:
        if requested_mode == "ranged":
            return {
                "name": "No ranged weapon",
                "type": "weapon",
                "mode": "ranged",
                "weapon_bonus": -1,
                "unavailable": True,
            }
        return {"name": "Unarmed", "type": "weapon", "mode": "melee", "weapon_bonus": -1}
    readied = [item for item in weapons if item.get("equipped") is True]
    if readied:
        weapons = readied
    return max(weapons, key=lambda item: int(item.get("weapon_bonus", 0) or 0))


def _armor_value(inventory: list[dict[str, Any]]) -> tuple[str, int]:
    armors = [
        item for item in inventory
        if isinstance(item, dict) and item.get("type") == "armor" and item.get("equipped") is True
    ]
    if not armors:
        return "None", 0
    armor = max(armors, key=lambda item: int(item.get("armor_value", 0) or 0))
    return str(armor.get("name") or "Armor"), int(armor.get("armor_value", 0) or 0)


def _advised_weapon(advice: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(advice, dict):
        return None
    weapon = advice.get("opponent_weapon")
    if not isinstance(weapon, dict) or not weapon.get("grounded"):
        return None
    name = " ".join(str(weapon.get("name") or "").split())[:80]
    mode = str(weapon.get("mode") or "melee")
    if not name or mode not in {"melee", "ranged"}:
        return None
    try:
        bonus = max(-1, min(4, int(weapon.get("bonus", 1) or 0)))
    except (TypeError, ValueError):
        bonus = 1
    return {
        "name": name,
        "mode": mode,
        "weapon_bonus": bonus,
        "natural": weapon.get("natural") is True,
        "source": "gemma_semantic",
        "affliction": (
            str(weapon.get("affliction") or "NONE")
            if str(weapon.get("affliction") or "NONE") in {"poisoned", "arcane_drain"}
            else "NONE"
        ),
    }


def _opponent_profile(name: str, advice: dict[str, Any] | None = None) -> dict[str, Any]:
    semantic = advice.get("opponent_profile") if isinstance(advice, dict) else None
    if isinstance(semantic, dict):
        max_hp = max(4, min(24, int(semantic.get("max_hp", 9) or 9)))
        humanoid = semantic.get("humanoid") is True
        profile = {
            "name": name,
            "hp": max_hp,
            "max_hp": max_hp,
            "STR": max(6, min(20, int(semantic.get("STR", 11) or 11))),
            "AGI": max(6, min(20, int(semantic.get("AGI", 11) or 11))),
            "weapon": {
                "name": "Unarmed" if humanoid else "Natural attack",
                "mode": "melee",
                "weapon_bonus": -1 if humanoid else 1,
                "natural": not humanoid,
                "source": "semantic_profile_fallback",
            },
            "armor": max(0, min(4, int(semantic.get("armor_value", 0) or 0))),
            "armor_name": str(semantic.get("armor_name") or "None")[:80],
            "standard_humanoid": humanoid,
            "authority": semantic.get("authority") is True,
            "enemy_count": max(1, min(5, int(semantic.get("enemy_count", 1) or 1))),
            "profile_basis": str(semantic.get("basis") or "")[:180],
            "profile_source": "gemma_semantic",
        }
    else:
        # Technical-classifier fallback only. Normal play never consults these
        # broad emergency shapes; Gemma's one-shot assessment owns the actual
        # encounter. Keeping the old conservative guard/beast split makes a
        # transient helper failure playable instead of turning every foe into
        # an identical unarmed person.
        folded = name.casefold()
        if any(word in folded for word in ("guard", "officer", "soldier", "watch")):
            profile = {
                "name": name, "hp": 11, "max_hp": 11, "STR": 14, "AGI": 12,
                "weapon": {"name": "Spear", "mode": "melee", "weapon_bonus": 2, "source": "technical_fallback"},
                "armor": 2, "armor_name": "Guard armor", "standard_humanoid": True,
                "authority": True,
            }
        elif any(word in folded for word in ("wolf", "boar", "hound", "beast")):
            profile = {
                "name": name, "hp": 8, "max_hp": 8, "STR": 13, "AGI": 14,
                "weapon": {"name": "Teeth and Claws", "mode": "melee", "weapon_bonus": 1, "natural": True, "source": "technical_fallback"},
                "armor": 0, "armor_name": "None", "standard_humanoid": False,
                "authority": False,
            }
        else:
            profile = {
                "name": name, "hp": 8, "max_hp": 8, "STR": 12, "AGI": 11,
                "weapon": {"name": "Club", "mode": "melee", "weapon_bonus": 1, "source": "technical_fallback"},
                "armor": 0, "armor_name": "None", "standard_humanoid": True,
                "authority": False,
            }
        profile["profile_basis"] = "Emergency conservative profile after semantic assessment was unavailable."
        profile["profile_source"] = "technical_fallback"
    grounded_weapon = _advised_weapon(advice)
    if grounded_weapon is not None:
        profile["weapon"] = grounded_weapon

    folded_name = name.casefold()
    is_caster = False
    known_spells: list[str] = []
    if isinstance(semantic, dict) and "is_caster" in semantic:
        # STRICT SEMANTIC GOVERNANCE:
        # When semantic opponent assessment is active, Gemma is authoritative.
        # If Gemma judged is_caster: False, keyword fallback never overrides it.
        is_caster = bool(semantic.get("is_caster"))
        known_spells = [str(x) for x in semantic.get("known_spells", []) if str(x).strip()]
    else:
        # Technical/test fallback when semantic opponent assessment was not provided
        if isinstance(semantic, dict):
            is_caster = bool(semantic.get("is_caster") or str(semantic.get("class_id") or "").casefold() == "mage")
            known_spells = [str(x) for x in semantic.get("known_spells", []) if str(x).strip()]
        if not is_caster and any(w in folded_name for w in ("mage", "witch", "sorcerer", "sorceress", "wizard", "pyromancer", "necromancer", "shaman", "cultist", "astrologer", "theurge", "geomancer")):
            is_caster = True
        if is_caster and not known_spells:
            if any(w in folded_name for w in ("pyro", "fire", "flame", "inquisitor")):
                known_spells = ["Flamma", "Aegis"]
            elif any(w in folded_name for w in ("witch", "tide", "water", "sea")):
                known_spells = ["Aqua", "Caligo"]
            elif any(w in folded_name for w in ("necro", "shadow", "death", "cultist")):
                known_spells = ["Vitae Drain", "Metus"]
            elif any(w in folded_name for w in ("earth", "stone", "geomancer")):
                known_spells = ["Terra", "Firmitas"]
            else:
                known_spells = ["Flamma", "Caligo"]

    profile["is_caster"] = is_caster
    arc_default = 15 if is_caster else 10
    profile["ARC"] = max(6, min(20, int(semantic.get("ARC", arc_default) or arc_default))) if isinstance(semantic, dict) else arc_default
    profile["known_spells"] = known_spells
    profile.setdefault("conditions", [])
    return profile


def _extract_attack_target(text: str) -> str:
    match = re.search(
        r"\b(?:attack|stab|slash|strike|shoot|fire\s+at|hit|club|punch|kick|cut|lunge\s+at)\b"
        r"\s+(?:at\s+)?(?:the\s+)?([^,.!?;]{1,70})",
        text,
        re.I,
    )
    if not match:
        return "hostile stranger"
    target = re.sub(r"\bwith\s+(?:my|the)\b.*$", "", match.group(1), flags=re.I).strip()
    return target[:70] or "hostile stranger"


def absorb_ward(owner: dict[str, Any], damage: int) -> int:
    ward = owner.get("ward")
    if not isinstance(ward, dict) or damage <= 0:
        return 0
    absorbed = min(max(0, int(ward.get("remaining", 0))), damage)
    ward["remaining"] = max(0, int(ward.get("remaining", 0)) - absorbed)
    if ward["remaining"] == 0:
        ward["shattered"] = True
        owner.pop("ward", None)
    return absorbed


def tick_magic_conditions(actor: dict[str, Any], previous: list | None = None) -> None:
    kept = []
    for condition in actor.get("conditions", []):
        if not isinstance(condition, dict):
            continue
        if (condition.get("kind") in {"fear", "confusion", "immobilized", "celeritas", "firmitas"}
                and (previous is None or any(condition is old for old in previous))):
            condition = {**condition, "turns": int(condition.get("turns", 1)) - 1}
            if condition["turns"] <= 0:
                continue
        kept.append(condition)
    actor["conditions"] = kept


def resolve_magic_action_denial(state: dict[str, Any], actor: str = "NONE") -> dict[str, Any] | None:
    combat = state.get("combat") or {}
    if combat.get("status") != "active" or combat_defense_pending(state):
        return None
    owner = roll_actor(state, actor)
    condition = next((c for c in owner.get("conditions", [])
                      if isinstance(c, dict) and c.get("denies_action") and int(c.get("turns", 0)) > 0), None)
    if condition is None:
        return None
    reason = f"{owner['name']} cannot act while {condition['name'].lower()}."
    tick_magic_conditions(owner)
    queue_enemy_defense_phase(state, originating_action="condition_denied")
    event = {"type": "combat_resolution", "action": "condition_denied", "phase": "player_action",
             "round": combat.get("round", 1), "exchanges": [], "reason": reason,
             "combat_status": combat["status"], "counterattack_pending": True,
             "player_hp": state["player"]["hp"]}
    record_combat_digest(state, event)
    return event


def _process_combat_conditions(
    actor: dict[str, Any],
    stat: str,
    *,
    is_defense: bool = False,
) -> tuple[int, int, list[dict[str, Any]]]:
    """Calculate combat condition modifier and armor bonus, and return remaining conditions with decremented uses."""
    condition_modifier = 0
    armor_condition_bonus = 0
    remaining_conditions: list[dict[str, Any]] = []

    for condition in actor.get("conditions", []):
        if not isinstance(condition, dict):
            continue
        if condition.get("condition_type") == "affliction":
            remaining_conditions.append(condition)
            continue

        name = str(condition.get("name") or "")
        applies = False

        if not is_defense:
            # Attacking
            if name in ("Epiphany", "Wheel of Fate (Epiphany)"):
                condition_modifier += 4
                applies = True
            elif name in ("Fate's Weight", "Wheel of Fate (Curse)"):
                condition_modifier -= 3
                applies = True
            elif name in ("Dread", "Wheel of Fate (Despair)"):
                condition_modifier -= 2
                applies = True
            elif name == "Wheel of Fate (Lucky Omen)":
                condition_modifier += 2
                applies = True
            elif name == "Wheel of Fate (Miraculous Favor)":
                condition_modifier += 2
                applies = True
            elif name == "Wheel of Fate (Broken Gear)" and stat in {"STR", "AGI", "SOC"}:
                condition_modifier -= 2
                applies = True
            elif condition.get("kind") in {"fear", "confusion"}:
                condition_modifier += int(condition.get("penalty", 0))
                applies = True
            elif "penalty" in condition:
                condition_modifier += int(condition.get("penalty", 0))
                applies = True
            elif "bonus" in condition:
                condition_modifier += int(condition.get("bonus", 0))
                applies = True
        else:
            # Defending
            if "armor_bonus" in condition:
                armor_condition_bonus += int(condition.get("armor_bonus", 0) or 0)
            if name in ("Epiphany", "Wheel of Fate (Epiphany)"):
                condition_modifier += 4
                applies = True
            elif name == "Wheel of Fate (Broken Gear)" and stat in {"STR", "AGI", "SOC"}:
                condition_modifier -= 2
                applies = True
            elif "bonus" in condition:
                condition_modifier += int(condition.get("bonus", 0) or 0)
                applies = True
            elif name in ("Wheel of Fate (Lucky Omen)", "Wheel of Fate (Miraculous Favor)"):
                condition_modifier += 2
                applies = True
            if "defense_penalty" in condition:
                condition_modifier += int(condition.get("defense_penalty", 0) or 0)
                applies = True
            elif name in ("Fate's Weight", "Wheel of Fate (Curse)"):
                condition_modifier -= 2
                applies = True
            elif name in ("Dread", "Wheel of Fate (Despair)"):
                condition_modifier -= 2
                applies = True
            elif "penalty" in condition and "defense_penalty" not in condition:
                condition_modifier += int(condition.get("penalty", 0) or 0)
                applies = True

        uses = condition.get("uses")
        if uses is not None:
            remaining_uses = int(uses) - (1 if applies else 0)
            if remaining_uses > 0:
                updated = dict(condition)
                updated["uses"] = remaining_uses
                updated["turns"] = remaining_uses
                remaining_conditions.append(updated)
        else:
            remaining_conditions.append(condition)

    return condition_modifier, armor_condition_bonus, remaining_conditions


def _exchange(
    state: dict[str, Any],
    *,
    attacker: dict[str, Any],
    defender: dict[str, Any],
    attacker_is_player: bool,
    attacker_bonus: int = 0,
    defense_bonus: int = 0,
    attacker_bonus_source: str | None = None,
    defense_bonus_source: str | None = None,
    attacker_manual_roll: int | None = None,
    defender_manual_roll: int | None = None,
) -> dict[str, Any]:
    weapon = attacker["weapon"]
    mode = str(weapon.get("mode") or "melee")
    if attacker_is_player or attacker.get("is_companion"):
        owner = roll_actor(state, attacker["name"]) if attacker.get("is_companion") else state["player"]
        denied = next((c for c in owner.get("conditions", []) if isinstance(c, dict)
                       and (c.get("denies_action") or (c.get("kind") == "immobilized" and mode == "melee"))), None)
        if denied:
            tick_magic_conditions(owner)
            return {"attacker": attacker["name"], "defender": defender["name"],
                    "weapon": weapon["name"], "mode": mode, "automatic": True,
                    "denied": True, "hit": False, "damage": 0,
                    "reason": f"{attacker['name']} cannot attack while {denied['name'].lower()}.",
                    "defender_hp_before": defender["hp"], "defender_hp_after": defender["hp"],
                    "attacker_is_player": attacker_is_player and not attacker.get("is_companion"),
                    "attacker_is_companion": bool(attacker.get("is_companion")), "manual_roll_owner": "NONE"}
    stat_name = "AGI" if mode == "ranged" else "STR"
    attacker_score = int(attacker.get(stat_name, 10))
    defender_score = int(defender.get(stat_name, 10))
    attacker_raw = _manual_or_random_roll(state, 10, attacker_manual_roll)
    defender_raw = _manual_or_random_roll(state, 10, defender_manual_roll)

    attacker_condition_mod, _, remaining_attacker_conditions = _process_combat_conditions(
        attacker, stat_name, is_defense=False
    )
    attacker["conditions"] = remaining_attacker_conditions
    if attacker_is_player or attacker.get("is_companion"):
        owner = roll_actor(state, attacker["name"]) if attacker.get("is_companion") else state["player"]
        owner["conditions"] = remaining_attacker_conditions

    defender_condition_mod, armor_condition_bonus, remaining_defender_conditions = _process_combat_conditions(
        defender, stat_name, is_defense=True
    )
    defender["conditions"] = remaining_defender_conditions
    if not attacker_is_player or defender.get("is_companion") or defender.get("name") == state.get("player", {}).get("name"):
        def_owner = roll_actor(state, defender["name"]) if defender.get("is_companion") else (
            state.get("player") if defender.get("name") == state.get("player", {}).get("name") else None
        )
        if def_owner:
            def_owner["conditions"] = remaining_defender_conditions

    attacker_total = attacker_raw + stat_modifier("D10", attacker_score) + int(attacker_bonus) + attacker_condition_mod
    defender_total = defender_raw + stat_modifier("D10", defender_score) + int(defense_bonus) + defender_condition_mod
    hit = attacker_total >= defender_total
    critical = attacker_raw == 10 and hit
    weapon_bonus = int(weapon.get("weapon_bonus", 0) or 0)
    armor = int(defender.get("armor", 0) or 0) + armor_condition_bonus
    margin = attacker_total - defender_total
    damage = max(0, margin + weapon_bonus + (weapon_bonus if critical else 0) - armor) if hit else 0

    ward_owner = defender
    if not attacker_is_player and not attacker.get("is_companion") and not defender.get("is_companion"):
        ward_owner = state.get("player", {})
    ward_absorbed = absorb_ward(ward_owner, damage)
    damage -= ward_absorbed

    defender_hp_before = int(defender.get("hp", 0))
    defender["hp"] = max(0, defender_hp_before - damage)
    exchange = {
        "attacker": attacker["name"],
        "defender": defender["name"],
        "weapon": weapon["name"],
        "mode": mode,
        "attacker_raw": attacker_raw,
        "defender_raw": defender_raw,
        "attacker_total": attacker_total,
        "defender_total": defender_total,
        "attacker_situational": int(attacker_bonus),
        "defender_situational": int(defense_bonus),
        "attacker_situational_source": attacker_bonus_source,
        "defender_situational_source": defense_bonus_source,
        "hit": hit,
        "critical": critical,
        "damage": damage,
        "ward_absorbed": ward_absorbed,
        "defender_hp_before": defender_hp_before,
        "defender_hp_after": defender["hp"],
        "attacker_is_player": attacker_is_player and not attacker.get("is_companion"),
        "attacker_is_companion": bool(attacker.get("is_companion")),
        "defender_is_companion": bool(defender.get("is_companion")),
        "manual_roll_owner": ("NONE" if attacker.get("is_companion") or defender.get("is_companion") else "Player"),
        "stat": stat_name,
        "attacker_modifier": attacker_total - attacker_raw,
        "defender_modifier": defender_total - defender_raw,
    }
    if attacker_is_player or attacker.get("is_companion"):
        tick_magic_conditions(owner)
    if not attacker_is_player and not defender.get("is_companion") and not attacker.get("is_companion") and hit and damage > 0:
        explicit = str(weapon.get("affliction") or "NONE")
        threshold = max(4, (int(defender.get("max_hp", 1) or 1) + 2) // 3)
        lingering = (
            explicit
            if explicit in {"poisoned", "arcane_drain"}
            else "untreated_wound" if critical or damage >= threshold else "NONE"
        )
        added = add_affliction(
            state,
            lingering,
            source=f"{attacker.get('name') or 'opponent'} · {weapon.get('name') or 'attack'}",
        )
        if isinstance(added, dict):
            exchange["affliction_added"] = dict(added)
    return exchange


def _automatic_stealth_exchange(
    *,
    attacker: dict[str, Any],
    defender: dict[str, Any],
    stealth_edge: dict[str, Any],
) -> dict[str, Any]:
    weapon = attacker["weapon"]
    weapon_bonus = int(weapon.get("weapon_bonus", 0) or 0)
    armor = int(defender.get("armor", 0) or 0)
    margin = max(5, int(stealth_edge.get("margin", 5) or 5))
    damage = max(1, margin + (2 * weapon_bonus) - armor)
    defender_hp_before = int(defender.get("hp", 0))
    defender["hp"] = max(0, defender_hp_before - damage)
    return {
        "attacker": attacker["name"],
        "defender": defender["name"],
        "weapon": weapon["name"],
        "mode": weapon.get("mode", "melee"),
        "attacker_raw": None,
        "defender_raw": None,
        "attacker_total": int(stealth_edge.get("total", 0) or 0),
        "defender_total": int(stealth_edge.get("dc", 0) or 0),
        "attacker_situational": 0,
        "defender_situational": 0,
        "hit": True,
        "critical": True,
        "automatic": True,
        "source": "preceding stealth margin",
        "damage": damage,
        "defender_hp_before": defender_hp_before,
        "defender_hp_after": defender["hp"],
        "attacker_is_player": True,
    }


def _combat_advice(semantic_roll: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(semantic_roll, dict):
        return {}
    advice = semantic_roll.get("combat")
    return advice if isinstance(advice, dict) else {}


def _combat_action(
    text: str,
    advice: dict[str, Any],
    *,
    semantic_authoritative: bool = False,
) -> str:
    advised = str(advice.get("action") or "NONE").casefold()
    if advised in {"attack", "defend", "flee", "surrender"}:
        return advised
    if semantic_authoritative:
        return "other"
    if SURRENDER_VERBS.search(text):
        return "surrender"
    if FLEE_VERBS.search(text):
        return "flee"
    if ATTACK_VERBS.search(text):
        return "attack"
    if DEFEND_VERBS.search(text):
        return "defend"
    return "other"


def _situational(advice: dict[str, Any], scope: str) -> tuple[int, str | None]:
    situation = advice.get("situational")
    if not isinstance(situation, dict) or str(situation.get("scope") or "NONE") != scope:
        return 0, None
    try:
        modifier = max(-2, min(2, int(situation.get("modifier") or 0)))
    except (TypeError, ValueError):
        modifier = 0
    reason = " ".join(str(situation.get("reason") or "").split())[:160]
    return (modifier, reason or None) if modifier else (0, None)


def _ensure_combat_shape(combat: dict[str, Any]) -> None:
    combat.setdefault("round", 1)
    combat.setdefault("phase", "player_action")
    combat.setdefault("pending_defense", None)
    if not combat.get("opponents") and isinstance(combat.get("opponent"), dict):
        combat["opponents"] = [combat["opponent"]]
    if combat.get("opponents") and "opponent" not in combat:
        combat["opponent"] = combat["opponents"][0]



def _defeat_anchor_id(state: dict[str, Any]) -> str:
    """Choose a broad stable anchor for post-defeat recovery without inventing a new site."""

    current_id = str(state.get("current_location_id") or "opening_threshold")
    location = state.get("locations", {}).get(current_id, {})
    scope = str(location.get("aether_geography_scope") or "") if isinstance(location, dict) else ""
    if current_id in AETHER_HARBOR_LOCAL_LOCATION_IDS or scope in {"local", "visible"}:
        return "opening_threshold"
    return current_id


def _set_recovery_scene_position(
    state: dict[str, Any],
    *,
    label: str,
    anchor_id: str,
) -> None:
    """Commit a small post-defeat micro-place; narration may define it more fully."""

    digest = hashlib.sha1(
        f"defeat:{anchor_id}:{label}:{state.get('turn_no', 0)}".encode("utf-8")
    ).hexdigest()[:10]
    state["current_location_id"] = anchor_id
    state["scene_position"] = {
        "id": f"scene_defeat_{digest}",
        "label": label,
        "anchor_location_id": anchor_id,
        "summary": "",
        "defining_excerpt": None,
        "provisional": True,
        "set_at_turn": int(state.get("turn_no", 0) or 0),
        "site_area": False,
        "source": "defeat_recovery",
    }


def resolve_zero_hp(
    state: dict[str, Any],
    *,
    cause: str = "combat defeat",
    opponent: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Resolve zero HP once: exactly 50% death, 50% costly survival.

    The coin flip and hard consequences are Python-owned. The narrator receives
    the committed result and only realizes it as fiction.
    """

    existing = state.get("last_defeat")
    if state.get("campaign_status") == "game_over" and isinstance(existing, dict):
        return existing
    player = state.setdefault("player", {})
    if int(player.get("hp", 0) or 0) > 0 and isinstance(existing, dict):
        return existing

    roll = _roll(state, 2)
    turn_no = int(state.get("turn_no", 0) or 0)
    opponent = opponent if isinstance(opponent, dict) else {}
    opponent_name = " ".join(str(opponent.get("name") or "").split())[:100]
    folded = opponent_name.casefold()
    official = (
        opponent.get("authority") is True
        if "authority" in opponent
        else any(word in folded for word in ("guard", "watch", "officer", "soldier"))
    )
    humanoid = bool(opponent.get("standard_humanoid", True))

    if roll == 1:
        player["hp"] = 0
        player["life_state"] = "dead"
        state["campaign_status"] = "game_over"
        outcome = {
            "outcome": "death",
            "game_over": True,
            "cause": cause,
            "opponent": opponent_name,
            "survival_roll": roll,
            "turn": turn_no,
            "hp_after": 0,
            "consequence": "death",
        }
    else:
        max_hp = max(1, int(player.get("max_hp", 1) or 1))
        recovery_hp = max(1, max_hp // 5)
        player["hp"] = recovery_hp
        player["life_state"] = "active"
        state["campaign_status"] = "active"
        confiscated: list[str] = []
        silver_lost = 0
        consequence = "left_for_dead"
        relocation = ""

        if official:
            consequence = "custody"
            relocation = "Harbor Watch Holding Cell" if _defeat_anchor_id(state) == "opening_threshold" else "Holding Cell"
            inventory = player.get("inventory") if isinstance(player.get("inventory"), list) else []
            kept: list[dict[str, Any]] = []
            for item in inventory:
                if (
                    isinstance(item, dict)
                    and item.get("equipped")
                    and str(item.get("type") or "") == "weapon"
                ):
                    confiscated.append(str(item.get("name") or "weapon")[:100])
                    continue
                kept.append(item)
            player["inventory"] = kept
            if confiscated:
                property_records = state.setdefault("confiscated_property", [])
                for item in inventory:
                    if (
                        isinstance(item, dict)
                        and str(item.get("name") or "") in confiscated
                        and item.get("equipped")
                        and str(item.get("type") or "") == "weapon"
                    ):
                        property_records.append(
                            {
                                "item": dict(item),
                                "reason": "official custody after defeat",
                                "turn": turn_no,
                                "holder": "Harbor Watch" if _defeat_anchor_id(state) == "opening_threshold" else "local authorities",
                            }
                        )
                state["confiscated_property"] = property_records[-12:]
            anchor_id = _defeat_anchor_id(state)
            _set_recovery_scene_position(state, label=relocation, anchor_id=anchor_id)
        elif opponent_name and humanoid:
            consequence = "robbed_and_left_for_dead"
            silver_before = max(0, int(player.get("silver", 0) or 0))
            silver_lost = min(silver_before, max(1, silver_before // 3)) if silver_before else 0
            player["silver"] = silver_before - silver_lost
            # The player remains in the same broader place; clear an impossible
            # micro-position such as a rooftop if the defeat occurred after a drop.
            state["scene_position"] = None
        elif opponent_name:
            # A beast or other non-humanoid does not steal gear. Survival means
            # being left unconscious where the fight happened.
            state["scene_position"] = None
        else:
            # Zero HP from a self-inflicted toll has no hostile party to rob or
            # capture the player. The time loss and near-death recovery are the cost.
            consequence = "collapsed_and_recovered"

        stealth = state.get("stealth") if isinstance(state.get("stealth"), dict) else None
        if stealth is not None:
            stealth["concealed"] = False
            stealth["edge"] = None
            stealth["suspicion"] = 0
            stealth["failed_chain"] = 0
            stealth["local_alert"] = "none"
            stealth["location_id"] = str(state.get("current_location_id") or "")

        outcome = {
            "outcome": "survived_unconscious",
            "game_over": False,
            "cause": cause,
            "opponent": opponent_name,
            "survival_roll": roll,
            "turn": turn_no,
            "hp_after": recovery_hp,
            "consequence": consequence,
            "time_passed": "several hours",
            "relocated_to": relocation,
            "confiscated_items": confiscated,
            "silver_lost": silver_lost,
        }

    state["last_defeat"] = outcome
    history = state.setdefault("defeat_history", [])
    history.append(dict(outcome))
    state["defeat_history"] = history[-6:]
    return outcome


def _combat_place_snapshot(state: dict[str, Any]) -> tuple[str, str]:
    location_id = str(state.get("current_location_id") or "")
    location = state.get("locations", {}).get(location_id)
    location_name = (
        str(location.get("name") or location_id)
        if isinstance(location, dict)
        else location_id
    )
    position = state.get("scene_position")
    position_name = (
        str(position.get("label") or "") if isinstance(position, dict) else ""
    )
    return location_name, position_name


def _begin_combat_memory(state: dict[str, Any], opponent: dict[str, Any]) -> None:
    """Start one bounded combat episode and discard digests from older fights."""

    location_name, position_name = _combat_place_snapshot(state)
    state["combat_history"] = []
    enemy_count = int(opponent.get("enemy_count", 1) or 1)
    base_name = str(opponent.get("name") or "opponent").strip()
    if enemy_count > 1:
        archetypes = {
            "guard", "watchman", "officer", "soldier", "sentinel", "bandit", "thug",
            "pirate", "sailor", "cultist", "watcher", "skeleton", "zombie", "wolf",
            "hound", "beast", "creature", "drone", "automaton", "mercenary", "assassin",
        }
        is_generic = any(arch in base_name.casefold() for arch in archetypes)
        opponents = []
        for i in range(enemy_count):
            if i == 0:
                opp_name = f"{base_name} 1" if is_generic else base_name
            else:
                if is_generic:
                    opp_name = f"{base_name} {i+1}"
                else:
                    basis = str(opponent.get("profile_basis") or "").casefold()
                    role_match = re.search(r"\b(scribe|acolyte|apprentice|servant|assistant|guard|thug|retainer|clerk)\b", basis)
                    role = role_match.group(1).capitalize() if role_match else "Associate"
                    opp_name = f"{role} {i}" if enemy_count > 2 else role
            opponents.append({
                **copy.deepcopy(opponent),
                "id": f"opp_{i+1}",
                "name": opp_name,
                "hp": opponent.get("hp", 0),
                "max_hp": opponent.get("hp", 0),
                "STR": opponent.get("STR", 10),
                "AGI": opponent.get("AGI", 10),
                "armor": opponent.get("armor", 0),
                "armor_name": opponent.get("armor_name", "None"),
                "standard_humanoid": opponent.get("standard_humanoid", True),
                "authority": opponent.get("authority", False),
                "weapon": opponent.get("weapon"),
            })
    else:
        opponents = [{
            **copy.deepcopy(opponent),
            "id": "opp_1",
            "name": base_name,
            "hp": opponent.get("hp", 0),
            "max_hp": opponent.get("hp", 0),
            "STR": opponent.get("STR", 10),
            "AGI": opponent.get("AGI", 10),
            "armor": opponent.get("armor", 0),
            "armor_name": opponent.get("armor_name", "None"),
            "standard_humanoid": opponent.get("standard_humanoid", True),
            "authority": opponent.get("authority", False),
            "weapon": opponent.get("weapon"),
        }]
    state["combat_episode"] = {
        "status": "active",
        "started_turn": int(state.get("turn_no", 0) or 0),
        "ended_turn": None,
        "opponents": opponents,
        "location": location_name,
        "scene_position": position_name or None,
        "player_hp_before": int(state.get("player", {}).get("hp", 0) or 0),
        "player_hp_after": int(state.get("player", {}).get("hp", 0) or 0),
        "opponent_hp_before": sum(int(o.get("hp", 0) or 0) for o in opponents),
        "opponent_hp_after": sum(int(o.get("hp", 0) or 0) for o in opponents),
        "resolved_beats": 0,
        "rounds": 0,
        "outcome": None,
        "prelude": [],
        "opening_excerpt": "",
        "ending_excerpt": "",
    }


def _compact_combat_excerpt(value: str, limit: int = 650) -> str:
    clean = " ".join(str(value or "").split())
    if len(clean) <= limit:
        return clean
    clipped = clean[:limit].rsplit(" ", 1)[0].rstrip(" ,;:-")
    return clipped + "…"


def note_combat_episode_narration(
    state: dict[str, Any],
    event: dict[str, Any] | None,
    narration: str,
    recent_turns: list[dict[str, Any]],
) -> None:
    """Attach bounded verbatim scene anchors after visible combat narration."""

    episode = state.get("combat_episode")
    if not isinstance(episode, dict) or not isinstance(event, dict):
        return
    event_type = str(event.get("type") or "")
    is_combat_event = (
        event_type in {"combat_resolution", "magic_resolution"}
        or (event_type == "world_pressure_resolution" and event.get("combat_started"))
    )
    if not is_combat_event:
        return
    if not episode.get("prelude"):
        episode["prelude"] = [
            {
                "speaker": str(row.get("speaker") or ""),
                "text": _compact_combat_excerpt(str(row.get("text") or ""), 500),
            }
            for row in recent_turns[-2:]
            if isinstance(row, dict) and str(row.get("text") or "").strip()
        ]
    excerpt = _compact_combat_excerpt(narration)
    if excerpt and not episode.get("opening_excerpt"):
        episode["opening_excerpt"] = excerpt
    if episode.get("status") == "completed" and excerpt:
        episode["ending_excerpt"] = excerpt


def _record_combat_digest(state: dict[str, Any], event: dict[str, Any]) -> None:
    exchanges = event.get("exchanges") if isinstance(event.get("exchanges"), list) else []
    exchange = exchanges[0] if exchanges and isinstance(exchanges[0], dict) else None
    if exchange:
        if int(exchange.get("defender_hp_after", 1) or 0) <= 0:
            outcome = "incapacitated" if exchange.get("attacker_is_player") or exchange.get("attacker_is_companion") else "player_defeated"
        elif exchange.get("hit") and int(exchange.get("damage", 0) or 0) > 0:
            outcome = "damaged_but_active"
        elif exchange.get("hit"):
            outcome = "contact_without_harm"
        else:
            outcome = "no_harm"
        compact = {
            "round": int(event.get("round", 1) or 1),
            "beat": str(event.get("phase") or event.get("action") or "combat"),
            "attacker": str(exchange.get("attacker") or ""),
            "defender": str(exchange.get("defender") or ""),
            "outcome": outcome,
            "player_hp_after": int(state.get("player", {}).get("hp", 0) or 0),
            "opponent_active": event.get("combat_status") == "active",
        }
    elif event.get("type") == "magic_resolution":
        combat_status = str(event.get("combat_status") or "active")
        damage = int(event.get("damage", 0) or 0)
        target_hp_after = event.get("target_hp_after")
        if combat_status == "won" or (
            isinstance(target_hp_after, int) and target_hp_after <= 0
        ):
            outcome = "incapacitated"
        elif combat_status == "defeated":
            outcome = "player_defeated"
        elif damage > 0:
            outcome = "damaged_but_active"
        else:
            outcome = "no_harm"
        compact = {
            "round": int(state.get("combat", {}).get("round", 1) or 1),
            "beat": "player_magic",
            "attacker": str(state.get("player", {}).get("name") or "player"),
            "defender": str(event.get("target_name") or "opponent"),
            "outcome": outcome,
            "player_hp_after": int(state.get("player", {}).get("hp", 0) or 0),
            "opponent_active": combat_status == "active",
        }
    else:
        compact = {
            "round": int(event.get("round", 1) or 1),
            "beat": str(event.get("action") or "combat"),
            "outcome": "success" if event.get("combat_status") in {"escaped", "surrendered"} else "failed",
            "player_hp_after": int(state.get("player", {}).get("hp", 0) or 0),
            "opponent_active": event.get("combat_status") == "active",
        }
    history = state.setdefault("combat_history", [])
    history.append(compact)
    state["combat_history"] = history[-16:]
    episode = state.get("combat_episode")
    if isinstance(episode, dict):
        episode["resolved_beats"] = int(episode.get("resolved_beats", 0) or 0) + 1
        episode["rounds"] = max(
            int(episode.get("rounds", 0) or 0), int(compact.get("round", 0) or 0)
        )
        episode["player_hp_after"] = int(state.get("player", {}).get("hp", 0) or 0)
        combat = state.get("combat") if isinstance(state.get("combat"), dict) else {}
        opponents = combat.get("opponents") if isinstance(combat.get("opponents"), list) else []
        episode["opponent_hp_after"] = sum(int(opp.get("hp", 0) or 0) for opp in opponents)
        combat_status = str(event.get("combat_status") or "active")
        if combat_status != "active":
            episode["status"] = "completed"
            episode["outcome"] = combat_status
            episode["ended_turn"] = int(state.get("turn_no", 0) or 0)


def record_combat_digest(state: dict[str, Any], event: dict[str, Any]) -> None:
    """Public hook for combat-capable systems such as formal magic."""

    _record_combat_digest(state, event)


def queue_enemy_defense_phase(
    state: dict[str, Any],
    *,
    defense_bonus: int = 0,
    defense_source: str | None = None,
    originating_action: str = "attack",
) -> bool:
    combat = state.get("combat")
    if not isinstance(combat, dict) or combat.get("status") != "active":
        return False
    active_opponents = [opp for opp in combat.get("opponents", []) if int(opp.get("hp", 0) or 0) > 0]
    opponent = active_opponents[0] if active_opponents else {}
    if not active_opponents or int(state.get("player", {}).get("hp", 0) or 0) <= 0:
        return False
    _ensure_combat_shape(combat)
    if combat_defense_pending(state):
        return True
    combat["phase"] = "player_defense"

    from .enemy_magic import choose_enemy_action
    actions = []
    for enemy in active_opponents:
        action = choose_enemy_action(state, enemy)
        action["opponent_id"] = enemy.get("id") or enemy["name"]
        if action["attack_mode"] == "magic":
            # Reserve the engine-owned cast once. Preview/manual defense cannot
            # reroll it or shift the following caster's die.
            action["caster_raw"] = _manual_or_random_roll(state, 20)
        actions.append(action)
    combat["pending_defense"] = {
        **actions[0],
        "actions": actions,
        "bonus": max(-2, min(4, int(defense_bonus))),
        "source": defense_source,
        "originating_action": originating_action,
    }
    return True


def begin_enemy_initiative(
    state: dict[str, Any],
    *,
    opponent_name: str,
    weapon_name: str = "",
    weapon_mode: str = "NONE",
    weapon_bonus: int = 0,
    weapon_natural: bool = False,
    opponent_profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Start the existing ping-pong combat with an opponent-owned first attack."""

    advice: dict[str, Any] | None = {"opponent_profile": opponent_profile} if isinstance(opponent_profile, dict) else None
    if weapon_name and weapon_mode in {"melee", "ranged"}:
        advice = advice or {}
        advice["opponent_weapon"] = {
            "name": weapon_name,
            "mode": weapon_mode,
            "bonus": max(-1, min(4, int(weapon_bonus))),
            "natural": bool(weapon_natural),
            "grounded": True,
        }
    opponent = _opponent_profile(opponent_name or "hostile stranger", advice)
    _begin_combat_memory(state, opponent)
    state["combat"] = {
        "status": "active",
        "round": 1,
        "phase": "player_action",
        "pending_defense": None,
        "opponents": state["combat_episode"]["opponents"],
        "combat_profile": opponent, # Store original profile for stat referencing
    }
    queue_enemy_defense_phase(state, originating_action="enemy_initiative")
    return opponent

def combat_defense_pending(state: dict[str, Any]) -> bool:
    combat = state.get("combat")
    return bool(
        isinstance(combat, dict)
        and combat.get("status") == "active"
        and combat.get("phase") == "player_defense"
        and isinstance(combat.get("pending_defense"), dict)
    )

def ensure_magic_combat_target(
    state: dict[str, Any], target_name: str, advice: dict[str, Any] | None = None
) -> dict[str, Any]:
    combat = state.get("combat")
    if isinstance(combat, dict) and combat.get("status") == "active":
        _ensure_combat_shape(combat)
        active_opponents = [opp for opp in combat.get("opponents", []) if int(opp.get("hp", 0) or 0) > 0]
        all_opponents = combat.get("opponents", [])
        if not all_opponents:
            return {}
        target_opponent = active_opponents[0] if active_opponents else all_opponents[0]
        if target_name:
            target_folded = target_name.casefold()
            for opp in active_opponents:
                if opp["name"].casefold() in target_folded or target_folded in opp["name"].casefold():
                    target_opponent = opp
                    break
        return target_opponent
    opponent = _opponent_profile(target_name or "hostile stranger", advice)
    _begin_combat_memory(state, opponent)
    state["combat"] = {
        "status": "active",
        "round": 1,
        "phase": "player_action",
        "pending_defense": None,
        "opponents": state["combat_episode"]["opponents"],
        "opponent": state["combat_episode"]["opponents"][0] if state["combat_episode"].get("opponents") else opponent,
        "combat_profile": opponent,
    }

    return state["combat"]["opponents"][0]


def resolve_pending_combat_defense(
    state: dict[str, Any],
    *,
    manual_roll: int | None = None,
    manual_rolls: list[int] | None = None,
    text: str = "",
    semantic_roll: dict[str, Any] | None = None,
    defense_path: str | None = None,
) -> dict[str, Any]:
    combat = state.get("combat")
    if not isinstance(combat, dict) or combat.get("status") != "active":
        raise ValueError("No active combat.")
    _ensure_combat_shape(combat)
    if not combat_defense_pending(state):
        raise ValueError("No enemy attack is waiting for a defense roll.")
    active_opponents = [opp for opp in combat.get("opponents", []) if int(opp.get("hp", 0) or 0) > 0]
    if not active_opponents:
        combat["status"] = "won"
        combat["phase"] = "complete"
        combat["pending_defense"] = None
        raise ValueError("All opponents are already out of the fight.")
    
    player = _player_combatant(state)
    active_companions = _companion_combatants(state)
    defenders = [player] + active_companions

    pending = combat.get("pending_defense") or {}
    defense_bonus = int(pending.get("bonus", 0) or 0)
    defense_source = str(pending.get("source") or "") or None
    originating_action = str(pending.get("originating_action") or "attack")
    
    exchanges = []
    defeat_outcome = None
    cause_name = ""
    
    player_roll_index = 0
    companion_target = pending.get("target_companion")
    if companion_target:
        defenders = [c for c in active_companions if c.get("name") == companion_target] or [player]
    for i, opponent in enumerate(active_opponents):
        living_defenders = [d for d in defenders if int(d.get("hp", 0)) > 0]
        if not living_defenders:
            break
        defender = living_defenders[i % len(living_defenders)]
        opp_manual_roll = None
        if not defender.get("is_companion"):
            if manual_rolls and player_roll_index < len(manual_rolls):
                opp_manual_roll = manual_rolls[player_roll_index]
            elif manual_roll is not None and player_roll_index == 0:
                opp_manual_roll = manual_roll
            player_roll_index += 1

        action_denied = False
        denial_reason = ""
        previous_conditions = list(opponent.get("conditions", []))
        for cond in opponent.get("conditions", []):
            if not isinstance(cond, dict):
                continue
            if cond.get("denies_action"):
                action_denied = True
                denial_reason = f"{opponent.get('name', 'Opponent')} is terrified by Metus (guard broken, action denied)"
            elif cond.get("kind") == "immobilized" and str(opponent.get("weapon", {}).get("mode", "melee")) == "melee":
                action_denied = True
                denial_reason = f"{opponent.get('name', 'Opponent')} is immobilized in earth and cannot close distance"
            
        if action_denied:
            tick_magic_conditions(opponent, previous_conditions)
            if not defender.get("is_companion"):
                player_roll_index -= 1
            exchanges.append({
                "automatic": True,
                "attacker": opponent["name"],
                "defender": defender["name"],
                "weapon": str(opponent.get("weapon", {}).get("name", "attack")),
                "mode": str(opponent.get("weapon", {}).get("mode", "melee")),
                "hit": False,
                "critical": False,
                "damage": 0,
                "denied": True,
                "reason": denial_reason,
                "defender_hp_before": int(defender.get("hp", 0)),
                "defender_hp_after": int(defender.get("hp", 0)),
                "attacker_is_player": False,
                "attacker_is_companion": False,
                "defender_is_companion": bool(defender.get("is_companion")),
            })
            continue

        queued = pending.get("actions", [])
        action = next((row for row in queued if row.get("opponent_id") == (opponent.get("id") or opponent["name"])), None)
        if action is None:
            from .enemy_magic import choose_enemy_action
            action = choose_enemy_action(state, opponent)
            if pending.get("caster_name") == opponent.get("name"):
                action = pending
        if action.get("attack_mode") == "magic":
            from .enemy_magic import resolve_enemy_spell
            magic_exchange = resolve_enemy_spell(
                state, opponent, defender, action, manual_roll=opp_manual_roll,
                defense_bonus=defense_bonus, text=text, defense_path=defense_path,
            )
            tick_magic_conditions(opponent, previous_conditions)
            exchanges.append(magic_exchange)
            if magic_exchange.get("automatic") and not defender.get("is_companion"):
                player_roll_index -= 1
            _sync_combatant(state, defender)
            if int(state["player"]["hp"]) <= 0:
                cause_name = f"{opponent.get('name') or 'an opponent'}'s {action['spell_name']}"
                break
            continue

        exchange = _exchange(
            state,
            attacker=opponent,
            defender=defender,
            attacker_is_player=False,
            defense_bonus=defense_bonus,
            defense_bonus_source=defense_source,
            defender_manual_roll=opp_manual_roll,
        )
        exchanges.append(exchange)
        tick_magic_conditions(opponent, previous_conditions)
        _sync_combatant(state, defender)
        if int(state["player"]["hp"]) <= 0:
            cause_name = opponent.get("name") or "an opponent"
            break

    if int(state["player"]["hp"]) <= 0:
        combat["status"] = "defeated"
        combat["phase"] = "complete"
        defeat_outcome = resolve_zero_hp(
            state,
            cause=f"defeated by {cause_name}",
            opponent=active_opponents[0],
        )
    elif not any(int(o.get("hp", 0)) > 0 for o in combat["opponents"]):
        combat.update(status="won", phase="complete")
    else:
        combat["round"] = int(combat.get("round", 1) or 1) + 1
        combat["phase"] = "player_action"
    combat["pending_defense"] = None
    
    result = {
        "type": "combat_resolution",
        "action": "defend" if originating_action == "defend" else "enemy_attack",
        "phase": "enemy_attack",
        "round": int(combat.get("round", 1) or 1) - (1 if combat.get("status") == "active" else 0),
        "exchanges": exchanges,
        "combat_status": combat["status"],
        "counterattack_pending": False,
        "player_hp": state["player"]["hp"],
        "defeat_outcome": defeat_outcome,
    }
    _record_combat_digest(state, result)
    return result


def _player_combatant(
    state: dict[str, Any],
    mode: str | None = None,
    *,
    allow_thrown_melee: bool = False,
) -> dict[str, Any]:
    player = state["player"]
    armor_name, armor = _armor_value(player.get("inventory", []))
    weapon = _best_weapon(
        player.get("inventory", []),
        mode,
        allow_thrown_melee=allow_thrown_melee,
    )
    return {
        "name": player["name"],
        "hp": int(player["hp"]),
        "max_hp": int(player["max_hp"]),
        "STR": int(player["stats"].get("STR", 10)),
        "AGI": int(player["stats"].get("AGI", 10)),
        "ARC": int(player["stats"].get("ARC", 10)),
        "conditions": player.setdefault("conditions", []),
        "ward": player.get("ward"),
        "known_spells": player.get("known_spells", []),
        "weapon": weapon,
        "armor": armor,
        "armor_name": armor_name,
    }


def _companion_combatants(state: dict[str, Any], mode: str | None = None) -> list[dict[str, Any]]:
    combatants = []
    for i, comp in enumerate(state.get("player", {}).get("companions", [])):
        if int(comp.get("hp", 0) or 0) <= 0:
            continue
            
        base_weapon = comp.get("weapon") if isinstance(comp.get("weapon"), dict) else {"name": "Companion Weapon", "mode": "melee", "weapon_bonus": 0}
        base_armor = int(comp.get("armor", comp.get("armor_value", 0)))
        base_armor_name = str(comp.get("armor_name") or "None")
        
        inventory = comp.get("inventory", [])
        best_inv_weapon = None
        best_inv_armor_item = None
        
        if inventory:
            comp_str = int(comp.get("STR", 10))
            comp_agi = int(comp.get("AGI", 10))

            def _comp_can_wield(item: dict[str, Any]) -> bool:
                bonus = int(item.get("weapon_bonus", 0) or 0)
                if bonus < 2:
                    return True
                finesse_or_ranged = str(item.get("mode") or "") == "ranged" or float(item.get("bulk", 2.0) or 2.0) <= 2.0
                stat = max(comp_str, comp_agi) if finesse_or_ranged else comp_str
                return stat >= 10 if bonus == 2 else stat >= 14

            weapons = [
                item for item in inventory 
                if isinstance(item, dict) and item.get("type") == "weapon" and (mode is None or item.get("mode") == mode)
                and _comp_can_wield(item)
            ]
            if not weapons and mode == "ranged":
                weapons = [
                    item for item in inventory 
                    if isinstance(item, dict) and item.get("type") == "weapon" and any(w in str(item.get("name") or "").lower() for w in ("dagger", "knife", "spear", "axe", "javelin", "dart", "flask"))
                    and _comp_can_wield(item)
                ]
            if weapons:
                best_inv_weapon = max(weapons, key=lambda item: int(item.get("weapon_bonus", 0) or 0))
            
            armors = [
                item for item in inventory 
                if isinstance(item, dict) and item.get("type") == "armor"
                and (int(item.get("armor_value", 0) or 0) < 2 or (int(item.get("armor_value", 0) or 0) >= 2 and comp_str >= 14))
            ]
            if armors:
                best_inv_armor_item = max(armors, key=lambda item: int(item.get("armor_value", 0) or 0))
                
        final_weapon = best_inv_weapon if best_inv_weapon and int(best_inv_weapon.get("weapon_bonus", 0) or 0) > int(base_weapon.get("weapon_bonus", 0) or 0) else base_weapon
        final_armor_val = int(best_inv_armor_item.get("armor_value", 0) or 0) if best_inv_armor_item and int(best_inv_armor_item.get("armor_value", 0) or 0) > base_armor else base_armor
        final_armor_name = str(best_inv_armor_item.get("name") or "Armor") if best_inv_armor_item and int(best_inv_armor_item.get("armor_value", 0) or 0) > base_armor else base_armor_name
        
        combatants.append({
            "id": f"comp_{i}",
            "name": comp.get("name"),
            "hp": int(comp.get("hp", 0) or 0),
            "max_hp": int(comp.get("max_hp", 0) or 0),
            "STR": int(comp.get("STR", 10)),
            "AGI": int(comp.get("AGI", 10)),
            "ARC": int(comp.get("ARC", 10)),
            "conditions": comp.setdefault("conditions", []),
            "ward": comp.get("ward"),
            "known_spells": comp.get("known_spells", []),
            "weapon": final_weapon,
            "armor": final_armor_val,
            "armor_name": final_armor_name,
            "is_companion": True,
            "companion_index": i,
        })
    return combatants

def _sync_combatant(state: dict[str, Any], combatant: dict[str, Any]) -> None:
    if combatant.get("is_companion"):
        idx = combatant.get("companion_index")
        companions = state.get("player", {}).get("companions", [])
        if not isinstance(idx, int) or not 0 <= idx < len(companions):
            return
        owner = companions[idx]
    else:
        owner = state["player"]
    owner["hp"] = int(combatant["hp"])
    owner["conditions"] = combatant.get("conditions", [])
    if combatant.get("ward") and combatant["ward"].get("remaining", 0) > 0:
        owner["ward"] = combatant["ward"]
    else:
        owner.pop("ward", None)


def begin_combat_from_text(
    state: dict[str, Any], text: str, *, semantic_roll: dict[str, Any] | None = None,
    manual_roll: int | None = None,
) -> dict[str, Any] | None:
    advice = _combat_advice(semantic_roll)
    semantic_authoritative = bool(
        isinstance(semantic_roll, dict) and isinstance(semantic_roll.get("combat"), dict)
    )
    if _combat_action(text, advice, semantic_authoritative=semantic_authoritative) != "attack":
        return None
    target_name = " ".join(str(advice.get("target") or "").split())[:70] or _extract_attack_target(text)
    opponent = _opponent_profile(target_name, advice)
    _begin_combat_memory(state, opponent)
    state["combat"] = {
        "status": "active",
        "round": 1,
        "phase": "player_action",
        "pending_defense": None,
        "opponents": state["combat_episode"]["opponents"],
        "combat_profile": opponent,
    }
    return resolve_combat_action(
        state, text, semantic_roll=semantic_roll, manual_roll=manual_roll
    )


def resolve_combat_action(
    state: dict[str, Any], text: str, *, semantic_roll: dict[str, Any] | None = None,
    manual_roll: int | None = None,
    manual_rolls: list[int] | None = None,
) -> dict[str, Any]:
    combat = state.get("combat")
    if not isinstance(combat, dict) or combat.get("status") != "active":
        raise ValueError("No active combat.")
    _ensure_combat_shape(combat)
    if combat.get("phase") == "player_defense":
        return resolve_pending_combat_defense(state, manual_roll=manual_roll, manual_rolls=manual_rolls, text=text, semantic_roll=semantic_roll)
    active_opponents = [opp for opp in combat.get("opponents", []) if int(opp.get("hp", 0) or 0) > 0]
    all_opponents = combat.get("opponents", [])
    if not all_opponents:
        combat["status"] = "resolved"
        return {"type": "combat_resolution", "action": "none", "phase": "complete", "round": combat.get("round", 1), "exchanges": [], "combat_status": "resolved", "counterattack_pending": False}
        
    advice = _combat_advice(semantic_roll)
    target_name = " ".join(str(advice.get("target") or "").split())[:70]
    
    target_opponent = active_opponents[0] if active_opponents else all_opponents[0]
    if target_name:
        target_folded = target_name.casefold()
        for opp in active_opponents:
            if opp["name"].casefold() in target_folded or target_folded in opp["name"].casefold():
                target_opponent = opp
                break
    opponent = target_opponent
    
    exchanges: list[dict[str, Any]] = []
    semantic_authoritative = bool(
        isinstance(semantic_roll, dict) and isinstance(semantic_roll.get("combat"), dict)
    )
    action = _combat_action(text, advice, semantic_authoritative=semantic_authoritative)

    grounded_weapon = _advised_weapon(advice)
    current_weapon = opponent.get("weapon") if isinstance(opponent.get("weapon"), dict) else {}
    if grounded_weapon is not None and current_weapon.get("source") != "established_scene":
        opponent["weapon"] = grounded_weapon

    if action == "surrender":
        combat["status"] = "surrendered"
        combat["phase"] = "complete"
        result = {"type": "combat_resolution", "action": "surrender", "phase": "player_action", "round": combat["round"], "exchanges": [], "combat_status": "surrendered", "counterattack_pending": False}
        _record_combat_digest(state, result)
        return result

    if action == "flee":
        raw = _manual_or_random_roll(state, 20, manual_roll)
        situation, situation_source = _situational(advice, "flee")
        modifier = stat_modifier("D20", int(state["player"]["stats"].get("AGI", 10))) + situation
        total = raw + modifier
        if total >= 12:
            combat["status"] = "escaped"
            combat["phase"] = "complete"
        else:
            queue_enemy_defense_phase(state, originating_action="flee")
        result = {
            "type": "combat_resolution",
            "action": "flee",
            "phase": "player_action",
            "flee_roll": {"die": "D20", "stat": "AGI", "raw": raw, "modifier": modifier, "situational_modifier": situation, "situational_source": situation_source, "total": total, "dc": 12, "success": total >= 12},
            "round": combat["round"],
            "exchanges": [],
            "combat_status": combat["status"],
            "counterattack_pending": combat_defense_pending(state),
        }
        _record_combat_digest(state, result)
        return result

    if action == "defend":
        situation, situation_source = _situational(advice, "player_defense")
        fixed_source = "defensive stance (+2)"
        combined_source = f"{fixed_source}; {situation_source}" if situation_source else fixed_source
        queue_enemy_defense_phase(
            state,
            defense_bonus=2 + situation,
            defense_source=combined_source,
            originating_action="defend",
        )
        return resolve_pending_combat_defense(state, manual_roll=manual_roll, manual_rolls=manual_rolls, text=text, semantic_roll=semantic_roll)

    if action == "attack":
        advised_mode = str(advice.get("attack_mode") or "NONE")
        requested_mode = advised_mode if advised_mode in {"melee", "ranged"} else (
            "ranged" if re.search(r"\b(?:shoot|fire|bow|pistol|musket|crossbow|throw|toss|hurl)\b", text, re.I) else "melee"
        )
        allow_thrown = bool(re.search(r"\b(?:throw|throws|throwing|threw|toss|hurl|fling)\b", text, re.I))
        player = _player_combatant(
            state,
            requested_mode,
            allow_thrown_melee=allow_thrown,
        )
        if player["weapon"].get("unavailable"):
            result = {
                "type": "combat_resolution",
                "action": "unavailable_ranged_attack",
                "phase": "player_attack",
                "round": int(combat["round"]),
                "exchanges": [],
                "combat_status": combat["status"],
                "counterattack_pending": False,
                "reason": "The player has no ranged weapon ready or carried.",
                "opponent": {
                    "name": opponent["name"],
                    "hp": opponent["hp"],
                    "max_hp": opponent["max_hp"],
                },
                "player_hp": state["player"]["hp"],
            }
            _record_combat_digest(state, result)
            return result
        situation, situation_source = _situational(advice, "player_attack")
        stealth = state.get("stealth") if isinstance(state.get("stealth"), dict) else {}
        stealth_edge = stealth.get("edge") if stealth.get("concealed") and stealth.get("location_id") == state.get("current_location_id") else None
        if isinstance(stealth, dict):
            stealth["concealed"] = False
            stealth["edge"] = None
        if isinstance(stealth_edge, dict) and stealth_edge.get("quality") == "surprise":
            exchanges.append(
                _exchange(
                    state,
                    attacker=player,
                    defender=opponent,
                    attacker_is_player=True,
                    attacker_bonus=4,
                    defense_bonus=-4,
                    attacker_bonus_source="concealed surprise",
                    defense_bonus_source="caught unaware",
                    attacker_manual_roll=manual_roll,
                )
            )
        elif (
            isinstance(stealth_edge, dict)
            and stealth_edge.get("quality") == "takedown_opportunity"
            and opponent.get("standard_humanoid")
            and TAKEDOWN_VERBS.search(text)
        ):
            damage = int(opponent.get("hp", 0) or 0)
            opponent["hp"] = 0
            exchanges.append(
                {
                    "attacker": player["name"],
                    "defender": opponent["name"],
                    "weapon": player["weapon"]["name"],
                    "mode": player["weapon"].get("mode", "melee"),
                    "attacker_raw": None,
                    "defender_raw": None,
                    "attacker_total": stealth_edge.get("total"),
                    "defender_total": stealth_edge.get("dc"),
                    "hit": True,
                    "critical": True,
                    "automatic": True,
                    "takedown": True,
                    "damage": damage,
                    "defender_hp_before": damage,
                    "defender_hp_after": 0,
                    "attacker_is_player": True,
                }
            )
        elif isinstance(stealth_edge, dict) and stealth_edge.get("quality") in {"automatic_critical", "takedown_opportunity"}:
            exchanges.append(_automatic_stealth_exchange(attacker=player, defender=opponent, stealth_edge=stealth_edge))
        else:
            exchanges.append(
                _exchange(
                    state,
                    attacker=player,
                    defender=opponent,
                    attacker_is_player=True,
                    attacker_bonus=situation,
                    attacker_bonus_source=situation_source,
                    attacker_manual_roll=manual_roll,
                )
            )
        if action == "attack":
            for companion in _companion_combatants(state, requested_mode):
                current_active_opponents = [opp for opp in combat.get("opponents", []) if int(opp.get("hp", 0) or 0) > 0]
                if not current_active_opponents:
                    break
                comp_opponent = next((opp for opp in current_active_opponents if opp["name"] == opponent["name"]), None) or current_active_opponents[0]
                comp_exchange = _exchange(
                    state,
                    attacker=companion,
                    defender=comp_opponent,
                    attacker_is_player=True,
                    attacker_bonus=0,
                    defense_bonus=0,
                )
                exchanges.append(comp_exchange)
                # Opponents are already mutated in-place; never sync their HP into the player.
    active_opponents = [opp for opp in combat.get("opponents", []) if int(opp.get("hp", 0) or 0) > 0]
    if not active_opponents:
        combat["status"] = "won"
        combat["phase"] = "complete"
        combat["pending_defense"] = None
    elif action == "attack":
        queue_enemy_defense_phase(state, originating_action="attack")
    else:
        queue_enemy_defense_phase(state, originating_action="other")
        return resolve_pending_combat_defense(state, manual_roll=manual_roll, manual_rolls=manual_rolls, text=text, semantic_roll=semantic_roll)

    result = {
        "type": "combat_resolution",
        "action": action,
        "phase": "player_attack",
        "round": int(combat["round"]),
        "exchanges": exchanges,
        "combat_status": combat["status"],
        "counterattack_pending": combat_defense_pending(state),
        "opponent": {"name": opponent["name"], "hp": opponent["hp"], "max_hp": opponent["max_hp"]},
        "player_hp": state["player"]["hp"],
    }
    _record_combat_digest(state, result)
    return result


def resolve_companion_attack(state: dict, actor: str, advice: dict) -> dict:
    companion = roll_actor(state, actor)
    combatant = next(c for c in _companion_combatants(state, advice.get("mode"))
                     if c.get("name") == companion.get("name"))
    target = str(advice.get("target") or "")
    ensure_magic_combat_target(state, target, advice)
    combat = state["combat"]
    active = [o for o in combat["opponents"] if int(o.get("hp", 0)) > 0]
    opponent = next((o for o in active if o["name"].casefold() == target.casefold()), active[0] if active else None)
    if opponent is None:
        return {"type": "companion_action", "actor": companion["name"], "committed": False}
    exchange = _exchange(state, attacker=combatant, defender=opponent, attacker_is_player=False)
    if not any(int(o.get("hp", 0)) > 0 for o in combat["opponents"]):
        combat.update(status="won", phase="complete", pending_defense=None)
    else:
        queue_enemy_defense_phase(state, originating_action="companion_attack")
        combat["pending_defense"]["target_companion"] = companion["name"]
    event = {"type": "combat_resolution", "action": "companion_attack", "phase": "companion_attack",
             "round": combat["round"], "exchanges": [exchange], "combat_status": combat["status"],
             "counterattack_pending": combat["status"] == "active", "player_hp": state["player"]["hp"]}
    _record_combat_digest(state, event)
    return event
