from __future__ import annotations

import copy
import logging
import random
import threading
import time
from pathlib import Path
from typing import Any, Callable

from .active_situations import note_active_situation_narration
from .afflictions import advance_afflictions, note_affliction_narration
from .books import note_book_seed_narration
from .celestial_spheres import classify_celestial_spheres_action, is_celestial_spheres_offered
from .fate import remaining_cooldown, spin as spin_fate
from .island_bank import maybe_bind_island
from .items import capture_resource_offer
from .local_games import capture_local_game_offer, classify_local_game_action
from .loot_splitter import split_compound_loot
from .mechanics import (
    combat_defense_pending,
    note_combat_episode_narration,
    parse_manual_roll,
    parse_manual_rolls,
    resolve_pending_combat_defense,
)
from .movement import (
    _emergent_id,
    capture_passage_offer,
    cement_arrival_excerpt,
    commit_pending_site_area_observation,
    commit_pending_site_transition,
    refresh_emergent_place_definition,
)
from .npc_engine import arrival_scene_occupied, maybe_seed as maybe_npc_seed
from .party import party_advice
from .party_runtime import apply_party_review, finish_party_review, prepare_party_profile
from .persistence import CampaignStore
from .prompting import build_messages, event_ledger_line, record_mechanical_ledger
from .recap_secretary import due as recap_due
from .recap_secretary import run as run_recap_secretary
from .risk_classifier import (
    classify_action_risk,
    classify_chase_setup,
    classify_new_item_profile,
    classify_new_opponent,
    classify_world_beat,
)
from .room_secretary import (
    apply_room_memory_result,
    note_site_transition,
    room_memory_due,
    run_room_secretary,
)
from .scenarios import (
    emergent_scenario_due,
    maybe_activate_scenario,
    note_scenario_narration,
    observe_scenario_action,
    run_emergent_scenario_architect,
)
from .scene_pressure import apply_action_consequences
from .secretary import due as secretary_due
from .secretary import note_transcript_scope, run as run_secretary
from .spatial_adjudication import (
    apply_for_anchor as apply_spatial_survey_for_anchor,
    run as run_spatial_secretary,
    survey_mode as spatial_survey_mode,
)
from .spatial_secretary import (
    _island_survey_due,
    note_material_reveal_from_narration,
    reserve_selected_exterior_site,
)
from .state import CLASS_PROFILES, current_location, inventory_summary, new_campaign
from .state_curator import due as curator_due
from .state_curator import queue_after_narration as queue_curator_after_narration
from .state_curator import run as run_state_curator
from .turn_engine import (
    commit_world_beat,
    pending_roll_prompt,
    preview_pending_combat_defense,
    preview_player_action,
    resolve_player_action,
)

logger = logging.getLogger("aether_harbor.engine")

PROTOTYPE_BUILD = "2026-10-27-gemma-v40-cascade"
OPENING_ACTION = "Begin the voyage in Aether Harbor."
BACKGROUND_WAIT_SECONDS = 240.0

Emit = Callable[[str, Any], None]


def _no_emit(_kind: str, _payload: Any = None) -> None:
    return None


class GameEngine:
    """
    Headless, per-player Aether Harbor engine for the web edition.

    This is a line-by-line port of the v.39 Tkinter orchestration in app.py
    (classification chain, roll preview/commit, resolution pipeline, narration
    commit hooks, grounding audit, spatial survey, curator and the secretary
    scheduler). Tk widgets are replaced by an ``emit(kind, payload)`` callback:

    status · player · ledger · gm_start · token · gm_reset · gm_end ·
    roll_prompt · error · game_over

    Concurrency model (one engine per browser session):
    - At most one foreground job (opening/action/roll/wheel) runs at a time;
      ``claim()`` rejects overlapping requests instead of queueing hidden work.
    - Background memory work runs after narration while the player reads, as in
      v.39. A new foreground job waits for it to finish (the desktop "queued
      action" behaviour), so structured results are never lost or overlapped.
    - Every live-state mutation happens under ``self.lock``; background results
      are applied only to the exact campaign that produced them.
    """

    def __init__(self, db_path: Path, model_client: Any, *, store: CampaignStore | None = None):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.store = store if store is not None else CampaignStore(self.db_path)
        self.model = model_client
        self.background_model = model_client
        self.lock = threading.RLock()
        # Never acquire the long-lived state lock to admit an HTTP request.
        self._admission_lock = threading.Lock()
        self.state: dict[str, Any] | None = None
        self.pending_action: dict[str, Any] | None = None
        self.pending_prompt: dict[str, Any] | None = None
        self.active_generation_context: dict[str, Any] | None = None
        self.generating = False
        self.busy = False
        self.background_idle = threading.Event()
        self.background_idle.set()
        self._background_jobs = 0
        self._public_cache: dict[str, Any] = {"active": False}
        self._history_key: tuple[str, str] | None = None
        self.background_last_started_turn = -999
        self.last_activity = time.time()
        self.last_ledger: list[str] = []
        self._load_active_campaign()

    # ------------------------------------------------------------------ setup
    def _load_active_campaign(self) -> None:
        self.state = self.store.latest_campaign()
        saved = self.state.get("_web_pending_roll") if self.state else None
        if (isinstance(saved, dict) and saved.get("campaign_id") == self.state.get("campaign_id")
                and saved.get("turn_no") == self.state.get("turn_no")
                and isinstance(saved.get("action"), dict) and isinstance(saved.get("prompt"), dict)):
            self.pending_action = copy.deepcopy(saved["action"])
            self.pending_prompt = copy.deepcopy(saved["prompt"])

    def has_active_campaign(self) -> bool:
        return self.state is not None

    def claim(self) -> bool:
        """Reserve the single foreground slot. Returns False when busy."""
        with self._admission_lock:
            if self.busy:
                return False
            self.busy = True
            self.last_activity = time.time()
            return True

    def release(self) -> None:
        with self._admission_lock:
            self.busy = False
            self.generating = False
            self.last_activity = time.time()

    def is_idle(self) -> bool:
        return not self.busy and self.background_idle.is_set()

    def start_new_campaign(self, name: str, char_class: str, appearance: str) -> None:
        name = str(name or "").strip()[:40] or "Visitor"
        char_class = str(char_class or "").lower().strip()
        if char_class not in CLASS_PROFILES:
            char_class = "fighter"
        appearance = str(appearance or "").strip()[:600] or "A traveler cloaked against the sea spray."
        with self.lock:
            state = new_campaign(name, char_class, appearance)
            state["prototype_build"] = PROTOTYPE_BUILD
            self.store.create_campaign(state)
            self.state = state
            self.pending_action = None
            self.pending_prompt = None
            self.active_generation_context = None
            self.background_last_started_turn = -999
            self.last_ledger = []
            self._public_cache = self._build_public_state()

    def _save(self, state: dict[str, Any] | None = None) -> None:
        """Persist only the live campaign; a superseded campaign never becomes 'latest'."""
        target = state if state is not None else self.state
        if target is not None and target is self.state:
            self.store.save_state(target)
            self._public_cache = self._build_public_state()

    def _is_live(self, campaign_id: str) -> bool:
        return bool(self.state and str(self.state.get("campaign_id") or "") == str(campaign_id or ""))

    # ------------------------------------------------------------- read model
    def get_public_state(self) -> dict[str, Any]:
        """Never blocks: while a foreground job holds the lock, the last snapshot is served."""
        if self.lock.acquire(blocking=False):
            try:
                self._public_cache = self._build_public_state()
            finally:
                self.lock.release()
        snapshot = copy.deepcopy(self._public_cache)
        snapshot["busy"] = self.busy
        snapshot["generating"] = self.generating
        return snapshot

    def _build_public_state(self) -> dict[str, Any]:
        if True:
            if not self.state:
                self._history_key = None
                return {"active": False, "busy": self.busy}
            state = self.state
            self._history_key = (
                str(state.get("campaign_id") or ""),
                str((state.get("player") or {}).get("name") or "Visitor"),
            )
            location = current_location(state)
            scene_position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
            player = state.get("player") or {}
            region = str(location.get("region") or "").strip()
            visible_region = region and region.casefold() not in {"emergent place", "emergent site", "the opening scene"}
            place_text = str(location.get("name") or "Aether Harbor")
            if visible_region:
                place_text += f" · {region}"
            if scene_position:
                place_text += f" · {scene_position.get('label')}"
            game_over = state.get("campaign_status") == "game_over"
            companions = [
                {
                    "name": c.get("name"),
                    "hp": c.get("hp"),
                    "max_hp": c.get("max_hp"),
                    "silver": int(c.get("silver", 0) or 0),
                    "weapon": (
                        {"name": str(c["weapon"].get("name"))}
                        if isinstance(c.get("weapon"), dict) and c["weapon"].get("name")
                        else None
                    ),
                    "inventory": [
                        {
                            "name": str(item.get("name") or "Unknown Item"),
                            "quantity": int(item.get("quantity", 1) or 1),
                            "equipped": bool(item.get("equipped")),
                        }
                        for item in (c.get("inventory") or [])
                        if isinstance(item, dict)
                    ],
                }
                for c in (player.get("companions") or []) if isinstance(c, dict)
            ]
            fate = state.get("fate") if isinstance(state.get("fate"), dict) else {}
            history = fate.get("history") if isinstance(fate.get("history"), list) else []
            latest_fate = history[-1] if history and isinstance(history[-1], dict) else None
            return {
                "active": True,
                "campaign_id": state.get("campaign_id"),
                "campaign_status": state.get("campaign_status", "active"),
                "game_over": game_over,
                "player": {
                    "name": player.get("name", "Visitor"),
                    "class": player.get("class_label") or player.get("class", "Visitor"),
                    "hp": player.get("hp", 0),
                    "max_hp": player.get("max_hp", 0),
                    "silver": player.get("silver", 0),
                    "inventory": inventory_summary(state),
                    "inventory_items": [
                        {
                            "name": str(item.get("name") or "Unknown Item"),
                            "quantity": int(item.get("quantity", 1) or 1),
                            "equipped": bool(item.get("equipped")),
                        }
                        for item in (player.get("inventory") or [])
                        if isinstance(item, dict)
                    ],
                    "appearance": player.get("appearance", ""),
                    "companions": companions,
                },
                "location": {
                    "id": state.get("current_location_id"),
                    "place_text": place_text,
                    "name": str(scene_position.get("label")) if scene_position else str(location.get("name") or ""),
                    "region": region,
                    "summary": (
                        str(scene_position.get("summary") or location.get("summary") or "")
                        if scene_position else str(location.get("summary") or "")
                    ),
                },
                "pending_roll": copy.deepcopy(self.pending_prompt) if self.pending_action else None,
                "wheel_cooldown": remaining_cooldown(state),
                "last_fate": (
                    {"result": latest_fate.get("result"), "polarity": latest_fate.get("polarity")}
                    if latest_fate else None
                ),
                "generating": self.generating,
                "busy": self.busy,
                "turn_no": state.get("turn_no", 0),
            }

    def get_transcript_history(self, limit: int = 60) -> list[dict[str, Any]]:
        self.get_public_state()
        if not self._history_key:
            return []
        campaign_id, player_name = self._history_key
        result = []
        for turn in self.store.recent_turns(campaign_id, limit=limit):
            speaker = str(turn.get("speaker") or "Aether Harbor")
            is_player = speaker.casefold() in {"visitor", "player", "user"}
            result.append({
                "speaker": player_name if is_player else speaker,
                "raw_speaker": speaker,
                "is_player": is_player,
                "text": str(turn.get("text") or ""),
            })
        return result

    # --------------------------------------------------------- shared helpers
    def _wait_for_background(self, emit: Emit) -> None:
        if not self.background_idle.is_set():
            emit("status", "Gemma 26B is judging the action…")
            if not self.background_idle.wait(BACKGROUND_WAIT_SECONDS):
                raise RuntimeError("Memory updates are still running. Please retry your action shortly.")

    def _emit_ledger(self, emit: Emit, ledger: str | None) -> None:
        if ledger:
            self.last_ledger = (self.last_ledger + [ledger])[-20:]
            emit("ledger", ledger)

    # ---------------------------------------------------------- opening turn
    def run_opening(self, emit: Emit = _no_emit) -> None:
        """Port of _start_opening: narrated without a visible player line."""
        with self.lock:
            if not self.state:
                emit("error", "No active campaign.")
                return
        self._start_generation(OPENING_ACTION, None, show_player=False, emit=emit)

    # ----------------------------------------------------------- player text
    def run_player_text(self, text: str, emit: Emit = _no_emit) -> None:
        """Port of _send_player_text/_begin_player_text + action_classified handling."""
        text = str(text or "").strip()
        if not text:
            return
        with self.lock:
            if not self.state:
                emit("error", "No active campaign.")
                return
            if self.state.get("campaign_status") == "game_over":
                emit("game_over", "GAME OVER · restart Aether Harbor for a new voyage")
                return
            if self.pending_action:
                emit("roll_prompt", copy.deepcopy(self.pending_prompt))
                return
        self._wait_for_background(emit)

        # A failed site plan must be retried before play advances (v.39).
        with self.lock:
            retry = self.state.get("pending_site_plan_retry") if self.state else None
        if isinstance(retry, dict):
            emit("status", "Gemma 26B is preparing the scene…")
            self._run_spatial_survey(
                **{key: retry.get(key) for key in ("player_text", "narration", "resolved_event", "planning_mode")},
                emit=emit,
            )
            with self.lock:
                if self.state and self.state.get("pending_site_plan_retry"):
                    emit("error", "Scene planning is still pending. Please retry your action shortly.")
                    return

        with self.lock:
            state = self.state
            if not state:
                return
            recent_before = self.store.recent_turns(state["campaign_id"], limit=12)
            state["turn_no"] = int(state.get("turn_no", 0)) + 1
            sequence_no = self.store.append_turn(state["campaign_id"], "Visitor", text)
            note_transcript_scope(state, sequence_no)
            self._save(state)
        emit("status", "Gemma 26B is judging the action…")

        with self.lock:
            data = self._classify_action(state, text, recent_before, emit)
            if data is None:
                return
            self._handle_action_classified(data, emit)

    def _classify_action(
        self, state: dict[str, Any], text: str, recent_before: list[dict[str, Any]], emit: Emit
    ) -> dict[str, Any] | None:
        """Exact port of the v.39 classification worker (app.py _begin_player_text.worker)."""
        pending = state.get("pending_party_review")
        if isinstance(pending, dict):
            review = finish_party_review(model=self.model, state=state, **pending)
            event = apply_party_review(state, review)
            self._record_party_review({"event": event, "error": review.get("error")}, emit)
            if review.get("error"):
                emit("error", "Party update pending · retry the action")
                return None
        try:
            maybe_activate_scenario(state, text)
        except Exception:
            pass
        try:
            semantic_roll = classify_action_risk(
                model=self.model, state=state, recent_turns=recent_before, player_text=text,
            )
            classifier_error = None
        except Exception as exc:
            semantic_roll = None
            classifier_error = str(exc)
        if semantic_roll is not None:
            try:
                semantic_roll = split_compound_loot(
                    model=self.model, semantic_roll=semantic_roll, player_text=text, recent_turns=recent_before,
                )
            except Exception:
                pass
            combat_advice = semantic_roll.get("combat") if isinstance(semantic_roll.get("combat"), dict) else None
            if (
                isinstance(combat_advice, dict)
                and combat_advice.get("action") == "attack"
                and not (isinstance(state.get("combat"), dict) and state["combat"].get("status") == "active")
            ):
                try:
                    assessment = classify_new_opponent(
                        model=self.model, state=state, recent_turns=recent_before, player_text=text,
                        opponent_name=str(combat_advice.get("target") or ""),
                    )
                    if isinstance(assessment, dict):
                        combat_advice.update(assessment)
                except Exception:
                    pass
            chase_advice = semantic_roll.get("chase") if isinstance(semantic_roll.get("chase"), dict) else None
            if (
                isinstance(chase_advice, dict)
                and chase_advice.get("action") == "start"
                and not str(chase_advice.get("quarry") or "").strip()
            ):
                try:
                    setup = classify_chase_setup(model=self.model, recent_turns=recent_before, player_text=text)
                    if isinstance(setup, dict):
                        semantic_roll["chase"] = setup
                except Exception:
                    semantic_roll["chase"] = {"action": "NONE", "quarry": "", "stake": "", "escape": "", "anchor": ""}
            resource_advice = (
                semantic_roll.get("resource_action") if isinstance(semantic_roll.get("resource_action"), dict) else None
            )
            if (
                isinstance(resource_advice, dict)
                and resource_advice.get("kind") in {"take", "purchase", "receive_item"}
                and resource_advice.get("status") == "confirmed"
                and resource_advice.get("item_kind") in {
                    "weapon", "armor", "tool", "valuable", "clothing", "consumable", "document", "misc"
                }
            ):
                try:
                    item_profile = classify_new_item_profile(
                        model=self.model, recent_turns=recent_before, player_text=text,
                        item_name=str(resource_advice.get("item") or ""),
                        item_kind=str(resource_advice.get("item_kind") or ""),
                    )
                    if isinstance(item_profile, dict):
                        resource_advice["item_profile"] = item_profile
                except Exception:
                    pass
            party = party_advice(semantic_roll)
            try:
                party = prepare_party_profile(
                    model=self.model, state=state, recent_turns=recent_before, player_text=text, advice=party,
                )
            except Exception:
                pass
            semantic_roll["party_action"] = party
            if is_celestial_spheres_offered(state):
                try:
                    cs_advice = classify_celestial_spheres_action(
                        model=self.model, state=state, recent_turns=recent_before, player_text=text,
                    )
                    if isinstance(cs_advice, dict):
                        semantic_roll["celestial_spheres"] = cs_advice
                except Exception:
                    pass
            if (semantic_roll.get("celestial_spheres") or {}).get("action", "NONE") == "NONE":
                try:
                    dice_advice = classify_local_game_action(
                        model=self.model, state=state, recent_turns=recent_before, player_text=text,
                    )
                    if dice_advice is not None:
                        semantic_roll["local_game"] = dice_advice
                except Exception:
                    semantic_roll["local_game"] = {"action": "NONE", "stake": 0}
        try:
            world_beat = classify_world_beat(
                model=self.model, state=state, recent_turns=recent_before, player_text=text,
                semantic_roll=semantic_roll,
            )
        except Exception:
            world_beat = None
        if (
            isinstance(world_beat, dict)
            and world_beat.get("hostile_attack") is True
            and not (isinstance(state.get("combat"), dict) and state["combat"].get("status") == "active")
        ):
            try:
                assessment = classify_new_opponent(
                    model=self.model, state=state, recent_turns=recent_before,
                    player_text=str(world_beat.get("action") or text),
                    opponent_name=str(world_beat.get("actor") or ""),
                )
                if isinstance(assessment, dict):
                    world_beat["opponent_profile"] = assessment.get("opponent_profile")
                    weapon = assessment.get("opponent_weapon")
                    if isinstance(weapon, dict) and weapon.get("grounded"):
                        world_beat["weapon_name"] = str(weapon.get("name") or "")
                        world_beat["weapon_mode"] = str(weapon.get("mode") or "NONE")
                        world_beat["weapon_bonus"] = int(weapon.get("bonus", 0) or 0)
                        world_beat["weapon_natural"] = weapon.get("natural") is True
            except Exception:
                pass
        return {
            "text": text,
            "recent": recent_before,
            "semantic_roll": semantic_roll,
            "world_beat": world_beat,
            "classifier_error": classifier_error,
        }

    def _handle_action_classified(self, data: dict[str, Any], emit: Emit) -> None:
        player_text = str(data.get("text") or "")
        semantic_roll = data.get("semantic_roll") if isinstance(data.get("semantic_roll"), dict) else None
        try:
            preview = preview_player_action(
                self.state,
                player_text,
                semantic_roll=semantic_roll,
                world_beat=data.get("world_beat") if isinstance(data.get("world_beat"), dict) else None,
                allow_regex_fallback=semantic_roll is None,
            ) if self.state else None
        except Exception as exc:
            preview = {"type": "engine_warning", "committed": False, "reason": str(exc)}
        self._save()
        roll_prompt = pending_roll_prompt(preview)
        if roll_prompt:
            self._set_pending(data, roll_prompt)
            emit("roll_prompt", copy.deepcopy(self.pending_prompt))
        else:
            self._resolve_and_narrate(data, emit)

    # ------------------------------------------------------------------ rolls
    def _set_pending(self, data: dict[str, Any], prompt: dict[str, Any]) -> None:
        """Port of _show_pending_roll: normalise the die/count/instruction for the UI."""
        button = str(prompt.get("button") or "Roll")
        maximum = int(prompt.get("maximum") or (10 if "D10" in button else 20))
        maximum = 10 if maximum == 10 else 20
        die = str(prompt.get("die") or f"D{maximum}").upper()
        action_prefix = (
            "ATTACK · " if button.casefold().startswith("attack")
            else "DEFEND · " if button.casefold().startswith("defend")
            else ""
        )
        detail = str(prompt.get("detail") or "").strip()
        roll_count = int(prompt.get("roll_count") or 1)
        dice = [int(d) for d in (prompt.get("roll_dice") or [maximum] * roll_count)]
        if len(set(dice)) > 1:
            instruction = "Enter results in order: " + ", ".join(f"D{s} (1–{s})" for s in dice)
        elif roll_count > 1:
            instruction = f"Enter {roll_count} physical results (1–{maximum}, e.g. 7, 4, 9)"
        else:
            instruction = f"Enter your physical result (1–{maximum})"
        self.pending_action = data
        self.pending_prompt = {
            "notice": "PENDING ROLL",
            "detail": " · ".join(part for part in (f"{action_prefix}{die}", detail) if part),
            "instruction": instruction,
            "maximum": maximum,
            "roll_count": roll_count,
            "roll_dice": dice,
            "kind": str(data.get("kind") or "action"),
        }
        self.state["_web_pending_roll"] = {
            "campaign_id": self.state["campaign_id"],
            "turn_no": self.state.get("turn_no", 0),
            "action": copy.deepcopy(data),
            "prompt": copy.deepcopy(self.pending_prompt),
        }
        self._save()

    def accept_roll(self, submitted: str) -> dict[str, Any]:
        """Validate a physical roll exactly like _submit_pending_roll. No model calls."""
        with self.lock:
            if not self.pending_action or not self.state or not self.pending_prompt:
                return {"status": "no_pending_roll"}
            prompt = self.pending_prompt
            maximum = int(prompt["maximum"])
            roll_count = int(prompt.get("roll_count") or 1)
            submitted = str(submitted or "").strip()
            if roll_count > 1:
                dice = list(prompt.get("roll_dice") or [maximum] * roll_count)
                manual_rolls = parse_manual_rolls(submitted, maximum)
                if (not manual_rolls or len(manual_rolls) != roll_count
                        or any(not 1 <= value <= sides for value, sides in zip(manual_rolls, dice))):
                    return {
                        "status": "invalid",
                        "error": "Enter exactly these results in order: " + ", ".join(f"D{s} (1–{s})" for s in dice),
                    }
                manual_roll = manual_rolls[0]
            else:
                manual_rolls = None
                manual_roll = parse_manual_roll(submitted, maximum)
                if manual_roll is None:
                    return {
                        "status": "invalid",
                        "error": (
                            f"Enter 1–{maximum}: for example {maximum}, twenty, or ‘I rolled twenty’."
                            if maximum == 20 else "Enter 1–10: for example 7, seven, or ‘I rolled seven’."
                        ),
                    }
            data = {**self.pending_action, "manual_roll": int(manual_roll)}
            if manual_rolls is not None:
                data["manual_rolls"] = [int(r) for r in manual_rolls]
            self.pending_action = None
            self.pending_prompt = None
            self._public_cache = self._build_public_state()
            return {"status": "accepted", "data": data}

    def run_roll(self, data: dict[str, Any], emit: Emit = _no_emit) -> None:
        self._wait_for_background(emit)
        emit("status", "Resolving submitted roll…")
        with self.lock:
            self._resolve_and_narrate(data, emit)

    def _show_queued_combat_defense(self, emit: Emit) -> bool:
        """Port: hold the text turn while the opponent's separate attack awaits a roll."""
        if not self.state or not combat_defense_pending(self.state):
            return False
        try:
            preview = preview_pending_combat_defense(self.state)
            prompt = pending_roll_prompt(preview)
        except Exception:
            return False
        if not prompt:
            self._resolve_and_narrate({
                "kind": "combat_defense", "text": "The queued enemy actions resolve.",
                "recent": self.store.recent_turns(self.state["campaign_id"], limit=12),
            }, emit)
            return True
        opponents = self.state.get("combat", {}).get("opponents", [])
        pending = self.state.get("combat", {}).get("pending_defense") or {}
        if opponents:
            opponent_name = str(opponents[0].get("name") or "the opponent")
            if len(opponents) > 1:
                opponent_name += " and their group"
        else:
            opponent_name = "the opponent"
        if pending.get("attack_mode") == "magic":
            action_text = f"I defend against {opponent_name}'s {pending.get('spell_name') or 'spell'}."
        else:
            action_text = f"I defend against {opponent_name}'s answering attack."
        self._set_pending({
            "kind": "combat_defense",
            "text": action_text,
            "recent": self.store.recent_turns(self.state["campaign_id"], limit=12),
        }, prompt)
        emit("roll_prompt", copy.deepcopy(self.pending_prompt))
        return True

    # ------------------------------------------------------------- resolution
    def _resolve_and_narrate(self, data: dict[str, Any], emit: Emit) -> None:
        """Exact port of app.py _resolve_and_narrate."""
        player_text = str(data.get("text") or "")
        recent_before = data.get("recent") if isinstance(data.get("recent"), list) else []
        semantic_roll = data.get("semantic_roll") if isinstance(data.get("semantic_roll"), dict) else None
        world_beat = data.get("world_beat") if isinstance(data.get("world_beat"), dict) else None
        manual_roll = int(data.get("manual_roll")) if data.get("manual_roll") is not None else None
        manual_rolls = data.get("manual_rolls") if isinstance(data.get("manual_rolls"), list) else None
        is_combat_defense = data.get("kind") == "combat_defense"
        try:
            if self.state and is_combat_defense:
                resolved = resolve_pending_combat_defense(self.state, manual_roll=manual_roll, manual_rolls=manual_rolls)
            else:
                resolved = resolve_player_action(
                    self.state,
                    player_text,
                    semantic_roll=semantic_roll,
                    world_beat=world_beat,
                    allow_regex_fallback=semantic_roll is None,
                    manual_roll=manual_roll,
                    manual_rolls=manual_rolls,
                ) if self.state else None
                if resolved is None and self.state and world_beat:
                    resolved = commit_world_beat(self.state, world_beat)
                if self.state:
                    resolved = apply_action_consequences(self.state, semantic_roll, resolved)
                    resolved = advance_afflictions(self.state, resolved)
                    maybe_bind_island(self.state, player_text, resolved)
                    self._prepare_voyage_and_island(player_text, recent_before, semantic_roll, resolved)
                    if isinstance(semantic_roll, dict) and semantic_roll.get("mass_combat_active"):
                        from .skirmish_resolution import resolve_skirmish_momentum
                        player_outcome = None
                        if isinstance(resolved, dict):
                            if "outcome" in resolved:
                                player_outcome = resolved.get("outcome")
                            elif isinstance(resolved.get("roll"), dict):
                                player_outcome = resolved["roll"].get("outcome")
                            elif resolved.get("exchanges"):
                                first_ex = resolved["exchanges"][0]
                                if first_ex.get("hit"):
                                    player_outcome = "critical_success" if first_ex.get("critical") else "success"
                                else:
                                    player_outcome = "critical_failure" if first_ex.get("critical") else "failure"
                        skirmish_result = resolve_skirmish_momentum(self.state, player_outcome)
                        if isinstance(resolved, dict):
                            resolved["skirmish_resolution"] = skirmish_result
                    scenario_updates = observe_scenario_action(
                        self.state,
                        player_text,
                        resolved,
                        semantic_flags=(
                            list(semantic_roll.get("scenario_flags") or []) if isinstance(semantic_roll, dict) else None
                        ),
                    )
                    if scenario_updates and isinstance(resolved, dict):
                        resolved["scenario_flag_updates"] = scenario_updates
        except Exception as exc:
            resolved = {"type": "engine_warning", "committed": False, "reason": str(exc)}
        ledger = event_ledger_line(resolved)
        if self.state:
            # Commit consumption alongside the mechanical outcome. Until this
            # save, a process restart can restore the unconsumed pending roll.
            self.state.pop("_web_pending_roll", None)
            record_mechanical_ledger(self.state, resolved, ledger)
            self._save()
        self._emit_ledger(emit, ledger)
        emit("state", None)
        self._start_generation(
            player_text,
            resolved,
            show_player=not is_combat_defense,
            recent_override=recent_before,
            semantic_roll=semantic_roll,
            emit=emit,
        )

    def _prepare_voyage_and_island(self, player_text, recent_before, semantic_roll, resolved) -> None:
        """Port of the synchronous voyage pre-mapping block inside _resolve_and_narrate."""
        state = self.state
        pending_voyage = semantic_roll.get("pending_voyage_destination") if isinstance(semantic_roll, dict) else ""
        from .voyage import clean_destination
        voyage = state.get("voyage") or {}
        if voyage.get("phase") in {"in_transit", "interrupted", "arrived"}:
            pending_voyage = voyage["destination_name"]
        if pending_voyage and pending_voyage != "NONE":
            pending_voyage = clean_destination(pending_voyage)
            voyage_id = (
                voyage.get("destination_id") if pending_voyage == voyage.get("destination_name") else None
            ) or _emergent_id(pending_voyage)
            if not isinstance(state.get("locations", {}).get(voyage_id, {}).get("site_memory"), dict):
                if voyage_id not in state.setdefault("locations", {}):
                    state["locations"][voyage_id] = {
                        "name": pending_voyage,
                        "region": "Emergent place",
                        "summary": "A place mapped in advance of arrival.",
                        "aliases": [pending_voyage],
                        "provisional": True,
                        "defining_excerpt": None,
                        "visit_count": 0,
                    }
                fake_resolved = {"type": "movement", "committed": True, "to_name": pending_voyage,
                                 "to_id": voyage_id, "prearrival": True}
                maybe_bind_island(state, "", fake_resolved)
                from .island_context import is_island
                if is_island(state, voyage_id):
                    mapping_state = copy.deepcopy(state)
                    mapping_state["current_location_id"] = voyage_id
                    mapping_state["scene_position"] = None
                    island_result = run_spatial_secretary(
                        model=self.background_model, state=mapping_state, recent_turns=recent_before,
                        player_text=player_text, narration="", resolved_event=fake_resolved,
                        planning_mode="island_macro",
                    )
                    apply_spatial_survey_for_anchor(state, island_result, anchor_location_id=voyage_id,
                                                    anchor_scene_position=None)
        if _island_survey_due(state):
            island_result = run_spatial_secretary(
                model=self.background_model, state=copy.deepcopy(state), recent_turns=recent_before,
                player_text=player_text, narration="", resolved_event=resolved, planning_mode="island_macro",
            )
            apply_spatial_survey_for_anchor(state, island_result,
                                            anchor_location_id=str(state.get("current_location_id")),
                                            anchor_scene_position=None)

    # ------------------------------------------------------------- generation
    def _maybe_shared_echo(self, resolved_event: dict[str, Any] | None) -> dict[str, Any] | None:
        if not self.state:
            return None
        eligible = resolved_event is None and int(self.state.get("turn_no", 0)) == 0
        eligible = eligible or bool(resolved_event and resolved_event.get("type") == "movement")
        if not eligible:
            return None
        sampler = random.Random(f"{self.state.get('rng_seed')}:{self.state.get('turn_no')}:shared-echo")
        if sampler.random() > 0.18:
            return None
        return self.store.random_shared_echo(
            exclude_campaign_id=self.state["campaign_id"],
            allowed_scales=["shard", "person", "site", "district"],
        )

    def _start_generation(
        self,
        player_text: str,
        resolved_event: dict[str, Any] | None,
        *,
        show_player: bool,
        recent_override: list[dict[str, Any]] | None = None,
        semantic_roll: dict[str, Any] | None = None,
        emit: Emit = _no_emit,
    ) -> None:
        """Port of _start_generation + the 'done'/'generation_error' handlers of _poll_events."""
        with self.lock:
            state = self.state
            if not state:
                return
            self.active_generation_context = {
                "player_text": player_text,
                "resolved_event": resolved_event,
                "semantic_roll": semantic_roll,
            }
            self.generating = True
            recent = recent_override if recent_override is not None else self.store.recent_turns(state["campaign_id"], limit=12)
            self.active_generation_context["recent"] = copy.deepcopy(recent[-12:])
            memory = self.store.recent_evidence(state["campaign_id"], limit=8)
            shared_echo = self._maybe_shared_echo(resolved_event)
            npc_seed = (
                None
                if shared_echo
                else maybe_npc_seed(
                    state,
                    resolved_event,
                    scene_occupied=arrival_scene_occupied(state, resolved_event, semantic_roll, player_text),
                    density=(
                        str(semantic_roll.get("npc_seed_density") or "ordinary")
                        if isinstance(semantic_roll, dict) else "ordinary"
                    ),
                )
            )
            messages = build_messages(
                state, recent, player_text, resolved_event,
                memory_evidence=memory, shared_echo=shared_echo, npc_seed=npc_seed,
            )

        emit("status", "Gemma 26B is writing…")
        emit("gm_start", None)
        try:
            complete = self.model.stream_chat(
                messages,
                on_token=lambda token: emit("token", token),
                on_reset=lambda: emit("gm_reset", None),
            )
            review = finish_party_review(
                model=self.model, state=copy.deepcopy(state), recent_turns=recent,
                player_text=player_text, narration=complete, semantic_roll=semantic_roll,
                resolved_event=resolved_event,
            )
        except Exception as exc:
            with self.lock:
                self.active_generation_context = None
                self.generating = False
            emit("gm_end", {"failed": True})
            emit("error", str(getattr(exc, "player_message", None) or exc))
            logger.warning("Narration failed: %s", exc)
            with self.lock:
                if self.state is state:
                    if state.get("campaign_status") == "game_over":
                        emit("game_over", "GAME OVER · narration failed; restart for a new voyage")
                    else:
                        self._show_queued_combat_defense(emit)
            return

        emit("gm_end", None)
        with self.lock:
            if self.state is not state:
                # The campaign was replaced while narrating; never write into it.
                return
            self._on_generation_done(str(complete or "").strip(), review, emit)

    def _record_party_review(self, data: dict[str, Any], emit: Emit) -> None:
        if not self.state:
            return
        event = data.get("event")
        ledger = event_ledger_line(event)
        if ledger:
            self._emit_ledger(emit, ledger)
            record_mechanical_ledger(self.state, event, ledger)
        if data.get("error"):
            emit("error", "Party update pending: " + str(data["error"]))
        self._save()

    def _on_generation_done(self, text: str, review: dict[str, Any] | None, emit: Emit) -> None:
        """Exact port of the _poll_events 'done' branch, scheduling background work afterwards."""
        state = self.state
        if state and isinstance(review, dict) and review:
            event = apply_party_review(state, review)
            self._record_party_review({"event": event, "error": review.get("error")}, emit)
        generation_context = self.active_generation_context or {}
        self.active_generation_context = None
        player_text = str(generation_context.get("player_text") or "")
        resolved_event = generation_context.get("resolved_event")
        resolved_event = resolved_event if isinstance(resolved_event, dict) else None
        audit_job = None
        if state and text:
            note_combat_episode_narration(
                state, resolved_event, text,
                generation_context.get("recent") if isinstance(generation_context.get("recent"), list) else [],
            )
            note_affliction_narration(state, resolved_event, text)
            note_book_seed_narration(state, text, player_text, resolved_event)
            note_active_situation_narration(state, text, resolved_event)
            note_scenario_narration(state, player_text, text, resolved_event)
            note_material_reveal_from_narration(state, player_text, text, resolved_event)
            capture_passage_offer(state, text)
            capture_resource_offer(state, text)
            capture_local_game_offer(state, text)
            commit_pending_site_area_observation(state)
            commit_pending_site_transition(state, text)
            cement_arrival_excerpt(state, text)
            refresh_emergent_place_definition(state, text)
            note_site_transition(state, text, resolved_event)
            sequence_no = self.store.append_turn(state["campaign_id"], "Aether Harbor", text)
            note_transcript_scope(state, sequence_no)
            self._save(state)
            audit_job = self._prepare_grounding_audit(player_text=player_text, narration=text, resolved_event=resolved_event)
        planning_mode = (
            spatial_survey_mode(state=state, player_text=player_text, narration=text, resolved_event=resolved_event)
            if state and text else None
        )
        spatial_job = None
        if state and text and planning_mode and self._spatial_enrichment_allowed(
            planning_mode=planning_mode, resolved_event=resolved_event
        ):
            spatial_job = self._prepare_spatial_survey(
                player_text=player_text, narration=text, resolved_event=resolved_event, planning_mode=planning_mode,
            )
        elif state and text:
            queue_curator_after_narration(state, allow_place_card=not bool(planning_mode))
            self._save(state)
        self.generating = False
        emit("state", None)

        self._public_cache = self._build_public_state()
        # _complete_generation_cycle
        if state and state.get("campaign_status") == "game_over":
            self.pending_action = None
            self.pending_prompt = None
            emit("game_over", "GAME OVER · restart Aether Harbor for a new voyage")
            self._public_cache = self._build_public_state()
            self._launch_background(audit_job, spatial_job, allow_secretary=False)
            return
        defense_shown = self._show_queued_combat_defense(emit)
        self._launch_background(audit_job, spatial_job, allow_secretary=not defense_shown)

    def _spatial_enrichment_allowed(self, *, planning_mode: str, resolved_event: dict[str, Any] | None) -> bool:
        """Throttle ordinary room-to-room enrichment, never first planning."""
        if not self.state or planning_mode != "interior":
            return True
        movement = resolved_event if isinstance(resolved_event, dict) else {}
        if str(movement.get("type") or "") in {"compound_resolution", "resource_movement_resolution"}:
            movement = movement.get("movement") if isinstance(movement.get("movement"), dict) else {}
        routine_local_move = bool(str(movement.get("type") or "") == "local_movement" and movement.get("committed"))
        if not routine_local_move:
            return True
        scheduler = (
            self.state.get("spatial_secretary_scheduler")
            if isinstance(self.state.get("spatial_secretary_scheduler"), dict) else {}
        )
        current_turn = int(self.state.get("turn_no", 0) or 0)
        last_turn = int(scheduler.get("last_started_turn", -999) or -999)
        return current_turn - last_turn >= 2

    # ------------------------------------------------------- background work
    def _prepare_grounding_audit(self, *, player_text: str, narration: str, resolved_event) -> dict[str, Any] | None:
        if not self.state or not narration.strip():
            return None
        from .grounding_auditor import audit_context, extract_pre_deducted_silver
        context = audit_context(self.state, resolved_event)
        pre_deducted = extract_pre_deducted_silver(resolved_event)
        campaign_id = str(self.state.get("campaign_id") or "")
        turn_no = int(self.state.get("turn_no", 0) or 0)
        return {
            "context": context,
            "job": {
                "audit_id": f"{campaign_id}:{turn_no}",
                "campaign_id": campaign_id,
                "turn_no": turn_no,
                "pre_deducted_silver": pre_deducted,
                "receipts": context["receipts"],
                "player_text": player_text,
                "narration": narration,
            },
        }

    def _prepare_spatial_survey(self, *, player_text, narration, resolved_event, planning_mode) -> dict[str, Any] | None:
        if not self.state:
            return None
        scheduler = self.state.setdefault("spatial_secretary_scheduler", {})
        current_turn = int(self.state.get("turn_no", 0) or 0)
        scheduler["last_started_turn"] = current_turn
        self.background_last_started_turn = current_turn
        if planning_mode == "exterior" and reserve_selected_exterior_site(self.state, narration):
            self._save()
        job = {
            "campaign_id": str(self.state.get("campaign_id") or ""),
            "turn_no": current_turn,
            "anchor_location_id": str(self.state.get("current_location_id") or ""),
            "anchor_scene_position": copy.deepcopy(
                self.state.get("scene_position") if isinstance(self.state.get("scene_position"), dict) else None
            ),
            "narration": narration,
            "player_text": player_text,
            "resolved_event": resolved_event,
            "planning_mode": planning_mode,
        }
        return {
            "job": job,
            "state_snapshot": copy.deepcopy(self.state),
            "recent": self.store.recent_turns(job["campaign_id"], limit=10),
        }

    def _launch_background(self, audit_job, spatial_job, *, allow_secretary: bool) -> None:
        if audit_job is None and spatial_job is None and not allow_secretary:
            return
        with self.lock:
            self._background_jobs += 1
            self.background_idle.clear()

        def worker() -> None:
            try:
                if audit_job is not None:
                    self._run_grounding_audit(audit_job)
                if spatial_job is not None:
                    self._run_spatial_job(spatial_job)
                if allow_secretary:
                    self._run_due_secretary()
            except Exception as exc:  # background memory is never load-bearing
                logger.warning("Background memory job failed: %s", exc)
            finally:
                with self.lock:
                    self._background_jobs -= 1
                    if self._background_jobs <= 0:
                        self._background_jobs = 0
                        self.background_idle.set()

        threading.Thread(target=worker, daemon=True, name="aether-background").start()

    def _run_grounding_audit(self, prepared: dict[str, Any]) -> None:
        from .grounding_auditor import apply_grounding_audit, run_grounding_auditor
        job = prepared["job"]
        try:
            result = run_grounding_auditor(
                model=self.background_model,
                player_text=job["player_text"],
                narration=job["narration"],
                pre_deducted_silver=job["pre_deducted_silver"],
                context=prepared["context"],
            )
            audit = result if isinstance(result, dict) else {}
        except Exception as exc:
            audit = {"error": str(exc) or "Grounding audit failed"}
        with self.lock:
            if self._is_live(job["campaign_id"]):
                apply_grounding_audit(self.state, audit, job=job)
                self._save()

    def _run_spatial_job(self, prepared: dict[str, Any], emit: Emit = _no_emit) -> None:
        job = prepared["job"]
        try:
            survey = run_spatial_secretary(
                model=self.background_model,
                state=prepared["state_snapshot"],
                recent_turns=prepared["recent"],
                player_text=job["player_text"],
                narration=job["narration"],
                resolved_event=job["resolved_event"],
                planning_mode=job["planning_mode"],
            )
            error = None
        except Exception as exc:
            survey, error = None, str(exc)
        with self.lock:
            if not self._is_live(job["campaign_id"]):
                return
            state = self.state
            if error is not None:
                state["pending_site_plan_retry"] = job
                emit("error", "Site planning failed; send your next action to retry before play advances.")
                queue_curator_after_narration(state, allow_place_card=True)
                self._save()
                return
            applied = apply_spatial_survey_for_anchor(
                state,
                survey if isinstance(survey, dict) else None,
                anchor_location_id=str(job.get("anchor_location_id") or ""),
                anchor_scene_position=(
                    job.get("anchor_scene_position") if isinstance(job.get("anchor_scene_position"), dict) else None
                ),
                narration=str(job.get("narration") or ""),
            )
            if isinstance(survey, dict) and survey.get("spatial_audit"):
                audit = survey["spatial_audit"]
                state["last_spatial_audit"] = audit
                if audit.get("pass3_triggered"):
                    state.setdefault("spatial_audit_history", []).append(audit)
            if applied:
                state.pop("pending_site_plan_retry", None)
                if int(state.get("turn_no", 0)) == int(job.get("turn_no", -1)):
                    note_site_transition(state, str(job.get("narration") or ""), job.get("resolved_event"))
                scheduler = state.setdefault("spatial_secretary_scheduler", {})
                scheduler["last_completed_turn"] = int(job.get("turn_no", 0) or 0)
            else:
                state["pending_site_plan_retry"] = job
                emit("error", "The site plan could not be validated. Your next action will retry planning before play advances.")
            queue_curator_after_narration(
                state,
                allow_place_card=isinstance(survey, dict) and survey.get("spatial_review_status") == "not_needed",
            )
            self._save()

    def _run_spatial_survey(self, *, player_text, narration, resolved_event, planning_mode, emit: Emit) -> None:
        """Synchronous retry of a failed site plan before the next action (v.39 pending_site_plan_retry)."""
        with self.lock:
            prepared = self._prepare_spatial_survey(
                player_text=str(player_text or ""), narration=str(narration or ""),
                resolved_event=resolved_event, planning_mode=str(planning_mode or "exterior"),
            )
        if prepared:
            self._run_spatial_job(prepared, emit)

    def _due_secretary_kind(self) -> str | None:
        if not self.state:
            return None
        if emergent_scenario_due(self.state):
            return "scenario"
        if room_memory_due(self.state):
            return "room_memory"
        if recap_due(self.state):
            return "recap"
        if secretary_due(self.state):
            return "evidence"
        if curator_due(self.state):
            return "curator"
        return None

    def _run_due_secretary(self) -> None:
        """Port of _schedule_secretary_if_due/_run_secretary_when_idle: one job per beat."""
        with self.lock:
            if not self.state or self.state.get("campaign_status") == "game_over":
                return
            if int(self.background_last_started_turn) == int(self.state.get("turn_no", 0) or 0):
                return
            kind = self._due_secretary_kind()
            if kind is None:
                return
            self.background_last_started_turn = int(self.state.get("turn_no", 0) or 0)
            snapshot = copy.deepcopy(self.state)
            job = {"campaign_id": str(snapshot.get("campaign_id") or ""), "turn_no": int(snapshot.get("turn_no", 0) or 0)}
        runner = {
            "scenario": run_emergent_scenario_architect,
            "room_memory": run_room_secretary,
            "recap": run_recap_secretary,
            "curator": run_state_curator,
            "evidence": run_secretary,
        }[kind]
        try:
            result = runner(model=self.background_model, store=self.store, state=snapshot, save_state=False)
        except Exception as exc:
            logger.warning("Secretary %s failed: %s", kind, exc)
            return
        with self.lock:
            self._apply_secretary_snapshot({"kind": kind, "result": result, "state_snapshot": snapshot, "job": job})

    def _apply_secretary_snapshot(self, data: dict[str, Any]) -> bool:
        """Apply one background result only to the exact beat it examined (port)."""
        if not self.state:
            return False
        job = data.get("job") if isinstance(data.get("job"), dict) else {}
        snapshot = data.get("state_snapshot") if isinstance(data.get("state_snapshot"), dict) else None
        if not isinstance(snapshot, dict):
            return False
        kind = str(data.get("kind") or "")
        if str(self.state.get("campaign_id") or "") != str(job.get("campaign_id") or ""):
            return False
        if kind == "room_memory":
            applied = apply_room_memory_result(self.state, data.get("result"))
            if applied:
                self._save()
            return applied
        if int(self.state.get("turn_no", 0) or 0) != int(job.get("turn_no", -1) or -1):
            return False
        keys = {
            "scenario": ("scenario_kernels",),
            "recap": ("campaign_recap", "hidden_currents"),
            "evidence": ("secretary", "npcs", "threads", "locations", "state_curator", "provisional_npc_anchors"),
            "curator": ("state_curator", "locations", "hidden_currents", "npcs", "threads"),
        }.get(kind, ())
        for key in keys:
            if key in snapshot:
                self.state[key] = copy.deepcopy(snapshot[key])
        if kind in {"evidence", "curator"} and isinstance(snapshot.get("player"), dict):
            snap_player = snapshot["player"]
            live_player = self.state.setdefault("player", {})
            snap_inv = snap_player.get("inventory") if isinstance(snap_player.get("inventory"), list) else []
            live_inv = live_player.get("inventory") if isinstance(live_player.get("inventory"), list) else []
            for snap_item in snap_inv:
                if not isinstance(snap_item, dict) or "known_details" not in snap_item:
                    continue
                snap_name = str(snap_item.get("name") or "").strip().casefold()
                for live_item in live_inv:
                    if isinstance(live_item, dict) and str(live_item.get("name") or "").strip().casefold() == snap_name:
                        live_item["known_details"] = copy.deepcopy(snap_item["known_details"])
                        if "known_details_updated_at_turn" in snap_item:
                            live_item["known_details_updated_at_turn"] = snap_item["known_details_updated_at_turn"]
            snap_comps = snap_player.get("companions") if isinstance(snap_player.get("companions"), list) else []
            live_comps = live_player.get("companions") if isinstance(live_player.get("companions"), list) else []
            for snap_comp in snap_comps:
                if not isinstance(snap_comp, dict) or not str(snap_comp.get("appearance") or "").strip():
                    continue
                snap_cname = str(snap_comp.get("name") or "").strip().casefold()
                for live_comp in live_comps:
                    if (
                        isinstance(live_comp, dict)
                        and str(live_comp.get("name") or "").strip().casefold() == snap_cname
                        and not str(live_comp.get("appearance") or "").strip()
                    ):
                        live_comp["appearance"] = snap_comp["appearance"]
        if kind == "recap" and isinstance(snapshot.get("player"), dict):
            snap_player = snapshot["player"]
            live_player = self.state.setdefault("player", {})
            if "appearance" in snap_player:
                live_player["appearance"] = snap_player["appearance"]
            if "appearance_locked" in snap_player:
                live_player["appearance_locked"] = bool(snap_player["appearance_locked"])
        self._save()
        return bool(keys)

    # ------------------------------------------------------------ wheel spin
    def begin_fate_spin(self) -> dict[str, Any]:
        """Synchronous part of _spin_wheel: commit the spin and return the outcome. No model calls."""
        with self.lock:
            if not self.state:
                return {"status": "no_campaign"}
            if self.state.get("campaign_status") == "game_over":
                return {"status": "game_over"}
            if self.pending_action:
                return {"status": "pending_roll"}
            if remaining_cooldown(self.state) > 0:
                return {"status": "cooldown", "remaining": remaining_cooldown(self.state)}
            event = spin_fate(self.state)
            if event.get("type") != "fate_resolution":
                return {"status": "cooldown", "remaining": remaining_cooldown(self.state)}
            self._save()
            return {
                "status": "spinning",
                "event": event,
                "outcome": event.get("result"),
                "polarity": event.get("polarity"),
                "remaining": remaining_cooldown(self.state),
            }

    def run_fate_narration(self, event: dict[str, Any], emit: Emit = _no_emit) -> None:
        """Port of _finish_fate_spin."""
        self._wait_for_background(emit)
        self._emit_ledger(emit, event_ledger_line(event))
        emit("state", None)
        action = (
            f"The Wheel of Fate has produced {event['result']}. "
            "Interrupt the current flow and manifest the exact committed consequence dramatically in the present scene."
        )
        self._start_generation(action, event, show_player=False, emit=emit)
