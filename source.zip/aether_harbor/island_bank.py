from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any


PLANETS = ("Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn")
_CATALOG_PATH = Path(__file__).resolve().parent.parent / "data" / "authored_islands.json"
_ISLAND_WORD = re.compile(r"\b(?:island|isle|islet|cay|archipelago)\b", re.I)
_VOYAGE_WORD = re.compile(r"\b(?:sail|voyage|embark|cast\s+off|set\s+out|land|approach|make\s+for)\b", re.I)
_HORIZON_INFORMATION_REQUEST = re.compile(
    r"\b(?:which|what|where|when|any|other|another|tell|mention(?:ed)?|list|know|"
    r"recommend|opinion|best|available|possible|specific|some|more|read|check|show|"
    r"look)\b|(?:^|[\"“])\s*(?:can|could|are|is|does|do)\b",
    re.I,
)
_HORIZON_TRAVEL_TOPIC = re.compile(
    r"\b(?:islands?|isles?|destinations?|departures?|passages?|voyages?|routes?|"
    r"foreign\s+lands?|distant\s+lands?|other\s+places?|other\s+ports?|"
    r"sail(?:s|ing)?|sailings|embark(?:ing)?)\b",
    re.I,
)
_HORIZON_VESSEL = re.compile(r"\b(?:ships?|boats?|vessels?|ferr(?:y|ies))\b", re.I)
_HORIZON_VESSEL_TRAVEL = re.compile(
    r"\b(?:leav(?:e|es|ing)|depart(?:s|ing)?|head(?:s|ed|ing)?|go(?:es|ing)?|"
    r"bound|passengers?|tickets?|fares?)\b", re.I,
)


def _is_horizon_request(player_text: str) -> bool:
    """Current travel inquiry only; stale dialogue and personal names are not triggers."""
    if not _HORIZON_INFORMATION_REQUEST.search(player_text) and "?" not in player_text:
        return False
    return bool(
        _HORIZON_TRAVEL_TOPIC.search(player_text)
        or (_HORIZON_VESSEL.search(player_text) and _HORIZON_VESSEL_TRAVEL.search(player_text))
        or _named_entry_from_text(player_text) is not None
    )


def _clean(value: Any, limit: int) -> str:
    return " ".join(str(value or "").split())[:limit]


def _load_catalog() -> tuple[dict[str, dict[str, Any]], dict[str, list[dict[str, Any]]]]:
    try:
        raw = json.loads(_CATALOG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}, {planet: [] for planet in PLANETS}
    if not isinstance(raw, list):
        return {}, {planet: [] for planet in PLANETS}
    by_id: dict[str, dict[str, Any]] = {}
    by_planet = {planet: [] for planet in PLANETS}
    for row in raw:
        if not isinstance(row, dict):
            continue
        island_id = _clean(row.get("id"), 80)
        planet = _clean(row.get("planet"), 16)
        if not island_id or planet not in PLANETS:
            continue
        # One island belongs to exactly one planet. Affinities stay in design
        # notes and can never become runtime metadata or prompt content.
        forbidden = {"planets", "secondary", "secondary_planet", "affinity", "affinities"}
        if forbidden.intersection(row):
            continue
        if island_id in by_id:
            continue
        spine = _clean(row.get("spine"), 900)
        name = _clean(row.get("name"), 100)
        if not spine or not name:
            continue
        layers: list[dict[str, Any]] = []
        for layer in row.get("layers", []):
            if not isinstance(layer, dict):
                continue
            kind = _clean(layer.get("kind"), 24)
            if kind not in {"settlement", "district", "site_or_cast"}:
                continue
            capsule = _clean(layer.get("capsule"), 700)
            terms = [_clean(term, 60).casefold() for term in layer.get("terms", []) if _clean(term, 60)]
            if capsule and terms:
                layers.append({**layer, "kind": kind, "capsule": capsule, "terms": terms[:12]})
        scenarios: list[dict[str, Any]] = []
        for scenario in row.get("scenarios", []):
            if not isinstance(scenario, dict):
                continue
            flags = [_clean(flag, 48) for flag in scenario.get("flags", []) if _clean(flag, 48)]
            terminal_flags = [
                _clean(flag, 48)
                for flag in scenario.get("terminal_flags", [])
                if _clean(flag, 48) in flags
            ]
            terms = [_clean(term, 60).casefold() for term in scenario.get("terms", []) if _clean(term, 60)]
            if (
                _clean(scenario.get("id"), 80)
                and _clean(scenario.get("objective"), 300)
                and _clean(scenario.get("hidden"), 400)
                and terms
                and len(flags) <= 3
            ):
                scenarios.append(
                    {
                        **scenario,
                        "flags": flags,
                        "terminal_flags": terminal_flags,
                        "terms": terms[:12],
                    }
                )
        clean_row = {
            **row,
            "id": island_id,
            "planet": planet,
            "name": name,
            "spine": spine,
            "layers": layers,
            "scenarios": scenarios,
        }
        by_id[island_id] = clean_row
        by_planet[planet].append(clean_row)
    for planet in PLANETS:
        by_planet[planet].sort(key=lambda row: str(row.get("id") or ""))
    return by_id, by_planet


ISLANDS_BY_ID, ISLANDS_BY_PLANET = _load_catalog()


def _digest(state: dict[str, Any], suffix: str) -> bytes:
    campaign = str(state.get("campaign_id") or "")
    seed = int(state.get("rng_seed", 0) or 0)
    return hashlib.sha256(f"{campaign}:{seed}:authored-island-bank-v2:{suffix}".encode("utf-8")).digest()


def _ensure_horizon_state(state: dict[str, Any], store: dict[str, Any]) -> list[str]:
    """Choose one stable authored identity per planet for public world knowledge."""

    existing = store.get("horizon_ids")
    if isinstance(existing, list):
        valid = [str(value) for value in existing if str(value) in ISLANDS_BY_ID]
        planets = {str(ISLANDS_BY_ID[value].get("planet") or "") for value in valid}
        if len(valid) == len(PLANETS) and planets == set(PLANETS):
            store.setdefault("horizon_query_count", 0)
            store.setdefault("last_horizon_query_turn", -999)
            return valid

    chosen: list[dict[str, Any]] = []
    for planet in PLANETS:
        eligible = list(ISLANDS_BY_PLANET.get(planet) or [])
        if not eligible:
            continue
        eligible.sort(
            key=lambda row: _digest(state, f"horizon-choice:{planet}:{row['id']}")
        )
        chosen.append(eligible[0])
    chosen.sort(key=lambda row: _digest(state, f"horizon-order:{row['id']}"))
    horizon_ids = [str(row["id"]) for row in chosen]
    store["horizon_ids"] = horizon_ids
    store["horizon_query_count"] = 0
    store["last_horizon_query_turn"] = -999
    return horizon_ids


def ensure_island_bank_state(state: dict[str, Any]) -> dict[str, Any]:
    store = state.setdefault("island_bank", {})
    manifest = store.get("manifest")
    valid_manifest = (
        isinstance(manifest, dict) and set(manifest) == set(PLANETS)
        and all(isinstance(value, bool) for value in manifest.values())
    )
    if not valid_manifest:
        # New worlds: the requested four authored / three improvised split.
        # Hash selection is stable for campaign+seed and does not consume global RNG.
        ordered = sorted(PLANETS, key=lambda planet: _digest(state, f"manifest-v4:{planet}"))
        improvised = set(ordered[:3])
        store["manifest"] = {planet: planet not in improvised for planet in PLANETS}
    # Preserve valid saved manifests and bindings, including older seven-authored worlds.
    store["authored_count"] = sum(store["manifest"].values())
    store.setdefault("bindings", {})
    if "discovery_revision" not in store:
        # Earlier builds publicly listed catalog names even for improvised planets.
        # Preserve those already-issued bearings; do not silently rewrite a save.
        count = int(store.get("horizon_query_count", 0) or 0)
        old_ids = store.get("horizon_ids") or []
        store["legacy_public_horizon_ids"] = list(old_ids[:min(7, count + 2)]) if count else []
        store["discovery_revision"] = 1
    _ensure_horizon_state(state, store)
    store["schema"] = 4
    return store


def manifest_for_debug(state: dict[str, Any]) -> dict[str, bool]:
    return dict(ensure_island_bank_state(state)["manifest"])


def _planet_from_text(value: Any) -> str | None:
    text = str(value or "")
    hits = [planet for planet in PLANETS if re.search(rf"\b{re.escape(planet)}\b", text, re.I)]
    return hits[0] if len(hits) == 1 else None


def _named_entry_from_text(value: Any) -> dict[str, Any] | None:
    folded = " ".join(str(value or "").casefold().split())
    matches = [
        row for row in ISLANDS_BY_ID.values()
        if len(str(row.get("name") or "")) >= 4
        and str(row.get("name") or "").casefold() in folded
    ]
    return matches[0] if len(matches) == 1 else None


def _movement_event(resolved_event: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(resolved_event, dict):
        return None
    if resolved_event.get("type") == "movement" and resolved_event.get("committed"):
        return resolved_event
    movement = resolved_event.get("movement")
    if isinstance(movement, dict) and movement.get("type") == "movement" and movement.get("committed"):
        return movement
    return None


def _generic_destination(name: str, planet: str) -> bool:
    folded = " ".join(name.casefold().split())
    generic = {
        planet.casefold(),
        f"{planet.casefold()} island",
        f"the {planet.casefold()} island",
        f"island of {planet.casefold()}",
        f"the island of {planet.casefold()}",
    }
    return folded in generic


def _choose_variant(
    state: dict[str, Any],
    planet: str,
    requested: dict[str, Any] | None,
    *,
    location_id: str,
) -> dict[str, Any] | None:
    eligible = list(ISLANDS_BY_PLANET.get(planet) or [])
    store = ensure_island_bank_state(state)
    grandfathered = isinstance(requested, dict) and requested.get("id") in store.get("legacy_public_horizon_ids", [])
    if not store.get("manifest", {}).get(planet, True) and not grandfathered:
        return None
    if requested in eligible:
        return requested
    if not eligible:
        return None
    horizon_entry = next(
        (
            ISLANDS_BY_ID.get(entry_id)
            for entry_id in _ensure_horizon_state(state, store)
            if isinstance(ISLANDS_BY_ID.get(entry_id), dict)
            and ISLANDS_BY_ID[entry_id].get("planet") == planet
        ),
        None,
    )
    bindings = ensure_island_bank_state(state).get("bindings", {})
    used = {
        str(binding.get("entry_id") or "")
        for bound_id, binding in bindings.items()
        if str(bound_id) != location_id
        and isinstance(binding, dict)
        and binding.get("ownership") == "authored"
        and binding.get("planet") == planet
    }
    if horizon_entry in eligible and str(horizon_entry.get("id") or "") not in used:
        return horizon_entry
    unused = [row for row in eligible if str(row.get("id") or "") not in used]
    pool = unused or eligible
    pool.sort(
        key=lambda row: _digest(
            state, f"variant:{planet}:{location_id}:{row['id']}"
        )
    )
    return pool[0]


def maybe_bind_island(
    state: dict[str, Any],
    player_text: str,
    resolved_event: dict[str, Any] | None,
) -> dict[str, Any] | None:
    movement = _movement_event(resolved_event)
    if not movement:
        return None
    destination_name = _clean(movement.get("to_name"), 100)
    from .island_context import destination_entry
    # Destination aliases do not broaden natural discovery/horizon triggers.
    requested = destination_entry(destination_name) or _named_entry_from_text(player_text)
    planet = _planet_from_text(f"{destination_name} {player_text}")
    if planet is None and requested is not None:
        planet = str(requested.get("planet") or "")
    if planet not in PLANETS:
        return None
    if not (
        _ISLAND_WORD.search(destination_name)
        or _ISLAND_WORD.search(player_text)
        or _VOYAGE_WORD.search(player_text)
        or requested is not None
    ):
        return None

    location_id = _clean(movement.get("to_id"), 160)
    location = state.get("locations", {}).get(location_id)
    if not location_id or not isinstance(location, dict):
        return None
    from .canon import AETHER_HARBOR_LOCAL_LOCATION_IDS, AETHER_HARBOR_REGIONAL_LOCATION_IDS
    if (location_id in set(AETHER_HARBOR_LOCAL_LOCATION_IDS) | set(AETHER_HARBOR_REGIONAL_LOCATION_IDS)
            or location.get('aether_geography_scope') in {'local', 'regional'}
            or location.get('kind') == 'vessel'):
        return None
    store = ensure_island_bank_state(state)
    bindings = store["bindings"]
    existing = bindings.get(location_id)
    if isinstance(existing, dict):
        return existing

    identity_preexists = bool(
        location.get("defining_excerpt")
        or (
            location.get("provisional") is False
            and int(location.get("visit_count", 0) or 0) > 1
        )
    )
    if identity_preexists and requested is None:
        binding = {
            "planet": planet,
            "ownership": "established",
            "bound_turn": int(state.get("turn_no", 0) or 0),
        }
        bindings[location_id] = binding
        return binding

    entry = _choose_variant(
        state,
        planet,
        requested,
        location_id=location_id,
    )
    if entry is None:
        binding = {
            "planet": planet,
            "ownership": "improvised" if not store["manifest"].get(planet, True) else "unavailable",
            "bound_turn": int(state.get("turn_no", 0) or 0),
        }
        bindings[location_id] = binding
        return binding

    binding = {
        "planet": planet,
        "ownership": "authored",
        "entry_id": entry["id"],
        "bound_turn": int(state.get("turn_no", 0) or 0),
    }
    bindings[location_id] = binding
    location["authored_island_binding"] = entry["id"]
    location["planet"] = planet
    if location.get("provisional") and _generic_destination(destination_name, planet):
        old_name = _clean(location.get("name"), 100)
        location["name"] = entry["name"]
        aliases = location.setdefault("aliases", [])
        for alias in (old_name, entry["name"]):
            if alias and alias.casefold() not in {str(value).casefold() for value in aliases}:
                aliases.append(alias)
    return binding


def active_authored_entry(state: dict[str, Any]) -> dict[str, Any] | None:
    from .island_context import island_root_id
    location_id = island_root_id(state) or str(state.get("current_location_id") or "")
    binding = ensure_island_bank_state(state).get("bindings", {}).get(location_id)
    if not isinstance(binding, dict) or binding.get("ownership") != "authored":
        return None
    return ISLANDS_BY_ID.get(str(binding.get("entry_id") or ""))


def _relevance_text(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
    resolved_event: dict[str, Any] | None,
) -> str:
    location = state.get("locations", {}).get(str(state.get("current_location_id") or ""), {})
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    pieces = [
        player_text,
        location.get("name"),
        location.get("summary"),
        location.get("defining_excerpt"),
        position.get("label"),
        position.get("summary"),
        position.get("defining_excerpt"),
    ]
    pieces.extend(
        row.get("text") for row in recent_turns[-3:]
        if isinstance(row, dict)
    )
    if isinstance(resolved_event, dict):
        pieces.append(json.dumps(resolved_event, ensure_ascii=False))
    return " ".join(str(piece or "") for piece in pieces).casefold()


def private_authored_island_context(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
    resolved_event: dict[str, Any] | None,
) -> dict[str, Any] | None:
    entry = active_authored_entry(state)
    if entry is None:
        return None
    relevance = _relevance_text(state, recent_turns, player_text, resolved_event)
    layer = next(
        (
            row for row in entry.get("layers", [])
            if isinstance(row, dict)
            and any(term in relevance for term in row.get("terms", []))
        ),
        None,
    )
    context: dict[str, Any] = {
        "instruction": (
            "This is the stable private spine of the current island. Preserve these bearings while freely "
            "inventing all gaps. Do not disclose selection mechanics, alternate spines or hidden bindings. "
            "A location or creature is not a quest, and no objective exists unless a separate active scenario says so."
        ),
        "planet": entry["planet"],
        "spine": entry["spine"],
    }
    if isinstance(layer, dict):
        context["relevant_layer"] = {
            "kind": layer.get("kind"),
            "capsule": layer.get("capsule"),
        }
    return context


def _public_bearing(entry: dict[str, Any]) -> str:
    spine = _clean(entry.get("spine"), 900)
    first = re.split(r"(?<=[.!?])\s+", spine, maxsplit=1)[0].strip()
    return first[:220]


def private_island_horizon_context(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> dict[str, Any] | None:
    """Expose only a tiny stable public horizon on a genuine travel-information turn."""

    del recent_turns  # The semantic gate is the current request, not stale harbor chatter.
    if not _is_horizon_request(player_text):
        return None
    store = ensure_island_bank_state(state)
    requested = _named_entry_from_text(player_text)
    bound_ids = {
        row.get("entry_id") for row in store.get("bindings", {}).values()
        if isinstance(row, dict) and row.get("ownership") == "authored"
    }
    def eligible(entry):
        return (store["manifest"].get(entry["planet"], True) or entry["id"] in bound_ids
                or entry["id"] in store.get("legacy_public_horizon_ids", []))
    if requested is not None:
        entries = [requested] if eligible(requested) else []
    else:
        turn_no = int(state.get("turn_no", 0) or 0)
        if int(store.get("last_horizon_query_turn", -999)) != turn_no:
            store["horizon_query_count"] = int(store.get("horizon_query_count", 0) or 0) + 1
            store["last_horizon_query_turn"] = turn_no
        query_count = max(1, int(store.get("horizon_query_count", 1) or 1))
        visible_count = min(len(PLANETS), 3 + query_count - 1)
        entries = [
            ISLANDS_BY_ID[entry_id]
            for entry_id in _ensure_horizon_state(state, store)
            if entry_id in ISLANDS_BY_ID and eligible(ISLANDS_BY_ID[entry_id])
        ][:visible_count]
    if not entries:
        return None
    return {
        "instruction": (
            "These are public bearings, not the private island repository. On this turn the in-world "
            "source the player asks has at least one of them: answer concretely with a supplied proper "
            "name instead of denying all destinations or substituting generic ones. Normally mention "
            "one to three; reveal more only after further questions. Hide private material and selection "
            "mechanics. This is not an exhaustive list of all destinations: ordinary exploration and "
            "improvised islands remain available. Do not book passage unless the resolved event commits it."
        ),
        "known_destinations": [
            {
                "name": entry.get("name"),
                "planet": entry.get("planet"),
                "public_bearing": _public_bearing(entry),
            }
            for entry in entries
        ],
    }
