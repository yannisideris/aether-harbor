from __future__ import annotations

import copy
import time
import uuid
from typing import Any


CLASS_PROFILES: dict[str, dict[str, Any]] = {
    "fighter": {
        "label": "Fighter",
        "max_hp": 15,
        "silver": 18,
        "stats": {"STR": 17, "AGI": 12, "SOC": 8, "ARC": 6, "PER": 13},
        "inventory": [
            {"name": "Short Sword", "quantity": 1, "type": "weapon", "mode": "melee", "weapon_bonus": 2, "affordances": ["cut", "threaten"], "equipped": True},
            {"name": "Leather Jerkin", "quantity": 1, "type": "armor", "armor_value": 1, "equipped": True},
            {"name": "Travel Cloak", "quantity": 1, "type": "clothing"},
            {"name": "Loaf of Bread", "quantity": 2, "type": "food", "affordances": ["eat"]},
        ],
    },
    "thief": {
        "label": "Thief",
        "max_hp": 12,
        "silver": 24,
        "stats": {"STR": 8, "AGI": 17, "SOC": 13, "ARC": 6, "PER": 12},
        "inventory": [
            {"name": "Dagger", "quantity": 1, "type": "weapon", "mode": "melee", "weapon_bonus": 1, "affordances": ["cut", "pry", "threaten"], "equipped": True},
            {"name": "Small Lock Kit", "quantity": 1, "type": "tool", "affordances": ["pick_lock"]},
            {"name": "Soft Boots", "quantity": 1, "type": "clothing"},
            {"name": "Travel Cloak", "quantity": 1, "type": "clothing"},
        ],
    },
    "mage": {
        "label": "Mage",
        "max_hp": 12,
        "silver": 22,
        "stats": {"STR": 6, "AGI": 8, "SOC": 12, "ARC": 17, "PER": 13},
        "known_spells": ["Flamma", "Revelatio", "Lucis"],
        "inventory": [
            {"name": "Dagger", "quantity": 1, "type": "weapon", "mode": "melee", "weapon_bonus": 1, "affordances": ["cut", "pry", "threaten"], "equipped": True},
            {"name": "Notebook", "quantity": 1, "type": "utility", "affordances": ["record", "compare_notes"]},
            {"name": "Small Lamp", "quantity": 1, "type": "utility", "affordances": ["light"]},
            {"name": "White Chalk", "quantity": 1, "type": "utility", "affordances": ["mark", "ritual_trace"]},
        ],
    },
}


LOCATIONS: dict[str, dict[str, Any]] = {
    "opening_threshold": {
        "name": "Aether Harbor",
        "region": "The opening scene",
        "summary": "The first narration will establish the voyage's immediate place.",
        "aliases": ["aether harbor"],
        "provisional": True,
        "defining_excerpt": None,
        "visit_count": 1,
    },
    "commercial_docks": {
        "name": "The Commercial Docks",
        "region": "Center",
        "summary": "Stone quays, warehouses, chandlers, taverns, and the practical violence of trade crowd the bay.",
        "aliases": ["commercial docks", "docks", "wharves", "quays", "harbour", "harbor"],
    },
    "harbormasters_office": {
        "name": "The Harbormaster's Office",
        "region": "Commercial Docks",
        "summary": "The functional port office stands amid the activity of the Commercial Docks.",
        "aliases": ["harbormaster's office", "harbormasters office", "harbormaster office", "port office"],
    },
    "central_plaza": {
        "name": "The Central Plaza",
        "region": "Center",
        "summary": "A broad civic square joins the waterfront streets to the wealthy quarter and the Governor's Palazzo.",
        "aliases": ["central plaza", "plaza", "main square", "square"],
    },
    "wealthy_quarter": {
        "name": "The Wealthy Quarter",
        "region": "Center",
        "summary": "The harbor's wealthiest residential streets extend from near the waterfront toward the Central Plaza.",
        "aliases": ["wealthy quarter", "wealthiest quarter", "wealthy residential quarter", "wealthiest residential quarter"],
    },
    "governors_palazzo": {
        "name": "The Governor's Palazzo",
        "region": "Center",
        "summary": "An imposing tiled-roof palazzo overlooks the civic center and the harbor's wealthiest streets.",
        "aliases": ["governor's palazzo", "governors palazzo", "palazzo", "governor's palace", "palace"],
    },
    "sentinel_lighthouse": {
        "name": "The Sentinel Lighthouse",
        "region": "North",
        "summary": "The lighthouse stands on a steep northern promontory above rough seas, cliffs, and secluded coves.",
        "aliases": ["sentinel lighthouse", "lighthouse", "northern promontory", "promontory", "cliffs"],
    },
    "northern_shore": {
        "name": "The Rough Northern Shore",
        "region": "North",
        "summary": "Beyond the lighthouse promontory, steep cliffs, secluded coves, and abrupt coastal ground line the rough northern shore.",
        "aliases": ["northern shore", "rough northern shore", "northern shoreline", "northern coast", "secluded coves", "northern coves"],
    },
    "southern_outskirts": {
        "name": "The Southern Outskirts",
        "region": "South",
        "summary": "Rural houses, gardens, villas, orchards, and olive groves loosen the town toward a sandy coast.",
        "aliases": ["southern outskirts", "south", "southern houses", "villas", "gardens", "orchards", "olive groves"],
    },
    "sandy_coast": {
        "name": "The Southern Sandy Coast",
        "region": "South",
        "summary": "A softer sandy shoreline lies beyond the orchards and scattered villas south of the harbor.",
        "aliases": ["sandy coast", "southern coast", "southern shore", "sandy shoreline", "beach"],
    },
    "eastern_quarters": {
        "name": "The Eastern Quarters",
        "region": "East",
        "summary": "Poorer stone dwellings climb the higher ground beneath the Mediterranean forest.",
        "aliases": ["eastern quarters", "poor quarters", "poorer quarters", "east", "upper streets"],
    },
    "forested_slopes": {
        "name": "The Forested Slopes",
        "region": "East",
        "summary": "Pines, dense shrubbery, rock outcrops, and rising hills begin beyond the last poor dwellings.",
        "aliases": [
            "forested slopes", "forest", "hills", "pine forest", "pinewood",
            "pinewoods", "woods", "woodland",
        ],
    },
    "rugged_mainland": {
        "name": "The Rugged Mainland",
        "region": "Inland",
        "summary": "Farther inland, Mediterranean pine forest, dense shrubbery, rocks, and hilly terrain open into wilderness beyond the town.",
        "aliases": ["rugged mainland", "mainland hinterland", "hinterland", "further inland", "farther inland", "beyond the forested hills"],
    },
}


EDGES: list[tuple[str, str]] = [
    ("commercial_docks", "harbormasters_office"),
    ("commercial_docks", "central_plaza"),
    ("commercial_docks", "wealthy_quarter"),
    ("commercial_docks", "sentinel_lighthouse"),
    ("commercial_docks", "southern_outskirts"),
    ("central_plaza", "wealthy_quarter"),
    ("central_plaza", "governors_palazzo"),
    ("central_plaza", "eastern_quarters"),
    ("central_plaza", "southern_outskirts"),
    ("sentinel_lighthouse", "northern_shore"),
    ("southern_outskirts", "sandy_coast"),
    ("eastern_quarters", "forested_slopes"),
    ("forested_slopes", "rugged_mainland"),
]


def new_campaign(player_name: str, class_id: str, appearance: str = "", *, seed: int | None = None) -> dict[str, Any]:
    class_key = class_id if class_id in CLASS_PROFILES else "fighter"
    profile = copy.deepcopy(CLASS_PROFILES[class_key])
    max_hp = int(profile["max_hp"])
    return {
        "schema_version": 2,
        "campaign_id": uuid.uuid4().hex,
        "created_at": int(time.time()),
        "turn_no": 0,
        "rng_seed": int(seed if seed is not None else time.time_ns() & 0x7FFFFFFF),
        "rng_counter": 0,
        "current_location_id": "opening_threshold",
        "scene_position": None,
        "locations": copy.deepcopy(LOCATIONS),
        "edges": [list(edge) for edge in EDGES],
        "player": {
            "name": " ".join(player_name.split())[:80] or "Visitor",
            "appearance": appearance[:200] if appearance else "You decide.",
            "class_id": class_key,
            "class_label": profile["label"],
            "hp": max_hp,
            "max_hp": max_hp,
            "silver": int(profile["silver"]),
            "stats": profile["stats"],
            "inventory": profile["inventory"],
            "conditions": [],
            "companions": [],
            "known_spells": list(profile.get("known_spells", [])),
            "life_state": "active",
        },
        "campaign_status": "active",
        "last_defeat": None,
        "defeat_history": [],
        "confiscated_property": [],
        "combat": None,
        "combat_episode": None,
        "combat_history": [],
        "resource_history": [],
        "mechanics_history": [],
        "scene_objects": [],
        "book_seeds": {"loci": {}, "revealed": {}, "active_reading": None},
        "island_bank": {"schema": 3, "manifest": {}, "bindings": {}},
        "scenario_kernels": {"active": None, "records": {}, "history": []},
        "active_situation": None,
        "active_situation_history": [],
        "celestial_spheres": {"loci": {}, "history": [], "pending_press": None},
        "commerce": {"awaiting_quote": None, "pending_offer": None},
        "npcs": {},
        "npc_engine": {"last_seed_turn": -999, "seed_count": 0, "eligible_misses": 0},
        "recovery": {"last_ordinary_rest_turn": -999, "safe_lodging": None, "history": []},
        "threads": [],
        "scene_flags": {},
        "scene_pressure": None,
        "scene_pressure_history": [],
        "spatial_secretary_scheduler": {
            "last_started_turn": -999,
            "last_completed_turn": -999,
        },
        "stealth": {
            "location_id": "opening_threshold",
            "concealed": False,
            "edge": None,
            "suspicion": 0,
            "failed_chain": 0,
            "local_alert": "none",
        },
        "magic": {
            "active_effects": [],
            "failed_learning_sources": {},
            "history": [],
        },
        "evidence": [],
        "secretary": {"last_sequence": 0, "last_campaign_turn": 0},
        "campaign_recap": {"text": "", "last_sequence": 0, "last_campaign_turn": 0},
        "hidden_currents": [],
        "state_curator": {
            "last_campaign_turn": -999,
            "last_hidden_review_turn": -999,
            "last_evidence_id": 0,
            "pending_location_ids": [],
            "pending_hidden_review": False,
            "pending_evidence_review": False,
        },
        "fate": {"last_spin_at": None, "history": []},
        "pending_arrival_anchor_id": "opening_threshold",
    }


def ensure_state_defaults(state: dict[str, Any]) -> dict[str, Any]:
    """Migrate older prototype saves without invalidating a voyage."""

    state["schema_version"] = max(2, int(state.get("schema_version", 1) or 1))
    player = state.setdefault("player", {})
    state.setdefault("campaign_status", "active")
    state.setdefault("last_defeat", None)
    state.setdefault("defeat_history", [])
    state.setdefault("confiscated_property", [])
    player.setdefault(
        "life_state",
        "dead" if int(player.get("hp", 1) or 0) <= 0 and state.get("campaign_status") == "game_over" else "active",
    )
    state.setdefault("scene_position", None)
    if "known_spells" not in player:
        player["known_spells"] = (
            ["Flamma", "Revelatio", "Lucis"]
            if str(player.get("class_id") or "").casefold() == "mage"
            else []
        )
    state.setdefault(
        "magic",
        {"active_effects": [], "failed_learning_sources": {}, "history": []},
    )
    state.setdefault(
        "stealth",
        {
            "location_id": str(state.get("current_location_id") or "commercial_docks"),
            "concealed": False,
            "edge": None,
            "suspicion": 0,
            "failed_chain": 0,
            "local_alert": "none",
        },
    )
    state.setdefault("secretary", {"last_sequence": 0, "last_campaign_turn": 0})
    state.setdefault(
        "campaign_recap",
        {"text": "", "last_sequence": 0, "last_campaign_turn": 0},
    )
    state.setdefault("hidden_currents", [])
    state.setdefault("scene_pressure", None)
    state.setdefault("scene_pressure_history", [])
    spatial_scheduler = state.setdefault("spatial_secretary_scheduler", {})
    spatial_scheduler.setdefault("last_started_turn", -999)
    spatial_scheduler.setdefault("last_completed_turn", -999)
    curator = state.setdefault("state_curator", {})
    curator.setdefault("last_campaign_turn", -999)
    curator.setdefault("last_hidden_review_turn", -999)
    curator.setdefault("last_evidence_id", 0)
    curator.setdefault("pending_location_ids", [])
    curator.setdefault("pending_hidden_review", False)
    curator.setdefault("pending_evidence_review", False)
    state.setdefault("combat_history", [])
    state.setdefault("combat_episode", None)
    state.setdefault("resource_history", [])
    state.setdefault("mechanics_history", [])
    state.setdefault("scene_objects", [])
    book_seeds = state.setdefault("book_seeds", {})
    book_seeds.setdefault("loci", {})
    book_seeds.setdefault("revealed", {})
    book_seeds.setdefault("active_reading", None)
    island_bank = state.setdefault("island_bank", {})
    island_bank.setdefault("schema", 3)
    island_bank.setdefault("manifest", {})
    island_bank.setdefault("bindings", {})
    scenario_kernels = state.setdefault("scenario_kernels", {})
    scenario_kernels.setdefault("active", None)
    scenario_kernels.setdefault("records", {})
    scenario_kernels.setdefault("history", [])
    state.setdefault("active_situation", None)
    state.setdefault("active_situation_history", [])
    celestial = state.setdefault("celestial_spheres", {})
    celestial.setdefault("loci", {})
    celestial.setdefault("history", [])
    celestial.setdefault("pending_press", None)
    state.setdefault("commerce", {"awaiting_quote": None, "pending_offer": None})
    state.setdefault("npcs", {})
    npc_engine = state.setdefault("npc_engine", {})
    npc_engine.setdefault("last_seed_turn", -999)
    npc_engine.setdefault("seed_count", 0)
    npc_engine.setdefault("eligible_misses", 0)
    recovery = state.setdefault("recovery", {})
    recovery.setdefault("last_ordinary_rest_turn", -999)
    recovery.setdefault("safe_lodging", None)
    recovery.setdefault("history", [])
    combat = state.get("combat")
    if isinstance(combat, dict) and combat.get("status") == "active":
        combat.setdefault("phase", "player_action")
        combat.setdefault("pending_defense", None)
    locations = state.get("locations", {})
    site_roots: dict[str, dict[str, Any]] = {}
    for location_id, location in locations.items():
        if isinstance(location, dict):
            location.setdefault("visit_count", 0)
            if isinstance(location.get("site_memory"), dict):
                location.setdefault("site_root_id", str(location_id))
                site_roots[str(location_id)] = location
    # Safely absorb only legacy child cards whose names already match an area
    # in their parent's authoritative plan. A mere mention near a site is not
    # enough to turn a remote place into one of its rooms.
    for location_id, location in locations.items():
        if not isinstance(location, dict) or location.get("site_root_id"):
            continue
        parent_id = str(location.get("parent_hint") or "")
        parent = site_roots.get(parent_id)
        if not parent:
            continue
        name_key = " ".join(str(location.get("name") or "").casefold().split())
        matching_area = next(
            (
                area for area in parent.get("site_memory", {}).get("areas", [])
                if isinstance(area, dict)
                and " ".join(str(area.get("name") or "").casefold().split()) == name_key
            ),
            None,
        )
        if matching_area is not None:
            location["site_root_id"] = parent_id
            location["site_area_name"] = str(matching_area.get("name") or location.get("name"))
    current_id = str(state.get("current_location_id") or "")
    current = locations.get(current_id)
    if isinstance(current, dict):
        root_id = str(current.get("site_root_id") or "")
        if root_id and root_id in locations and root_id != current_id:
            state["current_location_id"] = root_id
            state["scene_position"] = {
                "id": f"scene_migrated_{current_id}",
                "label": str(current.get("site_area_name") or current.get("name") or current_id),
                "anchor_location_id": root_id,
                "summary": str(current.get("summary") or ""),
                "defining_excerpt": current.get("defining_excerpt"),
                "provisional": False,
                "set_at_turn": int(state.get("turn_no", 0) or 0),
                "site_area": True,
            }
    return state


def current_location(state: dict[str, Any]) -> dict[str, Any]:
    locations = state.get("locations") if isinstance(state.get("locations"), dict) else LOCATIONS
    location_id = str(state.get("current_location_id") or "commercial_docks")
    return locations.get(location_id) or LOCATIONS["commercial_docks"]


def inventory_summary(state: dict[str, Any]) -> str:
    inventory = state.get("player", {}).get("inventory", [])
    parts: list[str] = []
    for item in inventory:
        if not isinstance(item, dict):
            continue
        quantity = max(1, int(item.get("quantity", 1) or 1))
        name = str(item.get("name") or "Item")
        if item.get("equipped"):
            marker = "worn" if item.get("type") in {"armor", "clothing"} else "readied"
            name = f"{name} ({marker})"
        known_details = [
            " ".join(str(value).split())[:180]
            for value in item.get("known_details", [])[:2]
            if str(value).strip()
        ]
        if known_details:
            name += " {known: " + " | ".join(known_details) + "}"
        parts.append(f"{name} ×{quantity}" if quantity > 1 else name)
    from .items import load_summary

    carried = ", ".join(parts) or "nothing"
    return f"{carried} [load {load_summary(state)}]"
