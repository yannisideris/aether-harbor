from __future__ import annotations

from .spatial_scope import site_scope, has_bounded_geometry

import hashlib
import re
from collections import deque
from typing import Any

from .canon import (
    AETHER_HARBOR_LOCAL_LOCATION_IDS,
    AETHER_HARBOR_REGIONAL_LOCATION_IDS,
)

MOVE_VERBS = re.compile(
    r"\b(?:go|walk|head|travel|leave|return|climb|descend|follow|make\s+my\s+way|"
    r"sail|set\s+out|depart|cast\s+off|embark|take\s+ship|ride|run|hike|cross|"
    r"jump|leap|vault|scramble|"
    r"flee|escape|break\s+away|retreat|enter|approach|continue|move|"
    r"get\s+(?:in|into|inside))\b",
    re.IGNORECASE,
)
LOCAL_PROXIMITY_MOVE = re.compile(
    r"\b(?:approach(?:es|ed|ing)?|"
    r"(?:walk|move|step)(?:s|ed|ing)?\s+"
    r"(?:(?:quietly|silently|slowly|carefully)\s+)?"
    r"(?:towards?|closer\s+to|up\s+to))\b",
    re.I,
)
QUESTION_OR_HYPOTHETICAL = re.compile(
    r"(?:\?|\b(?:ask|wonder|whether|what\s+if|if\s+i|can\s+i|could\s+i|would\s+i|"
    r"might\s+i|should\s+i|tell\s+me|describe)\b)",
    re.IGNORECASE,
)
CAPABILITY_QUESTION = re.compile(
    r"^\s*(?:(?:can|could|would|might|should)\s+(?:i|we)\b|"
    r"how\s+(?:can|could|would|might|should)\s+(?:i|we)\b|"
    r"am\s+i\s+able\s+to\b|are\s+we\s+able\s+to\b|"
    r"is\s+it\s+possible\s+for\s+(?:me|us)\s+to\b|"
    r"is\s+there\s+(?:any\s+)?(?:way|route)\s+(?:(?:that\s+)?(?:i|we)\s+(?:can|could)\s+|for\s+(?:me|us)\s+to\s+)|"
    r"what\s+would\s+it\s+take\s+for\s+(?:me|us)\s+to\b)",
    re.I,
)
PASSAGE_TRANSACTION = re.compile(
    r"\b(?:hire|rent|charter|book\s+passage|buy\s+passage|pay\s+for\s+passage)\b",
    re.IGNORECASE,
)
ACCEPT_OFFER = re.compile(
    r"\b(?:yes|accept|agreed|deal|pay|book\s+it|take\s+it|i'll\s+take|i\s+will\s+take|done)\b",
    re.IGNORECASE,
)
DECLINE_OFFER = re.compile(r"\b(?:no|decline|refuse|cancel|never\s+mind|too\s+much)\b", re.I)
SCENE_POSITION = re.compile(
    r"\b(?:roof|rooftop|ledge|balcony|room|chamber|corridor|hallway|stairs?|"
    r"staircase|stairwell|landing|deck|hold|rigging|mast|crow'?s\s+nest|loft|attic|cellar|"
    r"basement|courtyard|court|alley|passage|gallery|entrance|doorway|wing|stall|booth|"
    r"windows?|gutter|eaves?|wall|flank|"
    r"foyer|vestibule|kitchen|pantry|study|bedroom|parlour|salon|office|library|"
    r"workshop|storeroom|warehouse|sanctuary|crypt|hall|junction|door|gate|hatch|arch|"
    r"interior|terrace|foyer|reception)\b",
    re.I,
)
SITE_ONLY_POSITION = re.compile(r"\bquarters?\b", re.I)
RELATIVE_NEW_POSITION = re.compile(
    r"\b(?:another|next|adjacent|neighbou?ring|second|different|farther)\b",
    re.I,
)
EXPLORE_WITHIN = re.compile(
    r"\b(?:explore|look\s+for|search\s+for|find\s+(?:a|an|the|some)?|"
    r"continue|go\s+(?:deeper|farther|further|straight)|walk\b[^.!?]{0,80}\buntil)\b",
    re.I,
)
SITE_EXIT_CUE = re.compile(
    r"\b(?:leave|exit|depart|step\s+out|walk\s+out|move\s+out|go\s+out|get\s+out|"
    r"head\s+out|back\s+outside|outside)\b",
    re.I,
)
ROUTE_SPAN_EXIT = re.compile(
    r"(?:\b(?:all\s+the\s+way|straight|directly|the\s+way\s+i\s+came|"
    r"back\s+the\s+way)\b.{0,100}\b(?:out|outside|exit|leave)\b|"
    r"\b(?:out|outside|exit|leave)\b.{0,100}\b(?:all\s+the\s+way|"
    r"the\s+way\s+i\s+came|back\s+the\s+way)\b)",
    re.I,
)
_SITE_EGRESS_AREA = re.compile(
    r"\b(?:window|door|gate|entrance|entry|foyer|vestibule|portico|terrace|"
    r"courtyard|yard|garden|balcony|landing|threshold|hall)\b",
    re.I,
)
_SITE_CONNECTOR_POSITION = re.compile(
    r"\b(?:door|doorway|window|gate|hatch|arch|threshold)\b",
    re.I,
)
_BARRIER_KEYWORDS = re.compile(r"\b(?:locked|padlocked|barred|chained|bolted)\b", re.I)
_UNLOCKED_KEYWORDS = re.compile(r"\b(?:unlocked|unbarred)\b", re.I)
_BREACH_ACTION_KEYWORDS = re.compile(
    r"\b(?:pick\s+(?:the\s+)?lock|(?:force|break|unlock|smash)\s+"
    r"(?:(?:open|through|down)\s+)?(?:(?:the|a|this|that|locked|barred|chained|bolted|iron|wooden)\s+)*"
    r"(?:door|gate|hatch|lock|barrier)\b)", re.I)


def _is_locked_barrier(edge: dict[str, Any]) -> bool:
    if not isinstance(edge, dict):
        return False
    if edge.get("unlocked") is True or str(edge.get("status") or "").lower() in {"unlocked", "open"}:
        return False
    via = str(edge.get("via") or "")
    if _UNLOCKED_KEYWORDS.search(via) and not _BARRIER_KEYWORDS.search(via):
        return False
    return bool(_BARRIER_KEYWORDS.search(via))
_INTERIOR_SUFFIX = re.compile(
    r"\s+(?:interior|inside|main\s+interior|public\s+interior)$",
    re.I,
)
_INTERIOR_EVIDENCE = re.compile(
    r"\b(?:inside|interior|indoors|room|hall|foyer|vestibule|within\s+the\s+building)\b",
    re.I,
)
_AETHER_VISIBLE_TRAVEL = re.compile(
    r"(?:\b(?:within\s+sight|visible\s+from|overlooking|just\s+off|just\s+outside|nearby)\b"
    r"[^.!?]{0,80}\bAether\s+Harbou?r\b|\bAether\s+Harbou?r\b"
    r"[^.!?]{0,80}\b(?:within\s+sight|visible|on\s+the\s+horizon|overlooking)\b)",
    re.I,
)
_AETHER_DISTANT_TRAVEL = re.compile(
    r"\b(?:island|isle|islet|cay|archipelago|sail|voyage|embark|cast\s+off|"
    r"take\s+(?:a\s+)?ship|book\s+passage|across\s+the\s+sea|overseas)\b",
    re.I,
)


def _normalized(text: str) -> str:
    return re.sub(r"[^a-z0-9' ]+", " ", text.casefold()).strip()


_PLACE_MATCH_STOP = {
    "the", "a", "an", "of", "to", "into", "inside", "through", "from", "at",
    "main", "primary", "secondary", "nearby", "new", "other", "another",
    "room", "hall", "area", "space", "place",
}


def _place_tokens(value: str) -> set[str]:
    return {
        token
        for token in _normalized(value).split()
        if len(token) >= 4 and token not in _PLACE_MATCH_STOP
    }


def _question_blocks_movement(text: str) -> bool:
    """Reject a question-only movement request, but allow a committed clause after it.

    The old blanket ``?`` veto swallowed inputs such as
    ``Where am I now? Let's enter the room``.  Capability questions are still
    handled separately by ``is_capability_question``; here we only protect
    genuinely hypothetical/question-only phrasing.
    """

    if not QUESTION_OR_HYPOTHETICAL.search(text):
        return False

    # Restore V9's conservative question authority, with only one surgical
    # exception: a clause explicitly owned by I/we/let's may already commit
    # movement before a later hedge or question. A bare movement word is not
    # enough. This keeps ``I enter as if I live here`` and ``Where am I? Let's
    # enter`` while blocking the transcript regression ``Are the islands a
    # good place to travel to?`` even if the semantic model supplies the bad
    # destination ``Travel To``.
    clauses = [part.strip() for part in re.findall(r"[^.!?;]+[.!?;]?", text) if part.strip()]
    for clause in clauses:
        clean = clause.lstrip(" \t\"'â€œâ€â€˜â€™")
        owner = re.match(
            r"(?:(?:i|we)\s+(?:(?:will|shall|now|then|quietly|silently|carefully|"
            r"quickly|slowly|directly|back)\s+){0,2}|let(?:'s|\s+us)\s+)",
            clean,
            re.I,
        )
        if owner is None:
            continue
        movement = MOVE_VERBS.match(clean, owner.end())
        if movement is None:
            continue
        hedge = QUESTION_OR_HYPOTHETICAL.search(clause)
        if hedge is None or movement.start() < hedge.start():
            return False
    return True


def _has_more_specific_scene_position(
    state: dict[str, Any], site_root: str, destination_name: str
) -> bool:
    """True when a semantic destination names a part beyond the root site.

    A destination such as "The Harbormaster's Office" must remain the site
    itself, while "Harbormaster's Office Second-Story Window" is a real local
    endpoint. Comparing matched position nouns avoids treating the word
    "office" in the canonical building name as a new room.
    """

    root_name = str(state.get("locations", {}).get(site_root, {}).get("name") or "")
    destination_parts = {match.casefold() for match in SCENE_POSITION.findall(destination_name)}
    root_parts = {match.casefold() for match in SCENE_POSITION.findall(root_name)}
    return bool(destination_parts - root_parts)


def is_capability_question(text: str) -> bool:
    """True when the player asks feasibility without committing the action."""

    return bool(CAPABILITY_QUESTION.search(text))


def _adjacency(state: dict[str, Any]) -> dict[str, set[str]]:
    graph: dict[str, set[str]] = {}
    for raw_edge in state.get("edges", []):
        if not isinstance(raw_edge, (list, tuple)) or len(raw_edge) != 2:
            continue
        left, right = str(raw_edge[0]), str(raw_edge[1])
        graph.setdefault(left, set()).add(right)
        graph.setdefault(right, set()).add(left)
    return graph


def shortest_route(state: dict[str, Any], origin: str, destination: str) -> list[str] | None:
    if origin == destination:
        return [origin]
    graph = _adjacency(state)
    queue: deque[list[str]] = deque([[origin]])
    visited = {origin}
    while queue:
        path = queue.popleft()
        for neighbor in graph.get(path[-1], set()):
            if neighbor in visited:
                continue
            next_path = [*path, neighbor]
            if neighbor == destination:
                return next_path
            visited.add(neighbor)
            queue.append(next_path)
    return None


def resolve_destination(state: dict[str, Any], text: str) -> str | None:
    source = _normalized(text)
    matches: list[tuple[int, str]] = []
    for location_id, location in state.get("locations", {}).items():
        aliases = [str(location.get("name") or ""), *location.get("aliases", [])]
        for alias in aliases:
            needle = _normalized(alias)
            if needle and re.search(rf"\b{re.escape(needle)}\b", source):
                matches.append((len(needle), str(location_id)))
    if not matches:
        return None
    matches.sort(reverse=True)
    best_length = matches[0][0]
    best = {location_id for length, location_id in matches if length == best_length}
    return next(iter(best)) if len(best) == 1 else None


def _resolve_semantic_destination(state: dict[str, Any], text: str) -> str | None:
    """Ground a close semantic atlas paraphrase without reading route prose.

    A model endpoint such as ``Eastern Residential Quarter`` should match the
    atlas's ``Eastern Quarters``.  Requiring the same final place-kind token
    prevents a more specific endpoint such as ``Eastern Quarter Tenement``
    from collapsing back into the broad district.
    """

    def tokens(value: str) -> list[str]:
        result: list[str] = []
        for token in _normalized(value).split():
            if len(token) < 4 or token in _PLACE_MATCH_STOP:
                continue
            result.append(
                token[:-1]
                if len(token) > 4 and token.endswith("s") and not token.endswith("ss")
                else token
            )
        return result

    source = tokens(text)
    if len(source) < 2:
        return None
    source_set = set(source)
    matches: list[tuple[int, int, str]] = []
    for location_id, location in state.get("locations", {}).items():
        for alias in [str(location.get("name") or ""), *location.get("aliases", [])]:
            candidate = tokens(str(alias))
            if (
                len(candidate) >= 2
                and candidate[-1] == source[-1]
                and set(candidate).issubset(source_set)
            ):
                matches.append((len(set(candidate)), len(" ".join(candidate)), str(location_id)))
    if not matches:
        return None
    matches.sort(reverse=True)
    best_score = matches[0][:2]
    best = {location_id for count, length, location_id in matches if (count, length) == best_score}
    return next(iter(best)) if len(best) == 1 else None


def _display_name(raw: str) -> str:
    clean = " ".join(raw.strip(" .,!?:;\"'").split())
    clean = re.sub(r"^(?:the\s+)", "", clean, flags=re.I)
    if not clean:
        return ""
    if clean == clean.lower():
        clean = clean.title()
    if re.match(r"^(?:island|isle|harbor|harbour|cove|bay|forest|road|street|alley|tower|house|garden|shore|coast|cave|temple|chapel|palace|market|village|town)\b", clean, re.I):
        clean = "The " + clean
    return clean[:96]


def _emergent_destination(text: str) -> str | None:
    """Extract only an explicit free-text destination; never infer a route."""

    # Prefer the final explicit destination phrase. This lets text such as
    # "through the wealthy quarter toward the plaza" or "beyond the lighthouse
    # to the coves" resolve to the intended endpoint rather than an earlier
    # landmark mentioned as part of the route.
    matches = list(
        re.finditer(
            r"\b(?:to|towards?|into|inside|through|onto|up\s+to|down\s+to|for)\s+"
            r"(?:the\s+)?([^.!?;]{3,110}?)"
            r"(?=\s+\b(?:to|towards?|into|inside|through|onto|up\s+to|down\s+to|for)\b\s+|[.!?;]|$)",
            text,
            re.I,
        )
    )
    match = matches[-1] if matches else re.search(
        r"\b(?:enter|approach)\s+(?:the\s+)?([^.!?;]{3,110})",
        text,
        re.I,
    )
    if not match:
        return None
    raw = re.split(
        r"(?:,\s*)?\b(?:and\s+then|then|so\s+that|because|while|where\s+i)\b",
        match.group(1),
        maxsplit=1,
        flags=re.I,
    )[0]
    # "I attempt to flee into the lanes" first matches the infinitive's
    # "to". Remove that leading action phrase so the place itself becomes the
    # anchor rather than "Flee Into The Lanes".
    raw = re.sub(
        r"^(?:go|walk|head|travel|leave|return|climb|descend|follow|sail|ride|run|"
        r"hike|cross|jump|leap|vault|scramble|flee|escape|retreat|enter|approach|move)\s+"
        r"(?:to|towards?|into|inside|through|onto|up|down|over|across|up\s+to|down\s+to)\s+(?:(?:the|a|an)\s+)?",
        "",
        raw,
        flags=re.I,
    )
    raw = re.sub(r"\b(?:carefully|quickly|quietly|slowly|at\s+once|now)\b\s*$", "", raw, flags=re.I)
    folded = _normalized(raw)
    if folded in {"him", "her", "them", "it", "there", "somewhere", "outside", "inside", "away", "home"}:
        return None
    if len(folded.split()) > 16:
        return None
    return _display_name(raw)


def _emergent_id(name: str) -> str:
    digest = hashlib.sha1(_normalized(name).encode("utf-8")).hexdigest()[:12]
    return f"emergent_{digest}"


def _aether_scope_of(state: dict[str, Any], location_id: str) -> str:
    if location_id in AETHER_HARBOR_LOCAL_LOCATION_IDS:
        return "local"
    if location_id in AETHER_HARBOR_REGIONAL_LOCATION_IDS:
        return "regional"
    location = state.get("locations", {}).get(location_id, {})
    stored = str(location.get("aether_geography_scope") or "")
    return stored if stored in {"local", "visible", "regional", "distant"} else "distant"


def active_site_root_id(state: dict[str, Any], location_id: str | None = None) -> str:
    """Return the stable bounded-site anchor for a local position or absorbed child."""

    locations = state.get("locations", {}) if isinstance(state.get("locations"), dict) else {}
    cursor = str(location_id or state.get("current_location_id") or "commercial_docks")
    seen: set[str] = set()
    while cursor and cursor not in seen:
        seen.add(cursor)
        location = locations.get(cursor)
        if not isinstance(location, dict):
            break
        root = str(location.get("site_root_id") or "")
        if root and root in locations and root != cursor:
            cursor = root
            continue
        break
    return cursor


def _location_belongs_to_site(state: dict[str, Any], location_id: str, root_id: str) -> bool:
    """Follow explicit site lineage without turning every mentioned place into a room."""

    locations = state.get("locations", {}) if isinstance(state.get("locations"), dict) else {}
    cursor = str(location_id or "")
    seen: set[str] = set()
    for _ in range(8):
        if not cursor or cursor in seen:
            return False
        if cursor == root_id:
            return True
        seen.add(cursor)
        location = locations.get(cursor)
        if not isinstance(location, dict):
            return False
        explicit = str(location.get("site_root_id") or "")
        if not explicit:
            return False
        cursor = explicit
    return False


def _same_local_position(
    current: dict[str, Any] | None,
    destination_name: str,
    anchor: dict[str, Any],
    anchor_id: str,
) -> bool:
    """Treat an already-established interior and its generic suffix as one place."""

    def _strip_the(value: Any) -> str:
        return re.sub(r"^the\s+", "", _normalized(str(value or ""))).strip()

    destination = _normalized(destination_name)
    destination_stripped = _strip_the(destination_name)
    anchor_names = {
        _normalized(value)
        for value in [anchor.get("name"), *(anchor.get("aliases") or [])]
        if str(value or "").strip()
    }
    anchor_names_stripped = {
        _strip_the(value)
        for value in [anchor.get("name"), *(anchor.get("aliases") or [])]
        if str(value or "").strip()
    }
    destination_base = _normalized(_INTERIOR_SUFFIX.sub("", destination_name).strip())
    if not isinstance(current, dict) or str(current.get("anchor_location_id") or "") != anchor_id:
        memory = anchor.get("site_memory") if isinstance(anchor.get("site_memory"), dict) else {}
        current_pos = _strip_the(memory.get("current_position"))
        if not current_pos or current_pos in anchor_names_stripped:
            return bool(
                destination_stripped
                and destination_stripped in anchor_names_stripped
                and destination == destination_base
            )
        return bool(destination_stripped and destination_stripped == current_pos)
    current_name = _normalized(str(current.get("label") or ""))
    if current_name and (current_name == destination or _strip_the(current_name) == destination_stripped):
        return True
    current_base = _normalized(_INTERIOR_SUFFIX.sub("", str(current.get("label") or "")).strip())
    describes_anchor_interior = bool(
        (destination_base in anchor_names and destination != destination_base)
        or (current_base in anchor_names and current_name != current_base)
        or (destination in anchor_names and current_base in anchor_names)
    )
    evidence = " ".join(
        str(current.get(key) or "")
        for key in ("spatial_relation", "summary", "defining_excerpt")
    )[:1800]
    already_inside = (
        str(current.get("spatial_relation") or "") == "interior"
        or bool(_INTERIOR_EVIDENCE.search(evidence))
    )
    return bool(describes_anchor_interior and already_inside)


def _site_area(state: dict[str, Any], root_id: str, text: str) -> dict[str, Any] | None:
    root = state.get("locations", {}).get(root_id, {})
    memory = root.get("site_memory") if isinstance(root, dict) else None
    if not isinstance(memory, dict):
        return None
    source = _normalized(text)
    if site_scope(root) == "open":
        matches = [a for a in memory.get("areas", []) if isinstance(a, dict)
                   and source in {_normalized(str(n)) for n in [a.get("name"), *(a.get("aliases") or [])] if n}]
        return matches[0] if len(matches) == 1 else None
    if memory.get("plan_lock"):
        def name_key(value):
            value = str(value or "").casefold().replace("’", "'").replace("‘", "'")
            return " ".join(re.sub(r"[^a-z0-9]+", " ", value).split())

        areas = [a for a in memory.get("areas", []) if isinstance(a, dict)]
        # Canonical names precede aliases, including an exact canonical name
        # which another room happens to use as an alias.
        exact = [a for a in areas if str(a.get("name") or "") == text]
        if exact:
            return exact[0] if len(exact) == 1 else None

        def matches(label):
            canonical = [a for a in areas if name_key(a.get("name")) == label]
            if canonical:
                return canonical
            return [a for a in areas if label in {name_key(v) for v in a.get("aliases", [])}]

        found = matches(name_key(text))
        if found:
            return found[0] if len(found) == 1 else None
        owner_key = lambda value: re.sub(r"^the\s+", "", name_key(value))
        owners = {owner_key(n) for n in [root.get("name"), memory.get("site_name"), *(root.get("aliases") or [])] if n}
        qualified = re.split(r"\s+(?:inside|within|in|of)\s+|\s*,\s*|\s*\(\s*", text, maxsplit=1, flags=re.I)
        if len(qualified) == 2 and owner_key(qualified[1].rstrip('). ')) in owners:
            found = matches(name_key(qualified[0]))
            return found[0] if len(found) == 1 else None
        return None
    matches: list[tuple[int, dict[str, Any]]] = []
    for area in memory.get("areas", []):
        if not isinstance(area, dict):
            continue
        names = [str(area.get("name") or ""), *list(area.get("aliases") or [])]
        for name in names:
            needle = _normalized(name)
            if needle and re.search(rf"\b{re.escape(needle)}\b", source):
                matches.append((len(needle), area))
    if not matches:
        # A semantic judge may call an established area by a close paraphrase:
        # "Primary Living Quarters" vs the stored "Main Living Quarters".
        # Within an already-bounded site, two distinctive shared tokens are a
        # safer signal than promoting the paraphrase to a new atlas location.
        wanted = _place_tokens(text)
        fuzzy: list[tuple[int, int, dict[str, Any]]] = []
        if wanted:
            for area in memory.get("areas", []):
                if not isinstance(area, dict):
                    continue
                candidates = [str(area.get("name") or ""), *list(area.get("aliases") or [])]
                best_overlap = 0
                best_size = 999
                for candidate in candidates:
                    candidate_tokens = _place_tokens(candidate)
                    overlap = len(wanted & candidate_tokens)
                    if overlap > best_overlap:
                        best_overlap = overlap
                        best_size = len(candidate_tokens)
                if best_overlap >= 2:
                    fuzzy.append((best_overlap, -best_size, area))
        if not fuzzy:
            return None
        fuzzy.sort(key=lambda item: (item[0], item[1]), reverse=True)
        return fuzzy[0][2]
    matches.sort(key=lambda item: item[0], reverse=True)
    return matches[0][1]


def _site_position_event(
    state: dict[str, Any],
    root_id: str,
    destination_name: str,
    *,
    source_text: str,
    area: dict[str, Any] | None = None,
    absorbed_location_id: str | None = None,
    roll_success: bool | None = None,
) -> dict[str, Any]:
    """Move within one persistent site while keeping the atlas anchor stable."""

    locations = state.get("locations", {})
    root = locations.get(root_id, {})
    memory = root.get("site_memory") if isinstance(root.get("site_memory"), dict) else {}
    if memory.get("plan_lock"):
        planned = area or _site_area(state, root_id, destination_name)
        if planned is None:
            return {"type": "local_movement", "committed": False,
                "reason": "Endpoint is not in the sealed site plan; resolve the intended existing area before moving.",
                "to_name": destination_name, "site_root_id": root_id}
        area = planned
        destination_name = str(planned["name"])
    root["site_root_id"] = root_id
    if absorbed_location_id and absorbed_location_id in locations:
        absorbed = locations[absorbed_location_id]
        absorbed["site_root_id"] = root_id
        absorbed["site_area_name"] = destination_name
    current = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    same_position = _same_local_position(current, destination_name, root, root_id)
    if same_position and not RELATIVE_NEW_POSITION.search(source_text):
        if EXPLORE_WITHIN.search(source_text):
            return _site_exploration_event(state, root_id)
        return {
            "type": "local_movement",
            "committed": False,
            "location_id": root_id,
            "location_name": str(root.get("name") or root_id),
            "to_name": destination_name,
        }

    entering_from_exterior = bool(
        current
        and str(current.get("exterior_of_site_id") or "") == root_id
        and str(current.get("anchor_location_id") or "") == str(state.get("current_location_id") or "")
    )
    previous_name = (
        str(current.get("label") or root.get("name") or root_id)
        if current and str(current.get("anchor_location_id") or "") == root_id
        else str(memory.get("current_position") or root.get("name") or root_id)
    )
    if entering_from_exterior:
        previous_name = str(current.get("label") or "")
    planned_path = None
    if memory.get("plan_lock"):
        from .sealed_layout import planned_route
        from_area = previous_name
        if not _site_area(state, root_id, from_area):
            from_area = str(memory["plan_lock"].get("entry_area") or "")
        if entering_from_exterior:
            # A previous interior visit is not the source of a fresh entry.
            previous_name = from_area
        # Prefer an existing open route over a shorter locked route.
        planned_path = planned_route(memory, from_area, destination_name,
                                     edge_allowed=lambda edge: not _is_locked_barrier(edge))
        if planned_path is None:
            planned_path = planned_route(memory, from_area, destination_name)
        if planned_path is None:
            return {"type": "local_movement", "committed": False,
                "reason": "No route in the sealed graph; resolve the current entry before moving.",
                "to_name": destination_name, "site_root_id": root_id}
        barriers = [edge for edge in planned_path if _is_locked_barrier(edge)]
        can_breach = (len(barriers) == 1 and roll_success is True
                      and _BREACH_ACTION_KEYWORDS.search(source_text))
        blocked_edge = barriers[0] if barriers and not can_breach else None
        if blocked_edge is not None:
            via_desc = str(blocked_edge.get("via") or "a locked barrier")
            return {
                "type": "local_movement",
                "committed": False,
                "reason": f"Passage via '{via_desc}' is locked or barred; bypass or unlock the barrier before moving.",
                "to_name": destination_name,
                "site_root_id": root_id,
                "planned_route": planned_path,
                "blocked_via": via_desc,
            }
        if can_breach:
            edge = barriers[0]
            # Match both endpoints AND the passage; parallel doors stay distinct.
            def identity(conn):
                return (tuple(sorted((_normalized(conn.get("from")), _normalized(conn.get("to"))))),
                        _normalized(conn.get("via")))
            for conn in memory.get("connections", []):
                if identity(conn) == identity(edge):
                    conn.update(unlocked=True, status="unlocked")
            edge.update(unlocked=True, status="unlocked")
    label = destination_name
    if not memory.get("plan_lock") and same_position and RELATIVE_NEW_POSITION.search(source_text) and not RELATIVE_NEW_POSITION.search(label):
        label = f"Adjacent {destination_name}"
    summary = str((area or {}).get("physical_character") or "")
    excerpt = str((area or {}).get("defining_excerpt") or "") or None
    observed = bool(area and area.get("status") == "observed")
    connector_only = bool(area is None and _SITE_CONNECTOR_POSITION.search(label))
    if area is not None and site_scope(root) == "open":
        # Established open-area revisits remain current even when the map is full.
        memory["current_position"] = str(area["name"])
    if area is not None and not observed:
        # Keep the area private through the first-reveal prompt, then commit it
        # after that narration completes. This also prevents a successfully
        # visited latent room from remaining latent forever.
        state["pending_observed_site_area"] = {
            "site_root_id": root_id,
            "name": str(area.get("name") or destination_name),
        }
    digest = hashlib.sha1(f"{root_id}:{_normalized(label)}".encode("utf-8")).hexdigest()[:10]
    state["current_location_id"] = root_id
    state["scene_position"] = {
        "id": f"scene_{digest}",
        "label": label,
        "anchor_location_id": root_id,
        "summary": summary,
        "defining_excerpt": excerpt,
        "provisional": not observed,
        "set_at_turn": int(state.get("turn_no", 0) or 0),
        "site_area": not connector_only,
        "site_connector": connector_only,
    }
    # The connection itself is load-bearing continuity and must not wait for
    # the background architect.  Its stable description can be enriched after
    # narration, but this from/to pair is committed with the movement.
    state["pending_site_transition"] = {
        "site_root_id": root_id,
        "from_name": previous_name,
        "to_name": label,
        "set_at_turn": int(state.get("turn_no", 0) or 0),
        "connector_only": connector_only,
    }
    return {
        "type": "local_movement",
        "committed": True,
        "from_id": root_id,
        "from_name": previous_name,
        "to_id": root_id,
        "to_name": label,
        "anchor_name": str(root.get("name") or root_id),
        "site_root_id": root_id,
        "planned_route": planned_path,
        "emergent": not observed,
    }


def commit_pending_site_area_observation(state: dict[str, Any]) -> bool:
    pending = state.pop("pending_observed_site_area", None)
    if not isinstance(pending, dict):
        return False
    root_id = str(pending.get("site_root_id") or "")
    wanted = _normalized(str(pending.get("name") or ""))
    root = state.get("locations", {}).get(root_id)
    memory = root.get("site_memory") if isinstance(root, dict) else None
    if not isinstance(memory, dict) or not wanted:
        return False
    for area in memory.get("areas", []):
        if isinstance(area, dict) and _normalized(str(area.get("name") or "")) == wanted:
            area["status"] = "observed"
            area["observed_at_turn"] = int(state.get("turn_no", 0) or 0)
            memory["current_position"] = str(area.get("name") or "")
            return True
    return False


def commit_pending_site_transition(state: dict[str, Any], narration: str) -> bool:
    """Synchronously append one observed site node/edge after its narration.

    The Spatial Secretary may later fill empty descriptive fields or promote a
    pre-planned latent connector, but a slow or missed model call can no longer
    erase the route the player just traversed.
    """

    pending = state.pop("pending_site_transition", None)
    if not isinstance(pending, dict):
        return False
    root_id = str(pending.get("site_root_id") or "")
    from_name = " ".join(str(pending.get("from_name") or "").split())[:100]
    to_name = " ".join(str(pending.get("to_name") or "").split())[:100]
    connector_only = pending.get("connector_only") is True
    if not root_id or not to_name or to_name.casefold().startswith("further within "):
        return False
    root = state.get("locations", {}).get(root_id)
    memory = root.get("site_memory") if isinstance(root, dict) else None
    if not isinstance(memory, dict):
        return False

    def key(value: Any) -> str:
        return _normalized(str(value or ""))

    areas = [row for row in memory.setdefault("areas", []) if isinstance(row, dict)]
    by_name = {key(row.get("name")): row for row in areas if key(row.get("name"))}
    if memory.get("plan_lock"):
        destination = by_name.get(key(to_name))
        if destination is None:
            return False
        destination["status"] = "observed"
        destination["observed_at_turn"] = int(state.get("turn_no", 0) or 0)
        for edge in memory.get("connections", []):
            if {key(edge.get("from")), key(edge.get("to"))} == {key(from_name), key(to_name)}:
                edge["status"] = "observed"
        memory["current_position"] = destination["name"]
        return True
    summary = _concise_scene_summary(narration, label=to_name, max_chars=260)
    source_area = by_name.get(key(from_name))
    canonical_from = str(source_area.get("name") or from_name) if source_area else from_name
    site_name = str(memory.get("site_name") or root.get("name") or "")
    if key(canonical_from) == key(site_name):
        canonical_from = ""

    if connector_only:
        if canonical_from:
            state["last_site_connector"] = {
                "site_root_id": root_id,
                "from_name": canonical_from,
                "connector_name": to_name,
                "set_at_turn": int(state.get("turn_no", 0) or 0),
            }
            connections = [
                row for row in memory.setdefault("connections", []) if isinstance(row, dict)
            ]
            unresolved = f"Unresolved beyond {to_name}"
            if not any(
                key(row.get("from")) == key(canonical_from)
                and key(row.get("to")) == key(unresolved)
                for row in connections
            ):
                connections.append(
                    {
                        "from": canonical_from,
                        "to": unresolved,
                        "via": to_name,
                        "status": "observed",
                    }
                )
            memory["connections"] = connections
        memory["current_position"] = to_name
        position = state.get("scene_position")
        if isinstance(position, dict) and key(position.get("label")) == key(to_name):
            if summary and not str(position.get("summary") or "").strip():
                position["summary"] = summary
                position["summary_source"] = "narration"
            if narration and not position.get("defining_excerpt"):
                position["defining_excerpt"] = str(narration)[:1400]
            position["provisional"] = False
            position["site_area"] = False
            position["site_connector"] = True
        return True

    destination = by_name.get(key(to_name))
    if destination is None:
        destination = {
            "name": to_name,
            "placement": "",
            "physical_character": summary,
            "status": "observed",
            "observed_at_turn": int(state.get("turn_no", 0) or 0),
            "defining_excerpt": str(narration or "")[:1400] or None,
        }
        areas.append(destination)
        memory["areas"] = areas
    else:
        destination["status"] = "observed"
        destination["observed_at_turn"] = int(state.get("turn_no", 0) or 0)
        if summary and not str(destination.get("physical_character") or "").strip():
            destination["physical_character"] = summary
        if narration and not destination.get("defining_excerpt"):
            destination["defining_excerpt"] = str(narration)[:1400]

    canonical_to = str(destination.get("name") or to_name)
    canonical_from = from_name
    source_area = by_name.get(key(from_name))
    if source_area is not None:
        canonical_from = str(source_area.get("name") or from_name)
    elif key(from_name) == key(site_name):
        canonical_from = ""

    via = "Directly observed route"
    last_connector = state.get("last_site_connector")
    if (
        not source_area
        and isinstance(last_connector, dict)
        and str(last_connector.get("site_root_id") or "") == root_id
        and key(last_connector.get("connector_name")) == key(from_name)
    ):
        canonical_from = str(last_connector.get("from_name") or canonical_from)
        via = str(last_connector.get("connector_name") or via)
        state.pop("last_site_connector", None)

    if canonical_from and key(canonical_from) != key(canonical_to):
        connections = [
            row for row in memory.setdefault("connections", []) if isinstance(row, dict)
        ]
        pair = {key(canonical_from), key(canonical_to)}
        existing = next(
            (
                row for row in connections
                if {key(row.get("from")), key(row.get("to"))} == pair
            ),
            None,
        )
        if existing is None:
            connections = [
                row for row in connections
                if not (
                    key(row.get("from")) == key(canonical_from)
                    and key(row.get("to")) == key(f"Unresolved beyond {via}")
                )
            ]
            connections.append(
                {
                    "from": canonical_from,
                    "to": canonical_to,
                    "via": via,
                    "status": "observed",
                }
            )
        else:
            existing["status"] = "observed"
        memory["connections"] = connections

    memory["current_position"] = canonical_to
    position = state.get("scene_position")
    if (
        isinstance(position, dict)
        and str(position.get("anchor_location_id") or "") == root_id
        and key(position.get("label")) == key(to_name)
    ):
        if summary and not str(position.get("summary") or "").strip():
            position["summary"] = summary
            position["summary_source"] = "narration"
        if narration and not position.get("defining_excerpt"):
            position["defining_excerpt"] = str(narration)[:1400]
        position["provisional"] = False
        position["site_area"] = True
    return True


def _site_exploration_event(state: dict[str, Any], root_id: str) -> dict[str, Any]:
    """Commit open-ended movement, letting the post-narration survey name its endpoint."""

    root = state.get("locations", {}).get(root_id, {})
    current = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    from_name = (
        str(current.get("label") or root.get("name") or root_id)
        if current and str(current.get("anchor_location_id") or "") == root_id
        else str(root.get("name") or root_id)
    )
    state["current_location_id"] = root_id
    return {
        "type": "local_movement",
        "committed": True,
        "from_id": root_id,
        "from_name": from_name,
        "to_id": root_id,
        "to_name": f"Further within {str(root.get('name') or root_id)}",
        "anchor_name": str(root.get("name") or root_id),
        "site_root_id": root_id,
        "awaiting_spatial_position": True,
        "emergent": True,
    }


def _new_place_aether_scope(
    state: dict[str, Any],
    *,
    origin: str,
    destination_name: str,
    source_text: str,
) -> str:
    """Give one generated place a lightweight inherited geography scope."""

    evidence = f"{destination_name} {source_text}"
    if _AETHER_VISIBLE_TRAVEL.search(evidence):
        return "visible"
    if _AETHER_DISTANT_TRAVEL.search(evidence):
        return "distant"
    return _aether_scope_of(state, origin)


def _scene_position_event(
    state: dict[str, Any],
    destination_name: str,
    *,
    source_text: str,
    anchor_id: str | None = None,
) -> dict[str, Any]:
    """Track a local vantage without promoting it to a global atlas node.

    ``anchor_id`` lets an exit from a bounded site zoom back out to a broader
    atlas anchor while retaining a vivid immediate exterior label such as
    ``Sunny Street``.  The micro-place is therefore real in the scene without
    becoming a second persistent site root.
    """

    anchor_id = str(anchor_id or active_site_root_id(state))
    state["current_location_id"] = anchor_id
    anchor = state.get("locations", {}).get(anchor_id, {})
    current = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    same_position = _same_local_position(current, destination_name, anchor, anchor_id)
    if same_position and not RELATIVE_NEW_POSITION.search(source_text):
        return {
            "type": "local_movement",
            "committed": False,
            "location_id": anchor_id,
            "location_name": str(anchor.get("name") or anchor_id),
            "to_name": destination_name,
        }

    previous_name = (
        str(current.get("label") or "")
        if current and str(current.get("anchor_location_id") or "") == anchor_id
        else str(anchor.get("name") or anchor_id)
    )
    label = destination_name
    if same_position and RELATIVE_NEW_POSITION.search(source_text) and not RELATIVE_NEW_POSITION.search(label):
        label = f"Adjacent {destination_name}"
    turn_no = int(state.get("turn_no", 0) or 0)
    digest = hashlib.sha1(f"{anchor_id}:{turn_no}:{label}".encode("utf-8")).hexdigest()[:10]
    state["scene_position"] = {
        "id": f"scene_{digest}",
        "label": label,
        "anchor_location_id": anchor_id,
        "summary": "",
        "defining_excerpt": None,
        "provisional": True,
        "set_at_turn": turn_no,
    }
    return {
        "type": "local_movement",
        "committed": True,
        "from_id": anchor_id,
        "from_name": previous_name,
        "to_id": anchor_id,
        "to_name": label,
        "anchor_name": str(anchor.get("name") or anchor_id),
        "emergent": True,
    }


def _broader_exterior_anchor(state: dict[str, Any], site_root: str) -> str:
    """Choose a stable broader anchor when play exits one bounded site.

    Prefer a canonical ancestor (district/outskirts/etc.) when the site's
    lineage genuinely contains one.  Emergent arrival origins are not assumed
    to be containers: the Merchant Offices, for example, may have been reached
    from the Waterfront without being *inside* the Waterfront.  For ordinary
    Aether-Harbor-local sites, the city opening anchor is the safe final zoom
    level.  Remote sites fall back to their nearest non-site ancestor.
    """

    locations = state.get("locations", {}) if isinstance(state.get("locations"), dict) else {}
    root = locations.get(site_root, {}) if isinstance(locations.get(site_root), dict) else {}
    cursor = str(root.get("parent_hint") or "")
    seen = {site_root}
    first_non_site = ""
    for _ in range(8):
        if not cursor or cursor in seen:
            break
        seen.add(cursor)
        parent = locations.get(cursor)
        if not isinstance(parent, dict):
            break
        if cursor in AETHER_HARBOR_LOCAL_LOCATION_IDS or cursor in AETHER_HARBOR_REGIONAL_LOCATION_IDS:
            return cursor
        if site_scope(parent) == "open" or (not isinstance(parent.get("site_memory"), dict) and not str(parent.get("site_root_id") or "")):
            first_non_site = first_non_site or cursor
        cursor = str(parent.get("parent_hint") or "")

    scope = _aether_scope_of(state, site_root)
    if scope in {"local", "visible"} and "opening_threshold" in locations:
        return "opening_threshold"
    return first_non_site or site_root


def _site_exit_to_exterior_event(
    state: dict[str, Any],
    *,
    site_root: str,
    destination_name: str,
    source_text: str,
    force: bool = False,
) -> dict[str, Any] | None:
    """Pop out of a bounded site without minting an exterior duplicate root."""

    root = state.get("locations", {}).get(site_root, {})
    if not has_bounded_geometry(root):
        return None
    if not destination_name or (not force and not SITE_EXIT_CUE.search(source_text)):
        return None
    anchor_id = _broader_exterior_anchor(state, site_root)
    if anchor_id == site_root or anchor_id not in state.get("locations", {}):
        return None

    anchor = state["locations"][anchor_id]
    turn_no = int(state.get("turn_no", 0) or 0)
    prior_position = (
        state.get("scene_position")
        if isinstance(state.get("scene_position"), dict)
        else {}
    )
    digest = hashlib.sha1(
        f"{anchor_id}:{turn_no}:{_normalized(destination_name)}".encode("utf-8")
    ).hexdigest()[:10]
    state["current_location_id"] = anchor_id
    state["scene_position"] = {
        "id": f"scene_{digest}",
        "label": destination_name,
        "anchor_location_id": anchor_id,
        "summary": "",
        "defining_excerpt": None,
        "provisional": True,
        "set_at_turn": turn_no,
        "exterior_of_site_id": site_root,
    }
    if root.get("parent_area_name") and isinstance(anchor.get("site_memory"), dict) and site_scope(anchor) == "open":
        anchor["site_memory"]["current_position"] = str(root["parent_area_name"])
    _remember_connection(state, site_root, anchor_id)
    anchor["visit_count"] = int(anchor.get("visit_count", 0) or 0) + 1
    anchor["last_arrival_from"] = site_root
    return {
        "type": "movement",
        "committed": True,
        "from_id": site_root,
        "from_name": str(root.get("name") or site_root),
        "to_id": anchor_id,
        "to_name": destination_name,
        "atlas_anchor_name": str(anchor.get("name") or anchor_id),
        "emergent": True,
        "exited_site_root_id": site_root,
        "site_exit_from_position": str(
            prior_position.get("label")
            or root.get("site_memory", {}).get("current_position")
            or root.get("name")
            or site_root
        ),
        "route_span": bool(ROUTE_SPAN_EXIT.search(source_text)),
    }


def resolve_route_span_failure(
    state: dict[str, Any],
    text: str,
    *,
    severe: bool,
) -> dict[str, Any] | None:
    """Commit bounded partial progress on a severe end-to-end escape failure.

    Ordinary failure leaves the player at the starting position.  A critical
    failure may carry them into one already-observed intermediate area before
    the concrete obstruction lands, so the fiction has a precise place to
    continue without granting the requested escape.
    """

    if not severe or not ROUTE_SPAN_EXIT.search(text):
        return None
    root_id = active_site_root_id(state)
    root = state.get("locations", {}).get(root_id)
    memory = root.get("site_memory") if isinstance(root, dict) else None
    if not isinstance(memory, dict):
        return None
    current = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    current_name = str(current.get("label") or memory.get("current_position") or "")
    areas = {
        _normalized(str(area.get("name") or "")): area
        for area in memory.get("areas", [])
        if isinstance(area, dict)
        and area.get("status") == "observed"
        and str(area.get("name") or "").strip()
    }
    start = _normalized(current_name)
    if not start or start not in areas:
        return None
    graph: dict[str, set[str]] = {}
    for connection in memory.get("connections", []):
        if not isinstance(connection, dict) or connection.get("status") != "observed":
            continue
        left = _normalized(str(connection.get("from") or ""))
        right = _normalized(str(connection.get("to") or ""))
        if left in areas and right in areas:
            graph.setdefault(left, set()).add(right)
            graph.setdefault(right, set()).add(left)
    targets = {
        key for key, area in areas.items()
        if key != start and _SITE_EGRESS_AREA.search(str(area.get("name") or ""))
    }
    queue: deque[list[str]] = deque([[start]])
    visited = {start}
    route: list[str] | None = None
    while queue:
        path = queue.popleft()
        if path[-1] in targets:
            route = path
            break
        for neighbor in sorted(graph.get(path[-1], set())):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append([*path, neighbor])
    if not route or len(route) < 2:
        return None
    intermediate = areas[route[1]]
    event = _site_position_event(
        state,
        root_id,
        str(intermediate.get("name") or "Intermediate passage"),
        source_text=text,
        area=intermediate,
    )
    event["route_span_failure"] = True
    event["requested_endpoint"] = f"Outside {str(root.get('name') or root_id)}"
    return event


def prepare_passage_quote(
    state: dict[str, Any],
    text: str,
    *,
    semantic_roll: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    if not PASSAGE_TRANSACTION.search(text) and not isinstance(semantic_roll, dict):
        return None
    if isinstance(semantic_roll, dict):
        resource = semantic_roll.get("resource_action")
        if not isinstance(resource, dict):
            return None
        passage_item = str(resource.get("item") or "").casefold()
        if (
            resource.get("kind") != "purchase"
            or resource.get("status") not in {"inquiry", "offered"}
            or (resource.get('service_type') != 'passage' if 'service_type' in resource else
                not any(word in passage_item for word in ("passage", "boat", "ship", "ferry", "vessel", "ticket", "fare", "berth")))
        ):
            return None
    elif QUESTION_OR_HYPOTHETICAL.search(text):
        return None
    from .voyage import passage_destination
    resource = (semantic_roll or {}).get('resource_action') or {}
    parsed = (str(((semantic_roll or {}).get('passage_details') or {}).get('destination_name') or 'unknown islands')
              if 'service_type' in resource else passage_destination(str(resource.get('item') or ''), text))
    destination_id = resolve_destination(state, parsed or text)
    if destination_id == state.get("current_location_id"):
        destination_id = None
    destination_name = (
        parsed or str(state.get("locations", {}).get(destination_id or "", {}).get("name") or "")
        or _emergent_destination(text)
    )
    if not destination_name:
        return None
    from .voyage import clean_destination
    destination_name = clean_destination(destination_name)
    existing = state.get("pending_passage_intent")
    if (isinstance(existing, dict) and state.get("pending_passage_offer")
            and clean_destination(str(existing.get("destination_name") or "")).casefold() == destination_name.casefold()):
        return None  # A follow-up inquiry must not discard the already stored quote.
    state["pending_passage_intent"] = {
        "destination_name": destination_name,
        "request_text": text,
        "requested_at_turn": int(state.get("turn_no", 0) or 0),
    }
    state.pop("pending_passage_offer", None)
    return {
        "type": "passage_quote_required",
        "committed": False,
        "destination_name": destination_name,
        "instruction": (
            "Offer one plausible total price as a single integer amount of silver for one-way passage only. "
            "Do not complete payment, handover, departure, travel, or arrival."
        ),
    }


def _silver_amounts(text: str) -> list[int]:
    values = [int(value) for value in re.findall(r"\b(\d{1,3})\s+silver\b", text, re.I)]
    units = {
        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9,
    }
    small = {
        **units,
        "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13,
        "fourteen": 14, "fifteen": 15, "sixteen": 16,
        "seventeen": 17, "eighteen": 18, "nineteen": 19,
    }
    tens = {
        "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50,
        "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
    }
    unit_words = "|".join(units)
    small_words = "|".join(small)
    tens_words = "|".join(tens)
    word_pattern = re.compile(
        rf"\b(one\s+hundred|(?:{tens_words})(?:[- ](?:{unit_words}))?|{small_words})\s+silver\b",
        re.I,
    )
    for match in word_pattern.finditer(text):
        phrase = re.sub(r"[- ]+", " ", match.group(1).casefold()).strip()
        if phrase == "one hundred":
            values.append(100)
        elif phrase in small:
            values.append(small[phrase])
        else:
            parts = phrase.split()
            values.append(tens[parts[0]] + (units[parts[1]] if len(parts) > 1 else 0))
    return sorted(set(value for value in values if 1 <= value <= 200))


def capture_passage_offer(state: dict[str, Any], narration: str) -> bool:
    intent = state.get("pending_passage_intent")
    if not isinstance(intent, dict) or state.get("pending_passage_offer"):
        return False
    amounts = _silver_amounts(narration)
    if len(amounts) != 1 or not 5 <= amounts[0] <= 30:
        return False
    from .voyage import clean_destination, generic_destination, quoted_destination, offer_details
    destination = clean_destination(str(intent.get("destination_name") or ""))
    if generic_destination(destination):
        destination = quoted_destination(narration) or destination
    state["pending_passage_offer"] = {
        "destination_name": destination,
        "price": amounts[0],
        "quoted_at_turn": int(state.get("turn_no", 0) or 0),
        **offer_details(narration),
    }
    return True


def resolve_pending_passage(
    state: dict[str, Any],
    text: str,
    *,
    semantic_roll: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    from .voyage import is_passage_resource, generic_destination, quoted_destination
    intent = state.get("pending_passage_intent")
    resource = (
        semantic_roll.get("resource_action")
        if isinstance(semantic_roll, dict)
        and isinstance(semantic_roll.get("resource_action"), dict)
        else None
    )
    passage_resource = is_passage_resource(resource)
    silver_cur = int(state.get('player', {}).get('silver', 0) or 0)
    blocked = {"type": "passage_purchase", "committed": False, "success": False,
               "price": 0, "silver_before": silver_cur, "silver_after": silver_cur,
               "reason": "A matching grounded passage offer must be accepted before booking; no silver was charged."}
    if not isinstance(intent, dict):
        return blocked if passage_resource and resource.get('status') == 'confirmed' else None
    semantic_refusal = bool(passage_resource and resource.get("status") == "refused")
    if semantic_refusal or (resource is None and DECLINE_OFFER.search(text)):
        destination_name = str(intent.get("destination_name") or "passage")
        state.pop("pending_passage_intent", None)
        state.pop("pending_passage_offer", None)
        return {"type": "passage_declined", "committed": False, "destination_name": destination_name}
    offer = state.get("pending_passage_offer")
    if not isinstance(offer, dict):
        return {
            "type": "passage_quote_required",
            "committed": False,
            "destination_name": str(intent.get("destination_name") or "the destination"),
            "instruction": "State one total integer price in silver for one-way passage only; do not complete payment or travel.",
        }
    price = int(offer.get("price", 0) or 0)
    silver_before = int(state.get("player", {}).get("silver", 0) or 0)
    destination_name = str(offer.get("destination_name") or intent.get("destination_name") or "")
    details = (semantic_roll or {}).get('passage_details') or {}
    if not isinstance(details, dict):
        details = {}
    if generic_destination(destination_name):
        destination_name = quoted_destination(str(offer.get('quote_text') or ''), str(details.get('destination_name') or ''))
    if resource is not None:
        from .voyage import clean_destination, passage_destination
        item = str(resource.get("item") or "")
        requested = (str(details.get('destination_name') or '') if 'service_type' in resource
                     else quoted_destination(item) or passage_destination(item) or passage_destination(text))
        accepted = bool(
            passage_resource
            and (not requested or clean_destination(requested).casefold() == clean_destination(destination_name).casefold())
            and resource.get("kind") in {"purchase", "pay"}
            and resource.get("status") == "confirmed"
            and int(resource.get("amount", 0) or 0) == price
            and resource.get("offer_grounded") is True
        )
    else:
        accepted = bool(
            ACCEPT_OFFER.search(text)
            and not QUESTION_OR_HYPOTHETICAL.search(text)
        )
    if not accepted:
        return blocked if passage_resource else None
    if generic_destination(destination_name):
        return {**blocked, "reason": "The quoted destination is unresolved. Clarify the offer before payment; no silver was charged."}
    if not 5 <= price <= 30:
        return {"type":"passage_quote_required", "committed":False,
                "destination_name":destination_name,
                "instruction":"The stored fare is invalid. Obtain one grounded price from 5 to 30 silver; do not charge or travel."}
    if silver_before < price:
        return {
            "type": "passage_purchase",
            "committed": False,
            "success": False,
            "destination_name": destination_name,
            "price": price,
            "silver_before": silver_before,
            "silver_after": silver_before,
        }
    from .voyage import book, current, offer_details
    existing = current(state)
    if existing and existing.get('phase') != 'completed':
        return {"type":"passage_purchase", "success":False, "committed":False,
                "reason":"A paid passage is already outstanding; no second fare was charged.",
                "price":price, "silver_before":silver_before, "silver_after":silver_before,
                "destination_name":destination_name}
    import copy
    prepared_offer = {**offer, **offer_details(str(offer.get('quote_text') or ''), details),
                      'destination_name': destination_name}
    staged = copy.deepcopy(state)
    voyage = book(staged, prepared_offer)
    # Build all booking state successfully before touching currency or the offer.
    for key in ('voyage', 'voyage_serial', 'voyage_history'):
        if key in staged:
            state[key] = staged[key]
    vessel_id = voyage.get('vessel_id')
    if vessel_id in staged.get('locations', {}):
        state['locations'][vessel_id] = staged['locations'][vessel_id]
    state["player"]["silver"] = silver_before - price
    state.pop("pending_passage_intent", None)
    state.pop("pending_passage_offer", None)
    return {
        "type": "passage_purchase",
        "committed": True,
        "success": True,
        "destination_name": destination_name,
        "price": price,
        "silver_before": silver_before,
        "silver_after": state["player"]["silver"],
        "movement": None,
        "voyage_id": voyage['id'], "phase": voyage['phase'],
        "departure_label": voyage['departure_label'], "vessel_name": voyage['vessel_name'],
    }


def _remember_connection(state: dict[str, Any], origin: str, destination: str) -> None:
    if origin == destination:
        return
    seen = {
        frozenset((str(edge[0]), str(edge[1])))
        for edge in state.get("edges", [])
        if isinstance(edge, (list, tuple)) and len(edge) == 2
    }
    if frozenset((origin, destination)) not in seen:
        state.setdefault("edges", []).append([origin, destination])


def _concise_location_summary(narration: str, *, max_chars: int = 260) -> str:
    """Keep the scene header useful without duplicating the transcript."""

    first_paragraph = next(
        (part.strip() for part in re.split(r"\n\s*\n", narration.strip()) if part.strip()),
        "",
    )
    if not first_paragraph:
        return ""
    # Tk does not render Markdown; emphasis marks are visual noise in the small
    # scene strip even though the verbatim excerpt correctly keeps them.
    clean = re.sub(r"(?<!\w)[*_]+|[*_]+(?!\w)", "", first_paragraph)
    sentence_end = re.search(r"[.!?](?:[\"'”’]+)?(?=\s|$)", clean)
    summary = clean[: sentence_end.end()].strip() if sentence_end else clean.strip()
    if len(summary) <= max_chars:
        return summary
    shortened = summary[: max_chars - 1].rsplit(" ", 1)[0].rstrip(" ,;:”’-")
    return shortened + "..."


_SCENE_SUBJECT = re.compile(
    r"^(?:the|this|that)\s+(?:room|hall|gallery|court(?:yard)?|alley(?:way)?|"
    r"passage|corridor|landing|stair(?:case)?|kitchen|study|chamber|interior|"
    r"house|townhouse|residence|villa|building|warehouse|shrine|temple|cave|"
    r"cavern|vessel|ship|boat|hull|deck|dock|quay|plaza|quarter|street|shore|"
    r"slope|roof|garden|space|floor|yard|foyer|vestibule|cellar|crypt|sanctum)\b",
    re.I,
)
_SCENE_PLACE_WORD = re.compile(
    r"\b(?:room|hall|gallery|court(?:yard)?|alley(?:way)?|passage|corridor|"
    r"landing|stair(?:case)?|kitchen|study|chamber|interior|house|building|"
    r"townhouse|residence|villa|warehouse|shrine|temple|cave|cavern|vessel|ship|"
    r"boat|hull|deck|dock|quay|plaza|quarter|street|shore|slope|roof|garden|"
    r"space|floor|yard|foyer|vestibule|cellar|crypt|sanctum|walls?|ceiling|pavement)\b",
    re.I,
)
_TRANSIENT_SCENE_ACTION = re.compile(
    r"\b(?:you|your|climb|climbs|drop|drops|step|steps|slip|slips|move|moves|"
    r"run|runs|reach|reaches|push|pushes|enter|enters|pass|passes|crawl|crawls|"
    r"wait|waits|sneak|sneaks|hide|hides|watch|watches)\b",
    re.I,
)


def _concise_scene_summary(
    narration: str,
    *,
    label: str = "",
    max_chars: int = 260,
) -> str:
    """Prefer a stable place sentence over the action that reached it."""

    paragraphs = [
        part.strip()
        for part in re.split(r"\n\s*\n", narration.strip())
        if part.strip()
    ][:2]
    clean = re.sub(
        r"(?<!\w)[*_]+|[*_]+(?!\w)",
        "",
        " ".join(paragraphs),
    )
    candidates = [
        sentence.strip()
        for sentence in re.split(r"(?<=[.!?])\s+(?=[\"'A-Z])", clean)
        if sentence.strip()
    ]
    label_words = {
        word
        for word in re.findall(r"[a-z]{4,}", label.casefold())
        if word not in {"inside", "interior", "place"}
    }
    ranked: list[tuple[int, int, str]] = []
    for index, sentence in enumerate(candidates):
        folded = sentence.casefold().lstrip(" \t\r\n\"'")
        score = 0
        if _SCENE_SUBJECT.search(folded):
            score += 7
        if _SCENE_PLACE_WORD.search(folded):
            score += 2
        if label_words and any(
            re.search(rf"\b{re.escape(word)}\b", folded)
            for word in label_words
        ):
            score += 3
        if re.search(r"\b(?:is|are|stands|lies|contains|opens|occupies|forms|runs)\b", folded):
            score += 1
        if _TRANSIENT_SCENE_ACTION.search(folded):
            score -= 5
        ranked.append((score, -index, sentence))
    if ranked and max(ranked)[0] >= 2:
        summary = max(ranked)[2]
        # A transient smell is never useful as the persistent identity in the
        # narrow scene card, even when the narration happened to mention one.
        summary = re.sub(
            r",\s*(?:(?:the\s+)?air\b|smell(?:ing|s)?\b|scent(?:ed)?\b).*$",
            ".",
            summary,
            flags=re.I,
        )
        if len(summary) <= max_chars:
            return summary
        shortened = summary[: max_chars - 1].rsplit(" ", 1)[0].rstrip(" ,;:-")
        return shortened + "..."
    return _concise_location_summary(narration, max_chars=max_chars)


def cement_arrival_excerpt(state: dict[str, Any], narration: str) -> bool:
    """Let the first arrival narration define a provisional location verbatim."""

    location_id = str(state.get("pending_arrival_anchor_id") or "")
    location = None
    is_scene_position = False
    if location_id and location_id == str(state.get("current_location_id") or ""):
        location = state.get("locations", {}).get(location_id)
    else:
        position = state.get("scene_position")
        if (
            isinstance(position, dict)
            and position.get("provisional")
            and str(position.get("anchor_location_id") or "") == str(state.get("current_location_id") or "")
        ):
            location = position
            is_scene_position = True
    clean = narration.strip()
    if not isinstance(location, dict) or not clean:
        return False
    paragraphs = [part.strip() for part in re.split(r"\n\s*\n", clean) if part.strip()]
    excerpt = "\n\n".join(paragraphs[:2])[:1800]
    location["defining_excerpt"] = excerpt
    location["summary"] = (
        _concise_scene_summary(clean, label=str(location.get("label") or ""))
        if is_scene_position
        else _concise_scene_summary(clean, label=str(location.get("name") or ""))
    )
    location["summary_source"] = (
        "arrival_scene_summary" if is_scene_position else "arrival_excerpt"
    )
    if is_scene_position and _INTERIOR_EVIDENCE.search(" ".join(paragraphs[:2])[:1800]):
        location["spatial_relation"] = "interior"
    location["provisional"] = False
    location["defined_at_turn"] = int(state.get("turn_no", 0) or 0)
    if not is_scene_position:
        state.pop("pending_arrival_anchor_id", None)
    return True


def refresh_emergent_place_definition(state: dict[str, Any], narration: str) -> bool:
    """Let the first few discoveries replace a merely transitional arrival card.

    Arrival prose often says only that a door opens.  The place's actual
    identity may emerge one or two exchanges later.  This keeps the verbatim
    memory and compact UI summary current without another model call.
    """

    location_id = str(state.get("current_location_id") or "")
    location = state.get("locations", {}).get(location_id)
    if not location_id.startswith("emergent_") or not isinstance(location, dict):
        return False
    defined_at = int(location.get("defined_at_turn", -999) or -999)
    current_turn = int(state.get("turn_no", 0) or 0)
    if defined_at < 0 or not (1 <= current_turn - defined_at <= 3):
        return False
    clean = narration.strip()
    if not clean:
        return False
    first_paragraph = next(
        (part.strip() for part in re.split(r"\n\s*\n", clean) if part.strip()),
        "",
    )
    folded = first_paragraph.casefold()
    label_words = {
        word
        for word in re.findall(r"[a-z]{4,}", str(location.get("name") or "").casefold())
        if word not in {"the", "named", "place"}
    }
    place_cues = {
        "interior", "exterior", "house", "building", "room", "hall", "tower",
        "garden", "street", "quarter", "island", "shore", "cave", "temple",
        "palace", "warehouse", "ship", "deck", "district", "village", "forest",
    }
    exact_label = " ".join(str(location.get("name") or "").casefold().split())
    opening = folded[:140].lstrip(" \t\r\n\"'Ã¢â‚¬Å“Ã¢â‚¬Ëœ")
    starts_with_place = bool(
        (exact_label and opening.startswith(exact_label))
        or any(
            re.match(rf"^(?:the|this|that)\s+{re.escape(word)}\b", opening)
            for word in label_words | place_cues
        )
    )
    refers_to_place = starts_with_place
    identity_statement = bool(
        re.search(r"\b(?:is|are|stands|lies|contains|consists|appears|feels|seems|remains)\b", folded)
    )
    if not (refers_to_place and identity_statement):
        return False
    summary = _concise_location_summary(clean)
    if len(summary) < 35:
        return False
    paragraphs = [part.strip() for part in re.split(r"\n\s*\n", clean) if part.strip()]
    location["summary"] = summary
    location["summary_source"] = "narrative_refinement"
    location["defining_excerpt"] = "\n\n".join(paragraphs[:2])[:1400]
    location["definition_revision"] = int(location.get("definition_revision", 0) or 0) + 1
    location["last_defined_at_turn"] = current_turn
    return True


def apply_emergent_place_refinement(state: dict[str, Any], refinement: dict[str, Any] | None) -> bool:
    """Apply Qwen's optional earned display name/summary to the live place."""

    if not isinstance(refinement, dict):
        return False
    location_id = str(state.get("current_location_id") or "")
    location = state.get("locations", {}).get(location_id)
    if not location_id.startswith("emergent_") or not isinstance(location, dict):
        return False
    changed = False
    summary = " ".join(str(refinement.get("summary") or "").split()).strip()
    if 35 <= len(summary) <= 300 and summary != str(location.get("summary") or ""):
        location["summary"] = summary
        location["summary_source"] = "model_refinement"
        changed = True
    name = " ".join(str(refinement.get("name") or "").split()).strip(" \t\r\n\"'")
    name_words = name.split()
    current_name = str(location.get("name") or "")
    if (
        name
        and name.casefold() != current_name.casefold()
        and 2 <= len(name_words) <= 9
        and len(name) <= 80
        and not re.search(r"[.!?;:]", name)
    ):
        aliases = location.setdefault("aliases", [])
        for alias in (current_name, name):
            if alias and alias.casefold() not in {str(value).casefold() for value in aliases}:
                aliases.append(alias)
        location["name"] = name
        location["refined_name_at_turn"] = int(state.get("turn_no", 0) or 0)
        changed = True
    return changed


def resolve_movement(
    state: dict[str, Any],
    text: str,
    *,
    destination_hint: str | None = None,
    destination_scope: str | None = None,
    semantic_commitment: bool | None = None,
    roll_success: bool | None = None,
) -> dict[str, Any] | None:
    if semantic_commitment is False:
        return None
    if (
        (not destination_hint and not MOVE_VERBS.search(text))
        or (semantic_commitment is not True and _question_blocks_movement(text))
    ):
        return None
    origin = str(state.get("current_location_id") or "commercial_docks")
    site_root = active_site_root_id(state, origin)
    scope = str(destination_scope or "").upper()
    if scope not in {"LOCAL", "WORLD"}:
        scope = ""
    root = state.get("locations", {}).get(site_root, {})
    bounded_site = has_bounded_geometry(root)
    has_semantic_hint = bool(str(destination_hint or "").strip())
    # Exterior planning reserves a separate root while the player stays on
    # the broad atlas anchor. Consult that explicit identity before generic
    # local movement can replace the exterior position and lose the link.
    position = state.get("scene_position")
    exterior_root = ""
    if (
        isinstance(position, dict)
        and not position.get("site_area")
        and str(position.get("anchor_location_id") or "") == origin
    ):
        candidate = str(position.get("exterior_of_site_id") or "")
        memory = state.get("locations", {}).get(candidate, {}).get("site_memory")
        if candidate != site_root and isinstance(memory, dict) and memory.get("plan_lock"):
            exterior_root = candidate
    if exterior_root and has_semantic_hint:
        exterior_area = _site_area(state, exterior_root, str(destination_hint))
        if exterior_area is None:
            # The semantic endpoint may add a cosmetic article. Keep exact
            # area/owner matching; never search other sites or fuzzy names.
            exterior_area = _site_area(state, exterior_root,
                re.sub(r"^the\s+", "", str(destination_hint), flags=re.I))
        if exterior_area is not None:
            return _site_position_event(state, exterior_root,
                str(exterior_area["name"]), source_text=text, area=exterior_area, roll_success=roll_success)
        atlas_destination = resolve_destination(state, str(destination_hint))
        exterior = state["locations"][exterior_root]
        owner_key = lambda value: re.sub(r"^the\s+", "", _normalized(str(value)))
        whole_site = owner_key(destination_hint) in {
            owner_key(name) for name in [exterior.get("name"), *(exterior.get("aliases") or [])] if name
        }
        if scope == "LOCAL" and atlas_destination == exterior_root and not whole_site:
            return {"type": "local_movement", "committed": False,
                "reason": "Endpoint is not in the selected sealed site plan; resolve the intended existing area before moving.",
                "to_name": str(destination_hint), "site_root_id": exterior_root}
    # Canonical room identity precedes the atlas's cosmetic article/title case.
    raw_area = _site_area(state, site_root, str(destination_hint or '')) if has_semantic_hint else None
    if raw_area is None and bounded_site and has_semantic_hint:
        qualifier = re.fullmatch(r"(?:beside|near|by|at)\s+.+?\s+(?:in|within|on)\s+(.+)", str(destination_hint).strip(), re.I)
        if qualifier:
            raw_area = _site_area(state, site_root, qualifier.group(1))
    destination_name = str(raw_area['name']) if raw_area else _display_name(destination_hint or "")
    # A declared end-to-end escape is one intention.  The risk judge has
    # already priced the combined exposure; on success, do not strand the
    # player at the first room named by an over-literal semantic endpoint.
    if bounded_site and ROUTE_SPAN_EXIT.search(text):
        root_name = str(root.get("name") or site_root)
        return _site_exit_to_exterior_event(
            state,
            site_root=site_root,
            destination_name=f"Outside {root_name}",
            source_text=text,
            force=True,
        )
    if LOCAL_PROXIMITY_MOVE.search(text) and (
        not destination_name
        or _same_local_position(
            position if isinstance(position, dict) else None,
            destination_name,
            root,
            site_root,
        )
    ):
        # The semantic judge deliberately leaves destination empty when the
        # player merely closes distance to an actor or object. Do not let the
        # free-text atlas fallback or a repeated anchor name turn phrases such
        # as "approach the figure" into a location transition.
        return None
    destination_name = destination_name or _emergent_destination(text)
    matched_area = raw_area or _site_area(state, site_root, destination_name or text)
    if matched_area is not None:
        return _site_position_event(
            state,
            site_root,
            str(matched_area.get("name") or destination_name),
            source_text=text, roll_success=roll_success,
            area=matched_area,
        )
    if (
        bounded_site
        and isinstance(root.get("site_memory"), dict)
        and scope != "WORLD"
        and root["site_memory"].get("plan_lock")
        and not resolve_destination(state, destination_name or "")
        and (has_semantic_hint or not SITE_EXIT_CUE.search(text))
        and destination_name
        and re.search(
            r"\b(?:bar|counter|table|stool|chair|bench|hearth|fireplace|fire|corner|"
            r"map|dice|board|game|cask|barrel|crate|chest|desk|shelf|rack|bed|bunk|"
            r"hammock|altar|statue|fountain|well|man|men|woman|women|person|people|"
            r"figure|stranger|sailors?|patrons?|gamblers?|barkeep|bartender|innkeeper|"
            r"keeper|server|maid|clerk|guard|watchman|captain|mate|merchant|vendor|"
            r"seller|smith|priest|monk|beggar|child|boy|girl|dog|cat|horse)\b",
            destination_name,
            re.I,
        )
        and not re.search(
            r"\b(?:room|chamber|hall|corridor|hallway|stairs?|staircase|stairwell|"
            r"landing|deck|hold|loft|attic|cellar|basement|courtyard|court|alley|"
            r"passage|gallery|wing|foyer|vestibule|kitchen|pantry|study|bedroom|"
            r"parlour|salon|office|library|workshop|storeroom|warehouse|sanctuary|"
            r"crypt|terrace|roof|rooftop|balcony|garden|yard|vault)\b",
            destination_name,
            re.I,
        )
    ):
        # Closing distance to an NPC, table, bar, or fixture inside a sealed
        # room is intra-room movement, not a room transition.
        return None
    # The semantic judge owns local-vs-world intent.  Inside a bounded site a
    # newly worded local endpoint (for example "Upper Levels") is therefore a
    # scene/site position, not a new atlas root.  This keeps procedural zoom
    # while preventing internal floors/wings from becoming competing places.
    if scope == "LOCAL" and destination_name:
        scoped_destination = resolve_destination(state, destination_name)
        if (
            not scoped_destination
            or scoped_destination in {origin, site_root}
            or _location_belongs_to_site(state, scoped_destination, site_root)
        ):
            if bounded_site:
                return _site_position_event(
                    state,
                    site_root,
                    destination_name,
                    source_text=text, roll_success=roll_success,
                )
            return _scene_position_event(state, destination_name, source_text=text)
    destination = resolve_destination(state, destination_name or "")
    if not destination and destination_name:
        destination = _resolve_semantic_destination(state, destination_name)
    if not destination and not has_semantic_hint:
        destination = resolve_destination(state, text)
    # A newly named island must not collapse into a mainland anchor merely
    # because its phrase happens to contain a generic alias such as "orchards".
    if destination_name and re.search(
        r"\b(?:island|isle|islet|cay|archipelago)\b", destination_name, re.I
    ):
        known_name = str(state.get("locations", {}).get(destination or "", {}).get("name") or "")
        if not re.search(r"\b(?:island|isle|islet|cay|archipelago)\b", known_name, re.I):
            destination = None
    if destination and destination != site_root and _location_belongs_to_site(state, destination, site_root):
        child = state.get("locations", {}).get(destination, {})
        return _site_position_event(
            state,
            site_root,
            str(child.get("site_area_name") or child.get("name") or destination_name),
            source_text=text, roll_success=roll_success,
            absorbed_location_id=destination,
        )
    # Legacy/provisional atlas children occasionally arose for a room or wing
    # inside a site before the spatial layer had exclusive ownership.  If the
    # child explicitly points back to the active bounded site and the endpoint
    # is clearly local, absorb it instead of travelling to a second site root.
    if destination and destination != site_root:
        root = state.get("locations", {}).get(site_root, {})
        child = state.get("locations", {}).get(destination, {})
        parent_hint = str(child.get("parent_hint") or "") if isinstance(child, dict) else ""
        if (
            isinstance(root.get("site_memory"), dict)
            and parent_hint == site_root
            and destination_name
            and (SCENE_POSITION.search(destination_name) or SITE_ONLY_POSITION.search(destination_name))
        ):
            return _site_position_event(
                state,
                site_root,
                destination_name,
                source_text=text, roll_success=roll_success,
                absorbed_location_id=destination,
            )
    # WORLD scope from a bounded site means the player is leaving it.  Let the
    # exit/zoom-out path own even a novel exterior label before generic local
    # position heuristics see it.
    if (
        scope == "WORLD"
        and bounded_site
        and destination_name
        and (not destination or destination in {origin, site_root})
    ):
        exterior_name = destination_name
        if destination in {origin, site_root}:
            root_name = str(root.get("name") or site_root)
            if _normalized(destination_name) in {
                _normalized(root_name),
                *(_normalized(alias) for alias in root.get("aliases", [])),
            }:
                exterior_name = f"Outside {root_name}"
        exit_event = _site_exit_to_exterior_event(
            state,
            site_root=site_root,
            destination_name=exterior_name,
            source_text=text,
            force=True,
        )
        if exit_event is not None:
            return exit_event

    # A semantic endpoint such as "Harbormaster's Office Second-Story
    # Window" also contains the canonical site's name. Keep the specific
    # window/roof/balcony as a local position instead of collapsing it back to
    # the whole building.
    if (
        destination in {origin, site_root}
        and destination_name
        and _has_more_specific_scene_position(state, site_root, destination_name)
    ):
        if bounded_site:
            return _site_position_event(
                state, site_root, destination_name, source_text=text, roll_success=roll_success
            )
        return _scene_position_event(state, destination_name, source_text=text)
    if not destination and destination_name and SCENE_POSITION.search(destination_name):
        if bounded_site:
            return _site_position_event(
                state, site_root, destination_name, source_text=text, roll_success=roll_success
            )
        return _scene_position_event(state, destination_name, source_text=text)
    if not destination and destination_name:
        root = state.get("locations", {}).get(site_root, {})
        if isinstance(root.get("site_memory"), dict) and SITE_ONLY_POSITION.search(destination_name):
            return _site_position_event(
                state, site_root, destination_name, source_text=text, roll_success=roll_success
            )
    if not destination and destination_name:
        exit_event = _site_exit_to_exterior_event(
            state,
            site_root=site_root,
            destination_name=destination_name,
            source_text=text,
        )
        if exit_event is not None:
            return exit_event
    if not destination:
        if not destination_name:
            root = state.get("locations", {}).get(site_root, {})
            if isinstance(root.get("site_memory"), dict) and EXPLORE_WITHIN.search(text):
                return _site_exploration_event(state, site_root)
            return None
        destination = _emergent_id(destination_name)
        state.setdefault("locations", {}).setdefault(
            destination,
            {
                "name": destination_name,
                "region": "Emergent place",
                "summary": "A place named by the player and not yet defined by the narration.",
                "aliases": [destination_name],
                "provisional": True,
                "defining_excerpt": None,
                "visit_count": 0,
                "parent_hint": origin,
                "aether_geography_scope": _new_place_aether_scope(
                    state,
                    origin=origin,
                    destination_name=destination_name,
                    source_text=text,
                ),
            },
        )
    if destination in {origin, site_root}:
        current_position = state.get("scene_position")
        if isinstance(current_position, dict):
            root = state.get("locations", {}).get(site_root, {})
            if _same_local_position(
                current_position,
                destination_name or str(root.get("name") or site_root),
                root if isinstance(root, dict) else {},
                site_root,
            ):
                return {
                    "type": "local_movement",
                    "committed": False,
                    "location_id": site_root,
                    "location_name": str(root.get("name") or site_root),
                    "to_name": str(current_position.get("label") or destination_name),
                }
            if EXPLORE_WITHIN.search(text):
                return _site_exploration_event(state, site_root)
            from_name = str(current_position.get("label") or state["locations"][site_root]["name"])
            state["scene_position"] = None
            state["current_location_id"] = site_root
            return {
                "type": "local_movement",
                "location_id": site_root,
                "location_name": state["locations"][site_root]["name"],
                "from_name": from_name,
                "to_name": state["locations"][site_root]["name"],
                "committed": True,
                "emergent": False,
            }
        return {
            "type": "local_movement",
            "location_id": origin,
            "location_name": state["locations"][origin]["name"],
            "committed": False,
        }
    # Aether Harbor keeps a soft atlas, not a restrictive movement graph.  The
    # stored edges are useful continuity hints, but they never veto a clear
    # player departure. Qwen is free to author the actual streets and passage.
    route = shortest_route(state, origin, destination)

    # --- TRAVEL HAZARD SYSTEM ---
    from aether_harbor.mechanics import _manual_or_random_roll
    dest_name_str = state["locations"][destination]["name"]
    is_voyage = bool(scope == "WORLD" and re.search(r"\b(?:island|isle|islet|cay|archipelago|sea|ocean)\b", dest_name_str, re.I))

    hazard_event = None
    if is_voyage and origin != destination:
        # Travel danger is engine-owned; never request or borrow a player's die.
        hazard_roll = _manual_or_random_roll(state, 20, None)
        if hazard_roll <= 2:
            hazard_name = "Pirate Ambush at Sea"
            destination = _emergent_id(hazard_name)
            locs = state.setdefault("locations", {})
            if destination not in locs:
                locs[destination] = {
                    "name": hazard_name,
                    "region": "Emergent place",
                    "summary": "A sudden ambush on the open water.",
                    "aliases": [hazard_name],
                    "provisional": True,
                    "defining_excerpt": None,
                    "visit_count": 0,
                }
            hazard_event = "Ambush"
        elif hazard_roll <= 7:
            hazard_name = "Violent Storm at Sea"
            destination = _emergent_id(hazard_name)
            locs = state.setdefault("locations", {})
            if destination not in locs:
                locs[destination] = {
                    "name": hazard_name,
                    "region": "Emergent place",
                    "summary": "A treacherous storm threatening the vessel.",
                    "aliases": [hazard_name],
                    "provisional": True,
                    "defining_excerpt": None,
                    "visit_count": 0,
                }
            hazard_event = "Storm"

    _remember_connection(state, origin, destination)
    commerce = state.get("commerce")
    if isinstance(commerce, dict):
        commerce["awaiting_quote"] = None
        commerce["pending_offer"] = None
    state["current_location_id"] = destination
    state["scene_position"] = None
    location = state["locations"][destination]
    memory = location.get("site_memory") or {}
    entry_name = str((memory.get("plan_lock") or {}).get("entry_area") or "")
    entry = _site_area(state, destination, entry_name) if entry_name else None
    if entry is not None:
        # A world arrival reaches the sealed entry, not the room visited last
        # time. Keep the existing plan, allocation and door descriptions intact.
        label = str(entry["name"])
        digest = hashlib.sha1(f"{destination}:{_normalized(label)}".encode("utf-8")).hexdigest()[:10]
        state["scene_position"] = {
            "id": f"scene_{digest}", "label": label, "anchor_location_id": destination,
            "summary": str(entry.get("physical_character") or ""),
            "defining_excerpt": entry.get("defining_excerpt"),
            "provisional": entry.get("status") != "observed",
            "set_at_turn": int(state.get("turn_no", 0) or 0),
            "site_area": True, "site_connector": False,
        }
        memory["current_position"] = label
    location["visit_count"] = int(location.get("visit_count", 0) or 0) + 1
    location["last_arrival_from"] = origin
    if location.get("provisional") and not location.get("defining_excerpt"):
        state["pending_arrival_anchor_id"] = destination
    result = {
        "type": "movement",
        "committed": True,
        "from_id": origin,
        "from_name": state["locations"][origin]["name"],
        "to_id": destination,
        "to_name": state["locations"][destination]["name"],
        "emergent": bool(location.get("provisional") or destination.startswith("emergent_")),
        "soft_route_hint": (
            [state["locations"][loc_id]["name"] for loc_id in route] if route and len(route) <= 3 else None
        ),
    }
    if hazard_event:
        result["travel_hazard"] = hazard_event
    return result


