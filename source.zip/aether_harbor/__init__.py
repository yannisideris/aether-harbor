"""Aether Harbor local-AI RPG vertical slice."""

__version__ = "0.1.0"
