"""Private, versioned Supabase checkpoints for the single-instance web server.

SQLite remains the game engine's store. Every committed write is checkpointed,
including background memory writes. A failed upload stays dirty, is retried,
and prevents accepting the next player action. No credentials enter responses.
"""
from __future__ import annotations

import base64
import json
import os
import re
import sqlite3
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid
import zlib
from contextlib import closing, contextmanager
from pathlib import Path

from .persistence import CampaignStore

MAX_DATABASE_BYTES = 32 * 1024 * 1024
MAX_SNAPSHOT_BYTES = 8 * 1024 * 1024


class CloudSaveError(RuntimeError):
    pass


class SnapshotBackend:
    def __init__(self, url: str, key: str):
        if not re.fullmatch(r'https://[a-z0-9-]+\.supabase\.co', url):
            raise ValueError('AETHER_SAVE_URL must be an HTTPS Supabase project URL')
        self.url = url
        self.key = key

    def rpc(self, name: str, body: dict):
        request = urllib.request.Request(
            self.url + '/rest/v1/rpc/' + name,
            data=json.dumps(body, separators=(',', ':')).encode(),
            headers={'apikey': self.key, 'Authorization': 'Bearer ' + self.key,
                     'Content-Type': 'application/json'}, method='POST')
        try:
            with urllib.request.urlopen(request, timeout=12) as response:
                raw = response.read(MAX_SNAPSHOT_BYTES * 2 + 1)
            if len(raw) > MAX_SNAPSHOT_BYTES * 2:
                raise CloudSaveError('Cloud save exceeds the supported size')
            return json.loads(raw)
        except CloudSaveError:
            raise
        except Exception:
            # Provider response bodies can contain secrets or internal details.
            raise CloudSaveError('Cloud saves are temporarily unavailable') from None

    def load(self, sid: str):
        return self.rpc('aether_load_save', {'p_session_id': sid})

    def save(self, sid: str, revision: int, write_id: str, snapshot: str):
        result = self.rpc('aether_write_save', {
            'p_session_id': sid, 'p_expected_revision': revision,
            'p_write_id': write_id, 'p_snapshot': snapshot})
        if not isinstance(result, int) or isinstance(result, bool) or result != revision + 1:
            raise CloudSaveError('This voyage changed on another server; please reload later')
        return result


def configured_backend():
    url = os.environ.get('AETHER_SAVE_URL', '').rstrip('/')
    key = os.environ.get('AETHER_SAVE_KEY', '')
    if bool(url) != bool(key):
        raise ValueError('Both AETHER_SAVE_URL and AETHER_SAVE_KEY are required')
    if os.environ.get('AETHER_REQUIRE_CLOUD_SAVES') == '1' and not url:
        raise ValueError('Cloud save configuration is required for this deployment')
    return SnapshotBackend(url, key) if url else None


def _encode_database(path: Path) -> str:
    # backup() includes committed WAL pages; copying the .sqlite file does not.
    with tempfile.TemporaryDirectory(prefix='aether-checkpoint-') as tmp:
        dest = Path(tmp)/'checkpoint.sqlite'
        with closing(sqlite3.connect(path)) as source, closing(sqlite3.connect(dest)) as target:
            source.backup(target)
        raw = dest.read_bytes()
    if len(raw) > MAX_DATABASE_BYTES:
        raise CloudSaveError('This voyage exceeds the supported save size')
    compressed = zlib.compress(raw, level=6)
    if len(compressed) > MAX_SNAPSHOT_BYTES:
        raise CloudSaveError('This voyage exceeds the supported save size')
    return base64.b64encode(compressed).decode('ascii')


def _restore_database(path: Path, encoded: str):
    try:
        if not isinstance(encoded, str) or len(encoded) > MAX_SNAPSHOT_BYTES * 2:
            raise ValueError('size')
        compressed = base64.b64decode(encoded, validate=True)
        decoder = zlib.decompressobj()
        raw = decoder.decompress(compressed, MAX_DATABASE_BYTES + 1)
        if (len(raw) > MAX_DATABASE_BYTES or not decoder.eof
                or decoder.unused_data or not raw.startswith(b'SQLite format 3\x00')):
            raise ValueError('invalid checkpoint')
        with tempfile.TemporaryDirectory(prefix='aether-restore-') as tmp:
            src = Path(tmp)/'checkpoint.sqlite'
            src.write_bytes(raw)
            with closing(sqlite3.connect(src)) as source:
                if source.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                    raise ValueError('integrity')
                names = {r[0] for r in source.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if not {'campaigns', 'turns', 'memory_evidence', 'shared_echoes'} <= names:
                    raise ValueError('schema')
                path.parent.mkdir(parents=True, exist_ok=True)
                # SQLite backup safely replaces an existing database, including WAL.
                with closing(sqlite3.connect(path)) as target:
                    source.backup(target)
    except Exception:
        raise CloudSaveError('The saved voyage could not be restored; it has not been replaced') from None


class CloudCampaignStore(CampaignStore):
    def __init__(self, path: Path, backend: SnapshotBackend, sid: str):
        self.backend, self.sid = backend, sid
        self._sync_lock = threading.RLock()
        self.dirty = False
        self.error = False
        self._retry_running = False
        self._next_retry = 0.0
        self._generation = 0
        self._pending = None
        self.revision = 0
        self._initializing = True
        saved = backend.load(sid)  # An unavailable service must never look like an empty save.
        if saved is not None:
            if (not isinstance(saved, dict) or not isinstance(saved.get('revision'), int)
                    or saved['revision'] < 1 or not isinstance(saved.get('snapshot'), str)):
                raise CloudSaveError('Invalid cloud save response')
            _restore_database(Path(path), saved['snapshot'])
            self.revision = saved['revision']
        elif Path(path).exists():
            # A missing remote record must not silently resurrect stale local data.
            try:
                with closing(sqlite3.connect(path)) as connection:
                    populated = connection.execute('SELECT 1 FROM campaigns LIMIT 1').fetchone()
                if populated:
                    raise CloudSaveError('Cloud save is missing; local recovery requires review')
            except sqlite3.Error:
                raise CloudSaveError('Local save could not be checked') from None
        super().__init__(path)
        self._initializing = False

    @contextmanager
    def _session(self):
        with self._sync_lock:
            connection = self._connect()
            changed = False
            try:
                with connection:
                    yield connection
                changed = connection.total_changes > 0
            finally:
                connection.close()
            if changed and not self._initializing:
                self._generation += 1
                self.dirty = True
                if not self.error or time.monotonic() >= self._next_retry:
                    self._flush_locked()

    def _flush_locked(self) -> bool:
        try:
            while self.dirty:
                if self._pending is None:
                    self._pending = (self._generation, uuid.uuid4().hex,
                                     _encode_database(self.path))
                generation, write_id, snapshot = self._pending
                self.revision = self.backend.save(self.sid, self.revision, write_id, snapshot)
                self._pending = None
                self.dirty = self._generation != generation
            self.error = False
            return True
        except Exception:
            self.error = True
            self._next_retry = time.monotonic() + 15
            return False

    def flush(self) -> bool:
        with self._sync_lock:
            return self._flush_locked()

    def retry_in_background(self):
        if not self.dirty or self._retry_running or time.monotonic() < self._next_retry:
            return
        # Avoid blocking HTTP state reads behind a foreground checkpoint upload.
        if not self._sync_lock.acquire(blocking=False):
            return
        try:
            if self._retry_running or not self.dirty:
                return
            self._retry_running = True
        finally:
            self._sync_lock.release()

        def retry():
            try:
                self.flush()
            finally:
                self._retry_running = False
        threading.Thread(target=retry, daemon=True, name='aether-save-retry').start()

    def status(self):
        return {'mode': 'cloud', 'saved': not self.dirty, 'error': self.error,
                'revision': self.revision}
