import random
from typing import Any, Dict, Optional

def resolve_skirmish_momentum(state: Dict[str, Any], player_combat_outcome: Optional[str] = None) -> Dict[str, Any]:
    """
    Resolves the macro-scale battle momentum when mass_combat_active is true.
    player_combat_outcome can be 'critical_success', 'success', 'failure', 'critical_failure'.
    Returns a dict with the outcome and a directive string for the GM.
    """
    # Initialize momentum if not present
    current_momentum = state.get("skirmish_momentum", 0)
    
    # Calculate modifiers based on player action
    player_modifier = 0
    if player_combat_outcome == "critical_success":
        player_modifier = 3
    elif player_combat_outcome == "success":
        player_modifier = 1
    elif player_combat_outcome == "failure":
        player_modifier = -1
    elif player_combat_outcome == "critical_failure":
        player_modifier = -3
        
    # Also add current momentum as a modifier (snowball effect)
    base_roll = random.randint(1, 20)
    
    if base_roll == 1:
        total = 1 # Auto disaster
    elif base_roll == 20:
        total = 20 # Auto triumph
    else:
        total = base_roll + player_modifier + current_momentum
        
    # Determine shift
    directive = ""
    shift = 0
    
    if total <= 6:
        shift = -2
        directive = "[BATTLE UPDATE: The allied forces are suffering heavy losses or retreating. Describe the enemy advancing, overwhelming the lines, or allied NPCs falling back in chaos.]"
    elif 7 <= total <= 9:
        shift = -1
        directive = "[BATTLE UPDATE: The enemy forces are pushing back. Describe the allies struggling to hold the line.]"
    elif 10 <= total <= 14:
        shift = 0
        directive = "[BATTLE UPDATE: The skirmish is locked in a fierce stalemate. Describe the intense, balanced chaos of the surrounding battle.]"
    elif 15 <= total <= 18:
        shift = 1
        directive = "[BATTLE UPDATE: The allied forces are pushing forward. Describe the enemy faltering or retreating under pressure.]"
    else: # 19+
        shift = 2
        directive = "[BATTLE UPDATE: The allied forces make a triumphant breakthrough! Describe the enemy lines breaking, retreating in panic, or a major allied victory happening in the background.]"
        
    new_momentum = max(-5, min(5, current_momentum + shift))
    state["skirmish_momentum"] = new_momentum
    
    return {
        "type": "skirmish_resolution",
        "base_roll": base_roll,
        "player_modifier": player_modifier,
        "current_momentum": current_momentum,
        "total": total,
        "shift": shift,
        "new_momentum": new_momentum,
        "directive": directive
    }
