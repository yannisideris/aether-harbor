from __future__ import annotations

import asyncio
import json
import logging
import os
import queue
import re
import secrets
import threading
import time
from pathlib import Path
from typing import Any, Callable

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .cascading_model import CascadingModelClient
from .game_engine import GameEngine
from .cloud_saves import CloudCampaignStore, CloudSaveError, configured_backend

logger = logging.getLogger("aether_harbor.web")

PROJECT_ROOT = Path(__file__).resolve().parent.parent
STATIC_DIR = Path(__file__).resolve().parent / "static"
RUNTIME_DIR = Path(os.environ.get("AETHER_RUNTIME_DIR") or PROJECT_ROOT / "data" / "runtime")
SESSIONS_DIR = RUNTIME_DIR / "sessions"

SESSION_COOKIE = "ah_session_id"
SESSION_PATTERN = re.compile(r"^ah_sess_[0-9a-f]{24}$")
STREAM_PATTERN = re.compile(r"^stream_[0-9a-f]{16}$")
MAX_ENGINES = max(1, min(300, int(os.environ.get("AETHER_MAX_ENGINES", "300"))))
MAX_FOREGROUND_JOBS = max(1, min(32, int(os.environ.get("AETHER_MAX_JOBS", "32"))))
MAX_BODY_BYTES = 16_384
MAX_STREAMS = 128
MAX_STREAM_EVENTS = 4096
ENGINE_IDLE_SECONDS = 2 * 3600
STREAM_TTL_SECONDS = 15 * 60
KEEPALIVE_SECONDS = 15.0
MAX_ACTION_CHARS = 2000


def load_settings() -> dict[str, Any]:
    path = PROJECT_ROOT / "settings.json"
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.warning("Could not parse settings.json: %s", exc)
    return {}


SETTINGS = load_settings()
GLOBAL_CASCADE = CascadingModelClient(config=SETTINGS)
CLOUD_SAVES = configured_backend()


class StreamChannel:
    def __init__(self, owner: str):
        self.owner = owner
        self.queue: queue.Queue[tuple[str, Any] | None] = queue.Queue(maxsize=MAX_STREAM_EVENTS)
        self.created = time.time()
        self.finished = False
        self.overflowed = False

    def publish(self, item: tuple[str, Any] | None) -> None:
        if self.overflowed:
            return
        try:
            self.queue.put_nowait(item)
        except queue.Full:
            # Never let a disconnected/slow reader retain unbounded tokens or
            # stall game persistence. The browser can recover from history.
            self.overflowed = True
            while True:
                try:
                    self.queue.get_nowait()
                except queue.Empty:
                    break
            self.queue.put_nowait(("resync", None))
            self.queue.put_nowait(None)


class SessionManager:
    """One GameEngine (own SQLite file) per browser session, plus owned event streams."""

    def __init__(self) -> None:
        self.engines: dict[str, GameEngine] = {}
        self.streams: dict[str, StreamChannel] = {}
        self._lock = threading.RLock()
        self._active_jobs: set[int] = set()
        self._loading: set[str] = set()

    def get_or_create_engine(self, session_id: str) -> GameEngine:
        if not SESSION_PATTERN.match(session_id or ""):
            raise ValueError("invalid session id")
        with self._lock:
            engine = self.engines.get(session_id)
            if engine is not None:
                engine.last_activity = time.time()
                return engine
            self._evict_locked()
            if session_id in self._loading or len(self.engines) + len(self._loading) >= MAX_ENGINES:
                raise HTTPException(503, "The harbor is busy. Please retry shortly.")
            self._loading.add(session_id)
        try:
            # Remote restores must never hold the lock shared by all players.
            SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
            path = SESSIONS_DIR / f"{session_id}.sqlite"
            if CLOUD_SAVES is not None:
                store = CloudCampaignStore(path, CLOUD_SAVES, session_id)
                engine = GameEngine(path, GLOBAL_CASCADE, store=store)
            else:
                engine = GameEngine(path, GLOBAL_CASCADE)
            with self._lock:
                self.engines[session_id] = engine
            engine.last_activity = time.time()
            return engine
        except CloudSaveError:
            raise HTTPException(503, "Saved voyages are temporarily unavailable. Please retry; your save has not been replaced.") from None
        finally:
            with self._lock:
                self._loading.discard(session_id)

    def claim_engine(self, session_id: str) -> GameEngine | None:
        # Retrieval and admission are atomic relative to eviction. No state
        # lock is acquired here, even if inference is running on this engine.
        engine = self.get_or_create_engine(session_id)
        with self._lock:
            if self.engines.get(session_id) is not engine:
                raise HTTPException(503, "Please retry shortly.")
            if engine.busy:
                return None
            if len(self._active_jobs) >= MAX_FOREGROUND_JOBS:
                raise HTTPException(503, "The harbor is busy. Please retry shortly.")
            if not engine.claim():
                return None
            self._active_jobs.add(id(engine))
        if isinstance(engine.store, CloudCampaignStore) and not engine.store.flush():
            self.release_engine(engine)
            raise HTTPException(503, "Your last changes are still waiting to save. Please retry shortly.")
        return engine

    def release_engine(self, engine: GameEngine) -> None:
        with self._lock:
            engine.release()
            self._active_jobs.discard(id(engine))

    def _evict_locked(self) -> None:
        now = time.time()
        idle = [
            sid for sid, engine in self.engines.items()
            if engine.is_idle() and not getattr(engine.store, "dirty", False)
            and now - engine.last_activity > ENGINE_IDLE_SECONDS
        ]
        for sid in idle:
            self.engines.pop(sid, None)
        if len(self.engines) >= MAX_ENGINES:
            candidates = sorted(
                (e.last_activity, sid) for sid, e in self.engines.items()
                if e.is_idle() and not getattr(e.store, "dirty", False)
            )
            for _ts, sid in candidates[: len(self.engines) - MAX_ENGINES + 1]:
                self.engines.pop(sid, None)

    def create_stream(self, owner: str) -> tuple[str, StreamChannel]:
        with self._lock:
            now = time.time()
            for stale in [k for k, ch in self.streams.items() if now - ch.created > STREAM_TTL_SECONDS]:
                self.streams.pop(stale, None)
            if len(self.streams) >= MAX_STREAMS:
                completed = sorted((ch.created, k) for k, ch in self.streams.items() if ch.finished)
                for _created, key in completed[:len(self.streams) - MAX_STREAMS + 1]:
                    self.streams.pop(key, None)
            if len(self.streams) >= MAX_STREAMS:
                raise HTTPException(503, "The harbor is busy. Please retry shortly.")
            stream_id = f"stream_{secrets.token_hex(8)}"
            channel = StreamChannel(owner)
            self.streams[stream_id] = channel
            return stream_id, channel

    def get_stream(self, stream_id: str, owner: str) -> StreamChannel | None:
        with self._lock:
            channel = self.streams.get(stream_id)
            if channel is None or channel.owner != owner:
                return None
            return channel

    def remove_stream(self, stream_id: str) -> None:
        with self._lock:
            self.streams.pop(stream_id, None)


session_manager = SessionManager()

app = FastAPI(title="Aether Harbor Web Server", docs_url=None, redoc_url=None, openapi_url=None)


@app.middleware("http")
async def session_cookie_middleware(request: Request, call_next):
    sid = request.cookies.get(SESSION_COOKIE) or ""
    is_new = not SESSION_PATTERN.match(sid)
    if is_new:
        sid = f"ah_sess_{secrets.token_hex(12)}"
    request.state.session_id = sid
    response = await call_next(request)
    if is_new or request.url.path == "/api/state":
        response.set_cookie(
            key=SESSION_COOKIE,
            value=sid,
            max_age=365 * 86400,
            httponly=True,
            samesite="lax",
            secure=request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https",
        )
    return response


def _engine(request: Request) -> tuple[str, GameEngine]:
    sid = request.state.session_id
    return sid, session_manager.get_or_create_engine(sid)


def _busy() -> JSONResponse:
    return JSONResponse({"status": "busy", "error": "Aether Harbor is still answering your last action."}, status_code=409)


def _run_job(sid: str, engine: GameEngine, job: Callable[[Callable[[str, Any], None]], None]) -> str:
    """Run one foreground job in a worker thread, streaming typed events to its owner only."""
    try:
        stream_id, channel = session_manager.create_stream(sid)
    except Exception:
        session_manager.release_engine(engine)
        raise

    def emit(kind: str, payload: Any = None) -> None:
        channel.publish((kind, payload))

    def worker() -> None:
        try:
            job(emit)
        except Exception as exc:  # never leave the client hanging
            logger.exception("Foreground job failed")
            emit("error", f"Engine error: {exc}")
        finally:
            session_manager.release_engine(engine)
            channel.finished = True
            channel.publish(None)

    try:
        threading.Thread(target=worker, daemon=True, name="aether-foreground").start()
    except Exception:
        session_manager.remove_stream(stream_id)
        session_manager.release_engine(engine)
        raise
    return stream_id


async def _json_body(request: Request) -> dict[str, Any]:
    raw = bytearray()
    async for chunk in request.stream():
        raw.extend(chunk)
        if len(raw) > MAX_BODY_BYTES:
            raise HTTPException(413, "Request body is too large.")
    try:
        body = json.loads(raw)
    except Exception:
        return {}
    return body if isinstance(body, dict) else {}


if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/", response_class=HTMLResponse)
def serve_index() -> HTMLResponse:
    index_file = STATIC_DIR / "index.html"
    if index_file.exists():
        return HTMLResponse(content=index_file.read_text(encoding="utf-8"))
    return HTMLResponse("<h3>Aether Harbor web UI loading...</h3>")


@app.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/state")
def get_state(request: Request):
    _sid, engine = _engine(request)
    data = engine.get_public_state()
    data["telemetry_summary"] = GLOBAL_CASCADE.get_telemetry_summary()
    data["save_status"] = _save_status(engine)
    return JSONResponse(data)


def _save_status(engine: GameEngine):
    if isinstance(engine.store, CloudCampaignStore):
        engine.store.retry_in_background()
        return engine.store.status()
    return {"mode": "local", "saved": True, "error": False}


@app.get("/api/save/status")
def get_save_status(request: Request):
    _sid, engine = _engine(request)
    return JSONResponse(_save_status(engine))


@app.get("/api/history")
def get_history(request: Request):
    _sid, engine = _engine(request)
    return JSONResponse({"turns": engine.get_transcript_history(limit=60)})


@app.post("/api/campaign/new")
async def new_campaign_endpoint(request: Request):
    body = await _json_body(request)
    sid = request.state.session_id
    engine = await asyncio.to_thread(session_manager.claim_engine, sid)
    if engine is None:
        return _busy()
    try:
        await asyncio.to_thread(
            engine.start_new_campaign,
            str(body.get("name") or "Visitor"),
            str(body.get("class") or "fighter"),
            str(body.get("appearance") or ""),
        )
    except Exception:
        session_manager.release_engine(engine)
        raise
    stream_id = _run_job(sid, engine, engine.run_opening)
    return JSONResponse({"status": "created", "stream_id": stream_id})


@app.post("/api/action/submit")
async def submit_action(request: Request):
    body = await _json_body(request)
    text = str(body.get("text") or "").strip()[:MAX_ACTION_CHARS]
    if not text:
        return JSONResponse({"status": "empty"}, status_code=400)
    sid = request.state.session_id
    engine = await asyncio.to_thread(session_manager.claim_engine, sid)
    if engine is None:
        return _busy()
    stream_id = _run_job(sid, engine, lambda emit: engine.run_player_text(text, emit))
    return JSONResponse({"status": "streaming", "stream_id": stream_id})


@app.post("/api/roll/submit")
async def submit_roll(request: Request):
    body = await _json_body(request)
    submitted = str(body.get("roll") if body.get("roll") is not None else "").strip()[:100]
    sid = request.state.session_id
    engine = await asyncio.to_thread(session_manager.claim_engine, sid)
    if engine is None:
        return _busy()
    try:
        accepted = await asyncio.to_thread(engine.accept_roll, submitted)
    except Exception:
        session_manager.release_engine(engine)
        raise
    if accepted.get("status") != "accepted":
        session_manager.release_engine(engine)
        return JSONResponse(accepted, status_code=400)
    data = accepted["data"]
    stream_id = _run_job(sid, engine, lambda emit: engine.run_roll(data, emit))
    return JSONResponse({"status": "streaming", "stream_id": stream_id})


@app.post("/api/fate/spin")
async def spin_fate_endpoint(request: Request):
    sid = request.state.session_id
    engine = await asyncio.to_thread(session_manager.claim_engine, sid)
    if engine is None:
        return _busy()
    try:
        prep = await asyncio.to_thread(engine.begin_fate_spin)
    except Exception:
        session_manager.release_engine(engine)
        raise
    if prep.get("status") != "spinning":
        session_manager.release_engine(engine)
        return JSONResponse(prep)
    event = prep.pop("event")
    stream_id = _run_job(sid, engine, lambda emit: engine.run_fate_narration(event, emit))
    return JSONResponse({**prep, "stream_id": stream_id})


def _sse(kind: str, payload: Any) -> str:
    return f"event: {kind}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"


@app.get("/api/stream/{stream_id}")
async def stream_events(stream_id: str, request: Request):
    if not STREAM_PATTERN.match(stream_id):
        return JSONResponse({"detail": "Stream not found"}, status_code=404)
    channel = session_manager.get_stream(stream_id, request.state.session_id)
    if channel is None:
        return JSONResponse({"detail": "Stream not found"}, status_code=404)

    async def event_generator():
        last_sent = time.monotonic()
        try:
            while True:
                try:
                    item = channel.queue.get_nowait()
                except queue.Empty:
                    if await request.is_disconnected():
                        break
                    if time.monotonic() - last_sent > KEEPALIVE_SECONDS:
                        last_sent = time.monotonic()
                        yield ": keepalive\n\n"
                    await asyncio.sleep(0.03)
                    continue
                last_sent = time.monotonic()
                if item is None:
                    yield _sse("done", "[DONE]")
                    break
                kind, payload = item
                yield _sse(kind, payload)
        finally:
            session_manager.remove_stream(stream_id)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/api/telemetry")
def get_telemetry():
    return JSONResponse(GLOBAL_CASCADE.get_telemetry_summary())
