from __future__ import annotations

import re
from typing import Any

from .movement import _concise_scene_summary, active_site_root_id, _normalized


_ACTION_RESULT_PATTERN = re.compile(
    r"\b(taken|snatched|picked|opened|forced|broken|unlocked|locked|barred|shattered|damaged|looted|revealed|searched|discovered)\b",
    re.I,
)


_DIALOGUE_PATTERN = re.compile(r'["\'\u201c\u201d\u2018\u2019]')
_FIXTURE_PATTERN = re.compile(
    r"\b(?:windows?|sill|panes?|shafts?\s+of\s+light|light|lanterns?|lamps?|hearth|fireplace|"
    r"rafters?|beams?|counter|desk|tables?|shel(?:f|ves)|bookcases?|cabinets?|cupboards?|"
    r"casks?|barrels?|crates?|boxes?|chests?|pots?|jars?|vials?|bottles?|curtains?|drapes?|"
    r"tapestr(?:y|ies)|rugs?|carpets?|chandelier|braziers?|furnaces?|forges?|anvils?|altars?|"
    r"dais|shrine|pillars?|columns?|archways?|arches?|vaults?|flagstones?|tiles?|walls?|ceilings?|"
    r"roof|floor|grates?|bars?|balcon(?:y|ies)|stairs?|staircases?|ladders?|bunks?|cots?|beds?|"
    r"lockers?|workbenches?|benches?|racks?|pedestals?|statues?|fountains?|cisterns?|wells?|"
    r"pipes?|machinery|boilers?|mirrors?|closets?|sacks?|pallets?|ledgers?|envelopes?|candles?|"
    r"basins?|courtyard|precinct|limestone|brickwork)\b",
    re.I,
)
_STATIC_VERB_PATTERN = re.compile(
    r"\b(?:hangs?|hanging|sits?|sitting|stands?|standing|lies?|lying|rests?|resting|lines?|lining|"
    r"litters?|littered|stacks?|stacked|covers?|covered|dominates?|dominated|flanks?|flanked|"
    r"leans?|leaning|fills?|filled|holds?|holding|bears?|bearing|displays?|displayed|occupies?|"
    r"occupied|sprouts?|sprouting|stretches?|stretching|runs?|running|towers?|towering|bolted|"
    r"illuminate|pierce|dance|dances|danced|provide|provides|trickle|trickles)\b",
    re.I,
)


def extract_room_hallmark(narration: str, label: str = "") -> str:
    """Extract the dominant physical anchor, structure or hallmark sentence from spontaneous narration."""
    if not narration or not narration.strip():
        return ""
    paragraphs = [part.strip() for part in re.split(r"\n\s*\n", narration.strip()) if part.strip()][:2]
    clean = re.sub(r"(?<!\w)[*_]+|[*_]+(?!\w)", "", " ".join(paragraphs))
    candidates = [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[\"'A-Z])", clean) if s.strip()]

    ranked: list[tuple[int, int, str]] = []
    for idx, s in enumerate(candidates):
        score = 0
        if _DIALOGUE_PATTERN.search(s):
            score -= 10
        if re.search(r"\b(?:you|your|you're|you've|climb|step|slip|walk|enter|enters|reach|push|draw)\b", s, re.I):
            score -= 6
        if re.match(r"^(?:you|as you|when you)\b", s, re.I):
            score -= 12
        f_matches = len(_FIXTURE_PATTERN.findall(s))
        score += f_matches * 4
        v_matches = len(_STATIC_VERB_PATTERN.findall(s))
        score += v_matches * 3
        if re.match(r"^(?:the\b|a\b|an\b|rows\b|stacks\b|dust\b|narrow\b|great\b|heavy\b)", s, re.I):
            score += 3
        ranked.append((score, -idx, s))

    if ranked:
        best = max(ranked, key=lambda x: (x[0], x[1]))
        if best[0] > 0:
            res = best[2].strip().rstrip(". ")
            if len(res) <= 240:
                return res + "." if res else ""
            shortened = res[:239].rsplit(" ", 1)[0].rstrip(" ,;:-")
            return shortened + "..."

    summary = _concise_scene_summary(narration, label=label, max_chars=220)
    clean_summary = summary.strip().rstrip(". ")
    return clean_summary + "." if clean_summary else ""


def summarize_state_change(resolved_event: dict[str, Any] | None, narration: str) -> str:
    """Extract a concise physical state change (items taken, barriers locked/barred, damage)."""
    changes: list[str] = []
    
    if isinstance(resolved_event, dict):
        event_type = str(resolved_event.get("type") or "")
        
        # 1. Resource / item pickups
        if "resource_pickup" in event_type or resolved_event.get("item_acquired"):
            item_name = resolved_event.get("item_name") or resolved_event.get("item", {}).get("name")
            if item_name:
                changes.append(f"{item_name} taken")
        elif resolved_event.get("loot_acquired"):
            loot = resolved_event.get("loot_acquired")
            if isinstance(loot, list) and loot:
                changes.append(", ".join(str(i) for i in loot) + " taken")
                
        # 2. Combat aftermath
        if "combat" in event_type or resolved_event.get("combat_outcome"):
            outcome = resolved_event.get("combat_outcome") or resolved_event.get("outcome")
            if outcome:
                changes.append(f"combat resolved ({outcome})")
                
        # 3. Barring / locking / searching
        roll = resolved_event.get("roll")
        if isinstance(roll, dict) and roll.get("success"):
            desc = str(resolved_event.get("description") or resolved_event.get("action") or "").lower()
            if "bar" in desc or "door" in desc:
                changes.append("door secured")
            elif "search" in desc:
                changes.append("area searched")

    # 4. If no mechanical change identified, inspect narration for physical state cues
    if not changes and narration:
        matches = _ACTION_RESULT_PATTERN.findall(narration)
        if matches:
            # Keep unique keywords
            seen = set()
            unique_cues = [m.lower() for m in matches if not (m.lower() in seen or seen.add(m.lower()))]
            changes.append("recent signs of " + ", ".join(unique_cues[:3]))

    return "; ".join(changes)


def update_current_room_memory(
    state: dict[str, Any],
    narration: str,
    resolved_event: dict[str, Any] | None = None,
) -> bool:
    """Post-narration hook: updates the persistent room memory of the active site area.
    
    Zero latency, runs synchronously after narration is committed to transcript.
    """
    if not isinstance(state, dict) or not narration or not narration.strip():
        return False

    root_id = active_site_root_id(state)
    root = state.get("locations", {}).get(root_id)
    memory = root.get("site_memory") if isinstance(root, dict) else None
    if not isinstance(memory, dict):
        return False

    curr_pos = str(memory.get("current_position") or "").strip()
    if not curr_pos:
        return False

    wanted = _normalized(curr_pos)
    target_area = None
    for area in memory.get("areas", []):
        if isinstance(area, dict) and _normalized(str(area.get("name") or "")) == wanted:
            target_area = area
            break

    if target_area is None:
        return False

    # Get or create room_memory sub-dict
    rm = target_area.setdefault("room_memory", {})
    turn_no = int(state.get("turn_no", 0) or 0)

    # 1. First visit or missing hallmark: extract hallmark from spontaneous narration
    if not rm.get("hallmark"):
        hallmark = extract_room_hallmark(narration, label=curr_pos)
        if hallmark:
            rm["hallmark"] = hallmark

    # 2. Update state changes if an action or noticeable event occurred
    state_delta = summarize_state_change(resolved_event, narration)
    if state_delta:
        existing_state = str(rm.get("last_state") or "").strip()
        if existing_state and state_delta not in existing_state:
            rm["last_state"] = f"{existing_state}; {state_delta}"[:180]
        else:
            rm["last_state"] = state_delta[:180]

    rm["updated_at_turn"] = turn_no
    return True


def room_recall_area(state: dict[str, Any], event: dict[str, Any] | None) -> str | None:
    """Recall only a previously observed destination on an actual new arrival."""
    if not isinstance(event, dict):
        return None
    move = event if event.get("type") in {"movement", "local_movement"} else event.get("movement")
    if not isinstance(move, dict) or not move.get("committed") or move.get("emergent") is True:
        return None
    root_id = active_site_root_id(state)
    memory = state.get("locations", {}).get(root_id, {}).get("site_memory")
    if not isinstance(memory, dict) or not memory.get("plan_lock"):
        return None
    pos = state.get("scene_position") or {}
    if pos.get("exterior_of_site_id"):
        return None
    destination = str(pos.get("label") or memory.get("current_position") or "")
    if move.get("from_id") == move.get("to_id") and _normalized(str(move.get("from_name") or "")) == _normalized(destination):
        return None
    for area in memory.get("areas", []):
        if (isinstance(area, dict) and area.get("status") == "observed"
                and _normalized(str(area.get("name") or "")) == _normalized(destination)
                and area.get("room_memory")):
            return area["name"]
    return None


def format_room_recall_for_prompt(area: dict[str, Any]) -> str | None:
    """Formats the concise 1-line room memory to inject into the prompt ONLY on re-entry."""
    if not isinstance(area, dict):
        return None
    rm = area.get("room_memory")
    if not isinstance(rm, dict):
        return None
    hallmark = str(rm.get("hallmark") or "").strip()
    last_state = str(rm.get("last_state") or "").strip()
    
    parts = []
    if hallmark:
        parts.append(hallmark)
    if last_state:
        parts.append(f"Last known state: {last_state}.")
        
    if not parts:
        return None
    return " ".join(parts)
