from __future__ import annotations

import re
from typing import Any

from .afflictions import cure_afflictions

REST_ACTION = re.compile(
    r"\b(?:rest(?:ing|ed)?|sleep(?:ing|s)?|bed\s+down|catch\s+(?:my|our)\s+breath|take\s+a\s+breather|"
    r"spend\s+the\s+night|turn\s+in)\b",
    re.I,
)
EXTENDED_REST = re.compile(r"\b(?:sleep(?:ing|s)?|bed\s+down|spend\s+the\s+night|turn\s+in)\b", re.I)
UNCOMMITTED = re.compile(
    r"(?:\?|\b(?:wonder|whether|what\s+if|if\s+i|can\s+i|could\s+i|would\s+i|might\s+i|should\s+i)\b)",
    re.I,
)

ORDINARY_REST_COOLDOWN = 6


def _recovery_state(state: dict[str, Any]) -> dict[str, Any]:
    recovery = state.setdefault("recovery", {})
    recovery.setdefault("last_ordinary_rest_turn", -999)
    recovery.setdefault("safe_lodging", None)
    recovery.setdefault("history", [])
    return recovery


def grant_recovery_service(state: dict[str, Any], service_kind: str) -> dict[str, Any]:
    """Apply a purchased service without turning it into an inventory item."""

    recovery = _recovery_state(state)
    turn_no = int(state.get("turn_no", 0) or 0)
    if service_kind == "lodging":
        recovery["safe_lodging"] = {
            "location_id": str(state.get("current_location_id") or ""),
            "purchased_at_turn": turn_no,
            "available_until_turn": turn_no + 4,
        }
        return {"service_kind": "lodging", "service_status": "reserved"}
    if service_kind == "treatment":
        player = state.setdefault("player", {})
        before = max(0, int(player.get("hp", 0) or 0))
        maximum = max(1, int(player.get("max_hp", 1) or 1))
        after = min(maximum, before + 5)
        player["hp"] = after
        removed = cure_afflictions(state)
        if "magic" in state and isinstance(state["magic"], dict):
            state["magic"].pop("strained_learning_sources", None)
            state["magic"].pop("failed_learning_sources", None)
        
        # Also heal companions
        companions = player.get("companions")
        if isinstance(companions, list):
            for companion in companions:
                if isinstance(companion, dict) and int(companion.get("hp", 0)) > 0:
                    c_before = max(0, int(companion.get("hp", 0)))
                    c_max = max(1, int(companion.get("max_hp", 1)))
                    companion["hp"] = min(c_max, c_before + 5)
        return {
            "service_kind": "treatment",
            "service_status": "completed",
            "hp_before": before,
            "hp_after": after,
            "hp_restored": after - before,
            "conditions_removed": removed,
        }
    return {"service_kind": service_kind, "service_status": "completed"}


def resolve_recovery_action(state: dict[str, Any], text: str) -> dict[str, Any] | None:
    """Resolve the small Aiantindus-style rest ladder with one cooldown."""

    action = REST_ACTION.search(str(text or ""))
    if action is None:
        return None
    hedge = UNCOMMITTED.search(str(text or ""))
    if hedge is not None and hedge.start() < action.start():
        return None
    combat = state.get("combat")
    alert = str(state.get("stealth", {}).get("local_alert") or "none")
    if (isinstance(combat, dict) and combat.get("status") == "active") or alert not in {"", "none"}:
        return {
            "type": "recovery_resolution",
            "committed": False,
            "success": False,
            "kind": "interrupted",
            "reason": "Immediate danger prevents restorative rest.",
        }

    recovery = _recovery_state(state)
    player = state.setdefault("player", {})
    before = max(0, int(player.get("hp", 0) or 0))
    maximum = max(1, int(player.get("max_hp", 1) or 1))
    turn_no = int(state.get("turn_no", 0) or 0)
    lodging = recovery.get("safe_lodging")
    safe = bool(
        isinstance(lodging, dict)
        and str(lodging.get("location_id") or "") == str(state.get("current_location_id") or "")
        and turn_no <= int(lodging.get("available_until_turn", -1) or -1)
    )
    if safe:
        after = maximum
        recovery["safe_lodging"] = None
        kind = "safe_lodging"
    else:
        last = int(recovery.get("last_ordinary_rest_turn", -999) or -999)
        if turn_no - last < ORDINARY_REST_COOLDOWN:
            return {
                "type": "recovery_resolution",
                "committed": True,
                "success": False,
                "kind": "ordinary_rest",
                "reason": "Ordinary rest cannot restore HP again so soon.",
                "hp_before": before,
                "hp_after": before,
                "hp_restored": 0,
                "cooldown_remaining": ORDINARY_REST_COOLDOWN - (turn_no - last),
            }
        amount = 2 if EXTENDED_REST.search(str(text or "")) else 1
        after = min(maximum, before + amount)
        recovery["last_ordinary_rest_turn"] = turn_no
        kind = "extended_rest" if amount == 2 else "ordinary_rest"
    player["hp"] = after

    # Also heal companions
    companions = player.get("companions")
    if isinstance(companions, list):
        for companion in companions:
            if isinstance(companion, dict) and int(companion.get("hp", 0)) > 0:
                c_before = max(0, int(companion.get("hp", 0)))
                c_max = max(1, int(companion.get("max_hp", 1)))
                c_after = c_max if safe else min(c_max, c_before + amount)
                companion["hp"] = c_after
    if "magic" in state and isinstance(state["magic"], dict):
        state["magic"].pop("strained_learning_sources", None)
        state["magic"].pop("failed_learning_sources", None)

    event = {
        "type": "recovery_resolution",
        "committed": True,
        "success": True,
        "kind": kind,
        "hp_before": before,
        "hp_after": after,
        "hp_restored": after - before,
        "conditions_removed": [],
    }
    history = recovery.setdefault("history", [])
    history.append({"turn": turn_no, "kind": kind, "hp_restored": after - before})
    recovery["history"] = history[-12:]
    return event
