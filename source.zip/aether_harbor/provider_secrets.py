from __future__ import annotations

"""
Aether Harbor — Centralized Provider Credentials & Defaults
These default keys are embedded directly in the server environment so that
any public visitor can play immediately without configuration or prompts.
"""

# Google AI Studio / Gemini API
# Get your free key at: https://aistudio.google.com/app/apikey
DEFAULT_GOOGLE_API_KEY = ""

# Cloudflare Workers AI
# Account ID and API Token from Cloudflare Dashboard -> AI -> Workers AI
DEFAULT_CLOUDFLARE_ACCOUNT_ID = ""
DEFAULT_CLOUDFLARE_API_TOKEN = ""

# OpenRouter Free Tier
# Key from https://openrouter.ai/keys
DEFAULT_OPENROUTER_API_KEY = ""
