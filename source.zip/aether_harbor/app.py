from __future__ import annotations

import copy
import json
import math
import queue
import random
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk
from typing import Any

from .books import note_book_seed_narration
from .active_situations import note_active_situation_narration
from .afflictions import advance_afflictions, note_affliction_narration
from .island_bank import maybe_bind_island
from .scenarios import (
    emergent_scenario_due,
    maybe_activate_scenario,
    note_scenario_narration,
    observe_scenario_action,
    run_emergent_scenario_architect,
)
from .local_model import LocalQwen
from .loot_splitter import split_compound_loot
from .fate import SEGMENTS, SPIN_DURATION_MS, remaining_cooldown, spin as spin_fate
from .movement import (
    _emergent_id,
    capture_passage_offer,
    cement_arrival_excerpt,
    commit_pending_site_area_observation,
    commit_pending_site_transition,
    refresh_emergent_place_definition,
)
from .npc_engine import arrival_scene_occupied, maybe_seed as maybe_npc_seed
from .mechanics import (
    combat_defense_pending,
    note_combat_episode_narration,
    parse_manual_roll,
    parse_manual_rolls,
    resolve_pending_combat_defense,
)
from .items import capture_resource_offer
from .local_games import capture_local_game_offer, classify_local_game_action
from .celestial_spheres import classify_celestial_spheres_action, is_celestial_spheres_offered
from .persistence import CampaignStore
from .room_secretary import (
    note_site_transition,
    room_memory_due,
    run_room_secretary,
    apply_room_memory_result,
)
from .prompting import build_messages, event_ledger_line, record_mechanical_ledger
from .party import party_advice
from .party_runtime import prepare_party_profile, finish_party_review, apply_party_review
from .risk_classifier import (
    classify_action_risk,
    classify_chase_setup,
    classify_new_item_profile,
    classify_new_opponent,
    classify_world_beat,
)
from .scene_pressure import apply_action_consequences
from .recap_secretary import due as recap_due
from .world_clock import due as world_clock_due
from .world_clock import run as run_world_clock
from .recap_secretary import run as run_recap_secretary
from .secretary import due as secretary_due
from .secretary import run as run_secretary
from .spatial_adjudication import apply_for_anchor as apply_spatial_survey_for_anchor
from .spatial_secretary import reserve_selected_exterior_site
from .spatial_adjudication import run as run_spatial_secretary
from .spatial_adjudication import survey_mode as spatial_survey_mode
from .spatial_secretary import note_material_reveal_from_narration
from .spatial_secretary import _island_survey_due
from .state import CLASS_PROFILES, current_location, inventory_summary, new_campaign
from .state_curator import due as curator_due
from .state_curator import queue_after_narration as queue_curator_after_narration
from .state_curator import run as run_state_curator
from .turn_engine import (
    commit_world_beat,
    pending_roll_prompt,
    preview_pending_combat_defense,
    preview_player_action,
    resolve_player_action,
)


BG = "#1F1C3A"
PANEL = "#302B57"
FIELD = "#3E386C"
SLATE = "#6A5ACD"
TEXT = "#FFFFE0"
MUTED = "#DAD3AE"
ACCENT = "#FAF0BE"
USER = "#BDB4FF"
WARM_GOLD = "#E6C96A"
ERROR = "#EB7070"
PEACH_PINK = "#FF9A8B"
HEADING_FONT = "Constantia"
BODY_FONT = "Candara"
PROTOTYPE_BUILD = "2026-10-17-gemma-v33-npc-transcript"
AQUA_VELVET = "#00A29E"
PALATINATE_BLUE = "#273BE2"
JASMINE = "#F8DE7E"
FATE_COLORS = {
    "AMBUSH": PALATINATE_BLUE,
    "MIRACLE": JASMINE,
    "RUIN": PALATINATE_BLUE,
    "EPIPHANY": AQUA_VELVET,
    "CURSE": PALATINATE_BLUE,
    "FORTUNE": JASMINE,
    "DESPAIR": PALATINATE_BLUE,
    "DELIVERANCE": AQUA_VELVET,
}


def transcript_speaker_label(state: dict[str, Any] | None, speaker: str) -> str:
    """Keep transcript roles machine-stable while showing the player's name."""

    if speaker.casefold() not in {"visitor", "player", "user"}:
        return speaker
    if not isinstance(state, dict):
        return "Visitor"
    player = state.get("player") if isinstance(state.get("player"), dict) else {}
    return str(player.get("name") or "Visitor")


class AetherHarborApp:
    def __init__(self, root: tk.Tk, project_root: Path):
        self.root = root
        self.project_root = Path(project_root)
        self.runtime_dir = self.project_root / "data" / "runtime"
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        self.store = CampaignStore(self.runtime_dir / "aether_harbor.sqlite")
        # Version changes must never delete historical campaigns or transcripts.
        # Every application launch begins a fresh playthrough. Older campaigns
        # remain database-separated only for deliberately selected shared
        # echoes; their transcript and state are never resumed.
        self.state: dict[str, Any] | None = None
        self.events: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.generating = False
        self.pending_action: dict[str, Any] | None = None
        self.pending_roll_max = 20
        self.ai_buffer: list[str] = []
        self.active_generation_context: dict[str, Any] | None = None
        self.spatial_running = False
        self.spatial_jobs_pending = 0
        self.grounding_auditor_running = False
        self.opening_pending = False
        self.secretary_after_id: str | None = None
        self.secretary_running = False
        self.secretary_pending_kind: str | None = None
        self.queued_player_text: str | None = None
        self.queued_player_visible = False
        self.queued_fate_spin = False
        self.background_last_started_turn = -999
        self.fate_window: tk.Toplevel | None = None
        self.fate_canvas: tk.Canvas | None = None
        self.fate_result_label: tk.Label | None = None
        self.fate_status_label: tk.Label | None = None
        self.fate_timer_label: tk.Label | None = None
        self.fate_countdown_after_id: str | None = None
        self.fate_animation_after_id: str | None = None
        self.pending_fate_event: dict[str, Any] | None = None
        self.fate_animation_started_at = 0.0
        self.fate_animation_target = 0.0

        settings = self._load_settings()
        self.inference_lock = threading.Lock()
        self.model = LocalQwen(
            model_id=None,
            base_url=settings["base_url"],
            request_lock=self.inference_lock,
        )
        # Background work has a separate model handle but shares the inference
        # lock: two LM Studio calls must never run in parallel on this machine.
        self.background_model = LocalQwen(
            model_id=None,
            base_url=settings["base_url"],
            request_lock=self.inference_lock,
        )

        self._configure_window()
        self._build_ui()
        # The initial character dialog is positioned relative to the real,
        # mapped application window.  Before the root has become visible,
        # Windows may still report its provisional placement instead.
        self.root.update_idletasks()
        if not self.root.winfo_viewable():
            self.root.wait_visibility()
        self._load_or_create_campaign()
        self.root.after(30, self._poll_events)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        threading.Thread(target=self._prepare_model, daemon=True).start()

    def _load_settings(self) -> dict[str, Any]:
        path = self.project_root / "settings.json"
        defaults = {
            "base_url": "http://127.0.0.1:1234",
        }
        if not path.exists():
            return defaults
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return defaults
        return {**defaults, **loaded}

    def _configure_window(self) -> None:
        self.root.title("Aether Harbor — Gemma v.35")
        self.root.configure(bg=BG)
        screen_width = int(self.root.winfo_screenwidth())
        screen_height = int(self.root.winfo_screenheight())
        window_width = min(1120, screen_width - 40)
        window_height = min(1080, screen_height - 80)
        x = max(10, (screen_width - window_width) // 2)
        y = max(10, (screen_height - window_height) // 2 - 20)
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.root.minsize(min(820, screen_width - 40), min(600, screen_height - 80))
        self.root.option_add("*Font", (BODY_FONT, 11))

    def _build_ui(self) -> None:
        outer = tk.Frame(self.root, bg=BG, padx=26, pady=20)
        outer.pack(fill="both", expand=True)

        header = tk.Frame(outer, bg=BG)
        header.pack(fill="x", pady=(0, 10))
        title_row = tk.Frame(header, bg=BG)
        title_row.pack(fill="x")
        tk.Label(
            title_row,
            text="AETHER HARBOR",
            bg=BG,
            fg=ACCENT,
            font=(HEADING_FONT, 20, "bold"),
            anchor="w",
        ).pack(side="left", fill="x", expand=True)
        self.wheel_button = tk.Button(
            title_row,
            text="Wheel of Fate",
            command=self._spin_wheel,
            bg=PANEL,
            fg=ACCENT,
            activebackground=SLATE,
            activeforeground=TEXT,
            relief="flat",
            font=(HEADING_FONT, 12, "bold"),
            padx=13,
            pady=5,
        )
        self.wheel_button.pack(side="right")
        self.inventory_button = tk.Button(
            title_row,
            text="Inventory",
            command=self._show_inventory_window,
            bg=PANEL,
            fg=ACCENT,
            activebackground=SLATE,
            activeforeground=TEXT,
            relief="flat",
            font=(HEADING_FONT, 12, "bold"),
            padx=13,
            pady=5,
        )
        self.inventory_button.pack(side="right", padx=(0, 10))
        tk.Label(
            header,
            text="A port of seven possible worlds · narrated by the local model loaded in LM Studio",
            bg=BG,
            fg=MUTED,
            font=(BODY_FONT, 12),
            anchor="w",
        ).pack(fill="x", pady=(2, 0))

        self.status_bar = tk.Frame(outer, bg=PANEL, padx=14, pady=6)
        self.status_bar.pack(fill="x", pady=(0, 6))
        self.place_status = tk.Label(
            self.status_bar, text="", bg=PANEL, fg=ACCENT,
            font=(HEADING_FONT, 11, "bold"), anchor="w"
        )
        self.place_status.pack(side="left", fill="x", expand=True)
        self.player_status = tk.Label(
            self.status_bar, text="", bg=PANEL, fg=TEXT,
            font=(BODY_FONT, 11), anchor="e"
        )
        self.player_status.pack(side="right")

        self.scene_frame = tk.Frame(outer, bg=SLATE, padx=17, pady=11)
        self.scene_frame.pack(fill="x", pady=(0, 10))
        self.scene_title = tk.Label(
            self.scene_frame, text="", bg=SLATE, fg=TEXT,
            font=(HEADING_FONT, 15, "bold"), anchor="w"
        )
        self.scene_title.pack(fill="x")
        self.scene_summary = tk.Label(
            self.scene_frame, text="", bg=SLATE, fg=TEXT,
            font=(BODY_FONT, 12), anchor="w", justify="left", wraplength=1000
        )
        self.scene_summary.pack(fill="x", pady=(3, 0))

        footer = tk.Frame(outer, bg=BG)
        footer.pack(side="bottom", fill="x", pady=(7, 0))
        self.model_status = tk.Label(
            footer,
            text="Connecting to the loaded model in LM Studio…",
            bg=BG,
            fg=MUTED,
            font=(BODY_FONT, 9),
            anchor="w",
        )
        self.model_status.pack(side="left", fill="x", expand=True)
        tk.Label(
            footer,
            text="Voyage autosaved locally",
            bg=BG,
            fg=MUTED,
            font=(BODY_FONT, 9),
            anchor="e",
        ).pack(side="right")

        input_frame = tk.Frame(outer, bg=FIELD)
        self.input_frame = input_frame
        input_frame.pack(side="bottom", fill="x")
        self.input_box = tk.Text(
            input_frame,
            height=4,
            wrap="word",
            bg=FIELD,
            fg=TEXT,
            insertbackground=TEXT,
            selectbackground=SLATE,
            selectforeground=TEXT,
            relief="flat",
            borderwidth=0,
            padx=14,
            pady=10,
            font=(BODY_FONT, 15),
        )
        self.input_box.pack(fill="x")
        self.input_box.bind("<Return>", self._on_enter)
        self.input_box.bind("<Shift-Return>", self._on_shift_enter)
        self.input_box.bind("<KeyPress>", self._on_keypress, add="+")

        self._create_roll_panel()
        self.root.bind_all("<Return>", self._on_global_return, add="+")

        transcript_frame = tk.Frame(outer, bg=PANEL, highlightthickness=0)
        transcript_frame.pack(side="top", fill="both", expand=True, pady=(0, 10))
        scrollbar = ttk.Scrollbar(transcript_frame, orient="vertical")
        scrollbar.pack(side="right", fill="y")
        self.transcript = tk.Text(
            transcript_frame,
            wrap="word",
            bg=PANEL,
            fg=TEXT,
            insertbackground=TEXT,
            selectbackground=SLATE,
            selectforeground=TEXT,
            relief="flat",
            borderwidth=0,
            padx=14,
            pady=12,
            font=(BODY_FONT, 15),
            spacing1=1,
            spacing3=3,
            yscrollcommand=scrollbar.set,
            state="disabled",
        )
        self.transcript.pack(side="left", fill="both", expand=True)
        scrollbar.configure(command=self.transcript.yview)
        self.transcript.tag_configure("visitor_heading", foreground=USER, font=(HEADING_FONT, 15, "bold"), spacing1=8)
        self.transcript.tag_configure("gm_heading", foreground=ACCENT, font=(HEADING_FONT, 15, "bold"), spacing1=8)
        self.transcript.tag_configure("body", foreground=TEXT, font=(BODY_FONT, 15))
        self.transcript.tag_configure("visitor_body", foreground=WARM_GOLD, font=(BODY_FONT, 15))
        self.transcript.tag_configure("ledger", foreground=MUTED, font=(BODY_FONT, 11, "italic"), spacing1=3, spacing3=5)
        self.transcript.tag_configure("error", foreground=ERROR, font=(BODY_FONT, 12))
        # No custom palette here: on Windows a plain Tk menu uses the familiar
        # native light context-menu treatment the user expects.
        self.transcript_menu = tk.Menu(self.root, tearoff=False)
        self.transcript_menu.add_command(label="Copy", command=self._copy_transcript_selection)
        self.transcript_menu.add_command(label="Select all", command=self._select_all_transcript)
        self.transcript.bind("<Button-1>", lambda _event: self.transcript.focus_set(), add="+")
        self.transcript.bind("<Button-3>", self._show_transcript_menu)
        self.transcript.bind("<Control-c>", self._copy_transcript_selection)
        self.transcript.bind("<Control-a>", self._select_all_transcript)

    def _create_roll_panel(self) -> None:
        # Exact r11 placement/composition recovered from the Codex session log.
        self.roll_panel = tk.Frame(self.input_frame, bg=BG)
        self.roll_card = tk.Frame(
            self.roll_panel,
            bg=PANEL,
            padx=16,
            pady=10,
            highlightthickness=1,
            highlightbackground=PEACH_PINK,
            highlightcolor=PEACH_PINK,
        )
        self.roll_card.pack(fill="x")
        roll_header = tk.Frame(self.roll_card, bg=PANEL)
        roll_header.pack(fill="x")
        self.roll_notice = tk.Label(
            roll_header,
            text="PENDING ROLL",
            bg=PANEL,
            fg=PEACH_PINK,
            font=(HEADING_FONT, 11, "bold"),
            anchor="w",
            justify="left",
        )
        self.roll_notice.pack(side="left")
        self.roll_detail = tk.Label(
            roll_header,
            text="D20 · AGI · DC 13",
            bg=PANEL,
            fg=TEXT,
            font=(BODY_FONT, 11, "bold"),
            anchor="e",
        )
        self.roll_detail.pack(side="right")

        roll_controls = tk.Frame(self.roll_card, bg=PANEL)
        roll_controls.pack(fill="x", pady=(8, 0))
        self.roll_instruction = tk.Label(
            roll_controls,
            text="Enter your physical result (1–20)",
            bg=PANEL,
            fg=MUTED,
            font=(BODY_FONT, 11),
            anchor="w",
        )
        self.roll_instruction.pack(side="left", fill="x", expand=True)
        self.roll_input = tk.Entry(
            roll_controls,
            bg=FIELD,
            fg=TEXT,
            insertbackground=TEXT,
            selectbackground=SLATE,
            selectforeground=TEXT,
            relief="flat",
            font=(BODY_FONT, 15),
            width=14,
            justify="left",
        )
        self.roll_input.pack(side="left", padx=(16, 8), ipady=7)
        self.roll_input.bind("<Return>", self._on_roll_enter)
        self.roll_button = tk.Button(
            roll_controls,
            text="Submit roll",
            command=self._submit_pending_roll,
            bg=SLATE,
            fg=TEXT,
            activebackground=ACCENT,
            activeforeground=BG,
            relief="flat",
            font=(HEADING_FONT, 11, "bold"),
            padx=17,
            pady=7,
        )
        self.roll_button.pack(side="right")
        self.roll_error = tk.Label(
            self.roll_card,
            text="",
            bg=PANEL,
            fg=ERROR,
            font=(BODY_FONT, 10),
            anchor="w",
        )

    def _load_or_create_campaign(self) -> None:
        campaign_info = self._campaign_dialog(required=True)
        if campaign_info is None:
            self.root.after(10, self._on_close)
            return
            
        appearance = self._appearance_dialog(required=True)
        if appearance is None:
            self.root.after(10, self._on_close)
            return
            
        self.state = new_campaign(campaign_info["name"], campaign_info["class"], appearance)
        self.state["prototype_build"] = PROTOTYPE_BUILD
        
        self.store.create_campaign(self.state)
        self.opening_pending = True
        self._refresh_state_display()
        self.input_box.focus_set()

    def _campaign_dialog(self, *, required: bool) -> dict[str, Any] | None:
        dialog = tk.Toplevel(self.root)
        dialog.withdraw()
        dialog.title("Aether Harbor")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        result: dict[str, Any] = {}

        body = tk.Frame(dialog, bg=BG, padx=24, pady=20)
        body.pack(fill="both", expand=True)
        tk.Label(body, text="Enter Aether Harbor", bg=BG, fg=ACCENT, font=(HEADING_FONT, 19, "bold")).pack(anchor="w")
        tk.Label(body, text="Choose a name and class.", bg=BG, fg=MUTED, font=(BODY_FONT, 12)).pack(anchor="w", pady=(3, 16))

        tk.Label(body, text="Name", bg=BG, fg=TEXT, font=(BODY_FONT, 12)).pack(anchor="w")
        name_var = tk.StringVar(value="Visitor")
        name_entry = tk.Entry(body, textvariable=name_var, bg=FIELD, fg=TEXT, insertbackground=TEXT, relief="flat", font=(BODY_FONT, 14), width=38)
        name_entry.pack(fill="x", pady=(3, 12), ipady=5)

        placeholder_active = {"value": True}

        def replace_name_placeholder(event: tk.Event[Any]) -> str | None:
            if not placeholder_active["value"] or name_var.get() != "Visitor":
                return None
            if event.keysym in {"BackSpace", "Delete"}:
                name_var.set("")
                placeholder_active["value"] = False
                return "break"
            if event.char and event.char.isprintable() and not (event.state & 0x0004):
                name_var.set("")
                placeholder_active["value"] = False
            return None

        def replace_name_placeholder_for_paste(_event: tk.Event[Any]) -> None:
            if placeholder_active["value"] and name_var.get() == "Visitor":
                name_var.set("")
                placeholder_active["value"] = False

        name_entry.bind("<KeyPress>", replace_name_placeholder, add="+")
        name_entry.bind("<<Paste>>", replace_name_placeholder_for_paste, add="+")

        tk.Label(body, text="Class", bg=BG, fg=TEXT, font=(BODY_FONT, 12)).pack(anchor="w")
        class_var = tk.StringVar(value="fighter")
        for class_id, profile in CLASS_PROFILES.items():
            row = tk.Frame(body, bg=BG)
            row.pack(fill="x", pady=2)
            tk.Radiobutton(
                row,
                text=f"{profile['label']}  ·  {profile['max_hp']} HP  ·  {profile['silver']} silver",
                value=class_id,
                variable=class_var,
                bg=BG,
                fg=TEXT,
                activebackground=BG,
                activeforeground=ACCENT,
                selectcolor=FIELD,
                font=(BODY_FONT, 13),
                anchor="w",
            ).pack(fill="x")

        buttons = tk.Frame(body, bg=BG)
        buttons.pack(fill="x", pady=(18, 0))

        def begin() -> None:
            result["name"] = name_var.get()
            result["class"] = class_var.get()
            dialog.destroy()

        begin_button = tk.Button(
            buttons, text="Next", command=begin, bg=SLATE, fg=TEXT,
            activebackground=FIELD, activeforeground=TEXT, relief="flat",
            font=(BODY_FONT, 13, "bold"), padx=18, pady=6
        )
        begin_button.pack(side="right")
        if not required:
            tk.Button(
                buttons, text="Cancel", command=dialog.destroy, bg=PANEL, fg=TEXT,
                activebackground=FIELD, activeforeground=TEXT, relief="flat",
                font=(BODY_FONT, 13), padx=16, pady=6
            ).pack(side="right", padx=(0, 8))

        dialog.protocol("WM_DELETE_WINDOW", (lambda: None) if required else dialog.destroy)
        dialog.bind("<Return>", lambda _event: begin())
        dialog.update_idletasks()
        self.root.update_idletasks()

        # Map the dialog invisibly for one layout pass so Tk/Windows can report
        # the real title-bar and border extents before it is centered.
        dialog.attributes("-alpha", 0.0)
        dialog.deiconify()
        dialog.update_idletasks()
        root_side = max(0, self.root.winfo_rootx() - self.root.winfo_x())
        root_top = max(0, self.root.winfo_rooty() - self.root.winfo_y())
        dialog_side = max(0, dialog.winfo_rootx() - dialog.winfo_x())
        dialog_top = max(0, dialog.winfo_rooty() - dialog.winfo_y())
        root_outer_width = self.root.winfo_width() + 2 * root_side
        root_outer_height = self.root.winfo_height() + root_top + root_side
        dialog_outer_width = dialog.winfo_width() + 2 * dialog_side
        dialog_outer_height = dialog.winfo_height() + dialog_top + dialog_side
        x = self.root.winfo_x() + (root_outer_width - dialog_outer_width) // 2
        y = self.root.winfo_y() + (root_outer_height - dialog_outer_height) // 2
        dialog.geometry(f"+{x}+{y}")
        dialog.update_idletasks()
        dialog.attributes("-alpha", 1.0)
        dialog.lift(self.root)
        dialog.grab_set()
        name_entry.focus_set()
        name_entry.selection_range(0, "end")
        name_entry.icursor("end")
        self.root.wait_window(dialog)
        return result if "name" in result else None

    def _appearance_dialog(self, *, required: bool) -> str | None:
        dialog = tk.Toplevel(self.root)
        dialog.withdraw()
        dialog.title("Aether Harbor")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        result: dict[str, str] = {}

        body = tk.Frame(dialog, bg=BG, padx=24, pady=20)
        body.pack(fill="both", expand=True)
        tk.Label(body, text="Appearance", bg=BG, fg=ACCENT, font=(HEADING_FONT, 19, "bold")).pack(anchor="w")
        tk.Label(body, text="Briefly describe your character.", bg=BG, fg=MUTED, font=(BODY_FONT, 12)).pack(anchor="w", pady=(3, 16))

        app_entry = tk.Text(body, bg=FIELD, fg=TEXT, insertbackground=TEXT, relief="flat", font=(BODY_FONT, 14), width=38, height=3)
        app_entry.pack(fill="x", pady=(3, 20), ipady=5)

        buttons = tk.Frame(body, bg=BG)
        buttons.pack(fill="x", pady=(10, 0))

        def begin() -> None:
            appearance = app_entry.get("1.0", "end-1c").strip()
            if not appearance:
                return
            result["appearance"] = appearance
            dialog.destroy()

        begin_button = tk.Button(
            buttons, text="Begin", command=begin, bg=SLATE, fg=TEXT,
            activebackground=FIELD, activeforeground=TEXT, relief="flat",
            font=(BODY_FONT, 13, "bold"), padx=18, pady=6
        )
        begin_button.pack(side="right")
        if not required:
            tk.Button(
                buttons, text="Cancel", command=dialog.destroy, bg=PANEL, fg=TEXT,
                activebackground=FIELD, activeforeground=TEXT, relief="flat",
                font=(BODY_FONT, 13), padx=16, pady=6
            ).pack(side="right", padx=(0, 8))

        dialog.protocol("WM_DELETE_WINDOW", (lambda: None) if required else dialog.destroy)
        def on_return(event: tk.Event[Any]) -> str:
            begin()
            return "break"
        app_entry.bind("<Return>", on_return)
        dialog.bind("<Return>", lambda _event: begin())
        dialog.update_idletasks()
        self.root.update_idletasks()

        dialog.attributes("-alpha", 0.0)
        dialog.deiconify()
        dialog.update_idletasks()
        root_side = max(0, self.root.winfo_rootx() - self.root.winfo_x())
        root_top = max(0, self.root.winfo_rooty() - self.root.winfo_y())
        dialog_side = max(0, dialog.winfo_rootx() - dialog.winfo_x())
        dialog_top = max(0, dialog.winfo_rooty() - dialog.winfo_y())
        root_outer_width = self.root.winfo_width() + 2 * root_side
        root_outer_height = self.root.winfo_height() + root_top + root_side
        dialog_outer_width = dialog.winfo_width() + 2 * dialog_side
        dialog_outer_height = dialog.winfo_height() + dialog_top + dialog_side
        x = self.root.winfo_x() + (root_outer_width - dialog_outer_width) // 2
        y = self.root.winfo_y() + (root_outer_height - dialog_outer_height) // 2
        dialog.geometry(f"+{x}+{y}")
        dialog.update_idletasks()
        dialog.attributes("-alpha", 1.0)
        dialog.lift(self.root)
        dialog.grab_set()
        app_entry.focus_set()
        self.root.wait_window(dialog)
        
        return result.get("appearance")

    def _prepare_model(self) -> None:
        try:
            self.model.ensure_ready(lambda text: self.events.put(("status", text)))
            try:
                self.background_model.ensure_ready()
            except Exception:
                # Background memory is optional; foreground play stays live.
                pass
            self.events.put(("model_ready", None))
        except Exception as exc:
            self.events.put(("model_error", str(exc)))

    def _start_opening(self) -> None:
        if not self.state or self.generating or not self.opening_pending:
            return
        self.opening_pending = False
        action = "Begin the voyage in Aether Harbor."
        self._start_generation(action, resolved_event=None, show_player=False)

    def _on_enter(self, event: tk.Event[Any]) -> str:
        if event.state & 0x0001:
            return ""
        if self.pending_action:
            self._submit_pending_roll()
            return "break"
        self._send_player_text()
        return "break"

    def _on_global_return(self, _event: tk.Event[Any]) -> str | None:
        if not self.pending_action:
            return None
        self._submit_pending_roll()
        return "break"

    def _on_roll_enter(self, _event: tk.Event[Any]) -> str:
        self._submit_pending_roll()
        return "break"

    def _on_shift_enter(self, _event: tk.Event[Any]) -> None:
        self.input_box.insert("insert", "\n")

    def _on_keypress(self, _event: tk.Event[Any]) -> None:
        self._cancel_secretary_idle()

    def _send_player_text(self) -> None:
        if self.generating or not self.state or not self.model.base_url:
            return
        if self.state.get("campaign_status") == "game_over":
            self.model_status.configure(text="GAME OVER · restart Aether Harbor for a new voyage", fg=ERROR)
            return
        text = self.input_box.get("1.0", "end-1c").strip()
        if not text:
            return
        self.input_box.delete("1.0", "end")
        if self._background_call_running():
            # Structured Secretary output is atomic. Do not cancel and lose it,
            # and do not start the narrator beside it. Hold at most one player
            # action until the current memory job has committed.
            self.queued_player_text = text
            self.queued_player_visible = True
            self._append_message("Visitor", text)
            self.input_box.configure(state="disabled")
            # Use exactly the pre-queue foreground status. Background machinery
            # remains wholly invisible to the player.
            self.model_status.configure(text="Local AI is judging the action…", fg=ACCENT)
            return
        self._begin_player_text(text)

    def _begin_player_text(self, text: str, show_player: bool = True) -> None:
        if self.generating or not self.state or not self.model.base_url:
            return
        retry = self.state.get("pending_site_plan_retry")
        if isinstance(retry, dict):
            self.queued_player_text = text
            self.queued_player_visible = not show_player
            self._start_spatial_survey(**{key: retry[key] for key in
                ("player_text", "narration", "resolved_event", "planning_mode")})
            return
        self._cancel_secretary_idle()
        # The semantic-authority checkpoint restores V9's six full foreground exchanges. The extra immediate
        # exchange materially helped conversational relevance in transcript
        # comparisons; speed tuning can be revisited outside this checkpoint.
        recent_before = self.store.recent_turns(self.state["campaign_id"], limit=12)
        self.state["turn_no"] = int(self.state.get("turn_no", 0)) + 1
        sequence_no = self.store.append_turn(self.state["campaign_id"], "Visitor", text)
        from .secretary import note_transcript_scope
        note_transcript_scope(self.state, sequence_no)
        if show_player:
            self._append_message("Visitor", text)
        self.generating = True
        self.input_box.configure(state="disabled")
        self.model_status.configure(text="Local AI is judging the action…", fg=ACCENT)
        state = self.state

        def worker() -> None:
            pending = state.get("pending_party_review")
            if isinstance(pending, dict):
                review = finish_party_review(model=self.model, state=state, **pending)
                event = apply_party_review(state, review)
                self.events.put(("party_notice", {"event": event, "error": review.get("error")}))
                if review.get("error"):
                    self.events.put(("party_retry_failed", None))
                    return
            # Relevance may open a compact scenario before the semantic judge,
            # so the very first substantive solution can earn a flag. Merely
            # mentioning or asking still earns nothing because the judge owns
            # progress and Python validates the resolved outcome afterward.
            try:
                maybe_activate_scenario(state, text)
            except Exception:
                # Scenario relevance is optional layered context and must not
                # prevent the foreground action from being judged.
                pass
            try:
                semantic_roll = classify_action_risk(
                    model=self.model,
                    state=state,
                    recent_turns=recent_before,
                    player_text=text,
                )
                classifier_error = None
            except Exception as exc:
                # Technical classifier failure alone activates the old narrow
                # regex guard. A valid Qwen "no roll" is never overridden.
                semantic_roll = None
                classifier_error = str(exc)
            if semantic_roll is not None:
                try:
                    semantic_roll = split_compound_loot(
                        model=self.model,
                        semantic_roll=semantic_roll,
                        player_text=text,
                        recent_turns=recent_before,
                    )
                except Exception:
                    # The rare clarification is advisory. The primary semantic
                    # judgment remains valid if this small helper fails.
                    pass
                combat_advice = (
                    semantic_roll.get("combat")
                    if isinstance(semantic_roll.get("combat"), dict)
                    else None
                )
                if (
                    isinstance(combat_advice, dict)
                    and combat_advice.get("action") == "attack"
                    and not (
                        isinstance(state.get("combat"), dict)
                        and state["combat"].get("status") == "active"
                    )
                ):
                    try:
                        assessment = classify_new_opponent(
                            model=self.model,
                            state=state,
                            recent_turns=recent_before,
                            player_text=text,
                            opponent_name=str(combat_advice.get("target") or ""),
                        )
                        if isinstance(assessment, dict):
                            combat_advice.update(assessment)
                    except Exception:
                        # A failed relevant-only assessment falls back to the
                        # neutral technical profile; it never blocks the turn.
                        pass
                chase_advice = (
                    semantic_roll.get("chase")
                    if isinstance(semantic_roll.get("chase"), dict)
                    else None
                )
                if (
                    isinstance(chase_advice, dict)
                    and chase_advice.get("action") == "start"
                    and not str(chase_advice.get("quarry") or "").strip()
                ):
                    try:
                        setup = classify_chase_setup(
                            model=self.model,
                            recent_turns=recent_before,
                            player_text=text,
                        )
                        if isinstance(setup, dict):
                            semantic_roll["chase"] = setup
                    except Exception:
                        semantic_roll["chase"] = {
                            "action": "NONE", "quarry": "", "stake": "",
                            "escape": "", "anchor": "",
                        }
                resource_advice = (
                    semantic_roll.get("resource_action")
                    if isinstance(semantic_roll.get("resource_action"), dict)
                    else None
                )
                if (
                    isinstance(resource_advice, dict)
                    and resource_advice.get("kind") in {"take", "purchase", "receive_item"}
                    and resource_advice.get("status") == "confirmed"
                    and resource_advice.get("item_kind") in {
                        "weapon", "armor", "tool", "valuable", "clothing", "consumable", "document", "misc"
                    }
                ):
                    try:
                        item_profile = classify_new_item_profile(
                            model=self.model,
                            recent_turns=recent_before,
                            player_text=text,
                            item_name=str(resource_advice.get("item") or ""),
                            item_kind=str(resource_advice.get("item_kind") or ""),
                        )
                        if isinstance(item_profile, dict):
                            resource_advice["item_profile"] = item_profile
                    except Exception:
                        # The legacy conservative item shape remains a narrow
                        # technical fallback for this rare acquisition beat.
                        pass
                party = party_advice(semantic_roll)
                try:
                    party = prepare_party_profile(model=self.model, state=state, recent_turns=recent_before,
                                                  player_text=text, advice=party)
                except Exception:
                    # No neutral substitute: immediate post-narration review retries the profile.
                    pass
                semantic_roll["party_action"] = party
                if is_celestial_spheres_offered(state):
                    try:
                        cs_advice = classify_celestial_spheres_action(
                            model=self.model,
                            state=state,
                            recent_turns=recent_before,
                            player_text=text,
                        )
                        if isinstance(cs_advice, dict):
                            semantic_roll["celestial_spheres"] = cs_advice
                            # The engine dispatches table actions before generic D20
                            # handling. Preserve risk data for combat/other actions.
                    except Exception:
                        pass
                if (semantic_roll.get("celestial_spheres") or {}).get("action", "NONE") == "NONE":
                    try:
                        dice_advice = classify_local_game_action(model=self.model, state=state,
                            recent_turns=recent_before, player_text=text)
                        if dice_advice is not None:
                            semantic_roll["local_game"] = dice_advice
                    except Exception:
                        # Fail closed for table actions; do not convert a question
                        # into a payment/roll via the legacy text fallback.
                        semantic_roll["local_game"] = {"action": "NONE", "stake": 0}
            try:
                world_beat = classify_world_beat(
                    model=self.model,
                    state=state,
                    recent_turns=recent_before,
                    player_text=text,
                    semantic_roll=semantic_roll,
                )
            except Exception:
                # This optional pressure advance must never block the ordinary
                # player turn if its tiny structured call fails.
                world_beat = None
            if (
                isinstance(world_beat, dict)
                and world_beat.get("hostile_attack") is True
                and not (
                    isinstance(state.get("combat"), dict)
                    and state["combat"].get("status") == "active"
                )
            ):
                try:
                    assessment = classify_new_opponent(
                        model=self.model,
                        state=state,
                        recent_turns=recent_before,
                        player_text=str(world_beat.get("action") or text),
                        opponent_name=str(world_beat.get("actor") or ""),
                    )
                    if isinstance(assessment, dict):
                        world_beat["opponent_profile"] = assessment.get("opponent_profile")
                        weapon = assessment.get("opponent_weapon")
                        if isinstance(weapon, dict) and weapon.get("grounded"):
                            world_beat["weapon_name"] = str(weapon.get("name") or "")
                            world_beat["weapon_mode"] = str(weapon.get("mode") or "NONE")
                            world_beat["weapon_bonus"] = int(weapon.get("bonus", 0) or 0)
                            world_beat["weapon_natural"] = weapon.get("natural") is True
                except Exception:
                    pass
            self.events.put(
                (
                    "action_classified",
                    {
                        "text": text,
                        "recent": recent_before,
                        "semantic_roll": semantic_roll,
                        "world_beat": world_beat,
                        "classifier_error": classifier_error,
                    },
                )
            )

        threading.Thread(target=worker, daemon=True).start()

    def _background_call_running(self) -> bool:
        return bool(self.secretary_running or self.spatial_running or getattr(self, "grounding_auditor_running", False))

    def _resume_queued_player_text(self) -> bool:
        if (
            self.generating
            or self._background_call_running()
            or not getattr(self, "queued_player_text", None)
            or (getattr(self, "state", None) and self.state.get("pending_site_plan_retry"))
        ):
            return False
        text = self.queued_player_text
        already_visible = bool(getattr(self, "queued_player_visible", False))
        self.queued_player_text = None
        self.queued_player_visible = False
        if already_visible:
            self._begin_player_text(text, False)
        else:
            self._begin_player_text(text)
        return True

    def _resume_queued_foreground(self) -> bool:
        if self.generating or self._background_call_running():
            return False
        if self._resume_queued_player_text():
            return True
        if getattr(self, "queued_fate_spin", False):
            self.queued_fate_spin = False
            self._spin_wheel()
            return True
        return False

    def _spatial_enrichment_allowed(
        self,
        *,
        planning_mode: str,
        resolved_event: dict[str, Any] | None,
    ) -> bool:
        """Throttle ordinary room-to-room enrichment, never first planning."""

        if not self.state or planning_mode != "interior":
            return True
        movement = resolved_event if isinstance(resolved_event, dict) else {}
        event_type = str(movement.get("type") or "")
        if event_type in {"compound_resolution", "resource_movement_resolution"}:
            movement = (
                movement.get("movement")
                if isinstance(movement.get("movement"), dict)
                else {}
            )
        routine_local_move = bool(
            str(movement.get("type") or "") == "local_movement"
            and movement.get("committed")
        )
        if not routine_local_move:
            # A newly exposed branch or first interior plan is worth preserving
            # even if another spatial call happened on the previous beat.
            return True
        scheduler = (
            self.state.get("spatial_secretary_scheduler")
            if isinstance(self.state.get("spatial_secretary_scheduler"), dict)
            else {}
        )
        current_turn = int(self.state.get("turn_no", 0) or 0)
        last_turn = int(scheduler.get("last_started_turn", -999) or -999)
        return current_turn - last_turn >= 2

    def _show_pending_roll(self, prompt: dict[str, Any]) -> None:
        button = str(prompt.get("button") or "Roll")
        detail = str(prompt.get("detail") or "").strip()
        maximum = int(prompt.get("maximum") or (10 if "D10" in button else 20))
        self.pending_roll_max = 10 if maximum == 10 else 20
        die = str(prompt.get("die") or f"D{self.pending_roll_max}").upper()
        action_prefix = (
            "ATTACK · " if button.casefold().startswith("attack")
            else "DEFEND · " if button.casefold().startswith("defend")
            else ""
        )
        self.roll_notice.configure(text="PENDING ROLL")
        self.roll_detail.configure(
            text=" · ".join(part for part in (f"{action_prefix}{die}", detail) if part)
        )
        roll_count = int(prompt.get("roll_count") or 1)
        self.pending_roll_count = roll_count
        self.pending_roll_dice = list(prompt.get("roll_dice") or [self.pending_roll_max] * roll_count)
        if len(set(self.pending_roll_dice)) > 1:
            self.roll_instruction.configure(text="Enter results in order: " + ", ".join(
                f"D{sides} (1–{sides})" for sides in self.pending_roll_dice))
        elif roll_count > 1:
            self.roll_instruction.configure(
                text=f"Enter {roll_count} physical results (1–{self.pending_roll_max}, e.g. 7, 4, 9)"
            )
        else:
            self.roll_instruction.configure(
                text=f"Enter your physical result (1–{self.pending_roll_max})"
            )
        self.roll_error.configure(text="")
        if self.roll_error.winfo_manager():
            self.roll_error.pack_forget()
        self.roll_input.configure(state="normal")
        self.roll_input.delete(0, "end")
        self.roll_input.icursor(0)
        self.roll_button.configure(
            text="Submit roll",
            state="normal",
        )
        if self.input_box.winfo_manager():
            self.input_box.pack_forget()
        if not self.roll_panel.winfo_manager():
            self.roll_panel.pack(fill="x")
        self.roll_input.focus_set()
        if roll_count > 1:
            self.model_status.configure(
                text="Action committed · enter " + ", ".join(f"D{sides}" for sides in self.pending_roll_dice),
                fg=ACCENT,
            )
        else:
            self.model_status.configure(
                text=f"Action committed · enter your D{self.pending_roll_max} result",
                fg=ACCENT,
            )

    def _hide_pending_roll(self) -> None:
        self.roll_button.configure(state="disabled")
        self.roll_input.configure(state="disabled")
        self.roll_error.configure(text="")
        if self.roll_error.winfo_manager():
            self.roll_error.pack_forget()
        if self.roll_panel.winfo_manager():
            self.roll_panel.pack_forget()
        if not self.input_box.winfo_manager():
            self.input_box.pack(fill="x")

    def _show_queued_combat_defense(self) -> bool:
        """Hold the text turn while the opponent's separate attack awaits a roll."""

        if not self.state or not combat_defense_pending(self.state):
            return False
        try:
            preview = preview_pending_combat_defense(self.state)
            prompt = pending_roll_prompt(preview)
        except Exception:
            return False
        if not prompt:
            self._resolve_and_narrate({
                "kind": "combat_defense", "text": "The queued enemy actions resolve.",
                "recent": self.store.recent_turns(self.state["campaign_id"], limit=12),
            })
            return True
        opponents = self.state.get("combat", {}).get("opponents", [])
        pending = self.state.get("combat", {}).get("pending_defense") or {}
        if opponents:
            opponent_name = str(opponents[0].get("name") or "the opponent")
            if len(opponents) > 1:
                opponent_name += " and their group"
        else:
            opponent_name = "the opponent"
        if pending.get("attack_mode") == "magic":
            spell_name = pending.get("spell_name") or "spell"
            action_text = f"I defend against {opponent_name}'s {spell_name}."
        else:
            action_text = f"I defend against {opponent_name}'s answering attack."
        self.pending_action = {
            "kind": "combat_defense",
            "text": action_text,
            "recent": self.store.recent_turns(self.state["campaign_id"], limit=12),
        }
        self.input_box.configure(state="disabled")
        self._show_pending_roll(prompt)
        return True

    def _resolve_and_narrate(self, data: dict[str, Any]) -> None:
        player_text = str(data.get("text") or "")
        recent_before = data.get("recent") if isinstance(data.get("recent"), list) else []
        semantic_roll = data.get("semantic_roll") if isinstance(data.get("semantic_roll"), dict) else None
        world_beat = data.get("world_beat") if isinstance(data.get("world_beat"), dict) else None
        manual_roll = int(data.get("manual_roll")) if data.get("manual_roll") is not None else None
        manual_rolls = data.get("manual_rolls") if isinstance(data.get("manual_rolls"), list) else None
        is_combat_defense = data.get("kind") == "combat_defense"
        try:
            if self.state and is_combat_defense:
                resolved = resolve_pending_combat_defense(
                    self.state, manual_roll=manual_roll, manual_rolls=manual_rolls
                )
            else:
                resolved = resolve_player_action(
                    self.state,
                    player_text,
                    semantic_roll=semantic_roll,
                    world_beat=world_beat,
                    allow_regex_fallback=semantic_roll is None,
                    manual_roll=manual_roll,
                    manual_rolls=manual_rolls,
                ) if self.state else None
                if resolved is None and self.state and world_beat:
                    resolved = commit_world_beat(self.state, world_beat)
                if self.state:
                    resolved = apply_action_consequences(
                        self.state, semantic_roll, resolved
                    )
                    resolved = advance_afflictions(self.state, resolved)
                    maybe_bind_island(self.state, player_text, resolved)
                    pending_voyage = semantic_roll.get("pending_voyage_destination") if isinstance(semantic_roll, dict) else ""
                    from .voyage import clean_destination
                    voyage = self.state.get('voyage') or {}
                    if voyage.get('phase') in {'in_transit','interrupted','arrived'}:
                        pending_voyage = voyage['destination_name']
                    if pending_voyage and pending_voyage != "NONE":
                        pending_voyage = clean_destination(pending_voyage)
                        voyage_id = (voyage.get('destination_id') if pending_voyage == voyage.get('destination_name') else None) or _emergent_id(pending_voyage)
                        if not isinstance(self.state.get("locations", {}).get(voyage_id, {}).get("site_memory"), dict):
                            if voyage_id not in self.state.setdefault("locations", {}):
                                self.state["locations"][voyage_id] = {
                                    "name": pending_voyage,
                                    "region": "Emergent place",
                                    "summary": "A place mapped in advance of arrival.",
                                    "aliases": [pending_voyage],
                                    "provisional": True,
                                    "defining_excerpt": None,
                                    "visit_count": 0,
                                }
                            # Binding context only; the live player remains aboard.
                            fake_resolved = {"type": "movement", "committed": True,
                                             "to_name": pending_voyage, "to_id": voyage_id,
                                             "prearrival": True}
                            maybe_bind_island(self.state, "", fake_resolved)
                            from .island_context import is_island
                            if is_island(self.state, voyage_id):
                                print(f"[app] Early detecting voyage to {pending_voyage}, triggering cartographer...")
                                # Plan against a detached target view. A model failure
                                # must never teleport the live player to that island.
                                mapping_state = copy.deepcopy(self.state)
                                mapping_state['current_location_id'] = voyage_id
                                mapping_state['scene_position'] = None
                                island_result = run_spatial_secretary(
                                    model=self.background_model,
                                    state=mapping_state,
                                    recent_turns=recent_before,
                                    player_text=player_text,
                                    narration="",
                                    resolved_event=fake_resolved,
                                    planning_mode="island_macro",
                                )
                                apply_spatial_survey_for_anchor(self.state, island_result, anchor_location_id=voyage_id, anchor_scene_position=None)
                    if _island_survey_due(self.state):
                        print("[app] Synchronous pre-mapping of Island Macro...")
                        island_result = run_spatial_secretary(
                            model=self.background_model,
                            state=copy.deepcopy(self.state),
                            recent_turns=recent_before,
                            player_text=player_text,
                            narration="",
                            resolved_event=resolved,
                            planning_mode="island_macro",
                        )
                        apply_spatial_survey_for_anchor(self.state, island_result, anchor_location_id=str(self.state.get("current_location_id")), anchor_scene_position=None)
                    # Skirmish resolution
                    if isinstance(semantic_roll, dict) and semantic_roll.get("mass_combat_active"):
                        from .skirmish_resolution import resolve_skirmish_momentum
                        player_outcome = None
                        if isinstance(resolved, dict):
                            if "outcome" in resolved:
                                player_outcome = resolved.get("outcome")
                            elif isinstance(resolved.get("roll"), dict):
                                player_outcome = resolved["roll"].get("outcome")
                            elif resolved.get("exchanges"):
                                first_ex = resolved["exchanges"][0]
                                if first_ex.get("hit"):
                                    player_outcome = "critical_success" if first_ex.get("critical") else "success"
                                else:
                                    player_outcome = "critical_failure" if first_ex.get("critical") else "failure"
                        
                        skirmish_result = resolve_skirmish_momentum(self.state, player_outcome)
                        if isinstance(resolved, dict):
                            resolved["skirmish_resolution"] = skirmish_result
                    scenario_updates = observe_scenario_action(
                        self.state,
                        player_text,
                        resolved,
                        semantic_flags=(
                            list(semantic_roll.get("scenario_flags") or [])
                            if isinstance(semantic_roll, dict)
                            else None
                        ),
                    )
                    if scenario_updates and isinstance(resolved, dict):
                        resolved["scenario_flag_updates"] = scenario_updates
        except Exception as exc:
            resolved = {"type": "engine_warning", "committed": False, "reason": str(exc)}
        ledger = event_ledger_line(resolved)
        if self.state:
            record_mechanical_ledger(self.state, resolved, ledger)
            self.store.save_state(self.state)
        if ledger:
            self._append_ledger(ledger)
        self._refresh_state_display()
        self._start_generation(
            player_text,
            resolved,
            show_player=not is_combat_defense,
            recent_override=recent_before,
            semantic_roll=semantic_roll,
        )

    def _submit_pending_roll(self) -> None:
        if not self.pending_action:
            return
        submitted = self.roll_input.get().strip()
        roll_count = getattr(self, "pending_roll_count", 1)
        if roll_count > 1:
            manual_rolls = parse_manual_rolls(submitted, self.pending_roll_max)
            dice = getattr(self, "pending_roll_dice", [self.pending_roll_max] * roll_count)
            if (not manual_rolls or len(manual_rolls) != roll_count
                    or any(not 1 <= value <= sides for value, sides in zip(manual_rolls, dice))):
                self.roll_error.configure(
                    text="Enter exactly these results in order: " + ", ".join(f"D{sides} (1–{sides})" for sides in dice)
                )
                if not self.roll_error.winfo_manager():
                    self.roll_error.pack(fill="x", pady=(5, 0))
                self.model_status.configure(text=f"Waiting for {roll_count} valid rolls", fg=ERROR)
                self.roll_input.focus_set()
                self.roll_input.selection_range(0, "end")
                return
            self._commit_pending_roll(manual_rolls[0], manual_rolls=manual_rolls)
            return

        manual_roll = parse_manual_roll(submitted, self.pending_roll_max)
        if manual_roll is None:
            self.roll_error.configure(
                text=(
                    f"Enter 1–{self.pending_roll_max}: for example "
                    f"{self.pending_roll_max}, twenty, or ‘I rolled twenty’."
                    if self.pending_roll_max == 20
                    else "Enter 1–10: for example 7, seven, or ‘I rolled seven’."
                )
            )
            if not self.roll_error.winfo_manager():
                self.roll_error.pack(fill="x", pady=(5, 0))
            self.model_status.configure(text="Waiting for a valid roll result", fg=ERROR)
            self.roll_input.focus_set()
            self.roll_input.selection_range(0, "end")
            return
        self._commit_pending_roll(manual_roll)

    def _commit_pending_roll(self, manual_roll: int, manual_rolls: list[int] | None = None) -> None:
        if not self.pending_action or not self.state:
            return
        data = {**self.pending_action, "manual_roll": int(manual_roll)}
        if manual_rolls is not None:
            data["manual_rolls"] = [int(r) for r in manual_rolls]
        self.pending_action = None
        self._hide_pending_roll()
        self.model_status.configure(text="Resolving submitted roll…", fg=ACCENT)
        # Yield once so the submission visibly depresses before resolution and
        # narration begin.
        self.root.after(20, lambda: self._resolve_and_narrate(data))

    def _start_generation(
        self,
        player_text: str,
        resolved_event: dict[str, Any] | None,
        *,
        show_player: bool,
        recent_override: list[dict[str, Any]] | None = None,
        semantic_roll: dict[str, Any] | None = None,
    ) -> None:
        if not self.state:
            return
        self.active_generation_context = {
            "player_text": player_text,
            "resolved_event": resolved_event,
            "semantic_roll": semantic_roll,
        }
        self.generating = True
        self.ai_buffer = []
        self.input_box.configure(state="disabled")
        self.model_status.configure(text="Local AI is writing…", fg=ACCENT)
        self._begin_gm_message()
        recent = recent_override if recent_override is not None else self.store.recent_turns(self.state["campaign_id"], limit=12)
        self.active_generation_context["recent"] = copy.deepcopy(recent[-12:])
        memory = self.store.recent_evidence(self.state["campaign_id"], limit=8)
        shared_echo = self._maybe_shared_echo(resolved_event)
        npc_seed = (
            None
            if shared_echo
            else maybe_npc_seed(
                self.state,
                resolved_event,
                scene_occupied=arrival_scene_occupied(
                    self.state,
                    resolved_event,
                    semantic_roll,
                    player_text,
                ),
                density=(
                    str(semantic_roll.get("npc_seed_density") or "ordinary")
                    if isinstance(semantic_roll, dict)
                    else "ordinary"
                ),
            )
        )
        messages = build_messages(
            self.state,
            recent,
            player_text,
            resolved_event,
            memory_evidence=memory,
            shared_echo=shared_echo,
            npc_seed=npc_seed,
        )

        def worker() -> None:
            try:
                complete = self.model.stream_chat(messages, on_token=lambda token: self.events.put(("token", token)))
                review = finish_party_review(
                    model=self.model, state=copy.deepcopy(self.state), recent_turns=recent,
                    player_text=player_text, narration=complete, semantic_roll=semantic_roll,
                    resolved_event=resolved_event,
                )
                self.events.put(("done", {"text": complete, "party_review": review}))
            except Exception as exc:
                self.events.put(("generation_error", str(exc)))

        threading.Thread(target=worker, daemon=True).start()

    def _record_party_review(self, data: dict) -> None:
        if not self.state:
            return
        event = data.get("event")
        ledger = event_ledger_line(event)
        if ledger:
            self._append_ledger(ledger)
            record_mechanical_ledger(self.state, event, ledger)
        if data.get("error"):
            self._append_error("Party update pending: " + str(data["error"]))
        self.store.save_state(self.state)
        self._refresh_state_display()

    def _complete_generation_cycle(self) -> None:
        self.generating = False
        self._refresh_state_display()
        current_state = getattr(self, "state", None)
        if current_state and current_state.get("campaign_status") == "game_over":
            self.pending_action = None
            self._hide_pending_roll()
            self.input_box.configure(state="disabled")
            self.model_status.configure(text="GAME OVER · restart Aether Harbor for a new voyage", fg=ERROR)
            self._cancel_secretary_idle()
            return
        self.input_box.configure(state="normal")
        self.input_box.focus_set()
        model = getattr(self, "model", None)
        display_model = (getattr(model, "display_model_id", None) or getattr(model, "model_id", None) or "local model")
        self.model_status.configure(text=f"Ready · {display_model} in LM Studio", fg=ACCENT)
        if not self._show_queued_combat_defense():
            self._schedule_secretary_if_due()

    def _start_spatial_survey(
        self,
        *,
        player_text: str,
        narration: str,
        resolved_event: dict[str, Any] | None,
        planning_mode: str,
    ) -> None:
        if not self.state:
            return
        scheduler = self.state.setdefault("spatial_secretary_scheduler", {})
        current_turn = int(self.state.get("turn_no", 0) or 0)
        scheduler["last_started_turn"] = current_turn
        self.background_last_started_turn = current_turn
        if planning_mode == "exterior" and reserve_selected_exterior_site(self.state, narration):
            # Reserve the selected building/vessel synchronously so a quick
            # follow-up entry reaches this exact site even while its private
            # background plan is still being prepared.
            self.store.save_state(self.state)
        state_snapshot = copy.deepcopy(self.state)
        job = {
            "campaign_id": str(self.state.get("campaign_id") or ""),
            "turn_no": current_turn,
            "anchor_location_id": str(self.state.get("current_location_id") or ""),
            "anchor_scene_position": copy.deepcopy(
                self.state.get("scene_position")
                if isinstance(self.state.get("scene_position"), dict)
                else None
            ),
            "narration": narration,
            "player_text": player_text,
            "resolved_event": resolved_event,
            "planning_mode": planning_mode,
        }
        self.spatial_jobs_pending += 1
        self.spatial_running = True
        # Current action/narration are sent separately. Ten rows leave up to
        # four earlier approach exchanges after spatial-side deduplication.
        recent = self.store.recent_turns(job["campaign_id"], limit=10)

        def worker() -> None:
            try:
                result = run_spatial_secretary(
                    model=self.background_model,
                    state=state_snapshot,
                    recent_turns=recent,
                    player_text=player_text,
                    narration=narration,
                    resolved_event=resolved_event,
                    planning_mode=planning_mode,
                )
                self.events.put(("spatial_done", {"survey": result, "job": job}))
            except Exception as exc:
                self.events.put(("spatial_error", {"error": str(exc), "job": job}))

        threading.Thread(target=worker, daemon=True).start()

    def _start_grounding_audit(
        self,
        *,
        player_text: str,
        narration: str,
        resolved_event: dict[str, Any] | None,
    ) -> None:
        if not self.state or not narration.strip():
            return
        from .grounding_auditor import (
            audit_context,
            extract_pre_deducted_silver,
            run_grounding_auditor,
        )
        context = audit_context(self.state, resolved_event)
        pre_deducted = extract_pre_deducted_silver(resolved_event)
        campaign_id = str(self.state.get("campaign_id") or "")
        turn_no = int(self.state.get("turn_no", 0) or 0)
        job = {
            "audit_id": f"{campaign_id}:{turn_no}",
            "campaign_id": campaign_id,
            "turn_no": turn_no,
            "pre_deducted_silver": pre_deducted,
            "receipts": context["receipts"],
            "player_text": player_text,
            "narration": narration,
        }
        self.grounding_auditor_running = True

        def worker() -> None:
            try:
                result = run_grounding_auditor(
                    model=self.background_model,
                    player_text=player_text,
                    narration=narration,
                    pre_deducted_silver=pre_deducted,
                    context=context,
                )
                self.events.put(("grounding_done", {"audit": result, "job": job}))
            except Exception as exc:
                self.events.put(("grounding_error", {"error": str(exc), "job": job}))

        threading.Thread(target=worker, daemon=True).start()

    def _poll_events(self) -> None:
        token_batch: list[str] = []

        def flush_tokens() -> None:
            if token_batch:
                self._append_stream_chunk("".join(token_batch))
                token_batch.clear()

        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind != "token":
                    flush_tokens()
                if kind == "status":
                    self.model_status.configure(text=str(payload), fg=MUTED)
                elif kind == "model_ready":
                    self.model_status.configure(text=f"Ready · {self.model.display_model_id or self.model.model_id or 'local model'} in LM Studio", fg=ACCENT)
                    self.input_box.configure(state="normal")
                    self._start_opening()
                elif kind == "model_error":
                    self.model_status.configure(text="No usable loaded model in LM Studio", fg=ERROR)
                    self._append_error(str(payload))
                elif kind == "action_classified":
                    data = payload if isinstance(payload, dict) else {}
                    player_text = str(data.get("text") or "")
                    semantic_roll = data.get("semantic_roll") if isinstance(data.get("semantic_roll"), dict) else None
                    try:
                        preview = preview_player_action(
                            self.state,
                            player_text,
                            semantic_roll=semantic_roll,
                            world_beat=(
                                data.get("world_beat")
                                if isinstance(data.get("world_beat"), dict)
                                else None
                            ),
                            allow_regex_fallback=semantic_roll is None,
                        ) if self.state else None
                    except Exception as exc:
                        preview = {"type": "engine_warning", "committed": False, "reason": str(exc)}
                    if self.state:
                        self.store.save_state(self.state)
                    self._refresh_state_display()
                    roll_prompt = pending_roll_prompt(preview)
                    if roll_prompt:
                        self.pending_action = data
                        self._show_pending_roll(roll_prompt)
                    else:
                        self._resolve_and_narrate(data)
                elif kind == "token":
                    token = str(payload)
                    self.ai_buffer.append(token)
                    token_batch.append(token)
                elif kind == "party_notice":
                    self._record_party_review(payload)
                elif kind == "party_retry_failed":
                    self.generating = False
                    self.input_box.configure(state="normal")
                    self.model_status.configure(text="Party update pending · retry the action", fg=ERROR)
                elif kind == "done":
                    text = str(payload.get("text") if isinstance(payload, dict) else payload).strip()
                    self._finish_gm_message()
                    if self.state and isinstance(payload, dict) and payload.get("party_review"):
                        review = payload["party_review"]
                        event = apply_party_review(self.state, review)
                        self._record_party_review({"event": event, "error": review.get("error")})
                    generation_context = self.active_generation_context or {}
                    self.active_generation_context = None
                    player_text = str(generation_context.get("player_text") or "")
                    resolved_event = generation_context.get("resolved_event")
                    resolved_event = resolved_event if isinstance(resolved_event, dict) else None
                    if self.state and text:
                        note_combat_episode_narration(
                            self.state,
                            resolved_event,
                            text,
                            (
                                generation_context.get("recent")
                                if isinstance(generation_context.get("recent"), list)
                                else []
                            ),
                        )
                        note_affliction_narration(self.state, resolved_event, text)
                        note_book_seed_narration(
                            self.state, text, player_text, resolved_event
                        )
                        note_active_situation_narration(
                            self.state, text, resolved_event
                        )
                        note_scenario_narration(
                            self.state, player_text, text, resolved_event
                        )
                        # Spend a site's one-shot material seed only after its
                        # visible realization has actually been narrated.
                        note_material_reveal_from_narration(
                            self.state, player_text, text, resolved_event
                        )
                        capture_passage_offer(self.state, text)
                        capture_resource_offer(self.state, text)
                        capture_local_game_offer(self.state, text)
                        commit_pending_site_area_observation(self.state)
                        commit_pending_site_transition(self.state, text)
                        cement_arrival_excerpt(self.state, text)
                        refresh_emergent_place_definition(self.state, text)
                        note_site_transition(self.state, text, resolved_event)
                        sequence_no = self.store.append_turn(self.state["campaign_id"], "Aether Harbor", text)
                        from .secretary import note_transcript_scope
                        note_transcript_scope(self.state, sequence_no)
                        self.store.save_state(self.state)
                        self._start_grounding_audit(
                            player_text=player_text,
                            narration=text,
                            resolved_event=resolved_event,
                        )
                    planning_mode = (
                        spatial_survey_mode(
                            state=self.state,
                            player_text=player_text,
                            narration=text,
                            resolved_event=resolved_event,
                        )
                        if self.state and text
                        else None
                    )
                    if (
                        self.state
                        and text
                        and planning_mode
                        and self._spatial_enrichment_allowed(
                            planning_mode=planning_mode,
                            resolved_event=resolved_event,
                        )
                    ):
                        self._start_spatial_survey(
                            player_text=player_text,
                            narration=text,
                            resolved_event=resolved_event,
                            planning_mode=planning_mode,
                        )
                    else:
                        if self.state and text:
                            queue_curator_after_narration(
                                self.state,
                                # A throttled spatial beat already committed
                                # its hard geometry synchronously.
                                allow_place_card=not bool(planning_mode),
                            )
                            self.store.save_state(self.state)
                    # Once visible narration is complete, input resumes. Any
                    # due memory work runs while the player reads; a submitted
                    # action is queued behind it rather than overlapping it.
                    self._complete_generation_cycle()
                elif kind == "generation_error":
                    self._finish_gm_message()
                    self.active_generation_context = None
                    self._append_error(str(payload))
                    self.generating = False
                    if self.state and self.state.get("campaign_status") == "game_over":
                        self.input_box.configure(state="disabled")
                        self.model_status.configure(text="GAME OVER · narration failed; restart for a new voyage", fg=ERROR)
                    else:
                        self.input_box.configure(state="normal")
                        self.input_box.focus_set()
                        self.model_status.configure(text="Generation error · see local log", fg=ERROR)
                        self._show_queued_combat_defense()
                elif kind == "spatial_done":
                    data = payload if isinstance(payload, dict) else {}
                    job = data.get("job") if isinstance(data.get("job"), dict) else {}
                    same_campaign = bool(
                        self.state
                        and str(self.state.get("campaign_id") or "")
                        == str(job.get("campaign_id") or "")
                    )
                    applied = False
                    if self.state and same_campaign:
                        applied = apply_spatial_survey_for_anchor(
                            self.state,
                            data.get("survey") if isinstance(data.get("survey"), dict) else None,
                            anchor_location_id=str(job.get("anchor_location_id") or ""),
                            anchor_scene_position=(
                                job.get("anchor_scene_position")
                                if isinstance(job.get("anchor_scene_position"), dict)
                                else None
                            ),
                            narration=str(job.get("narration") or ""),
                        )
                        if isinstance(data.get("survey"), dict) and data["survey"].get("spatial_audit"):
                            audit = data["survey"]["spatial_audit"]
                            self.state["last_spatial_audit"] = audit
                            if audit.get("pass3_triggered"):
                                self.state.setdefault("spatial_audit_history", []).append(audit)

                        if applied:
                            self.state.pop("pending_site_plan_retry", None)
                            if int(self.state.get("turn_no", 0)) == int(job.get("turn_no", -1)):
                                note_site_transition(self.state, str(job.get("narration") or ""), job.get("resolved_event"))
                        else:
                            self.state["pending_site_plan_retry"] = job
                            self._append_error("The site plan could not be validated. Your next action will retry planning before play advances.")
                        queue_curator_after_narration(
                            self.state,
                            allow_place_card=(
                                isinstance(data.get("survey"), dict)
                                and data["survey"].get("spatial_review_status") == "not_needed"
                            ),
                        )
                        self.store.save_state(self.state)
                        self._refresh_state_display()
                    self.spatial_jobs_pending = max(0, self.spatial_jobs_pending - 1)
                    self.spatial_running = self.spatial_jobs_pending > 0
                    if not self.generating:
                        if self.state and same_campaign and applied:
                            scheduler = self.state.setdefault("spatial_secretary_scheduler", {})
                            scheduler["last_completed_turn"] = int(job.get("turn_no", 0) or 0)
                            self.store.save_state(self.state)
                        if not self._resume_queued_foreground():
                            self._schedule_secretary_if_due()
                elif kind == "grounding_done":
                    data = payload if isinstance(payload, dict) else {}
                    audit = data.get("audit") if isinstance(data.get("audit"), dict) else {}
                    job = data.get("job") if isinstance(data.get("job"), dict) else {}
                    if self.state and isinstance(audit, dict):
                        from .grounding_auditor import apply_grounding_audit
                        changes = apply_grounding_audit(self.state, audit, job=job)
                        self.store.save_state(self.state)
                        if changes:
                            self._refresh_state_display()
                    self.grounding_auditor_running = False
                    if not self.generating:
                        if not self._resume_queued_foreground():
                            self._schedule_secretary_if_due()
                elif kind == "grounding_error":
                    data = payload if isinstance(payload, dict) else {}
                    job = data.get("job") if isinstance(data.get("job"), dict) else {}
                    if self.state and job:
                        from .grounding_auditor import apply_grounding_audit
                        apply_grounding_audit(
                            self.state,
                            {"error": str(data.get("error") or "Grounding audit failed")},
                            job=job,
                        )
                        self.store.save_state(self.state)
                    self.grounding_auditor_running = False
                    if not self.generating:
                        if not self._resume_queued_foreground():
                            self._schedule_secretary_if_due()
                elif kind == "spatial_error":
                    # Spatial memory is useful but never a fallback that blocks play.
                    data = payload if isinstance(payload, dict) else {}
                    job = data.get("job") if isinstance(data.get("job"), dict) else {}
                    same_campaign = bool(
                        self.state
                        and str(self.state.get("campaign_id") or "")
                        == str(job.get("campaign_id") or "")
                    )
                    if self.state and same_campaign:
                        self.state["pending_site_plan_retry"] = job
                        self._append_error("Site planning failed; send your next action to retry before play advances.")
                        queue_curator_after_narration(
                            self.state,
                            allow_place_card=True,
                        )
                        self.store.save_state(self.state)
                    self.spatial_jobs_pending = max(0, self.spatial_jobs_pending - 1)
                    self.spatial_running = self.spatial_jobs_pending > 0
                    if not self.generating:
                        if not self._resume_queued_foreground():
                            self._schedule_secretary_if_due()
                elif kind == "secretary_done":
                    self.secretary_running = False
                    self.secretary_pending_kind = None
                    data = payload if isinstance(payload, dict) else {}
                    self._apply_secretary_snapshot(data)
                    self._refresh_state_display()
                    if not self.generating:
                        if not self._resume_queued_foreground():
                            self._schedule_secretary_if_due()
                elif kind == "secretary_error":
                    # Soft memory is never a load-bearing error path.
                    self.secretary_running = False
                    self.secretary_pending_kind = None
                    if not self.generating:
                        if not self._resume_queued_foreground():
                            self._schedule_secretary_if_due()
        except queue.Empty:
            flush_tokens()
        self.root.after(45, self._poll_events)

    def _refresh_state_display(self) -> None:
        if not self.state:
            return
        location = current_location(self.state)
        scene_position = self.state.get("scene_position") if isinstance(self.state.get("scene_position"), dict) else None
        player = self.state["player"]
        region = str(location.get("region") or "").strip()
        visible_region = region and region.casefold() not in {
            "emergent place", "emergent site", "the opening scene"
        }
        place_text = str(location["name"])
        if visible_region:
            place_text += f" · {region}"
        if scene_position:
            place_text += f" · {scene_position.get('label')}"
        self.place_status.configure(text=place_text)
        game_over = self.state.get("campaign_status") == "game_over"
        suffix = " · GAME OVER" if game_over else ""
        
        status_text = f"{player['name']} · {player['class_label']} · HP {player['hp']}/{player['max_hp']} · {player['silver']} silver"
        companions = player.get("companions", [])
        if companions:
            comp_texts = [f"{c['name']} HP {c['hp']}/{c['max_hp']}" for c in companions]
            status_text += f" | {' · '.join(comp_texts)}"
        status_text += suffix

        self.player_status.configure(
            text=status_text,
            fg=ERROR if game_over else TEXT,
        )
        self.scene_title.configure(text=str(scene_position.get("label")) if scene_position else location["name"])
        self.scene_summary.configure(
            text=str(scene_position.get("summary") or location["summary"])
            if scene_position
            else location["summary"]
        )

    def _maybe_shared_echo(self, resolved_event: dict[str, Any] | None) -> dict[str, Any] | None:
        if not self.state:
            return None
        eligible = resolved_event is None and int(self.state.get("turn_no", 0)) == 0
        eligible = eligible or bool(resolved_event and resolved_event.get("type") == "movement")
        if not eligible:
            return None
        sampler = random.Random(f"{self.state.get('rng_seed')}:{self.state.get('turn_no')}:shared-echo")
        if sampler.random() > 0.18:
            return None
        return self.store.random_shared_echo(
            exclude_campaign_id=self.state["campaign_id"],
            allowed_scales=["shard", "person", "site", "district"],
        )

    def _cancel_secretary_idle(self) -> None:
        if self.secretary_after_id is not None:
            try:
                self.root.after_cancel(self.secretary_after_id)
            except Exception:
                pass
            self.secretary_after_id = None
            self.secretary_pending_kind = None

    def _due_secretary_kind(self) -> str | None:
        if not self.state:
            return None
        if emergent_scenario_due(self.state):
            return "scenario"
        if room_memory_due(self.state):
            return "room_memory"
        if world_clock_due(self.state):
            return "clock"
        if recap_due(self.state):
            return "recap"
        if secretary_due(self.state):
            return "evidence"
        if curator_due(self.state):
            return "curator"
        return None

    def _schedule_secretary_if_due(self) -> None:
        self._cancel_secretary_idle()
        if (
            not self.state
            or self.generating
            or self.secretary_running
            or self.spatial_running
            or getattr(self, "grounding_auditor_running", False)
            or getattr(self, "queued_player_text", None)
            or getattr(self, "queued_fate_spin", False)
            or int(getattr(self, "background_last_started_turn", -999))
            == int(self.state.get("turn_no", 0) or 0)
        ):
            return
        pending_kind = self._due_secretary_kind()
        if pending_kind is None:
            return
        self.secretary_pending_kind = pending_kind
        # The narrator has emitted its final token and released the foreground
        # model. Start the highest-priority due job now, while the player reads,
        # instead of gambling on a 15-second idle window that typing cancels.
        self._run_secretary_when_idle()

    def _run_secretary_when_idle(self) -> None:
        self.secretary_after_id = None
        pending_kind = self.secretary_pending_kind
        self.secretary_pending_kind = None
        if (
            not self.state
            or self.generating
            or self.secretary_running
            or self.spatial_running
            or getattr(self, "grounding_auditor_running", False)
            or getattr(self, "queued_player_text", None)
            or getattr(self, "queued_fate_spin", False)
            or int(getattr(self, "background_last_started_turn", -999))
            == int(self.state.get("turn_no", 0) or 0)
        ):
            return
        if pending_kind != self._due_secretary_kind():
            return
        self.secretary_running = True
        self.background_last_started_turn = int(self.state.get("turn_no", 0) or 0)
        state = copy.deepcopy(self.state)
        job = {
            "campaign_id": str(state.get("campaign_id") or ""),
            "turn_no": int(state.get("turn_no", 0) or 0),
        }

        def worker() -> None:
            try:
                if pending_kind == "scenario":
                    result = run_emergent_scenario_architect(
                        model=self.background_model, store=self.store, state=state,
                        save_state=False,
                    )
                elif pending_kind == "room_memory":
                    result = run_room_secretary(
                        model=self.background_model, store=self.store, state=state,
                        save_state=False,
                    )
                elif pending_kind == "recap":
                    result = run_recap_secretary(
                        model=self.background_model, store=self.store, state=state,
                        save_state=False,
                    )
                elif pending_kind == "clock":
                    result = run_world_clock(
                        model=self.background_model, store=self.store, state=state,
                        save_state=False,
                    )
                elif pending_kind == "curator":
                    result = run_state_curator(
                        model=self.background_model, store=self.store, state=state,
                        save_state=False,
                    )
                else:
                    result = run_secretary(
                        model=self.background_model, store=self.store, state=state,
                        save_state=False,
                    )
                self.events.put(
                    (
                        "secretary_done",
                        {
                            "kind": pending_kind,
                            "result": result,
                            "state_snapshot": state,
                            "job": job,
                        },
                    )
                )
            except Exception as exc:
                self.events.put(("secretary_error", str(exc)))

        threading.Thread(target=worker, daemon=True).start()

    def _apply_secretary_snapshot(self, data: dict[str, Any]) -> bool:
        """Apply one background result only to the exact beat it examined."""

        if not self.state:
            return False
        job = data.get("job") if isinstance(data.get("job"), dict) else {}
        snapshot = (
            data.get("state_snapshot")
            if isinstance(data.get("state_snapshot"), dict)
            else None
        )
        if not isinstance(snapshot, dict):
            return False
        kind = str(data.get("kind") or "")
        if str(self.state.get("campaign_id") or "") != str(job.get("campaign_id") or ""):
            return False
        if kind == "room_memory":
            applied = apply_room_memory_result(self.state, data.get("result"))
            if applied:
                self.store.save_state(self.state)
            return applied
        if int(self.state.get("turn_no", 0) or 0) != int(job.get("turn_no", -1) or -1):
            # The player has already advanced. The next stream-complete event
            # will run a fresh job; never let a stale snapshot overwrite play.
            return False
        keys = {
            "scenario": ("scenario_kernels",),
            "clock": ("world_clock",),
            "recap": ("campaign_recap", "hidden_currents"),
            "evidence": (
                "secretary", "npcs", "threads", "locations",
                "state_curator", "provisional_npc_anchors",
            ),
            "curator": (
                "state_curator", "locations", "hidden_currents", "npcs",
                "threads",
            ),
        }.get(kind, ())
        for key in keys:
            if key in snapshot:
                self.state[key] = copy.deepcopy(snapshot[key])
        if kind in {"evidence", "curator"} and isinstance(snapshot.get("player"), dict):
            snap_player = snapshot["player"]
            live_player = self.state.setdefault("player", {})
            snap_inv = snap_player.get("inventory") if isinstance(snap_player.get("inventory"), list) else []
            live_inv = live_player.get("inventory") if isinstance(live_player.get("inventory"), list) else []
            for snap_item in snap_inv:
                if not isinstance(snap_item, dict) or "known_details" not in snap_item:
                    continue
                snap_name = str(snap_item.get("name") or "").strip().casefold()
                for live_item in live_inv:
                    if isinstance(live_item, dict) and str(live_item.get("name") or "").strip().casefold() == snap_name:
                        live_item["known_details"] = copy.deepcopy(snap_item["known_details"])
                        if "known_details_updated_at_turn" in snap_item:
                            live_item["known_details_updated_at_turn"] = snap_item["known_details_updated_at_turn"]
            snap_comps = snap_player.get("companions") if isinstance(snap_player.get("companions"), list) else []
            live_comps = live_player.get("companions") if isinstance(live_player.get("companions"), list) else []
            for snap_comp in snap_comps:
                if not isinstance(snap_comp, dict) or not str(snap_comp.get("appearance") or "").strip():
                    continue
                snap_cname = str(snap_comp.get("name") or "").strip().casefold()
                for live_comp in live_comps:
                    if (
                        isinstance(live_comp, dict)
                        and str(live_comp.get("name") or "").strip().casefold() == snap_cname
                        and not str(live_comp.get("appearance") or "").strip()
                    ):
                        live_comp["appearance"] = snap_comp["appearance"]
        if kind == "recap" and isinstance(snapshot.get("player"), dict):
            snap_player = snapshot["player"]
            live_player = self.state.setdefault("player", {})
            if "appearance" in snap_player:
                live_player["appearance"] = snap_player["appearance"]
            if "appearance_locked" in snap_player:
                live_player["appearance_locked"] = bool(snap_player["appearance_locked"])
        self.store.save_state(self.state)
        
        if isinstance(data.get("result"), dict):
            alerts = data["result"].get("alerts", [])
            if isinstance(alerts, list):
                for alert in alerts:
                    self._append_ledger(str(alert))
                    
        return bool(keys)

    def _show_inventory_window(self) -> None:
        if not self.state:
            return
            
        dialog = tk.Toplevel(self.root)
        dialog.title("Inventory")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        
        width, height = 450, 550
        self.root.update_idletasks()
        x = self.root.winfo_rootx() + max(10, (self.root.winfo_width() - width) // 2)
        y = self.root.winfo_rooty() + max(10, (self.root.winfo_height() - height) // 2)
        dialog.geometry(f"{width}x{height}+{x}+{y}")
        
        container = tk.Frame(dialog, bg=BG)
        container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Player Inventory
        tk.Label(container, text="YOUR INVENTORY", bg=BG, fg=ACCENT, font=(HEADING_FONT, 14, "bold")).pack(anchor="w", pady=(0, 5))
        
        silver = self.state.get("player", {}).get("silver", 0)
        tk.Label(container, text=f"Silver: {silver}", bg=BG, fg=JASMINE, font=(BODY_FONT, 11, "bold")).pack(anchor="w", padx=5, pady=(0, 10))
        
        player_inv = self.state.get("player", {}).get("inventory", [])
        if not player_inv:
            tk.Label(container, text="Empty", bg=BG, fg=MUTED, font=(BODY_FONT, 10, "italic")).pack(anchor="w", padx=15)
        else:
            for item in player_inv:
                name = item.get("name", "Unknown Item")
                qty = item.get("quantity", 1)
                qty_str = f"{qty}x " if int(qty) > 1 else ""
                equipped = " (Equipped)" if item.get("equipped") else ""
                tk.Label(container, text=f"• {qty_str}{name}{equipped}", bg=BG, fg=TEXT, font=(BODY_FONT, 11)).pack(anchor="w", padx=15, pady=2)
                
        # Companions
        companions = self.state.get("player", {}).get("companions", [])
        active_companions = [c for c in companions if int(c.get("hp", 0) or 0) > 0]
        for comp in active_companions:
            c_name = str(comp.get("name", "Companion")).upper()
            tk.Label(container, text=f"{c_name}'S INVENTORY", bg=BG, fg=ACCENT, font=(HEADING_FONT, 14, "bold")).pack(anchor="w", pady=(20, 5))
            
            items_found = False
            comp_silver = int(comp.get("silver", 0) or 0)
            if comp_silver > 0:
                tk.Label(container, text=f"Silver: {comp_silver}", bg=BG, fg=JASMINE, font=(BODY_FONT, 11, "bold")).pack(anchor="w", padx=15, pady=(0, 5))
                items_found = True
                
            comp_inv = comp.get("inventory", [])
            comp_weapon = comp.get("weapon")
            
            if isinstance(comp_weapon, dict) and comp_weapon.get("name"):
                items_found = True
                w_name = comp_weapon.get("name")
                tk.Label(container, text=f"• {w_name} (Equipped Weapon)", bg=BG, fg=TEXT, font=(BODY_FONT, 11)).pack(anchor="w", padx=15, pady=2)
                
            if isinstance(comp_inv, list):
                for item in comp_inv:
                    name = item.get("name", "Unknown Item")
                    qty = item.get("quantity", 1)
                    qty_str = f"{qty}x " if int(qty) > 1 else ""
                    equipped = " (Equipped)" if item.get("equipped") else ""
                    tk.Label(container, text=f"• {qty_str}{name}{equipped}", bg=BG, fg=TEXT, font=(BODY_FONT, 11)).pack(anchor="w", padx=15, pady=2)
                    items_found = True
                    
            if not items_found:
                tk.Label(container, text="Empty", bg=BG, fg=MUTED, font=(BODY_FONT, 10, "italic")).pack(anchor="w", padx=15)
                
        btn = tk.Button(dialog, text="Close", command=dialog.destroy, bg=PANEL, fg=TEXT, font=(BODY_FONT, 10), relief="flat")
        btn.pack(side="bottom", pady=20, ipadx=20)

    def _spin_wheel(self) -> None:
        if not self.state or not self.model.base_url:
            return
            
        if self.generating:
            return
            
        if self._background_call_running():
            if getattr(self, "queued_player_text", None):
                return
            self.queued_fate_spin = True
            self.input_box.configure(state="disabled")
            self.wheel_button.configure(state="disabled")
            self.model_status.configure(text="The Wheel is turning...", fg=ACCENT)
            return
            
        self._open_fate_window()
        from aether_harbor.fate import remaining_cooldown
        if remaining_cooldown(self.state) > 0:
            if self.fate_countdown_after_id:
                try:
                    self.root.after_cancel(self.fate_countdown_after_id)
                except Exception:
                    pass
                self.fate_countdown_after_id = None
            self._update_fate_cooldown_window()
            return
            
        event = spin_fate(self.state)
        if event.get("type") != "fate_resolution":
            self._update_fate_cooldown_window()
            return
        self.store.save_state(self.state)
        self._cancel_secretary_idle()
        if self.fate_countdown_after_id:
            try:
                self.root.after_cancel(self.fate_countdown_after_id)
            except Exception:
                pass
            self.fate_countdown_after_id = None
        self.generating = True
        self.input_box.configure(state="disabled")
        self.wheel_button.configure(state="disabled")
        self.model_status.configure(text="The Wheel is turning…", fg=ACCENT)
        if self.fate_result_label and self.fate_result_label.winfo_exists():
            self.fate_result_label.configure(text="")
        if self.fate_status_label and self.fate_status_label.winfo_exists():
            self.fate_status_label.configure(text="THE WHEEL IS TURNING", fg=JASMINE)
        if self.fate_timer_label and self.fate_timer_label.winfo_exists():
            self.fate_timer_label.configure(text="")
        self.pending_fate_event = event
        target_index = next(index for index, segment in enumerate(SEGMENTS) if segment[0] == event["result"])
        self.fate_animation_started_at = time.monotonic()
        self.fate_animation_target = (4 * 360) + (target_index * 45)
        self._animate_fate_wheel()

    def _open_fate_window(self) -> None:
        if self.fate_window and self.fate_window.winfo_exists():
            self.fate_window.deiconify()
            self.fate_window.lift()
            return
        dialog = tk.Toplevel(self.root)
        self.fate_window = dialog
        dialog.title("Wheel of Fate")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.protocol("WM_DELETE_WINDOW", self._close_fate_window)

        width, height = 560, 680
        self.root.update_idletasks()
        x = self.root.winfo_rootx() + max(10, (self.root.winfo_width() - width) // 2)
        y = self.root.winfo_rooty() + max(10, (self.root.winfo_height() - height) // 3)
        dialog.geometry(f"{width}x{height}+{x}+{y}")

        tk.Label(
            dialog,
            text="WHEEL OF FATE",
            bg=BG,
            fg=ACCENT,
            font=(HEADING_FONT, 18, "bold"),
        ).pack(pady=(18, 2))
        tk.Label(
            dialog,
            text="Eight arbitrary interventions · four boons, four banes",
            bg=BG,
            fg=MUTED,
            font=(BODY_FONT, 10),
        ).pack(pady=(0, 8))

        self.fate_canvas = tk.Canvas(
            dialog,
            width=500,
            height=480,
            bg=PANEL,
            highlightthickness=0,
            borderwidth=0,
        )
        self.fate_canvas.pack(padx=22, pady=(4, 8))
        self.fate_result_label = tk.Label(
            dialog,
            text="",
            bg=BG,
            fg=JASMINE,
            font=(HEADING_FONT, 17, "bold"),
        )
        self.fate_result_label.pack()
        self.fate_status_label = tk.Label(
            dialog,
            text="READY",
            bg=BG,
            fg=MUTED,
            font=(BODY_FONT, 10, "bold"),
        )
        self.fate_status_label.pack(pady=(2, 0))
        self.fate_timer_label = tk.Label(
            dialog,
            text="",
            bg=BG,
            fg=MUTED,
            font=(BODY_FONT, 10, "bold"),
        )
        self.fate_timer_label.pack(pady=(3, 12))
        self._draw_fate_wheel(0.0)
        dialog.lift()

    def _close_fate_window(self) -> None:
        if self.fate_countdown_after_id:
            try:
                self.root.after_cancel(self.fate_countdown_after_id)
            except Exception:
                pass
            self.fate_countdown_after_id = None
        if self.fate_window and self.fate_window.winfo_exists():
            self.fate_window.destroy()
        self.fate_window = None
        self.fate_canvas = None
        self.fate_result_label = None
        self.fate_status_label = None
        self.fate_timer_label = None

    def _draw_fate_wheel(self, rotation: float) -> None:
        canvas = self.fate_canvas
        if not canvas or not canvas.winfo_exists():
            return
        canvas.delete("all")
        cx, cy, radius = 250, 242, 188
        box = (cx - radius, cy - radius, cx + radius, cy + radius)
        for index, (name, _polarity) in enumerate(SEGMENTS):
            start = 67.5 + (index * 45) - rotation
            color = FATE_COLORS[name]
            canvas.create_arc(
                *box,
                start=start,
                extent=45,
                fill=color,
                outline=BG,
                width=3,
            )
            center_angle = math.radians(90 + (index * 45) - rotation)
            label_radius = radius * 0.66
            label_x = cx + label_radius * math.cos(center_angle)
            label_y = cy - label_radius * math.sin(center_angle)
            label_color = BG if color == JASMINE else TEXT
            canvas.create_text(
                label_x,
                label_y,
                text=name,
                fill=label_color,
                font=(BODY_FONT, 9, "bold"),
                width=92,
                justify="center",
            )
        canvas.create_oval(*box, outline=AQUA_VELVET, width=5)
        hub_radius = 31
        canvas.create_oval(
            cx - hub_radius,
            cy - hub_radius,
            cx + hub_radius,
            cy + hub_radius,
            fill=BG,
            outline=JASMINE,
            width=4,
        )
        canvas.create_text(cx, cy, text="FATE", fill=ACCENT, font=(HEADING_FONT, 10, "bold"))
        pointer_top = cy - radius - 26
        canvas.create_polygon(
            cx - 16,
            pointer_top,
            cx + 16,
            pointer_top,
            cx,
            pointer_top + 42,
            fill=JASMINE,
            outline=BG,
            width=3,
        )

    def _animate_fate_wheel(self) -> None:
        elapsed_ms = (time.monotonic() - self.fate_animation_started_at) * 1000.0
        progress = min(1.0, elapsed_ms / float(SPIN_DURATION_MS))
        eased = 1.0 - pow(1.0 - progress, 4)
        self._draw_fate_wheel(self.fate_animation_target * eased)
        if progress < 1.0:
            self.fate_animation_after_id = self.root.after(16, self._animate_fate_wheel)
            return
        self.fate_animation_after_id = None
        self._finish_fate_spin()

    def _finish_fate_spin(self) -> None:
        event = self.pending_fate_event
        self.pending_fate_event = None
        if not self.state or not event:
            self.generating = False
            self.input_box.configure(state="normal")
            self.wheel_button.configure(state="normal")
            return
        if self.fate_result_label and self.fate_result_label.winfo_exists():
            result_color = JASMINE if event.get("polarity") == "boon" else AQUA_VELVET
            self.fate_result_label.configure(text=str(event["result"]), fg=result_color)
        if self.fate_status_label and self.fate_status_label.winfo_exists():
            self.fate_status_label.configure(
                text=f"{str(event['polarity']).upper()} · THE WHEEL HAS SPOKEN",
                fg=MUTED,
            )
        self._update_fate_cooldown_window()
        ledger = event_ledger_line(event)
        if ledger:
            self._append_ledger(ledger)
        self._refresh_state_display()
        self.wheel_button.configure(state="normal")
        self.generating = False
        action = (
            f"The Wheel of Fate has produced {event['result']}. "
            "Interrupt the current flow and manifest the exact committed consequence dramatically in the present scene."
        )
        self._start_generation(action, event, show_player=False)

    def _update_fate_cooldown_window(self) -> None:
        if not self.state or not self.fate_window or not self.fate_window.winfo_exists():
            self.fate_countdown_after_id = None
            return
        remaining = remaining_cooldown(self.state)
        if remaining <= 0:
            if self.fate_result_label and self.fate_result_label.winfo_exists():
                self.fate_result_label.configure(text="READY", fg=JASMINE)
            if self.fate_status_label and self.fate_status_label.winfo_exists():
                self.fate_status_label.configure(text="The interval has passed · invoke the Wheel again", fg=MUTED)
            if self.fate_timer_label and self.fate_timer_label.winfo_exists():
                self.fate_timer_label.configure(text="")
            self.fate_countdown_after_id = None
            return
        minutes, seconds = divmod(remaining, 60)
        history = self.state.get("fate", {}).get("history", [])
        latest = history[-1] if isinstance(history, list) and history and isinstance(history[-1], dict) else None
        if latest:
            if self.fate_result_label and self.fate_result_label.winfo_exists():
                result_color = JASMINE if latest.get("polarity") == "boon" else AQUA_VELVET
                self.fate_result_label.configure(text=str(latest.get("result") or ""), fg=result_color)
            if self.fate_status_label and self.fate_status_label.winfo_exists():
                self.fate_status_label.configure(
                    text=f"{str(latest.get('polarity') or '').upper()} · THE WHEEL HAS SPOKEN",
                    fg=MUTED,
                )
        if self.fate_timer_label and self.fate_timer_label.winfo_exists():
            self.fate_timer_label.configure(
                text=f"RECHARGING · {minutes}:{seconds:02d} REMAIN",
                fg=MUTED,
            )
        self.fate_countdown_after_id = self.root.after(1000, self._update_fate_cooldown_window)

    def _clear_transcript(self) -> None:
        self.transcript.configure(state="normal")
        self.transcript.delete("1.0", "end")
        self.transcript.configure(state="disabled")

    def _copy_transcript_selection(self, _event: tk.Event[Any] | None = None) -> str:
        ranges = self.transcript.tag_ranges("sel")
        if len(ranges) != 2:
            return "break"
        selected = self.transcript.get(ranges[0], ranges[1])
        if selected:
            self.root.clipboard_clear()
            self.root.clipboard_append(selected)
            self.root.update_idletasks()
        return "break"

    def _select_all_transcript(self, _event: tk.Event[Any] | None = None) -> str:
        self.transcript.tag_add("sel", "1.0", "end-1c")
        self.transcript.focus_set()
        self.transcript.see("1.0")
        return "break"

    def _show_transcript_menu(self, event: tk.Event[Any]) -> str:
        has_selection = len(self.transcript.tag_ranges("sel")) == 2
        self.transcript_menu.entryconfigure("Copy", state="normal" if has_selection else "disabled")
        try:
            self.transcript_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.transcript_menu.grab_release()
        return "break"

    def _append_message(self, speaker: str, text: str) -> None:
        visitor = speaker.casefold() in {"visitor", "player", "user"}
        display_speaker = transcript_speaker_label(self.state, speaker)
        self.transcript.configure(state="normal")
        if self.transcript.index("end-1c") != "1.0":
            self.transcript.insert("end", "\n\n")
        self.transcript.insert("end", f"{display_speaker}\n", "visitor_heading" if visitor else "gm_heading")
        self.transcript.insert("end", text.strip(), "visitor_body" if visitor else "body")
        self.transcript.configure(state="disabled")
        self.transcript.see("end")

    def _append_ledger(self, text: str) -> None:
        at_bottom = self._transcript_at_bottom()
        self.transcript.configure(state="normal")
        self.transcript.insert("end", "\n" + text, "ledger")
        self.transcript.configure(state="disabled")
        if at_bottom:
            self.transcript.see("end")

    def _begin_gm_message(self) -> None:
        self.transcript.configure(state="normal")
        if self.transcript.index("end-1c") != "1.0":
            self.transcript.insert("end", "\n\n")
        self.transcript.insert("end", "Aether Harbor\n", "gm_heading")
        self.transcript.configure(state="disabled")
        self.transcript.see("end")

    def _append_stream_chunk(self, chunk: str) -> None:
        # Do one append-only redraw per UI tick. Replacing/re-styling the whole
        # response or toggling the widget for every token causes the severe
        # streaming jitter seen in the earlier Mnemosyne build.
        at_bottom = self._transcript_at_bottom()
        self.transcript.configure(state="normal")
        self.transcript.insert("end", chunk, "body")
        self.transcript.configure(state="disabled")
        if at_bottom:
            self.transcript.see("end")

    def _finish_gm_message(self) -> None:
        # Chunks already follow the tail. Completion must not pull a reader
        # away from earlier paragraphs or add another layout/scroll pass.
        pass

    def _transcript_at_bottom(self) -> bool:
        # A fractional tolerance grows with transcript length and can mistake
        # several screens of older text for the bottom. Use one pixel instead.
        first, last = self.transcript.yview()
        visible = max(last - first, 1e-9)
        hidden_pixels = (1.0 - last) * self.transcript.winfo_height() / visible
        return hidden_pixels <= 1.0

    def _append_error(self, text: str) -> None:
        self.transcript.configure(state="normal")
        if self.transcript.index("end-1c") != "1.0":
            self.transcript.insert("end", "\n\n")
        self.transcript.insert("end", "Local error\n", "gm_heading")
        self.transcript.insert("end", text, "error")
        self.transcript.configure(state="disabled")
        self.transcript.see("end")

    def _on_close(self) -> None:
        try:
            self._cancel_secretary_idle()
            if self.fate_animation_after_id:
                try:
                    self.root.after_cancel(self.fate_animation_after_id)
                except Exception:
                    pass
                self.fate_animation_after_id = None
            self._close_fate_window()
            if self.state:
                self.store.save_state(self.state)
            self.model.close()
            self.background_model.close()
        finally:
            self.root.destroy()


def run(project_root: Path) -> None:
    root = tk.Tk()
    AetherHarborApp(root, project_root)
    root.mainloop()
