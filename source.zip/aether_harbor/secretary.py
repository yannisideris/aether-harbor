from __future__ import annotations

import re
from typing import Any

from .canon import AETHER_HARBOR_LOCAL_LOCATION_IDS, AETHER_HARBOR_REGIONAL_LOCATION_IDS
from .items import matching_inventory_item
from .local_model import LocalQwen
from .movement import active_site_root_id
from .persistence import CampaignStore


SELECTOR_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "keep": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "line_ids": {
                        "type": "array",
                        "items": {"type": "integer"},
                        "minItems": 1,
                        "maxItems": 3,
                    },
                    "kind": {
                        "type": "string",
                        "enum": [
                            "npc_signature",
                            "relationship",
                            "promise",
                            "place",
                            "clue",
                            "rumor",
                            "thread",
                            "resolution",
                            "world_texture",
                        ],
                    },
                    "subject": {"type": "string"},
                    "status": {
                        "type": "string",
                        "enum": ["confirmed", "rumor", "open", "resolved", "temporary"],
                    },
                    "shareable_seed": {"type": "boolean"},
                },
                "required": ["line_ids", "kind", "subject", "status", "shareable_seed"],
                "additionalProperties": False,
            },
            "maxItems": 6,
        },
        "npc_profiles": {
            "type": "array",
            "maxItems": 2,
            "items": {
                "type": "object",
                "properties": {
                    "line_ids": {
                        "type": "array",
                        "items": {"type": "integer"},
                        "minItems": 1,
                        "maxItems": 4,
                    },
                    "subject": {"type": "string"},
                    "anchor": {"type": "string"},
                    "tier": {"type": "string", "enum": ["encountered", "engaged", "entangled"]},
                    "role": {"type": "string"},
                    "appearance": {
                        "type": "string",
                        "description": "Physical description including specific facial traits and general physique.",
                    },
                    "demeanor": {"type": "string"},
                    "current_goal": {"type": "string"},
                    "current_pressure": {"type": "string"},
                    "attitude_to_player": {"type": "string"},
                    "promise_or_debt": {"type": "string"},
                    "private_seed": {"type": "string"},
                },
                "required": [
                    "line_ids", "subject", "anchor", "tier", "role", "appearance",
                    "demeanor", "current_goal", "current_pressure",
                    "attitude_to_player", "promise_or_debt", "private_seed"
                ],
                "additionalProperties": False,
            },
        },
    },
    "required": ["keep", "npc_profiles"],
    "additionalProperties": False,
}


SYSTEM = """
You are a light-touch campaign secretary, not a narrator. Select transcript
lines worth retaining because they preserve a distinctive emerging NPC, a
returnable place or spatial relation, an exact promise, a clue, a rumor, an
undertaking, or a resolved durable change. Also preserve one or two unusually
specific, reusable oddities when present: a local custom, material detail,
peculiar object, gesture, phrase, or contradiction that
gives the world or a person identity even when it has no immediate plot use.
Label those world_texture. When a currently carried object acquires a newly
observed durable identifying property -- an inscription, seal, contents,
material feature, damage, maker's mark, title, or similarly persistent fact --
prefer the exact line as world_texture and use the carried object's established
name or a clear noun from it as subject. Do not select the mere act of picking
an object up as such a property. Do not infer hidden purpose, value, magic, or
meaning beyond what the transcript actually establishes.
Do not summarize or paraphrase; return only line IDs
and labels. Do not reduce the selection to objectives and clues. Omit generic
atmosphere, abandoned plans, hypotheticals, accusations not established as
facts, and things explicitly not done. It is fine to keep only some useful
material. shareable_seed is true only for a compact person, place, custom, myth,
object, or rumor that could enrich a different campaign without carrying this
player's mechanical state. Favor concrete, distinctive, memorable world elements
over merely plot-important ones: an ordinary or local place, person, vessel,
architectural feature, object, or incidental detail can be an excellent shared
seed when it has a specific identity and could recur or transform well in another
voyage. A transient encounter may qualify if it is genuinely distinctive; generic
or interchangeable material should not. Return the small JSON object only.

Classification is literal: npc_signature is for a named person and their
distinctive traits or behavior; place is only for a physical location, route,
building, settlement, or geographic feature, never a person; world_texture is
also the correct kind for a distinctive named vessel or object when no more
specific kind exists. A named ship or boat (for example "Salty Gull") is a
vessel or place, NEVER an NPC. Preserve a newly named vessel when it carries the player
or appears likely to recur. A single model response may contain several useful
facts on different numbered lines; they may be selected separately. Every
line_id must be one of the bracketed IDs actually supplied below. Use the exact
subject name found in the selected line, limited to the person's, vessel's,
object's, or place's proper name/title rather than its descriptive clause. Do
not reselect a subject listed as already known baseline material merely to
repeat known facts. An already known emergent place may still be selected when an
exact supplied line gives it a concrete, distinctive, self-contained identity
worth carrying as a shareable echo; canonical baseline geography remains baseline.

Separately, npc_profiles may contain at most two people who have become more
than scenery in these lines. subject must reuse a person name or person label
actually present in the cited lines (for example "the man"); anchor may turn
that into a stable grounded descriptor (for example "Room 301 scribe"). Cite
exact line_ids.
Keep every field terse. role, appearance, demeanor, current_goal, current_pressure,
attitude_to_player, and promise_or_debt must be grounded in the supplied
transcript; use an empty string when unsupported. tier is encountered for a
noticed figure, engaged after meaningful interaction, and entangled for an
ongoing promise, conflict, pursuit, debt, or undertaking. private_seed may be
ONE short provisional possibility that adds personal depth without
contradicting the transcript. It is not established canon and must never be
revealed merely because it is stored. Do not invent biography, affiliations,
family history, or extra plot machinery. Record party agreements as memory only;
immediate party bookkeeping already owns membership and character sheets. Never
profile the player character, vessels, ships, boats, money, weapons, or other objects as NPCs.
""".strip()


ABANDONED_PLAN = re.compile(
    r"\b(?:leave|left)\b[^.!?]{0,80}\b(?:alone|untouched)|"
    r"\bwithout\b[^.!?]{0,80}\b(?:doing|taking|stealing|burning|touching)|"
    r"\b(?:do|did)\s+not\b|\bdon't\b|\bdecide(?:d)?\s+not\b",
    re.IGNORECASE,
)
HYPOTHETICAL = re.compile(r"\b(?:maybe|perhaps|could|might|would|what\s+if|should)\b", re.I)
FULFILLED_PROMISE = re.compile(
    r"\b(?:promise\s+(?:is|was|has\s+been)\s+(?:fulfilled|kept)|"
    r"fulfilled\s+(?:the|his|her|their|my)\s+promise|"
    r"returned\b[^.!?]{0,60}\bas\s+promised|debt\s+(?:is|was)\s+paid)\b",
    re.I,
)


def due(state: dict[str, Any], *, cadence: int = 8) -> bool:
    secretary = state.get("secretary") if isinstance(state.get("secretary"), dict) else {}
    last_turn = int(secretary.get("last_campaign_turn", 0) or 0)
    current_turn = int(state.get("turn_no", 0) or 0)
    interval = max(4, int(cadence))
    if current_turn < interval:
        return False
    latest_beat = current_turn - (current_turn % interval)
    return latest_beat > last_turn


def _evidence_chunks(text: str) -> list[str]:
    """Split a model turn into exact sentence-scale evidence, without rewriting it."""

    chunks: list[str] = []
    for paragraph in re.split(r"\n\s*\n", str(text).strip()):
        paragraph = paragraph.strip()
        if not paragraph:
            continue
        sentences = [
            match.group(0).strip()
            for match in re.finditer(
                r".+?(?:[.!?](?:[\"”’]+)?(?=\s|$)|$)",
                paragraph,
            )
            if match.group(0).strip()
        ]
        chunks.extend(sentences or [paragraph])
    return chunks


def _selector_units(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    units: list[dict[str, Any]] = []
    selector_id = 1
    for row in rows:
        for chunk in _evidence_chunks(str(row.get("text") or "")):
            units.append(
                {
                    "selector_id": selector_id,
                    "source_turn_id": int(row.get("id", row.get("sequence_no", selector_id))),
                    "sequence_no": int(row.get("sequence_no", selector_id)),
                    "speaker": str(row.get("speaker") or ""),
                    "text": chunk,
                }
            )
            selector_id += 1
    return units


def build_messages(
    rows: list[dict[str, Any]],
    *,
    known_subjects: list[str] | None = None,
    carried_items: list[str] | None = None,
    provisional_actors: list[str] | None = None,
) -> list[dict[str, str]]:
    transcript = "\n".join(
        f"[{int(unit['selector_id'])}] {str(unit['speaker']).upper()}: {str(unit['text']).strip()}"
        for unit in _selector_units(rows)
    )
    known = [" ".join(str(subject).split()) for subject in (known_subjects or []) if str(subject).strip()]
    baseline = (
        "ALREADY KNOWN BASELINE SUBJECTS — do not reselect as evidence without a distinctive change; npc_profiles may still update an active person:\n"
        + " | ".join(known[:32])
        + "\n\n"
        if known
        else ""
    )
    carried = [" ".join(str(value).split()) for value in (carried_items or []) if str(value).strip()]
    carried_block = (
        "CURRENT CARRIED ITEMS — a world_texture line may add a durable player-known property to one of these, but never invent a property:\n"
        + " | ".join(carried[:20])
        + "\n\n"
        if carried
        else ""
    )
    return [
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": baseline + carried_block + transcript},
    ]


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.casefold()).strip("_")[:48] or "emerging_place"


def _subject_key(value: str) -> str:
    folded = re.sub(r"[^a-z0-9 ]+", " ", value.casefold())
    return re.sub(r"^the\s+", "", " ".join(folded.split()))


def _normalized_status(kind: str, status: str, excerpt: str) -> str:
    """Keep the selector's labels useful without trusting semantic lifecycle guesses."""

    if kind == "rumor":
        return "rumor"
    if kind == "promise":
        return "resolved" if FULFILLED_PROMISE.search(excerpt) else "open"
    if kind == "resolution":
        return "resolved"
    if kind in {"npc_signature", "relationship", "place", "world_texture"}:
        return "temporary" if status == "temporary" else "confirmed"
    if kind in {"thread", "clue"} and status == "resolved":
        return "resolved"
    return status if status in {"confirmed", "open", "temporary"} else "open"


def _is_abandoned_player_plan(selected_rows: list[dict[str, Any]], all_rows: list[dict[str, Any]]) -> bool:
    if not selected_rows:
        return False
    if not all(str(row.get("speaker") or "").casefold() in {"visitor", "player", "user"} for row in selected_rows):
        return False
    selected_text = " ".join(str(row.get("text") or "") for row in selected_rows)
    if not HYPOTHETICAL.search(selected_text):
        return False
    last_sequence = max(int(row.get("sequence_no", 0)) for row in selected_rows)
    later = " ".join(
        str(row.get("text") or "")
        for row in all_rows
        if int(row.get("sequence_no", 0)) > last_sequence
    )
    return bool(ABANDONED_PLAN.search(later))


_NPC_TIER_RANK = {"encountered": 1, "engaged": 2, "entangled": 3}
_GENERIC_NPC_KEYS = {
    "man", "woman", "person", "figure", "servant", "guard", "soldier", "worker",
    "clerk", "merchant", "sailor", "porter", "patrolman", "householder", "attendant",
    "young man", "young woman", "older man", "older woman",
    "middle aged man", "middle aged woman",
}


def _clean_profile_field(value: Any, limit: int = 220) -> str:
    return " ".join(str(value or "").split())[:limit]


def _profile_subject_is_grounded(subject: str, selected_rows: list[dict[str, Any]]) -> bool:
    """Allow stable unnamed-person descriptors without accepting free invention."""
    wanted = _subject_key(subject)
    if not wanted:
        return False
    text = _subject_key(" ".join(str(row.get("text") or "") for row in selected_rows))
    if wanted in text:
        return True
    stop = {
        "the", "a", "an", "in", "at", "of", "from", "with", "and", "room",
        "floor", "hallway", "corridor", "man", "woman", "person", "figure",
    }
    tokens = [token for token in wanted.split() if len(token) >= 4 and token not in stop]
    if not tokens:
        return any(noun in text.split() for noun in ("man", "woman", "person", "figure"))
    hits = sum(1 for token in tokens if token in text.split())
    return hits >= max(1, (len(tokens) + 1) // 2)


def _anchor_content_tokens(value: str) -> set[str]:
    stop = {
        "the", "a", "an", "in", "at", "of", "from", "with", "and", "room",
        "floor", "hallway", "corridor", *_GENERIC_NPC_KEYS,
    }
    return {
        token for token in _subject_key(value).split()
        if len(token) >= 4 and token not in stop
    }


def _find_npc_card(
    state: dict[str, Any],
    subject: str,
    anchor: str = "",
    *,
    scope_id: str = "",
) -> tuple[str, dict[str, Any]]:
    npcs = state.setdefault("npcs", {})
    subject_key = _subject_key(subject)
    anchor_key = _subject_key(anchor)
    generic_subject = subject_key in _GENERIC_NPC_KEYS
    same_scope_generic_matches: list[tuple[str, dict[str, Any]]] = []
    same_scope_unnamed_cards: list[tuple[str, dict[str, Any]]] = []
    for npc_id, card in npcs.items():
        if not isinstance(card, dict):
            continue
        card_name = _subject_key(str(card.get("name") or ""))
        card_anchor = _subject_key(str(card.get("anchor") or ""))
        card_scope = str(card.get("site_root_id") or "")
        same_scope = not scope_id or not card_scope or scope_id == card_scope
        # Generic role labels are not identities.  "servant" in one villa
        # must never silently become "servant" in another.  For them, require
        # a stable anchor (and, when known, the same site scope).
        if generic_subject:
            if (
                anchor_key
                and anchor_key not in _GENERIC_NPC_KEYS
                and anchor_key == card_anchor
                and same_scope
            ):
                return str(npc_id), card
            if not anchor_key and card_name == subject_key and same_scope:
                same_scope_generic_matches.append((str(npc_id), card))
            continue
        if subject_key and subject_key in {card_name, card_anchor}:
            return str(npc_id), card
        if anchor_key and anchor_key not in _GENERIC_NPC_KEYS and anchor_key in {card_name, card_anchor}:
            return str(npc_id), card
        if card_name in _GENERIC_NPC_KEYS and same_scope:
            same_scope_unnamed_cards.append((str(npc_id), card))

    if generic_subject and not anchor_key and same_scope_generic_matches:
        if len(same_scope_generic_matches) == 1:
            return same_scope_generic_matches[0]
        exact_unanchored = [
            pair for pair in same_scope_generic_matches
            if _subject_key(str(pair[1].get("anchor") or "")) in {"", subject_key}
        ]
        if exact_unanchored:
            return max(exact_unanchored, key=lambda pair: int(pair[1].get("last_turn", 0) or 0))

    if not generic_subject and same_scope_unnamed_cards:
        wanted_tokens = _anchor_content_tokens(anchor)
        if wanted_tokens:
            token_matches = [
                pair for pair in same_scope_unnamed_cards
                if wanted_tokens & _anchor_content_tokens(str(pair[1].get("anchor") or ""))
            ]
            if len(token_matches) == 1:
                return token_matches[0]
        turn_no = int(state.get("turn_no", 0) or 0)
        bare_generic = [
            pair for pair in same_scope_unnamed_cards
            if _subject_key(str(pair[1].get("anchor") or "")) in _GENERIC_NPC_KEYS
            and turn_no - int(pair[1].get("last_turn", 0) or 0) <= 8
        ]
        if len(bare_generic) == 1 and len(same_scope_unnamed_cards) == 1:
            return bare_generic[0]

    identity = anchor or subject
    if generic_subject:
        scope_part = _slug(scope_id or "unscoped")
        base = f"npc_{scope_part}_{_slug(identity)}"
    else:
        base = f"npc_{_slug(identity)}"
    npc_id = base
    suffix = 2
    while npc_id in npcs:
        npc_id = f"{base}_{suffix}"
        suffix += 1
    card = npcs.setdefault(
        npc_id,
        {
            "name": subject,
            "anchor": anchor or subject,
            "role": "emerging",
            "signature_shards": [],
            "relations": [],
            "last_turn": state.get("turn_no", 0),
            "site_root_id": scope_id or None,
        },
    )
    return npc_id, card


def note_transcript_scope(state: dict[str, Any], sequence_no: int) -> None:
    """Persist source-time scope; transcript sequence and gameplay turn are distinct."""
    scopes = state.setdefault('transcript_scopes', {})
    scopes[str(sequence_no)] = {'site_root_id': active_site_root_id(state),
                                'turn_no': int(state.get('turn_no', 0))}
    for key in sorted(scopes, key=int)[:-256]:
        del scopes[key]


def _source_scopes(state, selected_rows):
    scopes = state.get('transcript_scopes') or {}
    return [scopes.get(str(row.get('sequence_no'))) for row in selected_rows]


def _scope_id_for_rows(state: dict[str, Any], selected_rows: list[dict[str, Any]]) -> str:
    sources = _source_scopes(state, selected_rows)
    if sources and all(isinstance(source, dict) for source in sources):
        ids = {str(source.get('site_root_id') or '') for source in sources}
        if len(ids) == 1:
            return ids.pop()
        return 'unknown_source_scope'
    # Old voyage transcripts have no reliable source-time location. Do not
    # infer it from incomparable sequence numbers and gameplay turns.
    if state.get('voyage') and selected_rows:
        return 'unknown_source_scope'
    return active_site_root_id(state)


def _source_turn(state, selected_rows, fallback=0):
    sources = _source_scopes(state, selected_rows)
    if sources and all(isinstance(source, dict) for source in sources):
        return max(int(source.get('turn_no', 0)) for source in sources)
    return fallback


def _apply_npc_profile(
    state: dict[str, Any],
    profile: dict[str, Any],
    selected_rows: list[dict[str, Any]],
) -> bool:
    subject = _clean_profile_field(profile.get("subject"), 120)
    anchor = _clean_profile_field(profile.get("anchor"), 120) or subject
    if not subject or not _profile_subject_is_grounded(subject, selected_rows):
        return False
    if _subject_is_player_or_reserved(state, subject) or _subject_is_player_or_reserved(state, anchor):
        return False
    if _subject_is_known_object(state, subject) or _subject_is_known_object(state, anchor):
        return False
    if _subject_is_known_place(state, subject) or _subject_is_known_place(state, anchor):
        return False
    if _subject_is_known_vessel(state, subject, selected_rows=selected_rows) or _subject_is_known_vessel(state, anchor, selected_rows=selected_rows):
        return False
    scope_id = _scope_id_for_rows(state, selected_rows)
    _npc_id, card = _find_npc_card(state, subject, anchor, scope_id=scope_id)
    if not card.get("name") or _subject_key(str(card.get("name") or "")) in _GENERIC_NPC_KEYS:
        card["name"] = subject
    card["anchor"] = anchor
    card.setdefault("site_root_id", scope_id or None)
    old_tier = str(card.get("profile_tier") or "encountered")
    new_tier = str(profile.get("tier") or "encountered")
    card["profile_tier"] = (
        new_tier
        if _NPC_TIER_RANK.get(new_tier, 1) >= _NPC_TIER_RANK.get(old_tier, 1)
        else old_tier
    )
    grounded = card.setdefault("hidden_profile", {})
    for key in (
        "role", "appearance", "demeanor", "current_goal", "current_pressure",
        "attitude_to_player", "promise_or_debt",
    ):
        value = _clean_profile_field(profile.get(key), 220)
        if value:
            grounded[key] = value
    if grounded.get("appearance"):
        from .party import find_companion
        comp = find_companion(state, str(card.get("name") or subject)) or find_companion(state, anchor)
        if isinstance(comp, dict) and not str(comp.get("appearance") or "").strip():
            comp["appearance"] = grounded["appearance"]
    private_seed = _clean_profile_field(profile.get("private_seed"), 220)
    if private_seed:
        card["latent_seed"] = {
            "text": private_seed,
            "status": "provisional",
            "created_turn": int(state.get("turn_no", 0) or 0),
        }
    card["last_profile_sequence"] = max(
        [int(row.get("sequence_no", 0) or 0) for row in selected_rows] or [0]
    )
    card["last_turn"] = _source_turn(state, selected_rows, card.get("last_turn", 0))
    card["last_curated_turn"] = state.get("turn_no", 0)
    
    # Membership is committed immediately by party_runtime, never from delayed history.
    return True


def _attach_known_item_detail(
    state: dict[str, Any],
    *,
    kind: str,
    subject: str,
    excerpt: str,
) -> bool:
    """Bind exact selected evidence to a carried object without another AI call.

    The secretary already selected the sentence as durable evidence.  This
    simply gives the physical object a small persistent memory slot so a seal,
    inscription or observed contents do not vanish when the transcript window
    ages out.  The evidence is stored verbatim; no property is inferred here.
    """

    if kind not in {"world_texture", "clue", "resolution"}:
        return False
    item = matching_inventory_item(state, subject)
    if not isinstance(item, dict):
        return False
    clean = " ".join(str(excerpt or "").split())[:420]
    if not clean:
        return False
    details = item.setdefault("known_details", [])
    if clean not in details:
        details.append(clean)
        del details[:-4]
    item["known_details_updated_at_turn"] = int(state.get("turn_no", 0) or 0)
    return True


def _update_soft_cards(
    state: dict[str, Any],
    *,
    kind: str,
    subject: str,
    status: str,
    excerpt: str,
    selected_rows: list[dict[str, Any]] | None = None,
) -> None:
    _attach_known_item_detail(
        state, kind=kind, subject=subject, excerpt=excerpt
    )
    if (
        kind in {"npc_signature", "relationship"}
        and subject
        and not _subject_is_player_or_reserved(state, subject)
        and not _subject_is_known_object(state, subject)
        and not _subject_is_known_place(state, subject)
        and not _subject_is_known_vessel(state, subject, selected_rows=selected_rows)
    ):
        scope_id = _scope_id_for_rows(state, selected_rows or [])
        _npc_id, card = _find_npc_card(
            state,
            subject,
            scope_id=scope_id,
        )
        card.setdefault("site_root_id", scope_id or None)
        key = "relations" if kind == "relationship" else "signature_shards"
        values = card.setdefault(key, [])
        if excerpt not in values:
            values.append(excerpt)
            del values[:-4]
        card["last_turn"] = _source_turn(state, selected_rows or [], card.get("last_turn", 0))
        card["last_curated_turn"] = state.get("turn_no", 0)
    elif kind == "promise" and subject:
        existing_npc = next(
            (
                card for card in state.setdefault("npcs", {}).values()
                if str(card.get("name") or "").casefold() == subject.casefold()
            ),
            None,
        )
        if isinstance(existing_npc, dict):
            relations = existing_npc.setdefault("relations", [])
            if excerpt not in relations:
                relations.append(excerpt)
                del relations[:-4]
            existing_npc["last_turn"] = state.get("turn_no", 0)
    if kind == "place" and subject:
        existing = next(
            (location_id for location_id, location in state.get("locations", {}).items() if str(location.get("name") or "").casefold() == subject.casefold()),
            None,
        )
        if not existing:
            location_id = f"generated_{_slug(subject)}"
            root_id = active_site_root_id(state)
            current = state["locations"].get(root_id, {})
            if root_id in AETHER_HARBOR_LOCAL_LOCATION_IDS:
                scope = "local"
            elif root_id in AETHER_HARBOR_REGIONAL_LOCATION_IDS:
                scope = "regional"
            else:
                scope = str(current.get("aether_geography_scope") or "distant")
            site = current.get("site_memory") if isinstance(current.get("site_memory"), dict) else {}
            matching_area = next(
                (
                    row for row in site.get("areas", [])
                    if isinstance(row, dict)
                    and _subject_key(row.get("name")) == _subject_key(subject)
                ),
                None,
            )
            state["locations"][location_id] = {
                "name": subject,
                "region": current.get("region", "Emerging geography"),
                "summary": excerpt[:500],
                "aliases": [subject],
                "stability": "provisional",
                "parent_hint": root_id,
                "aether_geography_scope": scope,
            }
            if matching_area is not None:
                state["locations"][location_id]["site_root_id"] = root_id
                state["locations"][location_id]["site_area_name"] = str(
                    matching_area.get("name") or subject
                )
        elif (
            not isinstance(state["locations"][existing].get("site_memory"), dict)
            and len(excerpt) > len(str(state["locations"][existing].get("summary") or ""))
        ):
            state["locations"][existing]["summary"] = excerpt[:500]
    if kind in {"clue", "rumor", "thread", "promise"}:
        threads = state.setdefault("threads", [])
        fingerprint = (kind, subject.casefold(), excerpt.casefold())
        if not any(
            (str(row.get("kind")), str(row.get("subject", "")).casefold(), str(row.get("excerpt", "")).casefold()) == fingerprint
            for row in threads
            if isinstance(row, dict)
        ):
            threads.append({"kind": kind, "subject": subject, "status": status, "excerpt": excerpt, "last_turn": state.get("turn_no", 0)})
            del threads[:-8]


def _remove_soft_card(
    state: dict[str, Any],
    *,
    kind: str,
    subject: str,
    excerpt: str,
) -> None:
    """Undo only the derived card contribution of one evidence record."""

    if kind in {"npc_signature", "relationship"} and subject:
        card = next(
            (
                value for value in state.get("npcs", {}).values()
                if isinstance(value, dict)
                and _subject_key(str(value.get("name") or "")) == _subject_key(subject)
            ),
            None,
        )
        if isinstance(card, dict):
            key = "relations" if kind == "relationship" else "signature_shards"
            card[key] = [value for value in card.get(key, []) if value != excerpt]
            if (
                card.get("role") == "emerging"
                and not card.get("signature_shards")
                and not card.get("relations")
                and not card.get("hidden_profile")
            ):
                doomed = next(
                    (key for key, value in state.get("npcs", {}).items() if value is card),
                    None,
                )
                if doomed:
                    state.get("npcs", {}).pop(doomed, None)
    elif kind == "place" and subject:
        location_id = f"generated_{_slug(subject)}"
        location = state.get("locations", {}).get(location_id)
        if (
            isinstance(location, dict)
            and str(location.get("summary") or "") == excerpt[:500]
            and str(state.get("current_location_id") or "") != location_id
        ):
            state.get("locations", {}).pop(location_id, None)
    elif kind in {"clue", "rumor", "thread", "promise"}:
        state["threads"] = [
            row
            for row in state.get("threads", [])
            if not (
                isinstance(row, dict)
                and str(row.get("kind") or "") == kind
                and str(row.get("subject") or "").casefold() == subject.casefold()
                and str(row.get("excerpt") or "") == excerpt
            )
        ]


def _subject_is_known_object(state: dict[str, Any], subject: str) -> bool:
    """Reject the exact token-as-person failure without maintaining an item lexicon."""

    wanted = _subject_key(subject)
    if not wanted:
        return False
    # Money is an engine resource, not a character, even before it is in inventory.
    if re.fullmatch(
        r"(?:(?:[0-9]+|one|two|three|four|five|six|seven|eight|nine|ten)\s+)?"
        r"(?:silver|coins?|silver pieces|silver coins)",
        wanted,
    ):
        return True
    names = [
        str(item.get("name") or "")
        for item in state.get("player", {}).get("inventory", [])
        if isinstance(item, dict)
    ]
    names.extend(
        str(item.get("name") or "")
        for item in state.get("scene_objects", [])
        if isinstance(item, dict)
    )
    return any(
        wanted == _subject_key(name)
        or (len(wanted) >= 6 and wanted in _subject_key(name))
        for name in names
        if name.strip()
    )


def _subject_is_known_place(state: dict[str, Any], subject: str) -> bool:
    wanted = _subject_key(subject)
    if not wanted:
        return False
    person_tail = re.search(
        r"\b(?:man|woman|person|figure|attendant|clerk|guard|watchman|keeper|master|mistress|merchant|sailor|captain|worker|servant|bartender|barkeep|innkeeper|priest|monk|soldier|porter)\b$",
        wanted,
        re.I,
    )
    if person_tail:
        return False
    if re.match(
        r"^(?:guild|guildhall|house|temple|sanctuary|palace|palazzo|tower|lighthouse|library|archive|office|museum|fortress|citadel|monastery|abbey|cathedral|academy|observatory|bank|courthouse)\s+of\b",
        wanted,
        re.I,
    ):
        return True
    for location in state.get("locations", {}).values():
        if not isinstance(location, dict):
            continue
        site = location.get("site_memory") if isinstance(location.get("site_memory"), dict) else {}
        area_names = [
            area.get("name")
            for area in (site.get("areas") or [])
            if isinstance(area, dict) and area.get("name")
        ]
        for value in [location.get("name"), *(location.get("aliases") or []), site.get("site_name"), *area_names]:
            if wanted == _subject_key(str(value or "")):
                return True
    return False


def _subject_is_player_or_reserved(state: dict[str, Any], subject: str) -> bool:
    wanted = _subject_key(subject)
    reserved = {
        "aether harbor", "gm", "game master", "assistant", "visitor",
        "player", "player character", "protagonist", "user",
        _subject_key(str(state.get("player", {}).get("name") or "")),
    }
    return not wanted or wanted in reserved


def _register_known_vessel(state: dict[str, Any], vessel_name: str) -> None:
    if not vessel_name or not isinstance(state, dict):
        return
    clean = " ".join(str(vessel_name).split()).strip()
    if not clean:
        return
    vessels = state.setdefault("known_vessels", [])
    key = _subject_key(clean)
    if not any(_subject_key(str(v)) == key for v in vessels):
        vessels.append(clean)


def _subject_is_known_vessel(
    state: dict[str, Any],
    subject: str,
    *,
    selected_rows: list[dict[str, Any]] | None = None,
) -> bool:
    wanted = _subject_key(subject)
    if not wanted:
        return False

    if any(wanted == _subject_key(str(v or '')) for v in state.get('known_vessels', [])):
        return True

    for location in state.get('locations', {}).values():
        if isinstance(location, dict) and location.get('kind') == 'vessel':
            for val in [location.get('name'), *(location.get('aliases') or [])]:
                if wanted == _subject_key(str(val or '')):
                    return True

    voyage = state.get('voyage')
    if isinstance(voyage, dict) and wanted == _subject_key(str(voyage.get('vessel_name') or '')):
        return True

    # State identity takes precedence over a name that happens to contain a title.
    # Text evidence must describe THIS subject as a vessel, not merely place a
    # named person in a sentence about tides, manifests or boarding.
    raw = re.escape(wanted)
    for row in selected_rows or []:
        text = _subject_key(str(row.get("text") or ""))
        patterns = (
            rf"\b(?:ship|vessel|boat|sloop|schooner|ferry)\s+(?:named\s+|called\s+)?(?:the\s+)?{raw}\b",
            rf"\b{raw}\s+is\s+(?:a\s+|the\s+)?(?:ship|vessel|boat|sloop|schooner|ferry)\b",
            rf"\b{raw}\s+(?:is\s+clearing\s+(?:her|its)\s+holds|has\s+(?:\d+|one|two|three|four)\s+berths)\b",
        )
        if any(re.search(pattern, text) for pattern in patterns):
            _register_known_vessel(state, subject)
            return True

    return False


def _npc_subject_is_grounded(
    state: dict[str, Any],
    subject: str,
    selected_rows: list[dict[str, Any]],
) -> bool:
    """A transcript role label is not a named person inside the fiction."""

    if _subject_is_player_or_reserved(state, subject):
        return False
    if _subject_is_known_vessel(state, subject, selected_rows=selected_rows):
        return False
    wanted = _subject_key(subject)
    return any(
        wanted in _subject_key(str(row.get("text") or ""))
        for row in selected_rows
    )


def run(
    *,
    model: LocalQwen,
    store: CampaignStore,
    state: dict[str, Any],
    save_state: bool = True,
) -> dict[str, Any]:
    secretary_state = state.setdefault("secretary", {"last_sequence": 0, "last_campaign_turn": 0})
    rows = store.turns_after(
        state["campaign_id"],
        int(secretary_state.get("last_sequence", 0) or 0),
        limit=64,
    )
    if not rows:
        secretary_state["last_campaign_turn"] = state.get("turn_no", 0)
        return {"selected": 0, "saved": 0, "shared": 0, "profiled_npcs": 0}
    selector_units = _selector_units(rows)
    known_subjects: list[str] = []
    for location in state.get("locations", {}).values():
        if not isinstance(location, dict):
            continue
        site = location.get("site_memory") if isinstance(location.get("site_memory"), dict) else {}
        for value in [location.get("name"), *(location.get("aliases") or []), site.get("site_name")]:
            if str(value or "").strip():
                known_subjects.append(str(value))
    for card in state.get("npcs", {}).values():
        if not isinstance(card, dict):
            continue
        for value in (card.get("name"), card.get("anchor")):
            if str(value or "").strip():
                known_subjects.append(str(value))
    for vessel in state.get("known_vessels", []):
        if str(vessel or "").strip():
            known_subjects.append(str(vessel))
    known_subject_keys = {_subject_key(subject) for subject in known_subjects}
    echo_eligible_known_place_keys: set[str] = set()
    for location_id, location in state.get("locations", {}).items():
        if not isinstance(location, dict):
            continue
        if location_id in AETHER_HARBOR_LOCAL_LOCATION_IDS or location_id in AETHER_HARBOR_REGIONAL_LOCATION_IDS:
            continue
        site = location.get("site_memory") if isinstance(location.get("site_memory"), dict) else {}
        for value in [location.get("name"), *(location.get("aliases") or []), site.get("site_name")]:
            key = _subject_key(str(value or ""))
            if key:
                echo_eligible_known_place_keys.add(key)
    payload = model.chat_json(
        build_messages(
            rows,
            known_subjects=known_subjects,
            carried_items=[
                str(item.get("name") or "")
                for item in state.get("player", {}).get("inventory", [])
                if isinstance(item, dict)
            ],
            provisional_actors=[
                str(actor)
                for actor in (state.get("provisional_npc_anchors") or [])
                if str(actor or "").strip()
            ],
        ),
        schema=SELECTOR_SCHEMA,
        temperature=0.1,
    )
    unit_by_selector = {int(unit["selector_id"]): unit for unit in selector_units}
    profiled = 0
    alerts = []
    for profile in payload.get("npc_profiles", [])[:2]:
        if not isinstance(profile, dict):
            continue
        selected_profile_rows = [
            unit_by_selector[int(line_id)]
            for line_id in profile.get("line_ids", [])
            if str(line_id).lstrip("-").isdigit() and int(line_id) in unit_by_selector
        ]
        if selected_profile_rows and _apply_npc_profile(state, profile, selected_profile_rows):
            profiled += 1

    saved = 0
    shared = 0
    prepared: dict[tuple[str, str], dict[str, Any]] = {}
    for candidate in payload.get("keep", [])[:6]:
        if not isinstance(candidate, dict):
            continue
        selected_rows = [
            unit_by_selector[int(line_id)]
            for line_id in candidate.get("line_ids", [])
            if str(line_id).lstrip("-").isdigit() and int(line_id) in unit_by_selector
        ]
        if not selected_rows or _is_abandoned_player_plan(selected_rows, rows):
            continue
        kind = str(candidate.get("kind") or "clue")
        subject = " ".join(str(candidate.get("subject") or "Emerging detail").split())[:120]
        if kind == "npc_signature" and _subject_is_known_object(state, subject):
            kind = "world_texture"
        elif kind == "npc_signature" and _subject_is_known_place(state, subject):
            kind = "place"
        elif kind == "npc_signature" and _subject_is_known_vessel(state, subject, selected_rows=selected_rows):
            kind = "world_texture"
        if kind in {"npc_signature", "relationship"} and not _npc_subject_is_grounded(
            state, subject, selected_rows
        ):
            continue
        candidate_shareable = bool(candidate.get("shareable_seed")) and kind in {
            "npc_signature", "place", "clue", "rumor", "world_texture"
        }
        subject_key = _subject_key(subject)
        if kind in {"place", "world_texture"} and subject_key in known_subject_keys:
            if not (
                kind == "place"
                and candidate_shareable
                and subject_key in echo_eligible_known_place_keys
            ):
                continue
        status = str(candidate.get("status") or "open")
        if kind == "rumor":
            status = "rumor"
        if kind in {"place", "npc_signature"} and all(
            str(row.get("speaker") or "").casefold() in {"visitor", "player", "user"}
            for row in selected_rows
        ):
            world_matches = [
                row for row in selector_units
                if str(row.get("speaker") or "").casefold() not in {"visitor", "player", "user"}
                and subject.casefold() in str(row.get("text") or "").casefold()
            ]
            if world_matches:
                selected_rows = [max(world_matches, key=lambda row: len(str(row.get("text") or "")))]
        excerpt = " / ".join(str(row["text"]).strip() for row in selected_rows)[:900]
        status = _normalized_status(kind, status, excerpt)
        shareable = candidate_shareable
        all_world_lines = all(
            str(row.get("speaker") or "").casefold() not in {"visitor", "player", "user"}
            for row in selected_rows
        )
        key = (kind, subject.casefold())
        prepared_candidate = {
            "kind": kind,
            "subject": subject,
            "status": status,
            "excerpt": excerpt,
            "shareable": shareable,
            "all_world_lines": all_world_lines,
            "selected_rows": selected_rows,
        }
        previous = prepared.get(key)
        candidate_score = (1 if all_world_lines else 0, len(excerpt))
        previous_score = (
            (1 if previous and previous["all_world_lines"] else 0),
            len(str(previous.get("excerpt") or "")) if previous else -1,
        )
        if previous is None or candidate_score > previous_score:
            prepared[key] = prepared_candidate

    structural_priority = {
        "npc_signature": 3,
        "relationship": 3,
        "promise": 3,
        "place": 3,
        "clue": 2,
        "rumor": 2,
        "thread": 2,
        "resolution": 2,
        "world_texture": 1,
    }
    deduped_by_source: dict[tuple[int, ...], tuple[tuple[str, str], dict[str, Any]]] = {}
    for key, entry in prepared.items():
        source_key = tuple(sorted(int(row["selector_id"]) for row in entry["selected_rows"]))
        previous_pair = deduped_by_source.get(source_key)
        if previous_pair is None:
            deduped_by_source[source_key] = (key, entry)
            continue
        previous_key, previous_entry = previous_pair
        previous_rank = structural_priority.get(str(previous_entry["kind"]), 0)
        current_rank = structural_priority.get(str(entry["kind"]), 0)
        if current_rank > previous_rank:
            entry["shareable"] = bool(entry["shareable"] or previous_entry["shareable"])
            deduped_by_source[source_key] = (key, entry)
        else:
            previous_entry["shareable"] = bool(previous_entry["shareable"] or entry["shareable"])
            deduped_by_source[source_key] = (previous_key, previous_entry)
    prepared = {key: entry for key, entry in deduped_by_source.values()}

    selected_count = len(prepared)
    for entry in prepared.values():
        kind = str(entry["kind"])
        subject = str(entry["subject"])
        status = str(entry["status"])
        excerpt = str(entry["excerpt"])
        selected_rows = list(entry["selected_rows"])
        shareable = bool(entry["shareable"])
        evidence_id = store.add_evidence(
            state["campaign_id"],
            kind=kind,
            subject=subject,
            status=status,
            source_turn_ids=sorted({int(row["source_turn_id"]) for row in selected_rows}),
            excerpt=excerpt,
            priority=2 if kind in {"npc_signature", "promise", "place"} else 1,
            shareable_seed=shareable,
        )
        if evidence_id is None:
            continue
        saved += 1
        _update_soft_cards(
            state,
            kind=kind,
            subject=subject,
            status=status,
            excerpt=excerpt,
            selected_rows=selected_rows,
        )
        if shareable and entry["all_world_lines"]:
            scale = "person" if kind == "npc_signature" else ("site" if kind == "place" else "shard")
            if store.add_shared_echo(
                source_campaign_id=state["campaign_id"],
                scale=scale,
                kind=kind,
                subject=subject,
                text=excerpt,
                tags=[status],
            ) is not None:
                shared += 1
    secretary_state["last_sequence"] = max(int(row["sequence_no"]) for row in rows)
    secretary_state["last_campaign_turn"] = state.get("turn_no", 0)
    if isinstance(state.get("provisional_npc_anchors"), list):
        reviewed_text = _subject_key(" ".join(str(row.get("text") or "") for row in rows))
        known_npc_keys = {
            _subject_key(str(value or ""))
            for card in state.get("npcs", {}).values()
            if isinstance(card, dict)
            for value in (card.get("name"), card.get("anchor"))
        }
        state["provisional_npc_anchors"] = [
            actor
            for actor in state["provisional_npc_anchors"]
            if _subject_key(str(actor))
            and _subject_key(str(actor)) not in known_npc_keys
            and _subject_key(str(actor)) not in reviewed_text
        ]
    if saved:
        curator = state.setdefault("state_curator", {})
        curator["pending_evidence_review"] = True
    if save_state:
        store.save_state(state)
    return {"selected": selected_count, "saved": saved, "shared": shared, "profiled_npcs": profiled, "alerts": alerts}
