"""Shared paid-passage lifecycle. No model calls, new odds, or save migrations."""
from __future__ import annotations
import copy
import hashlib
import re
from typing import Any

ACTIONS = ['NONE', 'BOARD', 'WAIT_DEPARTURE', 'WAIT', 'FINISH', 'DISEMBARK', 'RESOLVE_INCIDENT']
WAIT = re.compile(r"\b(?:wait|sleep|rest|pass\s+(?:my|the)\s+time|hours?\s+pass|fast.forward|skip)\b", re.I)
BOARD = re.compile(r"\b(?:board|embark|go\s+aboard|step\s+aboard)\b", re.I)
FINISH = re.compile(r"\b(?:until|till)\b.*\b(?:arriv\w*|reach\w*|complete\w*|over|destination|ends?)\b|\b(?:finish|complete|skip)\s+(?:the\s+)?(?:voyage|journey|crossing)\b", re.I)
DEPARTURE = re.compile(r"\b(?:depart\w*|sail\w*|cast\s+off|tomorrow)\b", re.I)
TIME_ACTIONS = {'WAIT', 'WAIT_DEPARTURE', 'FINISH'}

# Private storm progression while meaningful voyage time passes (WAIT/FINISH
# during an unresolved Storm). Each check eases the storm on d20 >= target; the
# target falls with every check, so a storm cannot last forever:
# 25% -> 40% -> 55% -> 70% (floor). Ambushes never leave on their own.
STORM_EASE_TARGET = 16
STORM_EASE_STEP = 3
STORM_EASE_FLOOR = 7


def semantic_owns_voyage(semantic: dict | None) -> bool:
    """True when the semantic classifier explicitly judged the voyage intent.

    Its NONE is a decision, not a missing value: keyword fallbacks (board,
    wait, rest, until ... over) are reserved for legacy/offline payloads that
    carry no voyage_action field at all.
    """
    return isinstance(semantic, dict) and 'voyage_action' in semantic


def semantic_voyage_action(semantic: dict | None) -> str:
    action = str((semantic or {}).get('voyage_action') or 'NONE')
    return action if action in ACTIONS else 'NONE'


def clean_destination(value: str) -> str:
    name = re.split(r"\s+(?:aboard|on\s+board|on\s+the\s+(?:ship|boat|ferry|vessel))\b", str(value), maxsplit=1, flags=re.I)[0]
    name = ' '.join(name.split()).strip(' ,.;:!?"\'')[:100]
    from .island_bank import ISLANDS_BY_ID
    key = re.sub(r'^the\s+', '', name, flags=re.I).casefold()
    matches = [row['name'] for row in ISLANDS_BY_ID.values()
               if re.sub(r'^the\s+', '', row['name'], flags=re.I).casefold() == key]
    return matches[0] if len(matches) == 1 else name


def is_passage_resource(resource: dict | None) -> bool:
    """Semantic ownership first; narrow compatibility for pre-field payloads."""
    if not isinstance(resource, dict) or resource.get('kind') not in {'purchase', 'pay'}:
        return False
    if 'service_type' in resource:
        return resource.get('service_type') == 'passage'
    return (resource.get('item_kind', 'service') == 'service'
            and bool(re.search(r'\b(?:passage|ticket|fare|berth)\b', str(resource.get('item') or ''), re.I)))


def generic_destination(name: str) -> bool:
    return clean_destination(name).casefold() in {
        '', 'none', 'unknown', 'unknown islands', 'the destination', 'destination',
        'an island', 'islands', 'unknown island', 'somewhere',
    }


def quoted_destination(quote: str, supplied: str = '') -> str:
    """Read a grounded semantic name or one unambiguous authored identity.

    Do not guess an improvised destination by parsing a sentence's grammar.
    """
    plain = ' '.join(re.sub(r'[*_`]', '', quote).casefold().split())
    name = clean_destination(supplied)
    if not generic_destination(name) and name.casefold() in plain:
        return name
    from .island_bank import ISLANDS_BY_ID
    matches = [row['name'] for row in ISLANDS_BY_ID.values()
               if str(row['name']).casefold().removeprefix('the ') in plain]
    return matches[0] if len(matches) == 1 else ''


def offer_details(narration: str, supplied: dict | None = None) -> dict:
    """Keep exact quote evidence; accept semantic details only if present in it."""
    plain = re.sub(r'[*_`]', '', narration)
    out = {'quote_text': narration[:2400]}
    for key in ('vessel_name', 'departure_label', 'duration_label'):
        value = ' '.join(str((supplied or {}).get(key) or '').split())[:120]
        if value and value.casefold() in plain.casefold(): out[key] = value
    if 'vessel_name' not in out:
        match = re.search(r"\b(?:aboard|on board|ship|vessel|ferry)\s+(?:the\s+)?([A-Z][\w'-]*(?:\s+[A-Z][\w'-]*){0,2})", plain)
        if not match:
            match = re.search(r"\b[Tt]he\s+([A-Z][\w'-]*(?:\s+[A-Z][\w'-]*){0,2})\s+(?:sails|departs|leaves)\b", plain)
        if match: out['vessel_name'] = match.group(1)
    if 'departure_label' not in out:
        match = re.search(r'\b(?:tomorrow|tonight|today|at dawn|at dusk|at noon)(?:\s+(?:morning|afternoon|evening))?(?:,?\s+weather permitting)?', plain, re.I)
        if match: out['departure_label'] = match.group(0)
    if 'duration_label' not in out:
        match = re.search(r'\b(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|twelve)\s+(?:hours?|days?)\b', plain, re.I)
        if match: out['duration_label'] = match.group(0)
    return out


def current(state: dict) -> dict | None:
    value = state.get('voyage')
    return value if isinstance(value, dict) else None


def context(state: dict) -> dict | None:
    v = current(state)
    if not v: return None
    return {**copy.deepcopy(v), 'instruction': (
        'Authoritative paid passage. Payment never moves the player. Preserve ship identity and sealed rooms. '
        'Narrate only committed phase/time changes. WAIT/FINISH advances to incident or arrival; never add filler hours. '
        'An unresolved incident blocks arrival; only a successful substantive resolution releases it, '
        'or, for a storm only, the engine\'s private weather check while meaningful time passes. '
        'Voyage time is qualitative unless the quote gives a duration; do not invent an elapsed-hour clock. '
        'The risk draw is private engine bookkeeping, never a request for a player roll.'),
        'vessel_location':copy.deepcopy(state.get('locations', {}).get(v.get('vessel_id'), {}).get('vessel_location'))}


def book(state: dict, offer: dict) -> dict:
    from .canon import AETHER_HARBOR_LOCAL_LOCATION_IDS, AETHER_HARBOR_REGIONAL_LOCATION_IDS
    name = clean_destination(offer['destination_name'])
    harbor = set(AETHER_HARBOR_LOCAL_LOCATION_IDS) | set(AETHER_HARBOR_REGIONAL_LOCATION_IDS)
    embarkation = state['current_location_id']; seen = set()
    while embarkation not in seen:
        if embarkation in harbor:
            embarkation = 'commercial_docks'; break
        seen.add(embarkation)
        parent = state['locations'].get(embarkation, {}).get('parent_hint')
        if not parent or parent not in state['locations']: break
        embarkation = parent
    serial = int(state.get('voyage_serial', 0)) + 1
    state['voyage_serial'] = serial
    old = current(state)
    if old: state.setdefault('voyage_history', []).append(copy.deepcopy(old))
    vessel_id = offer.get('vessel_id')
    vessel_name = offer.get('vessel_name') or f'Passage vessel to {name}'
    if not vessel_id and offer.get('vessel_name'):
        vessel_id = vessel_site_id(state, offer['vessel_name'], embarkation_id=embarkation,
                                   allow_untyped=bool(offer.get('quote_text')))
    initial_phase = 'aboard' if vessel_id and state.get('current_location_id') == vessel_id else 'booked'
    if vessel_id in state.get('locations', {}):
        vessel = state['locations'][vessel_id]
        vessel['kind'] = 'vessel'
        vessel.setdefault('vessel_location', {'status': 'moored', 'location_id': embarkation})
    v = {'id': f"passage-{serial}", 'phase': initial_phase, 'destination_name': name,
         'origin_id': state['current_location_id'], 'embarkation_id': embarkation,
         'price_paid': int(offer['price']), 'booked_at_turn': int(state.get('turn_no', 0)),
         'vessel_name': vessel_name,
         'departure_label': offer.get('departure_label') or 'next available sailing',
         'duration_label': offer.get('duration_label') or '', 'quote_text': offer.get('quote_text', ''),
         'departure_ready': False, 'risk': None, 'elapsed_segments': [], 'transitions': []}
    if vessel_id:
        v['vessel_id'] = vessel_id
    state['voyage'] = v
    return v


def _event(v: dict, action: str, **extra) -> dict:
    return {'type': 'voyage_resolution', 'committed': True, 'action': action,
            'voyage_id': v['id'], 'phase': v['phase'], 'destination_name': v['destination_name'],
            'vessel_name': v['vessel_name'], **extra}


def _phase(state: dict, v: dict, phase: str):
    v['transitions'].append({'from': v['phase'], 'to': phase, 'turn': int(state.get('turn_no', 0))})
    v['phase'] = phase


def _destination(state: dict, v: dict) -> str:
    from .movement import _emergent_id
    from .island_bank import maybe_bind_island
    name = clean_destination(v['destination_name']); v['destination_name'] = name
    key = name.casefold().removeprefix('the ')
    known = [loc_id for loc_id, loc in state['locations'].items()
             if str(loc.get('name', '')).casefold().removeprefix('the ') == key
             and loc.get('aether_geography_scope') not in {'local', 'regional'}
             and loc.get('kind') != 'vessel']
    target = known[0] if len(known) == 1 else _emergent_id(name)
    if target in state['locations'] and state['locations'][target].get('aether_geography_scope') in {'local', 'regional'}:
        target = _emergent_id('voyage destination: ' + name)
    loc = state['locations'].setdefault(target, {'name': name, 'region': 'Distant island',
        'aliases': [name], 'provisional': True, 'visit_count': 0,
        'summary': 'A booked destination beyond Aether Harbor.', 'aether_geography_scope': 'distant'})
    loc['island_destination'] = True
    maybe_bind_island(state, name, {'type':'movement', 'committed':True, 'to_id':target, 'to_name':name})
    loc['aether_geography_scope'] = 'distant'
    v['destination_id'] = target
    return target


def _aboard(state: dict, v: dict) -> bool:
    return bool(v.get('vessel_id') and state.get('current_location_id') == v['vessel_id'])


def _movement(state: dict, target: str, name: str) -> dict:
    origin = state['current_location_id']
    state['current_location_id'] = target; state['scene_position'] = None
    loc = state['locations'][target]
    loc['visit_count'] = int(loc.get('visit_count', 0)) + 1
    loc['last_arrival_from'] = origin
    if loc.get('provisional') and not loc.get('defining_excerpt'):
        state['pending_arrival_anchor_id'] = target
    return {'type':'movement', 'committed':True, 'from_id':origin,
            'from_name':state['locations'][origin]['name'], 'to_id':target, 'to_name':name}


def vessel_site_id(state: dict, name: str, *, embarkation_id: str | None = None,
                   allow_untyped: bool = False) -> str:
    """Use the same vessel root for spatial boarding and paid passage."""
    from .movement import _emergent_id
    key = lambda value: re.sub(r'^the\s+', '', ' '.join(str(value).split()).casefold())
    matches = [loc_id for loc_id, loc in state.get('locations', {}).items()
               if loc.get('kind') == 'vessel' and key(loc.get('name', '')) == key(name)]
    if not matches and allow_untyped:
        from .canon import AETHER_HARBOR_LOCAL_LOCATION_IDS, AETHER_HARBOR_REGIONAL_LOCATION_IDS
        harbor = set(AETHER_HARBOR_LOCAL_LOCATION_IDS) | set(AETHER_HARBOR_REGIONAL_LOCATION_IDS)
        matches = [loc_id for loc_id, loc in state.get('locations', {}).items()
                   if key(loc.get('name', '')) == key(name)
                   and loc_id not in harbor
                   and (loc.get('parent_hint') == embarkation_id
                        or loc.get('site_root_id') == loc_id
                        or loc_id == _emergent_id(name))]
    if len(matches) > 1:
        raise ValueError('Ambiguous vessel identity; resolve the existing vessel before boarding.')
    if matches and embarkation_id:
        mooring = state['locations'][matches[0]].get('vessel_location') or {}
        if mooring and (mooring.get('status') != 'moored' or mooring.get('location_id') != embarkation_id):
            raise ValueError('The existing vessel is not moored at this embarkation port.')
    return matches[0] if matches else _emergent_id('vessel: ' + key(name))


def _board(state: dict, v: dict) -> dict:
    from .canon import AETHER_HARBOR_LOCAL_LOCATION_IDS, AETHER_HARBOR_REGIONAL_LOCATION_IDS
    allowed = {v['origin_id'], v['embarkation_id']}
    if v['embarkation_id'] == 'commercial_docks':
        allowed |= set(AETHER_HARBOR_LOCAL_LOCATION_IDS) | set(AETHER_HARBOR_REGIONAL_LOCATION_IDS)
    position = state['current_location_id']
    seen = set()
    while position not in allowed and position not in seen:
        seen.add(position)
        position = state['locations'].get(position, {}).get('parent_hint')
    if position not in allowed:
        return _event(v, 'blocked', reason='Return to the booked embarkation port before boarding.')
    try:
        vessel_id = v.get('vessel_id') or vessel_site_id(state, v['vessel_name'], embarkation_id=v['embarkation_id'],
                                                         allow_untyped=bool(v.get('quote_text')))
    except ValueError as exc:
        return _event(v, 'blocked', reason=str(exc))
    vessel = state['locations'].setdefault(vessel_id, {'name':v['vessel_name'], 'kind':'vessel',
        'region':'Vessel', 'summary':'The vessel named in the paid passage.', 'aliases':[v['vessel_name']],
        'provisional':False, 'visit_count':0, 'site_root_id':vessel_id, 'aether_geography_scope':'local'})
    vessel['kind'] = 'vessel'  # Retype a reused quoted site only after identity checks passed.
    vessel['parent_hint'] = v['embarkation_id']
    vessel['vessel_location'] = {'status':'moored', 'location_id':v['embarkation_id']}
    v['vessel_id'] = vessel_id
    move = _movement(state, vessel_id, vessel['name'])
    memory = vessel.get('site_memory') or {}
    if memory.get('areas'):
        entry = memory.get('plan_lock', {}).get('entry_area') or memory['areas'][0]['name']
        memory['current_position'] = entry
        state['scene_position'] = {'id':f'{vessel_id}:entry', 'label':entry,
            'anchor_location_id':vessel_id, 'site_area':True, 'provisional':False}
    _phase(state, v, 'aboard')
    return _event(v, 'boarded', movement=move, departure_label=v['departure_label'])


def _depart(state: dict, v: dict):
    from .mechanics import _roll
    v['departure_ready'] = True
    if not any(row['kind'] == 'until_departure' for row in v['elapsed_segments']):
        v['elapsed_segments'].append({'kind':'until_departure', 'label':v['departure_label']})
    _phase(state, v, 'in_transit')
    state['locations'][v['vessel_id']]['vessel_location'] = {'status':'at_sea', 'destination_id':_destination(state, v)}
    state['locations'][v['vessel_id']].pop('parent_hint', None)
    state['locations'][v['vessel_id']]['aether_geography_scope'] = 'distant'
    state['locations'][v['vessel_id']]['region'] = 'At sea'
    if v.get('risk') is None:
        counter = int(state.get('rng_counter', 0)); raw = _roll(state, 20)
        v['risk'] = {'raw':raw, 'sides':20, 'rng_seed':state.get('rng_seed'), 'counter_before':counter,
                     'kind':'Ambush' if raw <= 2 else 'Storm' if raw <= 7 else 'none', 'resolved':raw > 7}


def _advance(state: dict, v: dict) -> dict:
    risk = v['risk']
    if not risk['resolved']:
        _phase(state, v, 'interrupted')
        v['elapsed_segments'].append({'kind':'crossing_to_incident', 'label':risk['kind']})
        state['active_situation'] = {'kind':'voyage_incident', 'status':'active', 'voyage_id':v['id'],
            'hazard':risk['kind'], 'anchor':v['vessel_id']}
        return _event(v, 'incident', travel_hazard=risk['kind'], instruction='Stop the time skip at this incident; arrival has not occurred.')
    target = _destination(state, v)
    _phase(state, v, 'arrived')
    v['elapsed_segments'].append({'kind':'crossing_complete', 'label':v['duration_label'] or 'the remaining crossing'})
    state['locations'][v['vessel_id']]['vessel_location'] = {'status':'moored', 'location_id':target}
    state['locations'][v['vessel_id']]['parent_hint'] = target
    state['locations'][v['vessel_id']]['region'] = f"Moored at {v['destination_name']}"
    return _event(v, 'arrived', geographic_arrival_id=target,
                  instruction='The ship has arrived. The player remains in the same ship area until disembarking.')


def resolve(state: dict, text: str, semantic: dict | None) -> dict | None:
    """Resolve compatible explicit movement before a passive voyage time step."""
    semantic = semantic or {}
    v = current(state)
    if v and _aboard(state, v):
        cur_loc = state.get('locations', {}).get(state.get('current_location_id'), {})
        dest = str(semantic.get('destination') or '').strip()
        if dest and (
            dest.casefold().removeprefix('the ') == str(v.get('vessel_name', '')).casefold().removeprefix('the ')
            or dest.casefold().removeprefix('the ') == str(cur_loc.get('name', '')).casefold().removeprefix('the ')
            or dest.casefold() in [str(a).casefold() for a in cur_loc.get('aliases', [])]
        ):
            semantic = {**semantic, 'movement_commitment': 'NONE', 'destination': '', 'destination_scope': 'NONE'}
    action = semantic_voyage_action(semantic)
    waiting = action in TIME_ACTIONS or (action == 'NONE' and not semantic_owns_voyage(semantic)
                                         and (bool(WAIT.search(text)) or bool(FINISH.search(text))))
    joint_party = bool(re.search(r"\b(?:we|i|let's|let\s+us)\b", text, re.I))
    companion_only = str(semantic.get('acting_companion') or 'NONE') != 'NONE' and not joint_party
    if (v and v['phase'] != 'completed' and waiting
            and not semantic.get('_deferred_voyage_transport')
            and not companion_only
            and semantic.get('movement_commitment') == 'COMMITTED'
            and semantic.get('destination')
            and not semantic.get('requires_roll')
            and (state.get('combat') or {}).get('status') != 'active'
            and (state.get('active_situation') or {}).get('status') != 'active'):
        from .movement import resolve_movement, resolve_destination
        name = str(semantic['destination'])
        known = resolve_destination(state, name)
        local_target = state.get('locations', {}).get(known, {}).get('aether_geography_scope') in {'local','regional'}
        if semantic.get('destination_scope') == 'LOCAL' or local_target:
            trial = copy.deepcopy(state)
            move = resolve_movement(trial, text, destination_hint=name,
                destination_scope='LOCAL', semantic_commitment=True)
            if _aboard(state, v) and trial.get('current_location_id') != state.get('current_location_id'):
                return _event(v, 'movement_blocked', reason='Remain aboard until explicit disembarkation at a mooring; no movement or time skip committed.')
            if not move or (not move.get('committed') and move.get('reason')):
                return _event(v, 'movement_blocked', movement=move,
                    reason='The requested movement was not possible; do not narrate it or advance the wait.')
            # Resolve the rest on the same detached state, then commit together.
            event = _resolve(trial, text, {**semantic, 'movement_commitment':'NONE', 'destination':''})
            if event is not None:
                def commit(target, source):
                    # Runtime callers may retain references to private turn
                    # bookkeeping dictionaries; preserve those identities.
                    for key in list(target):
                        if key not in source: del target[key]
                    for key, value in source.items():
                        if isinstance(value, dict) and isinstance(target.get(key), dict):
                            commit(target[key], value)
                        else: target[key] = value
                commit(state, trial)
                event['movement'] = move
                return event
    return _resolve(state, text, semantic)


def _resolve(state: dict, text: str, semantic: dict | None) -> dict | None:
    v = current(state)
    if not v or v['phase'] == 'completed': return None
    if _aboard(state, v) and v['phase'] == 'booked':
        _phase(state, v, 'aboard')
    semantic = semantic or {}
    if semantic.get('_deferred_voyage_transport'): return None
    if re.search(r"\b(?:don't|do not|never)\s+(?:board|wait|sleep|rest|embark|disembark)\b", text, re.I): return None
    owned = semantic_owns_voyage(semantic)
    action = semantic_voyage_action(semantic)
    if ((not owned or action in TIME_ACTIONS) and WAIT.search(text)
            and re.search(r'\b(?:seconds?|minutes?|moment|a bit|a while)\b', text, re.I)):
        return _event(v, 'brief_pause', instruction='Only a brief pause; departure or arrival is not advanced.')
    if str(semantic.get('acting_companion') or 'NONE') != 'NONE' and not re.search(r"\b(?:we|i|let's|let\s+us)\b", text, re.I): return None
    if (action == 'NONE' and not _aboard(state, v)
            and semantic.get('recovery_intent') == 'REST'):
        return None  # A paid booking does not replace ordinary recovery ashore.
    if action == 'NONE' and not owned:  # Legacy/offline payloads only.
        if re.search(r'\b(?:disembark|go ashore|step ashore|leave the ship)\b', text, re.I): action = 'DISEMBARK'
        elif BOARD.search(text): action = 'BOARD'
        elif FINISH.search(text): action = 'FINISH'
        elif WAIT.search(text): action = 'WAIT_DEPARTURE' if DEPARTURE.search(text) else 'WAIT'
        elif re.search(r"^\s*(?:I|we|let's)\s+(?:sail|depart|cast off|set sail)\b", text, re.I): action = 'WAIT_DEPARTURE'
    requested_destination = clean_destination(str(semantic.get('destination') or ''))
    names_match = requested_destination.casefold().removeprefix('the ') == v['destination_name'].casefold().removeprefix('the ')
    if semantic.get('movement_commitment') == 'COMMITTED' and names_match:
        if not _aboard(state, v) and v['phase'] == 'booked':
            return _event(v, 'boarding_required', instruction='The paid passage is reserved; board its vessel before the crossing can advance. No arrival is committed.')
        if action == 'NONE' and not semantic.get('requires_roll') and _aboard(state, v): action = 'FINISH'
    if action == 'RESOLVE_INCIDENT': return None  # Normal engine adjudicates the tactic/roll first.
    if action == 'NONE':
        # Cross-world travel while aboard cannot bypass the booked voyage/incident.
        if _aboard(state, v) and semantic.get('movement_commitment') == 'COMMITTED' and semantic.get('destination_scope') == 'WORLD':
            return _event(v, 'blocked', reason='Use the booked voyage or disembark at a mooring; no over-water teleport is committed.')
        return None
    if semantic.get('requires_roll') and action in {'WAIT','WAIT_DEPARTURE','FINISH'}:
        return _event(v, 'blocked', reason='A time skip cannot resolve an uncertain tactic. Address the concrete hazard first; no arrival or recovery was committed.')
    if semantic.get('requires_roll') or (state.get('combat') or {}).get('status') == 'active': return None
    pressure = state.get('active_situation') or {}
    if pressure.get('status') == 'active' and pressure.get('kind') != 'voyage_incident':
        return _event(v, 'blocked', reason='Resolve the current active situation before skipping travel time.')
    if action == 'BOARD':
        if _aboard(state, v): return _event(v, 'already_aboard')
        if v['phase'] not in {'booked','aboard'}: return _event(v, 'blocked', reason='This sailing has already left its embarkation port.')
        return _board(state, v)
    if action == 'DISEMBARK':
        if not _aboard(state, v): return _event(v, 'blocked', reason='You are not aboard this vessel.')
        if v['phase'] not in {'aboard','arrived'}: return _event(v, 'blocked', reason='The vessel is still at sea.')
        target = v['destination_id'] if v['phase'] == 'arrived' else v['embarkation_id']
        move = _movement(state, target, state['locations'][target]['name'])
        _phase(state, v, 'completed' if v['phase'] == 'arrived' else 'booked')
        return _event(v, 'disembarked', movement=move)
    if not _aboard(state, v):
        if v['phase'] == 'booked' and action in {'WAIT_DEPARTURE','WAIT','FINISH'}:
            if not v['departure_ready']:
                v['elapsed_segments'].append({'kind':'until_departure', 'label':v['departure_label']})
            v['departure_ready'] = True
            return _event(v, 'departure_ready', instruction='The quoted departure time is reached; the player must still board.')
        return None
    if v['phase'] == 'interrupted':
        if action in TIME_ACTIONS and v['risk'].get('kind') == 'Storm':
            return _storm_progress(state, v, action)
        return _event(v, 'incident_pending', travel_hazard=v['risk']['kind'], instruction='The existing incident remains unresolved; waiting does not bypass it.')
    if v['phase'] == 'arrived': return _event(v, 'already_arrived', instruction='The ship is moored at the destination; disembark when the player chooses.')
    if v['phase'] == 'aboard':
        _depart(state, v)
        if action != 'FINISH': return _event(v, 'departed', departure_label=v['departure_label'])
    if v['phase'] == 'in_transit': return _advance(state, v)
    return None


def _settle_incident(state: dict, v: dict, resolved_by: str):
    v['risk']['resolved'] = True
    v['risk']['resolved_by'] = resolved_by
    _phase(state, v, 'in_transit')
    situation = state.get('active_situation') or {}
    if situation.get('kind') == 'voyage_incident' and situation.get('voyage_id') == v['id']:
        state.setdefault('active_situation_history', []).append(
            {**situation, 'status': 'resolved', 'resolved_by': resolved_by})
        state['active_situation'] = None


def _storm_progress(state: dict, v: dict, action: str) -> dict:
    """Private weather check for elapsed time inside an unresolved storm."""
    from .mechanics import _roll
    risk = v['risk']
    checks = risk.setdefault('weather_checks', [])
    target = max(STORM_EASE_FLOOR, STORM_EASE_TARGET - STORM_EASE_STEP * len(checks))
    counter = int(state.get('rng_counter', 0)); raw = _roll(state, 20)
    eased = raw >= target
    checks.append({'raw': raw, 'sides': 20, 'target': target, 'eased': eased,
                   'counter_before': counter, 'turn': int(state.get('turn_no', 0))})
    v['elapsed_segments'].append({'kind': 'storm_time', 'label': 'storm eases' if eased else 'storm persists'})
    if not eased:
        return _event(v, 'incident_persists', travel_hazard='Storm', instruction=(
            'Time passes inside the recorded storm and it has not eased. Present its continued pressure aboard '
            'the existing ship. No arrival, no player roll request, and no invented damage.'))
    _settle_incident(state, v, 'weather')
    if action == 'FINISH':
        event = _advance(state, v)
        event['storm_eased'] = True
        return event
    return _event(v, 'incident_eased', travel_hazard='Storm', instruction=(
        'The storm blows itself out on its own; the crossing resumes. Arrival has not occurred yet. '
        'Do not credit the player with ending it.'))


def note_resolution(state: dict, semantic: dict | None, event: dict | None):
    v = current(state)
    if not v or v['phase'] != 'interrupted' or not isinstance(event, dict): return
    action = (semantic or {}).get('voyage_action')
    if action != 'RESOLVE_INCIDENT': return
    if (state.get('combat') or {}).get('status') == 'active': return
    # Semantic relevance AND a successful mechanical resolution are required.
    combat_won = event.get('type') == 'combat_resolution' and event.get('combat_status') == 'won'
    roll = event.get('roll') if isinstance(event.get('roll'), dict) else event
    check_won = roll.get('success') is True and ('raw' in roll or event.get('type') == 'combat_resolution')
    if not (combat_won or check_won): return
    _settle_incident(state, v, 'player')
    event['voyage_incident_resolved'] = True


def passage_destination(*values: str) -> str:
    from .island_context import destination_entry
    for raw in values:
        entry = destination_entry(str(raw or ""))
        if entry:
            return str(entry.get("name") or "")
    prep = r"(?:of|on|in|at|by|the|and|[A-Z][A-Za-z'’.-]*)"
    patterns = (
        re.compile(
            rf"\b(?:landing|port|harbou?r|dock|shore)\s+(?:at|on|in)\s+([A-Z][A-Za-z'’.-]*(?:\s+{prep}){{0,5}})"
        ),
        re.compile(
            rf"\b(?:passage|ticket|fare|berth|voyage|depart\w*|sail\w*)\b[^.!?]{{0,80}}?\b(?:to|for|towards?)\s+([A-Z][A-Za-z'’.-]*(?:\s+{prep}){{0,5}})",
            re.I,
        ),
        re.compile(
            rf"\b(?:sail|travel|gets?\s+you|head\w*|bound)\s+(?:to|for)\s+(?:the\s+(?:southern|northern|eastern|western)\s+"
            rf"(?:landing|port|harbou?r|dock|shore)\s+at\s+)?([A-Z][A-Za-z'’.-]*(?:\s+{prep}){{0,5}})",
            re.I,
        ),
        re.compile(
            rf"\bto\s+([A-Z][A-Za-z'’.-]*(?:\s+{prep}){{0,5}})"
        ),
    )
    for raw in values:
        text = str(raw or "")
        if not text:
            continue
        for pattern in patterns:
            match = pattern.search(text)
            if not match:
                continue
            destination = " ".join(match.group(1).split()).strip(" ,.;:!?\"'")[:100]
            # Transport clauses are not part of a destination. The case-insensitive
            # name pattern can otherwise consume 'aboard the' up to its word cap.
            destination = re.split(
                r"\s+(?:aboard|on\s+board|on\s+the\s+(?:ship|boat|ferry|vessel))\b",
                destination, maxsplit=1, flags=re.I,
            )[0].strip()
            if destination and destination.casefold() not in {"the", "a", "an"}:
                return destination
    return ""

