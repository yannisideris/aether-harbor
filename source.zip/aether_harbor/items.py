from __future__ import annotations

import copy
import re
from typing import Any

from .afflictions import cure_afflictions
from .economy import price_bounds_for_item, service_kind_for_item


USE_VERBS = re.compile(
    r"\b(?:use|light|kindle|eat|drink|consume|unlock|open\s+with|"
    r"tie|secure|mark|draw\s+with|write\s+with|prepare)\b",
    re.IGNORECASE,
)


def _inventory(state: dict[str, Any]) -> list[dict[str, Any]]:
    return [item for item in state.get("player", {}).get("inventory", []) if isinstance(item, dict)]


def _mentioned_item(state: dict[str, Any], text: str) -> dict[str, Any] | None:
    folded = text.casefold()
    candidates: list[tuple[int, dict[str, Any]]] = []
    for item in _inventory(state):
        name = str(item.get("name") or "")
        aliases = [name, *[str(value) for value in item.get("aliases", []) if str(value).strip()]]
        if name.casefold().startswith("small "):
            aliases.append(name[6:])
        if name.casefold().startswith("loaf of "):
            aliases.append(name[8:])
        for alias in aliases:
            if alias and re.search(rf"\b{re.escape(alias.casefold())}\b", folded):
                candidates.append((len(alias), item))
    if not candidates:
        return None
    return max(candidates, key=lambda pair: pair[0])[1]


def equipment_assist(state: dict[str, Any], text: str, stat: str) -> tuple[int, str | None]:
    item = _mentioned_item(state, text)
    if not item:
        item = matching_inventory_item(state, text)
    if not item:
        return 0, None
    charges = item.get("charges")
    if charges is not None and int(charges) <= 0:
        return 0, None
    affordances = {str(value) for value in item.get("affordances", [])}
    folded = text.casefold()
    useful = False
    if str(item.get("stat_assist") or "NONE") == stat:
        useful = True
    elif "pick_lock" in affordances and "lock" in folded and stat == "AGI":
        useful = True
    elif affordances.intersection({"climb", "haul", "secure"}) and re.search(r"\b(?:climb|pull|haul|lower|secure|cross)\b", folded) and stat in {"STR", "AGI"}:
        useful = True
    elif "light" in affordances and re.search(r"\b(?:dark|search|inspect|examine|see)\b", folded) and stat == "PER":
        useful = True
    elif "ritual_trace" in affordances and re.search(r"\b(?:ritual|symbol|circle|trace|mark)\b", folded) and stat == "ARC":
        useful = True
    elif "decipher" in affordances and re.search(r"\b(?:decipher|read|translate|solve|study)\b", folded) and stat in {"ARC", "PER"}:
        useful = True
    elif "stealth_assist" in affordances and re.search(r"\b(?:sneak|stealth|hide|prowl|shadow)\b", folded) and stat == "AGI":
        useful = True
    elif "formal_dress" in affordances and re.search(r"\b(?:persuade|convince|charm|impress|court)\b", folded) and stat == "SOC":
        useful = True
    if useful:
        if charges is not None and int(charges) > 0:
            item["charges"] = int(charges) - 1
        return (2, str(item.get("name")))
    return (0, None)


def _remove_one(state: dict[str, Any], item: dict[str, Any]) -> None:
    quantity = int(item.get("quantity", 1) or 1) - 1
    if quantity > 0:
        item["quantity"] = quantity
    else:
        state["player"]["inventory"].remove(item)


def resolve_direct_item_use(
    state: dict[str, Any],
    text: str,
    *,
    item_hint: str = "",
) -> dict[str, Any] | None:
    if not USE_VERBS.search(text) and not item_hint:
        return None
    item = _mentioned_item(state, text)
    if not item and item_hint:
        item = matching_inventory_item(state, item_hint)
    if not item:
        item = matching_inventory_item(state, text)
    if not item:
        return None
    name = str(item.get("name") or "Item")
    affordances = {str(value) for value in item.get("affordances", [])}
    semantic_consume = bool(item_hint)

    for strict_use in item.get("strict_uses", []):
        if not isinstance(strict_use, dict):
            continue
        aliases = [str(value).casefold() for value in strict_use.get("target_aliases", [])]
        if aliases and not any(alias in text.casefold() for alias in aliases):
            continue
        flag = str(strict_use.get("flag") or "")
        if flag:
            state.setdefault("scene_flags", {})[flag] = True
        if strict_use.get("consume"):
            _remove_one(state, item)
        return {
            "type": "strict_item_use",
            "committed": True,
            "item": name,
            "effect": str(strict_use.get("effect") or "The established use succeeds."),
            "flag": flag or None,
        }

    if "cure_poison" in affordances and (semantic_consume or re.search(r"\b(?:drink|consume|use)\b", text, re.I)):
        removed = cure_afflictions(state, families={"toxic"})
        _remove_one(state, item)
        return {
            "type": "item_use",
            "committed": True,
            "item": name,
            "effect": "antidote",
            "conditions_removed": removed,
        }
    if "heal" in affordances and (semantic_consume or re.search(r"\b(?:drink|consume|use|give)\b", text, re.I)):
        target_companion = None
        for companion in state.get("player", {}).get("companions", []):
            if isinstance(companion, dict) and companion.get("name") and companion.get("name").casefold() in text.casefold():
                target_companion = companion
                break
                
        if target_companion:
            before = int(target_companion.get("hp", 0))
            target_companion["hp"] = min(int(target_companion.get("max_hp", 1)), before + 5)
            # Not curing companion conditions since they don't track them yet
            _remove_one(state, item)
            return {
                "type": "item_use", "committed": True, "item": name,
                "effect": f"healing on {target_companion.get('name')}", "hp_before": before,
                "hp_after": target_companion["hp"]
            }
        else:
            before = int(state["player"]["hp"])
            state["player"]["hp"] = min(int(state["player"]["max_hp"]), before + 5)
            removed = cure_afflictions(state, families={"physical"})
            _remove_one(state, item)
            return {
                "type": "item_use", "committed": True, "item": name,
                "effect": "healing", "hp_before": before,
                "hp_after": state["player"]["hp"], "conditions_removed": removed,
            }
    if ("eat" in affordances or str(item.get("type") or "") == "food") and (semantic_consume or re.search(r"\b(?:eat|consume)\b", text, re.I)):
        before = int(state["player"]["hp"])
        state["player"]["hp"] = min(int(state["player"]["max_hp"]), before + 1)
        _remove_one(state, item)
        return {"type": "item_use", "committed": True, "item": name, "effect": "food", "hp_before": before, "hp_after": state["player"]["hp"]}
    if "light" in affordances and re.search(r"\b(?:light|kindle|use)\b", text, re.I):
        state.setdefault("scene_flags", {})["active_light"] = name
        return {"type": "item_use", "committed": True, "item": name, "effect": "active light source"}

    if semantic_consume:
        return None
    state.setdefault("scene_flags", {})["prepared_item"] = name
    return {"type": "item_prepared", "committed": True, "item": name, "affordances": sorted(affordances)}


_ITEM_WORDS = re.compile(r"[a-z0-9]+", re.I)
_INFORMATIONAL = re.compile(
    r"^(?:rumou?r|clue|knowledge|information|memory|observation|lead|note\s+about)\b",
    re.I,
)
_SMALL_NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
    "nineteen": 19,
}
_TENS_NUMBER_WORDS = {
    "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50,
    "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
}
_NUMBER_ATOMS = tuple([
    *_SMALL_NUMBER_WORDS,
    *_TENS_NUMBER_WORDS,
    "hundred", "thousand", "and",
])
_NUMBER_PHRASE = "|".join(sorted((re.escape(word) for word in _NUMBER_ATOMS), key=len, reverse=True))


def _word_number(value: str) -> int | None:
    tokens = re.findall(r"[a-z]+", str(value).casefold().replace("-", " "))
    if not tokens:
        return None
    total = 0
    current = 0
    saw_number = False
    for token in tokens:
        if token == "and":
            continue
        if token in _SMALL_NUMBER_WORDS:
            current += _SMALL_NUMBER_WORDS[token]
            saw_number = True
        elif token in _TENS_NUMBER_WORDS:
            current += _TENS_NUMBER_WORDS[token]
            saw_number = True
        elif token == "hundred":
            current = max(1, current) * 100
            saw_number = True
        elif token == "thousand":
            total += max(1, current) * 1000
            current = 0
            saw_number = True
        else:
            return None
    return total + current if saw_number else None


def _number_amounts(text: str, *, require_silver: bool) -> list[int]:
    suffix = r"\s+(?:silver(?:\s+(?:coin|coins|piece|pieces))?|coins?|pieces?)" if require_silver else ""
    pattern = rf"\b(\d+|(?:{_NUMBER_PHRASE})(?:[\s-]+(?:{_NUMBER_PHRASE}))*){suffix}\b"
    values: list[int] = []
    for match in re.finditer(pattern, str(text or ""), re.I):
        token = match.group(1)
        value = int(token) if token.isdigit() else _word_number(token)
        if value is not None and 0 < value <= 100000:
            values.append(value)
    return values


def _item_key(value: Any) -> str:
    return " ".join(_ITEM_WORDS.findall(str(value or "").casefold()))


def _distinctive_tokens(value: Any) -> set[str]:
    stop = {"with", "from", "small", "large", "fine", "plain", "piece", "set", "pair"}
    return {token for token in _item_key(value).split() if len(token) >= 4 and token not in stop}


def matching_inventory_item(state: dict[str, Any], name: str) -> dict[str, Any] | None:
    wanted = _item_key(name)
    if not wanted:
        return None
    inventory = _inventory(state)
    exact = [
        item for item in inventory
        if any(
            _item_key(candidate) == wanted
            for candidate in [item.get("name"), *list(item.get("aliases") or [])]
        )
    ]
    if len(exact) == 1:
        return exact[0]
    wanted_tokens = _distinctive_tokens(name)
    matches = [
        item for item in inventory
        if any(
            wanted in _item_key(candidate)
            or _item_key(candidate) in wanted
            or bool(wanted_tokens and wanted_tokens.intersection(_distinctive_tokens(candidate)))
            for candidate in [item.get("name"), *list(item.get("aliases") or [])]
            if _item_key(candidate)
        )
    ]
    return matches[0] if len(matches) == 1 else None


def item_bulk(item: dict[str, Any]) -> float:
    if item.get("bulk") is not None:
        try:
            return max(0.0, float(item.get("bulk") or 0.0))
        except (TypeError, ValueError):
            pass
    name = str(item.get("name") or "").casefold()
    kind = str(item.get("type") or "misc")
    if kind == "valuable" or any(word in name for word in ("ring", "coin", "gem", "jewel")):
        return 0.1
    if kind in {"document", "key"}:
        return 0.5
    if kind == "weapon":
        return 1.0 if any(word in name for word in ("dagger", "knife", "sling")) else 2.0
    if kind == "armor":
        return 2.5
    if kind == "clothing":
        return 0.5 if any(word in name for word in ("boots", "hat", "gloves")) else 1.0
    if kind == "tool":
        return 2.0 if any(word in name for word in ("rope", "hammer", "shovel")) else 1.0
    if kind in {"food", "consumable"}:
        return 0.5
    if kind == "drink":
        return 1.0
    return 1.0


def carrying_capacity(state: dict[str, Any]) -> float:
    strength = int(state.get("player", {}).get("stats", {}).get("STR", 8) or 8)
    return float(max(4, strength))


def carried_load(state: dict[str, Any]) -> float:
    total = 0.0
    for item in _inventory(state):
        total += item_bulk(item) * max(1, int(item.get("quantity", 1) or 1))
    return round(total, 2)


def can_carry(state: dict[str, Any], item: dict[str, Any]) -> bool:
    added = item_bulk(item) * max(1, int(item.get("quantity", 1) or 1))
    return carried_load(state) + added <= carrying_capacity(state) + 1e-9


def load_summary(state: dict[str, Any]) -> str:
    load = carried_load(state)
    limit = carrying_capacity(state)
    return f"{load:g}/{limit:g}"


def _item_record(
    name: str,
    kind: str,
    *,
    quantity: int = 1,
    value_paid: int | None = None,
    known_detail: str = "",
    item_profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    clean = " ".join(str(name or "Item").split())[:100]
    folded = clean.casefold()
    kind = kind if kind in {
        "misc", "food", "drink", "tool", "key", "document", "weapon", "armor",
        "clothing", "consumable", "valuable",
    } else "misc"
    record: dict[str, Any] = {"name": clean, "quantity": max(1, int(quantity)), "type": kind}
    record["bulk"] = item_bulk(record)
    detail = " ".join(str(known_detail or "").split())[:180]
    if detail:
        record["known_details"] = [detail]
    if value_paid is not None:
        record["value_paid"] = max(0, int(value_paid))
    if kind == "weapon":
        mode = "ranged" if any(word in folded for word in ("bow", "pistol", "musket", "crossbow", "sling")) else "melee"
        if any(word in folded for word in ("pistol", "musket", "firearm")):
            bonus = 4
        elif "cutlass" in folded:
            bonus = 3
        elif any(word in folded for word in ("sword", "sabre", "saber", "spear", "bow", "crossbow", "axe")):
            bonus = 2
        else:
            bonus = 1
        record.update({"mode": mode, "weapon_bonus": bonus, "equipped": False})
    elif kind == "armor":
        armor = 2 if any(word in folded for word in ("brigandine", "breastplate", "plate")) else 1
        record.update({"armor_value": armor, "equipped": False})
    elif kind == "clothing":
        record["equipped"] = False
    elif kind == "food":
        record["affordances"] = ["eat"]
    elif kind == "drink":
        record["affordances"] = ["drink"]
    elif kind == "consumable" and "antidote" in folded:
        record["affordances"] = ["drink", "cure_poison"]
    elif kind == "consumable" and any(word in folded for word in ("healing", "potion", "medicine", "salve", "elixir", "tonic", "balm", "draught", "brew")):
        record["affordances"] = ["drink", "heal", "cure_wound"]
    elif kind == "tool" and "rope" in folded:
        record["affordances"] = ["climb", "haul", "bind", "secure"]
    elif kind == "tool" and any(word in folded for word in ("lamp", "lantern", "torch")):
        record["affordances"] = ["light"]
    _apply_item_profile(record, item_profile)
    return record


def _apply_item_profile(
    record: dict[str, Any], item_profile: dict[str, Any] | None
) -> dict[str, Any]:
    if not isinstance(item_profile, dict) or item_profile.get("source") != "gemma_semantic":
        return record
    kind = str(record.get("type") or "")
    profile_kind = str(item_profile.get("kind") or "")
    if profile_kind and profile_kind != kind and profile_kind in {"weapon", "armor", "tool", "consumable", "valuable", "clothing", "document", "misc"}:
        kind = profile_kind
        record["type"] = kind
    try:
        record["bulk"] = max(0.1, min(8.0, float(item_profile.get("bulk", record.get("bulk", 1.0)))))
    except (TypeError, ValueError):
        pass
    if kind == "weapon":
        mode = str(item_profile.get("weapon_mode") or "melee")
        record["mode"] = mode if mode in {"melee", "ranged"} else "melee"
        record["weapon_bonus"] = max(0, min(4, int(item_profile.get("weapon_bonus", 1) or 0)))
        record["equipped"] = False
    elif kind == "armor":
        record["armor_value"] = max(0, min(4, int(item_profile.get("armor_value", 1) or 0)))
        record["equipped"] = False
    if item_profile.get("is_magical"):
        record["is_magical"] = True
    stat_assist = str(item_profile.get("stat_assist") or "NONE")
    if stat_assist in {"STR", "AGI", "SOC", "ARC", "PER"}:
        record["stat_assist"] = stat_assist
    new_affordances = item_profile.get("affordances")
    if isinstance(new_affordances, list) and new_affordances:
        existing = set(str(v) for v in record.get("affordances", []))
        for a in new_affordances:
            clean_a = str(a).strip().casefold()
            if clean_a:
                existing.add(clean_a)
        record["affordances"] = sorted(existing)
    try:
        charges = max(0, min(10, int(item_profile.get("charges") or 0)))
        if charges > 0:
            record["charges"] = charges
    except (TypeError, ValueError):
        pass
    basis = " ".join(str(item_profile.get("basis") or "").split())[:160]
    if basis:
        record["mechanical_basis"] = basis
    record["mechanics_source"] = "gemma_semantic"
    return record


def _add_item(state: dict[str, Any], item: dict[str, Any]) -> dict[str, Any]:
    existing = matching_inventory_item(state, str(item.get("name") or ""))
    if existing and _item_key(existing.get("name")) == _item_key(item.get("name")):
        existing["quantity"] = int(existing.get("quantity", 1) or 1) + int(item.get("quantity", 1) or 1)
        return existing
    state["player"].setdefault("inventory", []).append(item)
    return item


def _remove_inventory_quantity(
    state: dict[str, Any], name: str, quantity: int
) -> tuple[dict[str, Any] | None, int]:
    item = matching_inventory_item(state, name)
    if not item:
        return None, 0
    owned = max(1, int(item.get("quantity", 1) or 1))
    removed = min(owned, max(1, int(quantity)))
    record = dict(item)
    record["quantity"] = removed
    if removed >= owned:
        state["player"]["inventory"].remove(item)
    else:
        item["quantity"] = owned - removed
    if state.get("scene_flags", {}).get("prepared_item") == record.get("name"):
        state["scene_flags"].pop("prepared_item", None)
    return record, removed


def _scene_scope(state: dict[str, Any]) -> tuple[str, str | None]:
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    return str(state.get("current_location_id") or ""), str(position.get("id")) if position else None


def _leave_scene_object(state: dict[str, Any], item: dict[str, Any]) -> None:
    item = dict(item)
    item["equipped"] = False
    location_id, position_id = _scene_scope(state)
    objects = state.setdefault("scene_objects", [])
    for record in objects:
        if (
            isinstance(record, dict)
            and record.get("status") == "available"
            and record.get("location_id") == location_id
            and record.get("scene_position_id") == position_id
            and _item_key(record.get("name")) == _item_key(item.get("name"))
        ):
            record["quantity"] = int(record.get("quantity", 1) or 1) + int(item.get("quantity", 1) or 1)
            return
    objects.append({
        "name": item.get("name"),
        "quantity": int(item.get("quantity", 1) or 1),
        "item": {key: value for key, value in item.items() if key != "quantity"},
        "location_id": location_id,
        "scene_position_id": position_id,
        "status": "available",
        "left_at_turn": int(state.get("turn_no", 0) or 0),
    })
    state["scene_objects"] = objects[-24:]


def _take_scene_object(state: dict[str, Any], name: str, quantity: int) -> dict[str, Any] | None:
    location_id, position_id = _scene_scope(state)
    matches = [
        record for record in state.get("scene_objects", [])
        if isinstance(record, dict)
        and record.get("status") == "available"
        and record.get("location_id") == location_id
        and record.get("scene_position_id") == position_id
        and (
            _item_key(name) == _item_key(record.get("name"))
            or bool(_distinctive_tokens(name).intersection(_distinctive_tokens(record.get("name"))))
        )
    ]
    if len(matches) != 1:
        return None
    record = matches[0]
    available = max(1, int(record.get("quantity", 1) or 1))
    taken = min(available, max(1, int(quantity)))
    item = dict(record.get("item") or {})
    item["name"] = str(record.get("name") or name)
    item["quantity"] = taken
    item["equipped"] = False
    if taken >= available:
        record["status"] = "taken"
    else:
        record["quantity"] = available - taken
    return item


def _record_resource_event(state: dict[str, Any], event: dict[str, Any]) -> None:
    compact = {
        "turn": int(state.get("turn_no", 0) or 0),
        "kind": event.get("kind") or event.get("action"),
        "item": event.get("item"),
        "quantity": event.get("quantity"),
        "silver_delta": event.get("silver_delta", 0),
        "success": bool(event.get("success")),
    }
    history = state.setdefault("resource_history", [])
    history.append(compact)
    state["resource_history"] = history[-12:]


def resource_advice(semantic_roll: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(semantic_roll, dict):
        return {}
    raw = semantic_roll.get("resource_action")
    if isinstance(raw, dict):
        return raw
    if "kind" in semantic_roll:
        return semantic_roll
    return {}


def resource_bundle_advice(semantic_roll: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not isinstance(semantic_roll, dict):
        return []
    raw = semantic_roll.get("resource_bundle")
    if not isinstance(raw, list):
        return []
    return [row for row in raw[:4] if isinstance(row, dict)]


def pending_commerce_offer(state: dict[str, Any]) -> dict[str, Any] | None:
    commerce = state.get("commerce") if isinstance(state.get("commerce"), dict) else {}
    pending = commerce.get("pending_offer")
    if not isinstance(pending, dict):
        return None
    quoted_location = str(pending.get("location_id") or "")
    if quoted_location and quoted_location != str(state.get("current_location_id") or ""):
        return None
    return pending


def _same_offer_item(left: str, right: str) -> bool:
    left_key, right_key = _item_key(left), _item_key(right)
    if not left_key or not right_key:
        return False
    if left_key in right_key or right_key in left_key:
        return True
    left_tokens, right_tokens = _distinctive_tokens(left), _distinctive_tokens(right)
    return bool(left_tokens and right_tokens and left_tokens.intersection(right_tokens))


def resolve_resource_action(
    state: dict[str, Any],
    semantic_roll: dict[str, Any] | None,
    *,
    roll_success: bool | None = None,
) -> dict[str, Any] | None:
    # Compatibility for old saved semantic payloads; the sole party writer
    # still owns validation, payment, identity and membership.
    if (semantic_roll or {}).get("resource_action", {}).get("kind") in {"recruit", "dismiss"}:
        from .party import commit_party_action, party_advice
        return commit_party_action(state, party_advice(semantic_roll), roll_success=roll_success)
    advice = resource_advice(semantic_roll)
    from .voyage import is_passage_resource
    if is_passage_resource(advice):
        from .movement import resolve_pending_passage
        return resolve_pending_passage(state, '', semantic_roll={**(semantic_roll or {}), 'resource_action': advice})
    kind = str(advice.get("kind") or "NONE")
    status = str(advice.get("status") or "NONE")
    item_name = " ".join(str(advice.get("item") or "").split())[:100]
    if item_name.casefold() in {"none", "null", "n/a", "unknown", "ambiguous", "unspecified"}:
        item_name = ""
    quantity = max(1, min(20, int(advice.get("quantity", 1) or 1)))
    amount = max(0, int(advice.get("amount", 0) or 0))
    item_kind = str(advice.get("item_kind") or "misc")
    timing = str(advice.get("timing") or "none")
    counterparty = " ".join(str(advice.get("counterparty") or "").split())[:100]
    commerce = state.setdefault("commerce", {"awaiting_quote": None, "pending_offer": None})

    if kind in {"purchase", "sell"} and status == "inquiry" and item_name:
        service_kind = service_kind_for_item(item_name, item_kind=item_kind)
        price_name = {
            "lodging": "Inn Stay",
            "treatment": "Physician Treatment",
        }.get(str(service_kind or ""), item_name)
        unit_low, unit_high = price_bounds_for_item(price_name, item_kind)
        low, high = unit_low * quantity, unit_high * quantity
        direction = "buy" if kind == "purchase" else "sell"
        commerce["awaiting_quote"] = {
            "item": item_name,
            "item_kind": item_kind,
            "quantity": quantity,
            "direction": direction,
            "counterparty": counterparty,
            "location_id": str(state.get("current_location_id") or ""),
            "minimum": low,
            "maximum": high,
        }
        return {
            "type": "resource_quote_required",
            "committed": False,
            "kind": kind,
            "direction": direction,
            "item": item_name,
            "item_kind": item_kind,
            "quantity": quantity,
            "minimum_price": low,
            "maximum_price": high,
            "counterparty": counterparty,
        }

    if kind == "haggle":
        pending = pending_commerce_offer(state)
        quote_bounds: tuple[int, int] | None = None
        if isinstance(pending, dict) and roll_success is True:
            unit_low, unit_high = price_bounds_for_item(
                str(pending.get("item") or ""), str(pending.get("item_kind") or "misc")
            )
            pending_quantity = max(1, int(pending.get("quantity", 1) or 1))
            low, high = unit_low * pending_quantity, unit_high * pending_quantity
            current_amount = max(1, int(pending.get("amount", 0) or 1))
            if pending.get("direction") == "sell":
                low, high = current_amount + 1, max(high, current_amount + 1)
            else:
                lower_offer = max(1, current_amount - 1)
                low, high = min(low, lower_offer), lower_offer
            quote_bounds = (low, high)
            commerce["awaiting_quote"] = {
                **pending,
                "minimum": low,
                "maximum": high,
                "requote": True,
            }
        elif roll_success is False:
            commerce["awaiting_quote"] = None
        return {
            "type": "resource_negotiation",
            "committed": False,
            "kind": "haggle",
            "success": roll_success,
            "item": str(pending.get("item") or "") if isinstance(pending, dict) else item_name,
            "pending_offer": pending,
            "minimum_price": quote_bounds[0] if quote_bounds else None,
            "maximum_price": quote_bounds[1] if quote_bounds else None,
        }

    if status == "ambiguous" and kind not in {"NONE", "browse"}:
        return {
            "type": "resource_transfer",
            "committed": False,
            "success": False,
            "kind": kind,
            "item": item_name or None,
            "quantity": quantity,
            "amount": amount,
            "reason": "The requested transfer is not grounded precisely enough to commit.",
            "silver_delta": 0,
        }
    if kind in {"NONE", "browse"} or status not in {"confirmed", "offered"}:
        return None
    if timing == "on_success" and roll_success is not True:
        event = {
            "type": "resource_transfer",
            "committed": False,
            "success": False,
            "kind": kind,
            "item": item_name or None,
            "quantity": quantity,
            "amount": amount,
            "reason": "The required roll did not succeed.",
            "silver_delta": 0,
        }
        _record_resource_event(state, event)
        return event
    if status != "confirmed":
        return None

    pending_offer = pending_commerce_offer(state)
    if kind in {"purchase", "sell"}:
        direction = "buy" if kind == "purchase" else "sell"
        pending_matches = bool(
            pending_offer
            and pending_offer.get("direction") == direction
            and _same_offer_item(item_name, str(pending_offer.get("item") or ""))
            and amount == int(pending_offer.get("amount", 0) or 0)
        )
        if not pending_matches and not advice.get("offer_grounded"):
            return {
                "type": "resource_transfer",
                "committed": False,
                "success": False,
                "kind": kind,
                "item": item_name or None,
                "quantity": quantity,
                "amount": amount,
                "reason": "No exact accepted offer grounds this transaction.",
                "silver_delta": 0,
            }

    silver_before = int(state.get("player", {}).get("silver", 0) or 0)
    silver_delta = 0
    inventory_change = "none"
    service_change: dict[str, Any] = {}
    actual_item = item_name
    success = True
    reason = ""

    if kind in {"take", "receive_item"}:
        scene_snapshot = copy.deepcopy(state.get("scene_objects"))
        scene_item = _take_scene_object(state, item_name, quantity) if kind == "take" else None
        item = scene_item or _item_record(
            item_name,
            item_kind,
            quantity=quantity,
            known_detail=str(advice.get("known_detail") or ""),
            item_profile=(advice.get("item_profile") if isinstance(advice.get("item_profile"), dict) else None),
        )
        if scene_item is not None:
            _apply_item_profile(
                item,
                advice.get("item_profile") if isinstance(advice.get("item_profile"), dict) else None,
            )
        if not can_carry(state, item):
            state["scene_objects"] = scene_snapshot
            success = False
            reason = (
                f"Carrying capacity exceeded ({load_summary(state)} load before this item; "
                f"{item_bulk(item) * quantity:g} more required)."
            )
        else:
            added_item = _add_item(state, item)
            actual_item = str(item.get("name") or item_name)
            inventory_change = "added"
            if kind == "receive_item" and counterparty:
                from .party import find_companion
                target = find_companion(state, counterparty)
                if isinstance(target, dict):
                    target_inventory = target.setdefault("inventory", [])
                    for i, c_item in enumerate(target_inventory):
                        if isinstance(c_item, dict) and _item_key(c_item.get("name")) == _item_key(actual_item):
                            cur_q = int(c_item.get("quantity", 1) or 1)
                            if cur_q > quantity:
                                c_item["quantity"] = cur_q - quantity
                            else:
                                target_inventory.pop(i)
                            break
        if kind == "take" and success:
            # The material opportunity is site state, not loot-generator state.
            # Mark it depleted before any same-action movement can change the
            # current area, and only if this grounded take matches the stored
            # realization.  Local import avoids making item mechanics depend
            # on the spatial planner at module-import time.
            from .movement import active_site_root_id
            from .spatial_secretary import note_material_take
            if note_material_take(state, actual_item):
                added_item.setdefault("provenance", {})["material_opportunity"] = {
                    "site_id": active_site_root_id(state),
                    "turn": int(state.get("turn_no", 0) or 0),
                }
    elif kind in {"drop", "give_item", "consume"}:
        removed, removed_quantity = _remove_inventory_quantity(state, item_name, quantity)
        if not removed:
            success, reason = False, "The player does not carry that item."
        else:
            quantity = removed_quantity
            actual_item = str(removed.get("name") or item_name)
            inventory_change = "removed"
            if kind == "drop":
                _leave_scene_object(state, removed)
            elif kind == "give_item" and counterparty:
                from .party import find_companion
                target = find_companion(state, counterparty)
                if isinstance(target, dict):
                    target_inventory = target.setdefault("inventory", [])
                    existing = next((i for i in target_inventory if isinstance(i, dict) and _item_key(i.get("name")) == _item_key(removed.get("name")) and str(i.get("type") or "") == str(removed.get("type") or "")), None)
                    if existing:
                        existing["quantity"] = int(existing.get("quantity", 1) or 1) + int(removed.get("quantity", 1) or 1)
                    else:
                        target_inventory.append(dict(removed))
            elif kind == "consume":
                affordances = {str(value) for value in removed.get("affordances", [])}
                if "cure_poison" in affordances:
                    cured = cure_afflictions(state, families={"toxic"})
                    service_change.update({"effect": "antidote", "conditions_removed": cured})
                elif "heal" in affordances:
                    before = int(state["player"]["hp"])
                    state["player"]["hp"] = min(int(state["player"]["max_hp"]), before + 5 * quantity)
                    cured = cure_afflictions(state, families={"physical"})
                    service_change.update({
                        "effect": "healing",
                        "hp_before": before,
                        "hp_after": state["player"]["hp"],
                        "conditions_removed": cured,
                    })
                elif "eat" in affordances or str(removed.get("type") or "") == "food":
                    before = int(state["player"]["hp"])
                    state["player"]["hp"] = min(int(state["player"]["max_hp"]), before + 1 * quantity)
                    service_change.update({
                        "effect": "food",
                        "hp_before": before,
                        "hp_after": state["player"]["hp"],
                    })
    elif kind in {"equip", "unequip"}:
        item = matching_inventory_item(state, item_name)
        if not item:
            success, reason = False, "The player does not carry that item."
        else:
            stats = state.get("player", {}).get("stats", {})
            player_str = int(stats.get("STR", 10))
            player_agi = int(stats.get("AGI", 10))
            is_heavy_armor = str(item.get("type") or "") == "armor" and int(item.get("armor_value", 0) or 0) >= 2
            is_weapon = str(item.get("type") or "") == "weapon"
            weapon_bonus = int(item.get("weapon_bonus", 0) or 0)
            uses_finesse_or_aim = is_weapon and (
                str(item.get("mode") or "") == "ranged" or item_bulk(item) <= 2.0
            )
            effective_weapon_stat = max(player_str, player_agi) if uses_finesse_or_aim else player_str
            is_heavy_weapon = is_weapon and weapon_bonus >= 3
            is_med_weapon = is_weapon and weapon_bonus == 2

            if kind == "equip" and is_heavy_armor and player_str < 14:
                success, reason = False, "The player lacks the physical strength (STR 14+) to wear heavy armor."
            elif kind == "equip" and is_heavy_weapon and effective_weapon_stat < 14:
                success, reason = False, "The player lacks the martial prowess (STR or AGI 14+) to wield this weapon."
            elif kind == "equip" and is_med_weapon and effective_weapon_stat < 10:
                success, reason = False, "The player lacks the martial prowess (STR or AGI 10+) to wield this weapon effectively."
            else:
                if kind == "equip" and str(item.get("type") or "") == "armor":
                    for other in _inventory(state):
                        if other is not item and str(other.get("type") or "") == "armor":
                            other["equipped"] = False
                elif kind == "equip" and str(item.get("type") or "") == "weapon":
                    for other in _inventory(state):
                        if other is not item and str(other.get("type") or "") == "weapon":
                            other["equipped"] = False
                item["equipped"] = kind == "equip"
                actual_item = str(item.get("name") or item_name)
                inventory_change = "equipped" if kind == "equip" else "unequipped"
    elif kind == "purchase":
        total = amount
        if amount <= 0:
            success, reason = False, "The accepted price is missing."
        elif silver_before < total:
            success, reason = False, "Insufficient silver."
        else:
            silver_delta = -total
            service_kind = service_kind_for_item(item_name, item_kind=item_kind)
            if service_kind:
                from .recovery import grant_recovery_service

                service_change = grant_recovery_service(state, service_kind)
                inventory_change = "service"
                item_kind = "service"
            elif item_kind == "service":
                # Passage/bookings are entitlements, not one-load objects.
                state.setdefault("service_receipts", []).append({
                    "item": item_name, "counterparty": counterparty,
                    "amount": total, "quantity": quantity,
                    "purchased_at_turn": int(state.get("turn_no", 0) or 0),
                    "location_id": str(state.get("current_location_id") or ""),
                })
                inventory_change = "service"
            else:
                item = _item_record(
                    item_name,
                    item_kind,
                    quantity=quantity,
                    value_paid=total,
                    item_profile=(
                        advice.get("item_profile")
                        if isinstance(advice.get("item_profile"), dict)
                        else None
                    ),
                )
                if not can_carry(state, item):
                    success = False
                    reason = f"Carrying capacity exceeded ({load_summary(state)} load)."
                else:
                    _add_item(state, item)
                    inventory_change = "added"
            if success:
                commerce["pending_offer"] = None
    elif kind == "sell":
        removed, removed_quantity = _remove_inventory_quantity(state, item_name, quantity)
        if not removed:
            success, reason = False, "The player does not carry that item."
        elif amount <= 0:
            _add_item(state, removed)
            success, reason = False, "The accepted price is missing."
        else:
            quantity = removed_quantity
            actual_item = str(removed.get("name") or item_name)
            silver_delta = amount
            inventory_change = "removed"
            commerce["pending_offer"] = None
    elif kind == "pay":
        if amount <= 0:
            success, reason = False, "No exact payment amount was supplied."
        elif silver_before < amount:
            success, reason = False, "Insufficient silver."
        else:
            silver_delta = -amount
            if counterparty:
                from .party import find_companion
                target = find_companion(state, counterparty)
                if isinstance(target, dict):
                    target["silver"] = int(target.get("silver", 0) or 0) + amount
            if (
                isinstance(pending_offer, dict)
                and pending_offer.get("direction") == "buy"
                and int(pending_offer.get("amount", 0) or 0) == amount
            ):
                commerce["pending_offer"] = None
    elif kind == "receive_money":
        if amount <= 0:
            success, reason = False, "No exact received amount was supplied."
        else:
            silver_delta = amount
            if counterparty:
                from .party import find_companion
                target = find_companion(state, counterparty)
                if isinstance(target, dict):
                    cur_silver = int(target.get("silver", 0) or 0)
                    if cur_silver >= amount:
                        target["silver"] = cur_silver - amount
                    else:
                        success, reason = False, "The companion has insufficient silver."
                        silver_delta = 0
    else:
        return None

    if success and silver_delta:
        state["player"]["silver"] = silver_before + silver_delta
    event = {
        "type": "resource_transfer",
        "committed": success,
        "success": success,
        "kind": kind,
        "item": actual_item or None,
        "item_kind": item_kind,
        "quantity": quantity,
        "amount": amount,
        "counterparty": counterparty or None,
        "inventory_change": inventory_change,
        "silver_before": silver_before,
        "silver_delta": silver_delta if success else 0,
        "silver_after": int(state.get("player", {}).get("silver", silver_before) or 0),
        "reason": reason,
        "load_after": carried_load(state),
        "load_limit": carrying_capacity(state),
        **service_change,
    }
    _record_resource_event(state, event)
    return event


def resolve_resource_bundle(
    state: dict[str, Any],
    semantic_roll: dict[str, Any] | None,
    *,
    roll_success: bool | None = None,
) -> dict[str, Any] | None:
    """Commit a rare, explicitly split loot bundle as one atomic transfer."""

    bundle = resource_bundle_advice(semantic_roll)
    if len(bundle) < 2:
        return None
    from .voyage import is_passage_resource
    if any(is_passage_resource(advice) for advice in bundle):
        return {"type": "compound_resource_transfer", "committed": False, "success": False,
                "reason": "Book passage separately through the passage offer; no bundled transfer was charged."}
    snapshot = {
        "player": copy.deepcopy(state.get("player")),
        "scene_objects": copy.deepcopy(state.get("scene_objects")),
        "resource_history": copy.deepcopy(state.get("resource_history")),
    }
    parts: list[dict[str, Any]] = []
    for advice in bundle:
        part_semantic = {
            "requires_roll": bool(semantic_roll and semantic_roll.get("requires_roll") is True),
            "resource_action": advice,
        }
        part = resolve_resource_action(state, part_semantic, roll_success=roll_success)
        if not isinstance(part, dict) or not part.get("success"):
            state["player"] = snapshot["player"]
            state["scene_objects"] = snapshot["scene_objects"]
            state["resource_history"] = snapshot["resource_history"]
            return {
                "type": "compound_resource_transfer",
                "committed": False,
                "success": False,
                "parts": [],
                "reason": str(part.get("reason") or "One part of the grounded bundle could not be committed.")
                if isinstance(part, dict)
                else "One part of the grounded bundle could not be committed.",
            }
        parts.append(part)
    event = {
        "type": "compound_resource_transfer",
        "committed": True,
        "success": True,
        "parts": parts,
        "silver_delta": sum(int(part.get("silver_delta", 0) or 0) for part in parts),
        "silver_after": int(state.get("player", {}).get("silver", 0) or 0),
    }
    state.setdefault("resource_history", []).append(
        {
            "turn": int(state.get("turn_no", 0) or 0),
            "kind": "compound_loot",
            "item": "; ".join(str(part.get("item") or "") for part in parts if part.get("item")),
            "quantity": len(parts),
            "silver_delta": event["silver_delta"],
            "success": True,
        }
    )
    state["resource_history"] = state["resource_history"][-12:]
    return event


def silver_amounts(text: str) -> list[int]:
    return _number_amounts(text, require_silver=True)


def stated_amounts(text: str) -> list[int]:
    """Return explicit numeric/word amounts, including context-bound bare prices."""

    return _number_amounts(text, require_silver=False)


def capture_resource_offer(state: dict[str, Any], narration: str) -> bool:
    commerce = state.setdefault("commerce", {"awaiting_quote": None, "pending_offer": None})
    awaiting = commerce.get("awaiting_quote")
    if not isinstance(awaiting, dict):
        return False
    minimum = max(1, int(awaiting.get("minimum", 1) or 1))
    maximum = max(minimum, int(awaiting.get("maximum", minimum) or minimum))
    values = silver_amounts(narration)
    if not values:
        # Merchants naturally answer "Four. Take it or leave it."  A bare
        # number is safe only inside an active quote and only when exactly one
        # candidate falls inside Python's already-computed range.
        values = [
            value for value in _number_amounts(narration, require_silver=False)
            if minimum <= value <= maximum
        ]
    if not values or len(set(values)) != 1:
        return False
    amount = values[0]
    if not minimum <= amount <= maximum:
        return False
    if not re.search(
        r"\b(?:ask|asks|asking|cost|costs|price|offer|offers|pay|pays|worth|"
        r"take|accept|sell|buy|for)\b",
        narration,
        re.I,
    ):
        return False
    commerce["pending_offer"] = {
        "item": str(awaiting.get("item") or "")[:100],
        "item_kind": str(awaiting.get("item_kind") or "misc"),
        "quantity": max(1, int(awaiting.get("quantity", 1) or 1)),
        "amount": amount,
        "direction": str(awaiting.get("direction") or "buy"),
        "counterparty": str(awaiting.get("counterparty") or "")[:100],
        "location_id": str(awaiting.get("location_id") or state.get("current_location_id") or ""),
        "quoted_at_turn": int(state.get("turn_no", 0) or 0),
    }
    commerce["awaiting_quote"] = None
    return True
