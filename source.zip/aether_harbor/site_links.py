"""Bound the active site overview without deleting established geography."""
from .sealed_layout import key

MAX_CHILD_SITES_PER_SUB_AREA = 3


def remember_child_site(memory, row, *, newly_discovered=False):
    # Archived links remain canonical, revisitable places. A routine sync must
    # not keep cycling them through the three active overview slots.
    known = {}
    for child in [*memory.get("archived_child_sites", []), *memory.get("child_sites", [])]:
        if isinstance(child, dict) and child.get("site_id"):
            known[child["site_id"]] = dict(child)
    site_id = row.get("site_id")
    if site_id in known:
        known[site_id].update(row)
    elif newly_discovered:
        known[site_id] = dict(row)
    else:
        # Recover a link lost by older pruning from the location's stored parent.
        known = {site_id: dict(row), **known}
    counts, active, archived = {}, [], []
    for child in reversed(list(known.values())):
        area = key(child.get("at_area"))
        counts[area] = counts.get(area, 0) + 1
        (active if counts[area] <= MAX_CHILD_SITES_PER_SUB_AREA else archived).append(child)
    memory["child_sites"] = list(reversed(active))
    memory["archived_child_sites"] = list(reversed(archived))
