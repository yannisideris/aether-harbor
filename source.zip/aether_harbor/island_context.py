"""Existing island identity and private overview retrieval; no generation or RNG."""
from __future__ import annotations
import copy
import re


def destination_entry(name):
    from .island_bank import ISLANDS_BY_ID, _named_entry_from_text
    entry = _named_entry_from_text(name)
    if entry: return entry
    key = ' '.join(str(name).casefold().split()).removeprefix('the ')
    matches = [row for row in ISLANDS_BY_ID.values() if key in {
        ' '.join(str(alias).casefold().split()).removeprefix('the ')
        for alias in row.get('aliases', [])}]
    return matches[0] if len(matches) == 1 else None


def is_island(state, location_id):
    loc = state.get('locations', {}).get(location_id, {})
    return bool(loc.get('island_destination') or loc.get('authored_island_binding')
        or location_id in state.get('island_bank', {}).get('bindings', {})
        or (loc.get('kind') != 'vessel' and loc.get('aether_geography_scope') == 'distant'
            and re.search(r'\bislands?\b', str(loc.get('region') or ''), re.I)))


def island_root_id(state, location_id=None):
    """Follow explicit containment only, with cycle and vessel boundaries."""
    locations = state.get('locations', {})
    todo = [str(location_id or state.get('current_location_id') or '')]
    seen = set()
    while todo:
        key = todo.pop(0)
        if not key or key in seen: continue
        seen.add(key)
        loc = locations.get(key, {})
        if loc.get('kind') == 'vessel': continue
        if is_island(state, key): return key
        for field in ('island_root_id','site_root_id','parent_hint'):
            parent = loc.get(field)
            if parent and parent != key and parent in locations: todo.append(parent)
    return None


def private_island_overview(state, location_id=None):
    root = island_root_id(state, location_id)
    if not root: return None
    loc = state['locations'][root]
    binding = state.get('island_bank', {}).get('bindings', {}).get(root, {})
    from .island_bank import ISLANDS_BY_ID
    entry = ISLANDS_BY_ID.get(binding.get('entry_id')) if binding.get('ownership') == 'authored' else None
    from .prompting import _compact_site_geometry
    return {'island_id':root, 'name':loc.get('name'), 'summary':loc.get('summary'),
        'ownership':binding.get('ownership', 'established'), 'planet':binding.get('planet'),
        'authored_spine':entry.get('spine') if entry else None,
        'authored_layers':copy.deepcopy(entry.get('layers', [])) if entry else [],
        'geography':_compact_site_geometry(loc.get('site_memory'), None),
        'instruction':'Private whole-island continuity. Preserve this geography while exploring child sites; reveal only what the player perceives. Do not replace improvised identity with a catalogue island.'}
