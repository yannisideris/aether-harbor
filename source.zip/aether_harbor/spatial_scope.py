"""Spatial ownership is independent of interior/exterior and map completeness.

Legacy locked plans retain their authority; this is not a save migration.
Names are a compatibility fallback. Explicit scope supports newly named places.
"""
import re

BOUNDED_NAME = re.compile(
    r"\b(?:house|home|villa|estate|manor|palazzo|palace|office|warehouse|"
    r"storeroom|workshop|shop|apothecary|bakery|smithy|forge|tavern|inn|"
    r"temple|sanctuary|shrine|cathedral|monastery|abbey|priory|tower|watchtower|"
    r"lighthouse|library|archive|museum|guild|guildhall|lodge|academy|observatory|"
    r"dispensary|infirmary|clinic|counting\s+house|customhouse|bank|courthouse|"
    r"bathhouse|theater|theatre|gatehouse|fort|fortress|citadel|bastion|keep|"
    r"cave|cavern|crypt|tomb|mine|ruins?|ship|vessel|boat|brig|brigantine|barque|"
    r"schooner|galleon|galley|sloop|cog|building|residence|dwelling|mansion|"
    r"townhouse|tenement|common\s+room|study|vestibule|foyer|chapel|mill|foundry|"
    r"armory|barracks|prison|jail)\b", re.I)
OPEN_NAME = re.compile(
    r"\b(?:district|quarters?|outskirts|docks|wharves|waterfront|harbou?r|"
    r"plaza|square|coast|shore|shoreline|countryside|mainland|hinterland|"
    r"forest|woodland|slopes|wilderness|islands?|archipelago)\b", re.I)


def site_scope(location):
    if not isinstance(location, dict):
        return 'unknown'
    memory = location.get('site_memory')
    memory = memory if isinstance(memory, dict) else {}
    if memory.get('plan_lock'):
        return 'bounded'  # Preserve even historically misclassified saves.
    for record in (memory, location):
        if record.get('site_scope') in {'bounded', 'open'}:
            return record['site_scope']
    if location.get('kind') == 'vessel':
        return 'bounded'
    if location.get('island_destination') or location.get('authored_island_binding'):
        return 'open'
    name = str(location.get('name') or '')
    # A district containing warehouses is open; an office by a harbor is bounded.
    if re.search(r'\b(?:district|quarters?|outskirts)\b', name, re.I):
        return 'open'
    if BOUNDED_NAME.search(name):
        return 'bounded'
    if OPEN_NAME.search(name):
        return 'open'
    return 'unknown'


def has_bounded_geometry(location):
    return isinstance(location, dict) and isinstance(location.get('site_memory'), dict) and site_scope(location) != 'open'
