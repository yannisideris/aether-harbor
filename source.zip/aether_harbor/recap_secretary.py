from __future__ import annotations

import copy
import json
import re
from typing import Any

from .items import pending_commerce_offer
from .local_model import LocalQwen
from .persistence import CampaignStore


_REVEAL_ENTRY = re.compile(
    r"\b(?:enter(?:s|ed)?|go(?:es|ne)?\s+into|step(?:s|ped)?\s+into|walk(?:s|ed)?\s+into)\b",
    re.I,
)
_REVEAL_STOP = {
    "the", "a", "an", "arion", "player", "visitor", "room", "area", "space",
    "into", "through", "beyond", "behind", "within", "inside",
    "or", "and", "if", "when", "makes", "make", "significant", "noise",
}


def _reveal_tokens(value: str) -> set[str]:
    folded = re.sub(r"[^a-z0-9 ]+", " ", str(value or "").casefold())
    return {
        token for token in folded.split()
        if len(token) >= 4 and token not in _REVEAL_STOP
    }


def _reveal_condition_already_met(
    reveal_if: str,
    *,
    state: dict[str, Any],
) -> bool:
    """Catch a small class of stale background secrets before they become state.

    The recap can run several turns behind visible play.  If it proposes an
    entry-based reveal condition for the exact local position the player is
    already standing in, the secret is already stale and should not be born.
    More semantic lifecycle questions remain the curator's job.
    """

    if not reveal_if or not _REVEAL_ENTRY.search(reveal_if):
        return False
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    label = str(position.get("label") or "")
    if not label:
        return False
    # Compare only the concrete entry target clause, not the whole condition.
    match = _REVEAL_ENTRY.search(reveal_if)
    tail = reveal_if[match.end():] if match else reveal_if
    tail = re.split(r"\b(?:or|and\s+if|unless|until)\b", tail, maxsplit=1, flags=re.I)[0]
    target_tokens = _reveal_tokens(tail)
    label_tokens = _reveal_tokens(label)
    if not target_tokens or not label_tokens:
        return False
    overlap = target_tokens & label_tokens
    return len(overlap) >= 2 or (
        len(target_tokens) == 1 and target_tokens == label_tokens
    )


RECAP_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "recap": {"type": "string", "maxLength": 1600},
        "hidden_currents": {
            "type": "array",
            "maxItems": 2,
            "items": {
                "type": "object",
                "properties": {
                    "kind": {
                        "type": "string",
                        "enum": [
                            "npc_plan", "access_requirement",
                            "world_pressure", "concealed_relation"
                        ],
                    },
                    "subject": {"type": "string"},
                    "target_aliases": {
                        "type": "array",
                        "items": {"type": "string"},
                        "maxItems": 3,
                    },
                    "truth": {"type": "string"},
                    "outward_tell": {"type": "string"},
                    "reveal_if": {"type": "string"},
                    "required_item": {"type": "string"},
                    "urgency": {
                        "type": "string",
                        "enum": ["dormant", "stirring", "imminent"],
                    },
                },
                "required": [
                    "kind", "subject", "target_aliases", "truth", "outward_tell",
                    "reveal_if", "required_item", "urgency"
                ],
                "additionalProperties": False,
            },
        },
        "player_appearance_refinement": {
            "type": "string"
        },
    },
    "required": ["recap", "hidden_currents"],
    "additionalProperties": False,
}

SYSTEM = """
You are the private continuity secretary for an improvisational fantasy RPG,
not its narrator. Rewrite the previous rolling recap in light of the exact new
transcript. Preserve the causal sequence, the present situation, important NPC
identities and relationships, promises, major outcomes, established places,
unresolved tensions, and the latest explicit location, holder, or physical
state of salient objects. Keep distinctive details and strange emerging facts
when they matter; do not reduce the recap to logistics.

Distinguish fact, rumor, belief, and possibility. Never invent a fact in the
recap; the narrow hidden-current exception is defined below. Never repair,
rationalize, sanitize, or explain away a surreal event or contradiction that
the transcript itself established. If the new transcript supersedes an older
fact, retain the latest state and enough causal history to understand the
change. Prefer concrete transcript language over abstract explanations, and do
not infer an object's purpose or power merely to explain its strangeness. The
exact recent transcript outranks the previous recap. AUTHORITATIVE CAMPAIGN
REFERENCES outrank prose for the player's current inventory, equipped state,
silver, and the exact scene where a tracked dropped object remains. Quotes and
pending offers are not completed transfers.

AUTHORITATIVE SITE GEOMETRY also outranks prose. Do not rewrite its observed
areas or connections, and do not spend recap space cataloging room-by-room
doors, windows, or directional layouts that are already stored in that site
geometry. Spatial topology belongs exclusively to the Spatial Secretary; never
create, infer, or maintain hidden site layouts here. Leave directional
conflicts unresolved unless that geometry resolves them. Do not turn repeated
atmospheric scent into a hidden current unless it is an actionable clue or
hazard. Areas and connections marked latent remain private and must not be
recapped as something the player already observed.

Because the live narrator only sees a short window of recent turns, this
rolling recap serves as the campaign's long-range narrative memory across a
long voyage. Dedicated subsystems already store room-by-room site blueprints,
detailed NPC cards, and inventory lists, so do not waste recap space on
architectural catalogs or item rosters; for NPCs, capture their central role,
relationship, and actions in the story rather than repeating minor card
details. Return natural, flowing prose in the JSON field "recap" (keep it
proportional to campaign length and bounded to roughly 120-220 words across at
most two or three short paragraphs; naturally shorter in early turns). Never
write a turn-by-turn log or bureaucratic checklist: weave older settled
episodes into a smooth narrative arc—preserving enduring consequences, key
people, promises, debts, and salient objects in motion—while giving fuller
weight to the most recent developments and the immediate situation. Do not
address the player and do not continue the story.

Also maintain zero to two private hidden currents. A current is an off-stage
truth, motive, concealed preparation, or accumulating pressure grounded in the
campaign's existing material but not yet known to the player. Give it one
subtle outward tell and a concrete reveal condition. Preserve a still-useful
previous current rather than replacing it merely for novelty; omit one once it
has been openly revealed, resolved, contradicted, or made irrelevant. It is
fine and often preferable to return an empty list. The default is []. For a new
hidden current only, you may rarely author one minimal off-stage development
beyond the visible transcript, but only as the direct next consequence of a
concrete, unresolved cause already established there. It must add genuinely
concealed state and change what an actor or process will do if the player does
nothing. Its outward_tell is a future symptom that could later enter narration,
not the visible evidence which originally suggested the current.
If the proposed truth is already visible, is merely a description or possible
interpretation, or has no concrete next effect, keep it in the recap or omit it.
Atmosphere, weather texture, curiosity, a smile, an unusual object, an unknown
symbol, a possible motive, or merely evaluating someone is not enough. Track
one real-world development once: its deadline, object, actor and consequence do
not become separate currents. Never use hidden currents to retroactively negate an
established fact or player success, and avoid turning every person or scene into
a conspiracy. Maintain at most one npc_plan or concealed_relation at a time;
prefer a practical pressure or no current at all over another secret scheme.
Spatial structure itself is never a hidden-current responsibility here.

Decision boundary:
- A quiet room, ordinary weather, a fruitless search, or ambient sound: [].
- A smile, guarded manner, sales offer, curious object, or unknown map without
  a concrete unresolved action: [].
- A responsible house servant will soon finish a stated duty after the player
  stole a displayed valuable: at most one grounded next action, such as the
  servant privately checking the display; not separate servant/owner currents.
- An actor explicitly bribes transport to depart before a deadline: at most one
  continuing actor plan; the vehicle, deadline, cargo and actor are not four
  currents.

Mere proximity to an unusual map, relic, symbol, or recent mystical motif does
not ground a secret affiliation. Do not make a person its guardian, cultist,
agent, chosen bearer, or supernatural counterpart unless the transcript or an
existing authored current supplies concrete evidence. When a new pressure is
warranted, practical human developments such as an expected owner returning,
a servant noticing an absence, a delayed alarm, or a mundane obligation are as
valid as occult ones; do not establish any of them without grounding.

When an npc_plan or world_pressure is already supported, phrase truth around
the actor's concrete present objective and resolve, not merely a mood,
suspicion, or passive monitoring. Do not invent hostility or violence: preserve
uncertainty when the transcript establishes only interest, caution, or rumor.

Choose kind access_requirement only for a threshold, room, container, or other
access target that truly requires one specific item. Both the exact target and
the required item must already exist in the transcript or selected evidence,
the item must remain plausibly obtainable, and the established fiction must
support ordinary force or magic not bypassing it. Put concise matching names in
target_aliases and the exact existing item name in required_item. Never invent
a hard access requirement merely to create a quest or delay the player. For all
other kinds required_item is an empty string and target_aliases may be empty.
""".strip()


def due(state: dict[str, Any], *, cycle: int = 8, phase: int = 4) -> bool:
    recap = state.get("campaign_recap") if isinstance(state.get("campaign_recap"), dict) else {}
    current_turn = int(state.get("turn_no", 0) or 0)
    last_turn = int(recap.get("last_campaign_turn", 0) or 0)
    interval = max(4, int(cycle))
    target_phase = int(phase) % interval
    first_beat = target_phase if target_phase else interval
    if current_turn < first_beat:
        return False
    latest_beat = first_beat + ((current_turn - first_beat) // interval) * interval
    return latest_beat > last_turn


def build_messages(
    rows: list[dict[str, Any]],
    *,
    previous_recap: str = "",
    campaign_references: dict[str, Any] | None = None,
    check_appearance: bool = False,
) -> list[dict[str, str]]:
    transcript = "\n".join(
        f"[{int(row.get('sequence_no', index))}] {str(row.get('speaker') or '').upper()}: "
        f"{str(row.get('text') or '').strip()}"
        for index, row in enumerate(rows, start=1)
        if str(row.get("text") or "").strip()
    )
    prior = previous_recap.strip() or "(none; this is the first recap)"
    references = json.dumps(campaign_references or {}, ensure_ascii=False, indent=2)
    
    system_prompt = SYSTEM
    if check_appearance:
        system_prompt += (
            "\n\nReview the player's current `appearance` in the references. If their input is gibberish "
            "or entirely non-descriptive (e.g., 'n', 'test', 'you decide'), replace it with a newly invented "
            "physical description of 10-25 words that fits their class, incorporating any details from the transcript if present. "
            "If their current description contradicts their mechanical `class` (e.g. an 'incredibly muscular' "
            "Thief), adapt it gracefully to fit their class while preserving their unique flavor. "
            "Capture the final, evocative physical description (around 10-25 words) in `player_appearance_refinement`. "
            "If the current appearance is perfectly fine and requires no adaptation, output the exact word 'OK'."
        )
        
    return [
        {"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": (
                "AUTHORITATIVE CAMPAIGN REFERENCES:\n"
                + references
                + "\n\nPREVIOUS ROLLING RECAP:\n"
                + prior
                + "\n\nNEW EXACT TRANSCRIPT SINCE THAT RECAP:\n"
                + transcript
            ),
        },
    ]


def run(
    *,
    model: LocalQwen,
    store: CampaignStore,
    state: dict[str, Any],
    save_state: bool = True,
) -> dict[str, Any]:
    recap_state = state.setdefault(
        "campaign_recap",
        {"text": "", "last_sequence": 0, "last_campaign_turn": 0},
    )
    rows = store.turns_after(
        state["campaign_id"],
        int(recap_state.get("last_sequence", 0) or 0),
        limit=96,
    )
    if not rows:
        recap_state["last_campaign_turn"] = int(state.get("turn_no", 0) or 0)
        if save_state:
            store.save_state(state)
        return {"updated": False, "rows": 0}

    player = state.get("player", {}) if isinstance(state.get("player"), dict) else {}
    current_location = (
        state.get("locations", {}).get(str(state.get("current_location_id") or ""), {})
        if isinstance(state.get("locations"), dict)
        else {}
    )
    npcs = sorted(
        (card for card in state.get("npcs", {}).values() if isinstance(card, dict)),
        key=lambda card: int(card.get("last_turn", 0) or 0),
    )[-8:]
    evidence = store.recent_evidence(state["campaign_id"], limit=12)
    grounding_corpus = " ".join(
        [
            str(recap_state.get("text") or ""),
            *(str(row.get("text") or "") for row in rows),
            *(str(row.get("excerpt") or "") for row in evidence),
            json.dumps(state.get("hidden_currents") or [], ensure_ascii=False),
            *(
                f"{location.get('name', '')} {location.get('summary', '')}"
                for location in state.get("locations", {}).values()
                if isinstance(location, dict)
            ),
            *(str(item.get("name") or "") for item in player.get("inventory", []) if isinstance(item, dict)),
        ]
    ).casefold()
    
    active_schema = copy.deepcopy(RECAP_SCHEMA)
    if not player.get("appearance_locked", False):
        active_schema["required"].append("player_appearance_refinement")
        
    payload = model.chat_json(
        build_messages(
            rows,
            previous_recap=str(recap_state.get("text") or ""),
            campaign_references={
                "player": {
                    "name": str(player.get("name") or "Visitor"),
                    "appearance": str(player.get("appearance") or ""),
                    "class": str(player.get("class_label") or ""),
                    "hp": player.get("hp"),
                    "max_hp": player.get("max_hp"),
                    "silver": player.get("silver"),
                    "conditions": list(player.get("conditions") or []),
                    "inventory": [
                        {
                            "name": item.get("name"),
                            "quantity": item.get("quantity", 1),
                            "equipped": bool(item.get("equipped")),
                            "known_details": list(item.get("known_details") or [])[:3],
                        }
                        for item in player.get("inventory", [])
                        if isinstance(item, dict)
                    ],
                    "companions": [
                        {
                            "name": comp.get("name"),
                            "descriptor": comp.get("descriptor") or comp.get("anchor"),
                            "appearance": comp.get("appearance") or "",
                            "trait": comp.get("character_trait") or "",
                            "hp": comp.get("hp"),
                            "max_hp": comp.get("max_hp"),
                            "silver": comp.get("silver", 0),
                        }
                        for comp in player.get("companions", [])
                        if isinstance(comp, dict)
                    ],
                },
                "current_atlas_anchor": {
                    "id": state.get("current_location_id"),
                    "name": current_location.get("name"),
                    "region": current_location.get("region"),
                },
                "local_scene_position": state.get("scene_position"),
                "active_combat": state.get("combat"),
                "recent_combat_outcomes": list(state.get("combat_history") or [])[-6:],
                "recent_resource_outcomes": list(state.get("resource_history") or [])[-8:],
                "pending_commerce_offer": pending_commerce_offer(state),
                "tracked_scene_objects": [
                    {
                        "name": row.get("name"),
                        "quantity": row.get("quantity", 1),
                        "location_id": row.get("location_id"),
                        "scene_position_id": row.get("scene_position_id"),
                        "status": row.get("status"),
                    }
                    for row in state.get("scene_objects", [])[-12:]
                    if isinstance(row, dict)
                ],
                "recent_emerging_npc_cards": npcs,
                "recent_threads": list(state.get("threads") or [])[-8:],
                "selected_verbatim_evidence": evidence,
                "previous_private_hidden_currents": list(state.get("hidden_currents") or [])[:2],
                "authoritative_site_geometry": [
                    {
                        "id": location_id,
                        "name": location.get("name"),
                        "aliases": list(location.get("aliases") or [])[:8],
                        "geometry": location.get("site_memory"),
                    }
                    for location_id, location in state.get("locations", {}).items()
                    if isinstance(location, dict)
                    and isinstance(location.get("site_memory"), dict)
                ][-6:],
            },
            check_appearance=not player.get("appearance_locked", False),
        ),
        schema=active_schema,
        temperature=0.1,
    )
    recap = str(payload.get("recap") or "").strip()
    if not recap:
        raise ValueError("Continuity secretary returned an empty recap.")

    previous_currents = [
        row for row in state.get("hidden_currents", [])[:2] if isinstance(row, dict)
    ]
    hidden_currents: list[dict[str, Any]] = []
    concealed_scheme_kept = False
    for candidate in payload.get("hidden_currents", [])[:2]:
        if not isinstance(candidate, dict):
            continue
        kind = str(candidate.get("kind") or "world_pressure")
        subject = " ".join(str(candidate.get("subject") or "").split())[:100]
        target_aliases = [
            " ".join(str(alias).split())[:100]
            for alias in candidate.get("target_aliases", [])[:3]
            if str(alias).strip()
        ]
        truth = " ".join(str(candidate.get("truth") or "").split())[:360]
        outward_tell = " ".join(str(candidate.get("outward_tell") or "").split())[:240]
        reveal_if = " ".join(str(candidate.get("reveal_if") or "").split())[:240]
        required_item = " ".join(str(candidate.get("required_item") or "").split())[:100]
        urgency = str(candidate.get("urgency") or "dormant")
        known_subject = any(
            name.casefold() in grounding_corpus
            for name in [subject, *target_aliases]
            if name.strip()
        )
        if kind in {"npc_plan", "concealed_relation"} and not known_subject:
            continue
        if kind in {"npc_plan", "concealed_relation"} and concealed_scheme_kept:
            continue
        if kind == "access_requirement" and not required_item:
            continue
        if kind == "access_requirement" and (
            required_item.casefold() not in grounding_corpus
            or not any(
                name.casefold() in grounding_corpus
                for name in [subject, *target_aliases]
                if name.strip()
            )
        ):
            continue
        if kind != "access_requirement":
            required_item = ""
        if _reveal_condition_already_met(reveal_if, state=state):
            continue
        if subject and truth and outward_tell and reveal_if:
            previous = next(
                (
                    row for row in previous_currents
                    if str(row.get("kind") or "") == kind
                    and str(row.get("subject") or "").casefold() == subject.casefold()
                ),
                None,
            )
            hidden_currents.append(
                {
                    "kind": kind if kind in {
                        "npc_plan", "access_requirement",
                        "world_pressure", "concealed_relation"
                    } else "world_pressure",
                    "subject": subject,
                    "target_aliases": target_aliases,
                    "truth": truth,
                    "outward_tell": outward_tell,
                    "reveal_if": reveal_if,
                    "required_item": required_item,
                    "urgency": urgency if urgency in {"dormant", "stirring", "imminent"} else "dormant",
                    "created_at_turn": int(
                        previous.get("created_at_turn", state.get("turn_no", 0))
                        if isinstance(previous, dict)
                        else state.get("turn_no", 0)
                    ),
                }
            )
            if kind in {"npc_plan", "concealed_relation"}:
                concealed_scheme_kept = True

    recap_state["text"] = recap
    recap_state["last_sequence"] = max(int(row["sequence_no"]) for row in rows)
    recap_state["last_campaign_turn"] = int(state.get("turn_no", 0) or 0)
    state["hidden_currents"] = hidden_currents
    if not state.get("player", {}).get("appearance_locked"):
        appearance_refinement = str(payload.get("player_appearance_refinement") or "").strip()
        player_dict = state.setdefault("player", {})
        
        current_app = str(player_dict.get("appearance") or "")
        needs_description = current_app.casefold() in {"you decide", "you decide.", ""}
        
        if appearance_refinement and appearance_refinement.casefold() != "ok":
            player_dict["appearance"] = appearance_refinement[:400]
            player_dict["appearance_locked"] = True
        elif appearance_refinement.casefold() == "ok":
            player_dict["appearance_locked"] = True
        elif not needs_description:
            # The model returned nothing, but the player already has a real description, so lock it.
            player_dict["appearance_locked"] = True

    if save_state:
        store.save_state(state)
    return {"updated": True, "rows": len(rows)}
