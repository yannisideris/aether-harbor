from __future__ import annotations


AETHER_HARBOR_CANON = """
The adventure begins in Aether Harbor, a bustling port-city hub with a vague
early 17th-century atmosphere. Its culture is Aether Harbor's own fused
maritime culture. Behind the design, its mercantile institutions, craft
traditions, and built environment draw from the British Isles, the Netherlands,
and Italian regions, but in-world prose renders that fusion as local detail
rather than naming or comparing those source cultures. Personal names belong
to this mixed port society and vary rather than returning to a narrow stock of
familiar fantasy names. The town is mostly safe compared to the islands and
wilderness. The overall atmosphere remains realistic and gritty. Firearms
exist, but they are rare and expensive.

Aether Harbor lies on a mostly north-south coastline, sheltered within a small
bay that opens westward to the sea. The rising slopes behind the town give way
to hilly terrain covered in a Mediterranean forest: pine trees, rocky outcrops,
dense shrubbery, bushes and rocks. Further inland this rugged mainland may hold
encounters unrelated to the islands.

The north is defined by a rugged promontory with steep rocky cliffs. The
Sentinel Lighthouse stands here above rougher seas, guarding the bay entrance.
Beyond it begins a rough northern shore of cliffs, secluded coves and abrupt
coastal terrain. The city sprawls around the natural harbour. The Commercial
Docks and functional Harbormaster's Office are central to port activity. Near
the waterfront and extending toward the central plaza dominated by the
Governor's Palazzo lies the wealthiest residential quarter. In the older civic
core, stone construction and tiled roofs often give buildings a sturdy,
established appearance; elsewhere construction and upkeep vary with district
and use.

To the south, the town gives way to more rural-looking houses with small
gardens. Some larger villas and estates belonging to wealthier citizens are
also situated near the fertile agricultural lands in the southern outskirts.
Beyond lie olive groves, orchards, and a few scattered villas. The southern
coast is more sandy.

As the terrain slopes uphill towards the eastern forests, the dwellings
generally become poorer and more modest. The poorer quarters lie below the
forest, on the higher ground behind the central urban core.
""".strip()


# These are prompt-relevance zones, not movement nodes. A generated tavern,
# lane, house, or quarter can inherit the zone of the place from which it was
# reached without making travel itself more restrictive.
AETHER_HARBOR_LOCAL_LOCATION_IDS = frozenset(
    {
        "opening_threshold",
        "commercial_docks",
        "harbormasters_office",
        "central_plaza",
        "wealthy_quarter",
        "governors_palazzo",
        "sentinel_lighthouse",
        "northern_shore",
        "southern_outskirts",
        "sandy_coast",
        "eastern_quarters",
        "forested_slopes",
    }
)
AETHER_HARBOR_REGIONAL_LOCATION_IDS = frozenset({"rugged_mainland"})


AETHER_HARBOR_ORIGIN_CONTEXT = """
Aether Harbor is the journey's established port-city of origin and a standing
hub to which the player may return. It has its own fused maritime culture and
a vague early 17th-century atmosphere; it is gritty but mostly safer than the
islands and wilderness, and firearms are rare and expensive. Do not transplant
its named districts, local coastline, or mainland terrain into a distant place.
""".strip()


AETHER_HARBOR_REGIONAL_CONTEXT = """
Aether Harbor remains the regional point of reference behind the player. Its
small bay opens west on a mostly north-south coast; the Sentinel Lighthouse is
on the rugged northern promontory, the softer sandy coast lies south, and the
town climbs east into Mediterranean forest and then rugged mainland. Preserve
these bearings when the harbor is seen or approached, without importing every
city district into remote inland terrain.
""".strip()


SEVEN_ISLAND_PREMISE = """
From Aether Harbor, the player may voyage to seven unique islands,
each influenced by one classical planet: Sun, Moon, Mercury, Venus, Mars,
Jupiter, and Saturn. A town or port with different quarters, countryside,
possible hamlets, and a dungeon is one possible island pattern rather than a
fixed template; settlement and dungeon patterns may be sparser, denser,
stranger, or absent when the emerging place calls for it. Positions and
explored layouts develop during play and remain stable once established.
Mythic material may draw organically from Greco-Roman,
Medieval European, Manichaean, Indian, Egyptian, and newly devised sources.
The city and its mainland hinterland are complete fields of play where new
places and events may emerge as freely as on the islands. Island passage is
available whenever the player chooses it, but is never presumed.
Architecture, geography, society, hazards, flora, and magic should reflect the
island without becoming generic fantasy. A planetary influence is a thematic
core, not a restrictive mold.
""".strip()


PLANETARY_THEMES = {
    "Sun": "Sun (air): abstract thought, conceptual clarity, underlying principles, illumination, archetypal patterns.",
    "Moon": "Moon (air): intuition, visionary insight, symbolic imagination, dream logic, subjective inner world, prophecies, hidden meanings.",
    "Mercury": "Mercury (air-water): communication, translation, swiftness, diplomacy, trade, adaptability, trickery, effective flow of information.",
    "Venus": "Venus (water): love, beauty, desire, compassion, harmony, pleasure, direct emotional connection, art, healing, social grace.",
    "Mars": "Mars (ether): raw energy, action, willpower, vitality, courage, initiative, conflict, physical prowess, direct obstacles.",
    "Jupiter": "Jupiter (fire): worldly power, influence, expansion, organization, leadership, law, politics, strategy, abundance, social gravity, fate-like pressure.",
    "Saturn": "Saturn (earth): grounding, structure, stability, limitation, patience, discipline, practical mastery, defense, endurance, artisanal or technical knowledge, melancholic or restrictive atmosphere.",
}
