from __future__ import annotations

import math
import random
import secrets
import time
from typing import Any


SEGMENTS = [
    ("AMBUSH", "bane"),
    ("MIRACLE", "boon"),
    ("RUIN", "bane"),
    ("EPIPHANY", "boon"),
    ("CURSE", "bane"),
    ("FORTUNE", "boon"),
    ("DESPAIR", "bane"),
    ("DELIVERANCE", "boon"),
]
COOLDOWN_SECONDS = 480
SPIN_DURATION_MS = 4000


def remaining_cooldown(state: dict[str, Any], *, now: float | None = None) -> int:
    now_value = float(now if now is not None else time.time())
    last = state.get("fate", {}).get("last_spin_at")
    if last is None:
        return 0
    return max(0, int(math.ceil(COOLDOWN_SECONDS - (now_value - float(last)))))


def _random_index() -> int:
    """Draw directly from the operating system; campaign state cannot weight fate."""
    return secrets.randbelow(len(SEGMENTS))


def _condition(
    player: dict[str, Any],
    name: str,
    *,
    turns: int,
    effect: str,
    uses: int | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    record: dict[str, Any] = {
        "name": name,
        "turns": int(turns),
        "effect": effect,
        "source": "Wheel of Fate",
    }
    if uses is not None:
        record["uses"] = int(uses)
    record.update(kwargs)
    player.setdefault("conditions", []).append(record)
    return record


def _is_harmful_condition(cond: dict[str, Any]) -> bool:
    if not isinstance(cond, dict):
        return False
    if cond.get("condition_type") == "affliction":
        return True
    if cond.get("kind") in {"fear", "confusion", "immobilized", "wound", "poison", "curse", "affliction"}:
        return True
    if int(cond.get("penalty", 0) or 0) < 0 or int(cond.get("defense_penalty", 0) or 0) < 0:
        return True
    name = str(cond.get("name") or "").lower()
    return any(bad in name for bad in ("curse", "despair", "weight", "dread", "wound", "broken", "ruin", "poison", "affliction"))


def spin(state: dict[str, Any], *, now: float | None = None) -> dict[str, Any]:
    now_value = float(now if now is not None else time.time())
    remaining = remaining_cooldown(state, now=now_value)
    if remaining:
        return {"type": "fate_cooldown", "committed": False, "remaining_seconds": remaining}

    name, polarity = SEGMENTS[_random_index()]
    player = state["player"]
    effect: dict[str, Any]

    if name == "AMBUSH":
        if isinstance(state.get("combat"), dict) and state["combat"].get("status") == "active":
            combat = state["combat"]
            opponents = combat.setdefault("opponents", [])
            reinforcement_added = False
            if len(opponents) < 4:
                reinforcement = {
                    "name": "an ambushing flanker",
                    "hp": 9,
                    "max_hp": 9,
                    "STR": 12,
                    "AGI": 12,
                    "weapon": {"name": "Ambush Dagger", "mode": "melee", "weapon_bonus": 1, "source": "profile"},
                    "armor": 0,
                }
                opponents.append(reinforcement)
                reinforcement_added = True
            combat["pending_defense"] = {
                "source": "Flanking Ambush Strike",
                "bonus": 0,
                "originating_action": "ambush",
            }
            combat["phase"] = "player_defense"
            effect = {
                "kind": "combat_reinforced",
                "detail": "Ambushers strike from the flank! The enemy seizes initiative and a defense roll is immediately required.",
                "reinforcements": 1 if reinforcement_added else 0,
            }
        else:
            ambush_rng = random.Random(f"{state.get('rng_seed', 0)}:{state.get('turn_no', 0)}:{now_value}:fate-ambush")
            ambush_roll = ambush_rng.random()
            if ambush_roll < 0.45:
                enemy_count = 1
                profile = "ruthless ambusher"
                hp_val = 12
                opponents = [
                    {
                        "name": "a ruthless ambusher",
                        "hp": 12,
                        "max_hp": 12,
                        "STR": 13,
                        "AGI": 13,
                        "weapon": {"name": "Ambusher's Blade", "mode": "melee", "weapon_bonus": 2, "source": "profile"},
                        "armor": 1,
                    }
                ]
            elif ambush_roll < 0.85:
                enemy_count = 2
                profile = "pair of ambushers"
                hp_val = 8
                opponents = [
                    {
                        "name": "first ambusher",
                        "hp": 8,
                        "max_hp": 8,
                        "STR": 12,
                        "AGI": 12,
                        "weapon": {"name": "Ambush Blade", "mode": "melee", "weapon_bonus": 1, "source": "profile"},
                        "armor": 0,
                    },
                    {
                        "name": "second ambusher",
                        "hp": 8,
                        "max_hp": 8,
                        "STR": 12,
                        "AGI": 12,
                        "weapon": {"name": "Ambush Cudgel", "mode": "melee", "weapon_bonus": 1, "source": "profile"},
                        "armor": 0,
                    },
                ]
            else:
                enemy_count = 3
                profile = "trio of ambushers"
                hp_val = 7
                opponents = [
                    {
                        "name": "lead ambusher",
                        "hp": 7,
                        "max_hp": 7,
                        "STR": 12,
                        "AGI": 12,
                        "weapon": {"name": "Ambush Dagger", "mode": "melee", "weapon_bonus": 1, "source": "profile"},
                        "armor": 0,
                    },
                    {
                        "name": "second ambusher",
                        "hp": 7,
                        "max_hp": 7,
                        "STR": 11,
                        "AGI": 12,
                        "weapon": {"name": "Ambush Club", "mode": "melee", "weapon_bonus": 1, "source": "profile"},
                        "armor": 0,
                    },
                    {
                        "name": "third ambusher",
                        "hp": 7,
                        "max_hp": 7,
                        "STR": 11,
                        "AGI": 11,
                        "weapon": {"name": "Ambush Dirk", "mode": "melee", "weapon_bonus": 1, "source": "profile"},
                        "armor": 0,
                    },
                ]
            state["combat"] = {
                "status": "active",
                "round": 1,
                "phase": "player_action",
                "pending_defense": None,
                "opponent": opponents[0],
                "opponents": opponents,
            }
            effect = {
                "kind": "combat_started",
                "opponent_profile": profile,
                "opponent_hp": hp_val,
                "enemy_count": enemy_count,
            }
    elif name == "MIRACLE":
        before = int(player["hp"])
        player["hp"] = int(player["max_hp"])
        remaining_conds = []
        purged = []
        for cond in player.get("conditions", []):
            if isinstance(cond, dict) and _is_harmful_condition(cond):
                purged.append(cond.get("name") or "affliction")
            else:
                remaining_conds.append(cond)
        player["conditions"] = remaining_conds

        ward_granted = 0
        favor_granted = False
        if player["hp"] - before < 3:
            ward = player.setdefault("ward", {"max": 8, "remaining": 0, "source": "miracle"})
            ward["remaining"] = max(int(ward.get("remaining", 0)), 8)
            ward["max"] = max(int(ward.get("max", 8)), 8)
            ward_granted = 8
            _condition(
                player,
                "Wheel of Fate (Miraculous Favor)",
                turns=3,
                uses=3,
                effect="+2 to the next three rolls and combat defense",
                bonus=2,
            )
            favor_granted = True

        effect = {
            "kind": "restoration",
            "hp_before": before,
            "hp_after": player["hp"],
            "purged_conditions": purged,
            "removed_condition": purged[0] if purged else None,
            "ward_granted": ward_granted,
            "favor_granted": favor_granted,
        }
    elif name == "RUIN":
        before = int(player.get("silver", 0))
        if before >= 20:
            loss = max(20, before // 2)
            player["silver"] = max(0, before - loss)
            effect = {
                "kind": "silver_loss",
                "silver_before": before,
                "silver_lost": loss,
                "silver_after": player["silver"],
            }
        elif before > 0:
            loss = before
            player["silver"] = 0
            cond = _condition(
                player,
                "Wheel of Fate (Broken Gear)",
                turns=4,
                uses=4,
                effect="-2 to the next four physical and social rolls",
            )
            effect = {
                "kind": "ruin_breakage",
                "silver_before": before,
                "silver_lost": loss,
                "silver_after": 0,
                "condition": cond,
            }
        else:
            cond = _condition(
                player,
                "Wheel of Fate (Broken Gear)",
                turns=4,
                uses=4,
                effect="-2 to the next four physical and social rolls",
            )
            effect = {
                "kind": "ruin_breakage",
                "silver_before": 0,
                "silver_lost": 0,
                "silver_after": 0,
                "condition": cond,
            }
    elif name == "EPIPHANY":
        condition = _condition(
            player,
            "Wheel of Fate (Epiphany)",
            turns=3,
            uses=3,
            effect="+4 to the next three risky rolls of any stat",
        )
        effect = {"kind": "insight", "condition": condition}
    elif name == "CURSE":
        condition = _condition(
            player,
            "Wheel of Fate (Curse)",
            turns=3,
            uses=3,
            defense_penalty=-2,
            effect="-3 to the next three risky rolls and -2 to combat defense",
        )
        effect = {"kind": "condition", "condition": condition}
    elif name == "FORTUNE":
        before = int(player.get("silver", 0))
        gain = 60
        player["silver"] = before + gain
        condition = _condition(
            player,
            "Wheel of Fate (Lucky Omen)",
            turns=3,
            uses=3,
            bonus=2,
            effect="+2 to the next three risky rolls and combat defense",
        )
        effect = {
            "kind": "silver_gain",
            "silver_before": before,
            "silver_gained": gain,
            "silver_after": player["silver"],
            "condition": condition,
        }
    elif name == "DESPAIR":
        condition = _condition(
            player,
            "Wheel of Fate (Despair)",
            turns=4,
            uses=4,
            defense_penalty=-2,
            effect="-2 to all risky rolls and combat defense",
        )
        effect = {"kind": "condition", "condition": condition}
    else:  # DELIVERANCE
        combat_was_active = isinstance(state.get("combat"), dict) and state["combat"].get("status") == "active"
        if combat_was_active:
            state["combat"]["status"] = "delivered"
            state["combat"]["phase"] = "complete"
            state["combat"]["pending_defense"] = None
        before = int(player["hp"])
        player["hp"] = min(int(player["max_hp"]), before + 10)
        ward_granted = 0
        if not combat_was_active and before >= int(player["max_hp"]) - 2:
            ward = player.setdefault("ward", {"max": 6, "remaining": 0, "source": "deliverance"})
            ward["remaining"] = max(int(ward.get("remaining", 0)), 6)
            ward["max"] = max(int(ward.get("max", 6)), 6)
            ward_granted = 6
        effect = {
            "kind": "escape_or_relief",
            "combat_ended": combat_was_active,
            "hp_before": before,
            "hp_after": player["hp"],
            "ward_granted": ward_granted,
        }

    event = {
        "type": "fate_resolution",
        "committed": True,
        "result": name,
        "polarity": polarity,
        "effect": effect,
        "spun_at": now_value,
    }
    fate = state.setdefault("fate", {"last_spin_at": None, "history": []})
    fate["last_spin_at"] = now_value
    fate.setdefault("history", []).append(event)
    del fate["history"][:-20]
    return event
