from __future__ import annotations

import copy

from .mechanics import roll_actor, resolve_companion_attack
from .party import commit_party_action, party_advice, find_companion
import re
from typing import Any

from .mechanics import (
    apply_general_critical_failure_harm,
    apply_general_failure_affliction,
    begin_combat_from_text,
    begin_enemy_initiative,
    combat_defense_pending,
    queue_enemy_defense_phase,
    recognize_risky_action,
    resolve_combat_action,
    resolve_d20,
    resolve_pending_combat_defense,
)
from .movement import (
    MOVE_VERBS,
    is_capability_question,
    prepare_passage_quote,
    resolve_movement,
    resolve_pending_passage,
    resolve_route_span_failure,
)
from .items import (
    equipment_assist,
    resolve_direct_item_use,
    resolve_resource_action,
    resolve_resource_bundle,
    resource_advice,
    resource_bundle_advice,
)
from .magic import resolve_magic_action
from .recovery import resolve_recovery_action
from .stealth import carry_concealment, resolve_stealth_action, sync_stealth_location
from .active_situations import (
    end_active_situation,
    resolve_active_situation_action,
    start_chase_from_semantic,
)
from .celestial_spheres import resolve_celestial_spheres_action
from .local_games import resolve_local_game_action




PREPARATORY_STEALTH_ATTACK = re.compile(
    r"\b(?:get\s+ready|be\s+ready|ready\s+myself|prepare(?:\s+myself)?|"
    r"wait\s+to|lie\s+in\s+wait|hold\s+my\s+attack|set\s+up\s+to)\b",
    re.I,
)

SEQUENCED_FOLLOWUP = re.compile(r"(?:,\s*)?(?:and\s+)?then\b", re.I)


def _semantic_movement_authorized(semantic_roll: dict[str, Any] | None) -> bool:
    """Let an explicit semantic movement verdict outrank text fallbacks.

    Older callers and saved test fixtures predate ``movement_commitment`` and
    retain the legacy behavior.  Current foreground judgments always provide
    the field, so a deliberate NONE cannot be converted into a place such as
    ``Get Into`` by the free-text movement fallback.
    """

    if not isinstance(semantic_roll, dict) or "movement_commitment" not in semantic_roll:
        return True
    return str(semantic_roll.get("movement_commitment") or "NONE").upper() == "COMMITTED"


def _explicit_semantic_commitment(semantic_roll: dict[str, Any] | None) -> bool | None:
    """Expose only the new explicit verdict; legacy callers keep legacy guards."""

    if not isinstance(semantic_roll, dict) or "movement_commitment" not in semantic_roll:
        return None
    return str(semantic_roll.get("movement_commitment") or "NONE").upper() == "COMMITTED"


def _attach_magic_subactions(
    state: dict[str, Any],
    text: str,
    semantic_roll: dict[str, Any] | None,
    magic: dict[str, Any],
) -> dict[str, Any]:
    """Keep a player's utility cast and its explicit pickups/travel in one event.

    Reuse the spell outcome, never roll again. Pickup precedes departure so
    scene objects and material opportunities are consumed at their source.
    Combat, companion turns, learning and rejected casts retain their owners.
    """
    if (
        not isinstance(semantic_roll, dict)
        or magic.get("type") != "magic_resolution"
        or not magic.get("committed")
        or str(magic.get("actor") or "").casefold() != "player"
        or magic.get("hostile")
        or magic.get("defeat_outcome")
        or magic.get("counterattack_pending")
        or (state.get("combat") or {}).get("status") == "active"
        or int(state.get("player", {}).get("hp", 0)) <= 0
    ):
        return magic

    succeeded = magic.get("outcome") in {"success", "strong_success"}
    bundle = resource_bundle_advice(semantic_roll)
    advice = resource_advice(semantic_roll)
    pickups = {"take", "receive_item", "receive_money"}
    resource = None
    if len(bundle) >= 2:
        # Never partially execute a bundle containing an unsupported action.
        if all(row.get("kind") in pickups for row in bundle):
            resource = resolve_resource_bundle(state, semantic_roll, roll_success=succeeded)
    elif advice.get("kind") in pickups:
        resource = resolve_resource_action(state, semantic_roll, roll_success=succeeded)
    if resource is not None:
        magic["resource"] = resource

    destination = str(semantic_roll.get("destination") or "").strip()
    independent = semantic_roll.get("movement_dependency") == "INDEPENDENT"
    if destination and _explicit_semantic_commitment(semantic_roll) is True:
        if not succeeded and not independent:
            movement = {"type": "local_movement", "committed": False,
                        "reason": "Movement depended on the spell, which did not succeed."}
        elif resource is not None and not resource.get("success") and not independent:
            movement = {"type": "local_movement", "committed": False,
                        "reason": "The requested pickup did not complete before departure."}
        else:
            movement = resolve_movement(
                state, text, destination_hint=destination,
                destination_scope=str(semantic_roll.get("destination_scope") or "NONE"),
                semantic_commitment=True,
            )
        if movement is not None:
            magic["movement"] = movement
            magic["movement_independent"] = independent
            if movement.get("committed"):
                sync_stealth_location(state)
    return magic


def _explicit_move_before_perceptive_followup(
    text: str, semantic_roll: dict[str, Any] | None
) -> bool:
    """Recover only an explicit ``move, then inspect`` sequence.

    Gemma occasionally classifies the later PER/ARC action correctly but omits
    the already-stated local destination. This narrow grammar fallback avoids
    leaving saved position behind the narration without guessing place names
    or treating a failed climb/escape as successful movement.
    """

    if not isinstance(semantic_roll, dict):
        return False
    if str(semantic_roll.get("stat") or "") not in {"PER", "ARC"}:
        return False
    movement = MOVE_VERBS.search(text)
    if movement is None:
        return False
    return SEQUENCED_FOLLOWUP.search(text, movement.end()) is not None

ACCESS_ACTION = re.compile(
    r"\b(?:open|unlock|unseal|enter|go\s+into|step\s+into|force|break\s+into|"
    r"access|melt|shatter|blast|dispel)\b",
    re.I,
)


def _normalized(value: str) -> str:
    return " ".join(re.sub(r"[^a-z0-9 ]+", " ", str(value).casefold()).split())


def _mentions_hidden_target(text: str, current: dict[str, Any]) -> bool:
    source = _normalized(text)
    names = [str(current.get("subject") or ""), *current.get("target_aliases", [])]
    return any(
        needle and re.search(rf"\b{re.escape(needle)}\b", source)
        for needle in (_normalized(name) for name in names)
    )


def _owns_required_item(state: dict[str, Any], required_item: str) -> bool:
    required = _normalized(required_item)
    if not required:
        return False
    for item in state.get("player", {}).get("inventory", []):
        if not isinstance(item, dict) or int(item.get("quantity", 1) or 0) <= 0:
            continue
        item_name = _normalized(str(item.get("name") or ""))
        if item_name == required or (len(required) >= 5 and required in item_name):
            return True
    return False


def _resolve_hidden_access(state: dict[str, Any], text: str) -> dict[str, Any] | None:
    """Enforce the rare Secretary-authored access rule without exposing its secret."""

    if not ACCESS_ACTION.search(text):
        return None
    opened = state.setdefault("scene_flags", {}).setdefault("opened_hidden_access", [])
    for current in state.get("hidden_currents", [])[:2]:
        if not isinstance(current, dict) or current.get("kind") != "access_requirement":
            continue
        subject = str(current.get("subject") or "")
        subject_key = _normalized(subject)
        if not subject_key or subject_key in opened or not _mentions_hidden_target(text, current):
            continue
        required_item = str(current.get("required_item") or "")
        if not _owns_required_item(state, required_item):
            return {
                "type": "hidden_access_blocked",
                "committed": False,
                "subject": subject,
                "outward_tell": str(current.get("outward_tell") or ""),
                "reveal_if": str(current.get("reveal_if") or ""),
            }
        opened.append(subject_key)
        movement = None
        if re.search(r"\b(?:enter|go\s+into|step\s+into)\b", text, re.I):
            movement = resolve_movement(state, text, destination_hint=subject, roll_success=True)
        return {
            "type": "hidden_access_opened",
            "committed": True,
            "subject": subject,
            "required_item": required_item,
            "item_consumed": False,
            "movement": movement,
        }
    return None


def _attach_take_movement(
    state: dict[str, Any],
    text: str,
    semantic_roll: dict[str, Any] | None,
    resource: dict[str, Any] | None,
    *,
    roll: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Commit a stated departure after the same successful grounded take.

    The resource judge has only one ordinary action field.  A rare bundle
    helper may split several objects, but neither should swallow an explicit
    endpoint such as "take the books and run outside".  No extra roll or
    destination is invented here: both must already be present in Qwen's
    semantic judgment.
    """

    if not isinstance(resource, dict) or resource.get("success") is not True:
        return None
    if not isinstance(semantic_roll, dict) or not _semantic_movement_authorized(semantic_roll):
        return None
    destination = str(semantic_roll.get("destination") or "").strip()
    if not destination:
        return None
    if resource.get("type") == "compound_resource_transfer":
        parts = resource.get("parts") if isinstance(resource.get("parts"), list) else []
        take_kinds = {
            str(part.get("kind") or "")
            for part in parts
            if isinstance(part, dict)
        }
        if not parts or not take_kinds.issubset({"take", "receive_item", "receive_money"}):
            return None
    elif str(resource.get("kind") or "") not in {"take", "receive_item", "receive_money", "pay", "purchase", "sell", "drop", "give_item", "equip", "unequip"} or resource.get("service_kind") == "lodging":
        return None
    movement = resolve_movement(
        state,
        text,
        destination_hint=destination,
        destination_scope=str(semantic_roll.get("destination_scope") or "NONE"),
        semantic_commitment=_explicit_semantic_commitment(semantic_roll),
        roll_success=(bool(roll.get("success")) if roll and semantic_roll.get("movement_dependency") != "INDEPENDENT" else None),
    )
    if not isinstance(movement, dict) or not movement.get("committed"):
        return None
    sync_stealth_location(state)
    return {
        "type": "resource_movement_resolution",
        "committed": True,
        "success": True,
        "roll": roll,
        "resource": resource,
        "movement": movement,
    }


def _resolve_move_then_resource_inquiry(
    state: dict[str, Any],
    text: str,
    semantic_roll: dict[str, Any] | None,
    advice: dict[str, Any],
) -> dict[str, Any] | None:
    """Compose a judged arrival with the purchase/sale inquiry made there.

    This is intentionally semantic-only.  It does not inspect the player's
    wording for travel or question phrases: both halves must already have been
    returned explicitly by the foreground judge.  Movement is committed first
    so the pending quote belongs to the destination rather than the place the
    player just left.
    """

    if (
        _explicit_semantic_commitment(semantic_roll) is not True
        or not isinstance(semantic_roll, dict)
        or semantic_roll.get("requires_roll") is True
        or str(advice.get("kind") or "NONE") not in {"purchase", "sell"}
        or str(advice.get("status") or "NONE") != "inquiry"
    ):
        return None
    destination = " ".join(str(semantic_roll.get("destination") or "").split())[:120]
    if not destination:
        return None
    movement = resolve_movement(
        state,
        text,
        destination_hint=destination,
        destination_scope=str(semantic_roll.get("destination_scope") or "NONE"),
        semantic_commitment=True,
    )
    if not isinstance(movement, dict) or not movement.get("committed"):
        return None
    sync_stealth_location(state)
    resource = resolve_resource_action(state, semantic_roll)
    if not isinstance(resource, dict):
        return movement
    return {
        "type": "resource_movement_resolution",
        "committed": True,
        "success": True,
        "roll": None,
        "resource": resource,
        "movement": movement,
    }


def _attach_stealth_movement(
    state: dict[str, Any],
    text: str,
    semantic_roll: dict[str, Any] | None,
    stealth: dict[str, Any],
) -> dict[str, Any] | None:
    """Apply the judged endpoint of a stealthy approach with the same die.

    Only an explicit semantic commitment with a destination moves the player.
    Movement that depends on the roll happens only on success; a detected
    approach stays where it is. A successful arrival keeps its concealment.
    Remaining hidden in place (no destination) stays a plain stealth event.
    """

    if not isinstance(semantic_roll, dict) or _explicit_semantic_commitment(semantic_roll) is not True:
        return None
    destination = " ".join(str(semantic_roll.get("destination") or "").split())[:120]
    if not destination:
        return None
    roll = stealth.get("roll") if isinstance(stealth.get("roll"), dict) else {}
    succeeded = bool(roll.get("success"))
    independent = str(semantic_roll.get("movement_dependency") or "ROLL") == "INDEPENDENT"
    if not succeeded and not independent:
        return None
    movement = resolve_movement(
        state,
        text,
        destination_hint=destination,
        destination_scope=str(semantic_roll.get("destination_scope") or "NONE"),
        semantic_commitment=True,
        roll_success=(succeeded if not independent else None),
    )
    if not isinstance(movement, dict) or not movement.get("committed"):
        return None
    if succeeded:
        stealth_now = carry_concealment(state, stealth)
    else:
        stealth_now = sync_stealth_location(state)
    stealth = {**stealth, "concealed": bool(stealth_now.get("concealed")),
               "local_alert": stealth_now.get("local_alert", "none")}
    return {
        "type": "compound_resolution",
        "roll": roll,
        "movement": movement,
        "movement_independent": independent,
        "route_span_failure": False,
        "stealth": stealth,
    }


def _attach_combat_movement(
    state: dict[str, Any],
    text: str,
    semantic_roll: dict[str, Any] | None,
    combat_event: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Commit only an explicit semantic endpoint for a moving combat action."""

    if not isinstance(combat_event, dict):
        return combat_event
    if combat_event.get("action") == "flee" and combat_event.get("combat_status") != "escaped":
        return combat_event
    if not isinstance(semantic_roll, dict) or not _semantic_movement_authorized(semantic_roll):
        return combat_event
    destination = " ".join(str(semantic_roll.get("destination") or "").split())[:120]
    if not destination:
        return combat_event
    movement = resolve_movement(
        state,
        text,
        destination_hint=destination,
        destination_scope=str(semantic_roll.get("destination_scope") or "NONE"),
        semantic_commitment=_explicit_semantic_commitment(semantic_roll),
    )
    if not isinstance(movement, dict) or not movement.get("committed"):
        return combat_event
    sync_stealth_location(state)
    combat_event["movement"] = movement
    return combat_event


def _resolve_player_action_core(
    state: dict[str, Any],
    text: str,
    *,
    semantic_roll: dict[str, Any] | None = None,
    world_beat: dict[str, Any] | None = None,
    allow_regex_fallback: bool = True,
    manual_roll: int | None = None,
    manual_rolls: list[int] | None = None,
) -> dict[str, Any] | None:
    """Commit only explicit, deterministic boundaries before narration."""

    if is_capability_question(text):
        return None
    party = party_advice(semantic_roll)
    target = party.get("target", "")
    acting = str((semantic_roll or {}).get("acting_companion") or "NONE")
    if acting != "NONE" or (party.get("action") == "recruit" and bool(target and find_companion(state, target))):
        party = party_advice(None)
    if party["action"] != "NONE":
        roll = None
        if (semantic_roll or {}).get("requires_roll"):
            roll = resolve_d20(state, str(semantic_roll.get("stat") or "SOC"),
                               int(semantic_roll.get("dc") or 13),
                               str(semantic_roll.get("reason") or "party agreement"),
                               manual_roll=manual_roll)
        event = commit_party_action(state, party, roll_success=roll.get("success") if roll else None)
        return {"type": "party_roll_resolution", "roll": roll, "party": event} if roll else event
    from .voyage import resolve as resolve_voyage
    voyage_event = resolve_voyage(state, text, semantic_roll)
    if voyage_event is not None:
        return voyage_event

    # An outstanding enemy beat is resolved before another actor can act.
    if combat_defense_pending(state):
        return resolve_pending_combat_defense(state, manual_roll=manual_roll,
            manual_rolls=manual_rolls, text=text, semantic_roll=semantic_roll)
    actor = str((semantic_roll or {}).get("acting_companion") or "NONE")
    magic_actor = ((semantic_roll or {}).get("magic") or {}).get("actor")
    condition_actor = actor
    if actor == "NONE" and magic_actor and str(magic_actor).upper() not in {"NONE", "PLAYER"}:
        condition_actor = str(magic_actor)
    from .mechanics import resolve_magic_action_denial
    denied = resolve_magic_action_denial(state, condition_actor)
    if denied is not None:
        return denied
    if actor != "NONE":
        companion = roll_actor(state, actor)  # Validate before any mutation or UI roll.
        if int(companion.get("hp", 0)) <= 0:
            return {"type": "engine_warning", "committed": False, "reason": f"{companion['name']} cannot act at 0 HP."}
        magic_advice = (semantic_roll or {}).get("magic")
        if isinstance(magic_advice, dict) and magic_advice.get("is_magic"):
            # The party dispatcher owns the actor, even if the model's nested
            # magic actor label is absent or inconsistent.
            spell_advice = {**semantic_roll, "magic": {**magic_advice, "actor": actor}}
            magic = resolve_magic_action(state, text, semantic_roll=spell_advice,
                allow_regex_fallback=allow_regex_fallback)
            if magic is not None:
                return _attach_magic_subactions(state, text, spell_advice, magic)
        if ((semantic_roll or {}).get("combat") or {}).get("action") == "attack":
            return resolve_companion_attack(state, actor, semantic_roll["combat"])

        combat_advice = (semantic_roll or {}).get("combat") or {}
        resource_advice_row = (semantic_roll or {}).get("resource_action") or {}
        plain_check = str(combat_advice.get("action") or "NONE") != "attack"
        if plain_check:
            if not (semantic_roll or {}).get("requires_roll"):
                if not (_semantic_movement_authorized(semantic_roll) and re.search(r"\b(?:we|i)\b", text, re.I)):
                    return {"type": "companion_action", "actor": companion.get("name", actor), "committed": True}
            else:
                stat = str(semantic_roll.get("stat") or "AGI")
                actor_state = {**state, "player": companion}
                assist, source = equipment_assist(actor_state, text, stat)
                roll = resolve_d20(state, stat, int(semantic_roll.get("dc") or 13),
                    str(semantic_roll.get("reason") or "companion check"), actor=actor,
                    situational_modifier=assist, situational_source=source)
                # Ordinary companion checks never invoke player-only stealth/magic
                # state machines, consume a player die, or relocate the player.
                harm = max(0, min(2, int(semantic_roll.get("critical_failure_harm") or 0)))
                if roll.get("critical_failure") and harm:
                    before = int(companion.get("hp", 0))
                    companion["hp"] = max(0, before - harm)
                    roll.update(hp_before=before, hp_after=companion["hp"], critical_failure_harm=harm)
                apply_general_failure_affliction(actor_state, roll, str(semantic_roll.get("harm_affliction") or "NONE"))
                return roll

    semantic_combat = (
        semantic_roll.get("combat") if isinstance(semantic_roll, dict) else None
    )
    semantic_resource = (
        semantic_roll.get("resource_action") if isinstance(semantic_roll, dict) else None
    )
    recovery_is_solo = not isinstance(semantic_roll, dict) or not (
        semantic_roll.get("requires_roll") is True
        or str(semantic_roll.get("destination") or "").strip()
        or (
            isinstance(semantic_combat, dict)
            and str(semantic_combat.get("action") or "NONE") != "NONE"
        )
        or (
            isinstance(semantic_resource, dict)
            and str(semantic_resource.get("kind") or "NONE") != "NONE"
        )
    )
    semantic_recovery = (
        str(semantic_roll.get("recovery_intent") or "NONE")
        if isinstance(semantic_roll, dict) and "recovery_intent" in semantic_roll
        else None
    )
    recovery_committed = semantic_recovery in {None, "REST"}
    if recovery_is_solo and recovery_committed:
        if isinstance(world_beat, dict) and world_beat.get("advance") is True:
            recovery_preview = resolve_recovery_action(copy.deepcopy(state), text)
            if recovery_preview is not None:
                pressure = commit_world_beat(state, world_beat)
                if pressure is not None:
                    pressure["interrupted_recovery"] = True
                    return pressure
        recovery = resolve_recovery_action(state, text)
        if recovery is not None:
            return recovery

    pending_passage = resolve_pending_passage(state, text, semantic_roll=semantic_roll)
    if pending_passage is not None:
        return pending_passage

    combat = state.get("combat")
    if isinstance(combat, dict) and combat.get("status") == "active":
        if combat_defense_pending(state):
            return resolve_pending_combat_defense(state, manual_roll=manual_roll, manual_rolls=manual_rolls, text=text, semantic_roll=semantic_roll)

        advice = resource_advice(semantic_roll)
        resource_kind = str(advice.get("kind") or "NONE")
        # An explicit weapon attack may say "use my sword". Only semantic
        # consumption belongs before combat/magic dispatch.
        is_combat_consume = resource_kind == "consume"
        if is_combat_consume:
            requires_consume_roll = bool(
                semantic_roll and semantic_roll.get("requires_roll") is True
            )
            if requires_consume_roll:
                stat = str(semantic_roll.get("stat") or "AGI")
                dc = int(semantic_roll.get("dc") or 13)
                reason = str(semantic_roll.get("reason") or advice.get("reason") or "consume item under combat pressure")
                assist, source = equipment_assist(state, text, stat)
                actor = str(semantic_roll.get("acting_companion") or "NONE") if isinstance(semantic_roll, dict) else "NONE"
                roll = resolve_d20(
                    state,
                    stat,
                    dc,
                    reason,
                    situational_modifier=assist,
                    situational_source=source,
                    manual_roll=manual_roll,
                    actor=actor,
                )
                if not roll.get("success"):
                    queue_enemy_defense_phase(state, originating_action="other")
                    return {
                        "type": "resource_roll_resolution",
                        "roll": roll,
                        "resource": {
                            "type": "item_use_failed",
                            "committed": False,
                            "item": str(advice.get("item") or ""),
                            "reason": "The required roll did not succeed.",
                        },
                    }
            item_use = resolve_direct_item_use(
                state, text, item_hint=str(advice.get("item") or "")
            )
            if item_use is not None:
                queue_enemy_defense_phase(state, originating_action="other")
                if requires_consume_roll:
                    return {
                        "type": "resource_roll_resolution",
                        "roll": roll,
                        "resource": item_use,
                    }
                return item_use

        magic = resolve_magic_action(
            state,
            text,
            semantic_roll=semantic_roll,
            manual_roll=manual_roll,
            allow_regex_fallback=allow_regex_fallback,
        )
        if magic is not None:
            return _attach_magic_subactions(state, text, semantic_roll, magic)
        combat_event = resolve_combat_action(
            state, text, semantic_roll=semantic_roll, manual_roll=manual_roll, manual_rolls=manual_rolls
        )
        return _attach_combat_movement(state, text, semantic_roll, combat_event)

    start_chase_from_semantic(state, semantic_roll)
    active_situation = resolve_active_situation_action(
        state, text, semantic_roll=semantic_roll, manual_roll=manual_roll
    )
    if active_situation is not None:
        return active_situation

    celestial_spheres = resolve_celestial_spheres_action(
        state, text, semantic_roll=semantic_roll
    )
    if celestial_spheres is not None:
        return celestial_spheres

    local_game = resolve_local_game_action(state, text, semantic_roll=semantic_roll)
    if local_game is not None:
        return local_game

    passage_quote = prepare_passage_quote(state, text, semantic_roll=semantic_roll)
    if passage_quote is not None:
        return passage_quote

    hidden_access = _resolve_hidden_access(state, text)
    if hidden_access is not None:
        return hidden_access

    advice = resource_advice(semantic_roll)
    resource_kind = str(advice.get("kind") or "NONE")
    if resource_kind == "consume":
        requires_consume_roll = bool(
            semantic_roll and semantic_roll.get("requires_roll") is True
        )
        if requires_consume_roll:
            stat = str(semantic_roll.get("stat") or "AGI")
            dc = int(semantic_roll.get("dc") or 13)
            reason = str(semantic_roll.get("reason") or advice.get("reason") or "consume item under pressure")
            assist, source = equipment_assist(state, text, stat)
            actor = str(semantic_roll.get("acting_companion") or "NONE") if isinstance(semantic_roll, dict) else "NONE"
            roll = resolve_d20(
                state,
                stat,
                dc,
                reason,
                situational_modifier=assist,
                situational_source=source,
                manual_roll=manual_roll,
                actor=actor,
            )
            if not roll.get("success"):
                return {
                    "type": "resource_roll_resolution",
                    "roll": roll,
                    "resource": {
                        "type": "item_use_failed",
                        "committed": False,
                        "item": str(advice.get("item") or ""),
                        "reason": "The required roll did not succeed.",
                    },
                }
            item_use = resolve_direct_item_use(
                state, text, item_hint=str(advice.get("item") or "")
            )
            if item_use is not None:
                return {
                    "type": "resource_roll_resolution",
                    "roll": roll,
                    "resource": item_use,
                }
        else:
            item_use = resolve_direct_item_use(
                state, text, item_hint=str(advice.get("item") or "")
            )
            if item_use is not None:
                return item_use

    magic = resolve_magic_action(
        state,
        text,
        semantic_roll=semantic_roll,
        manual_roll=manual_roll,
        allow_regex_fallback=allow_regex_fallback,
    )
    if magic is not None:
        return _attach_magic_subactions(state, text, semantic_roll, magic)

    stealth = resolve_stealth_action(
        state, text, manual_roll=manual_roll, semantic_roll=semantic_roll
    )
    if stealth is not None:
        # If the player explicitly attacks *now* ("I sneak up behind the guard
        # and stab him"), resolve the stealth approach on the D20 prompt and
        # then immediately chain into combat resolution on the same turn so a
        # surviving or alerted target naturally transitions into active combat.
        # Keep preparatory phrasing ("get ready to stab", "lie in wait") as
        # stealth-only.
        immediate_attack = bool(
            stealth.get("attack_declared")
            and not PREPARATORY_STEALTH_ATTACK.search(text)
        )
        if immediate_attack and manual_roll is not None:
            combat_start = begin_combat_from_text(
                state, text, semantic_roll=semantic_roll, manual_roll=None
            )
            if isinstance(combat_start, dict):
                end_active_situation(state, "combat")
                combat_start["stealth_setup"] = stealth
                return _attach_combat_movement(state, text, semantic_roll, combat_start)
        if not immediate_attack:
            combined = _attach_stealth_movement(state, text, semantic_roll, stealth)
            if combined is not None:
                return combined
        return stealth

    combat_start = begin_combat_from_text(
        state, text, semantic_roll=semantic_roll, manual_roll=manual_roll
    )
    if combat_start is not None:
        end_active_situation(state, "combat")
        return _attach_combat_movement(state, text, semantic_roll, combat_start)

    bundle = resource_bundle_advice(semantic_roll)
    if bundle:
        requires_bundle_roll = bool(
            semantic_roll
            and semantic_roll.get("requires_roll") is True
            and any(row.get("timing") in {"on_success", "immediate"} for row in bundle)
        )
        if requires_bundle_roll:
            stat = str(semantic_roll.get("stat") or "AGI")
            dc = int(semantic_roll.get("dc") or 13)
            reason = str(semantic_roll.get("reason") or "resolve the contested bundle transfer")
            assist, source = equipment_assist(state, text, stat)
            actor = str(semantic_roll.get("acting_companion") or "NONE") if isinstance(semantic_roll, dict) else "NONE"
            roll = resolve_d20(
                state,
                stat,
                dc,
                reason,
                situational_modifier=assist,
                situational_source=source,
                manual_roll=manual_roll,
                actor=actor,
            )
            resource = resolve_resource_bundle(
                state,
                semantic_roll,
                roll_success=bool(roll.get("success")),
            )
            combined = _attach_take_movement(
                state, text, semantic_roll, resource, roll=roll
            )
            if combined is not None:
                return combined
            return {"type": "resource_roll_resolution", "roll": roll, "resource": resource}
        resource = resolve_resource_bundle(state, semantic_roll)
        if resource is not None:
            combined = _attach_take_movement(state, text, semantic_roll, resource)
            if combined is not None:
                return combined
            return resource

    advice = resource_advice(semantic_roll)
    resource_kind = str(advice.get("kind") or "NONE")
    move_then_inquiry = _resolve_move_then_resource_inquiry(
        state, text, semantic_roll, advice
    )
    if move_then_inquiry is not None:
        return move_then_inquiry
    if resource_kind != "NONE":
        requires_resource_roll = bool(
            semantic_roll
            and semantic_roll.get("requires_roll") is True
            and (advice.get("timing") in {"on_success", "immediate"} or resource_kind == "haggle")
        )
        if requires_resource_roll:
            stat = str(semantic_roll.get("stat") or "AGI")
            dc = int(semantic_roll.get("dc") or 13)
            reason = str(semantic_roll.get("reason") or advice.get("reason") or "resolve the contested transfer")
            assist, source = equipment_assist(state, text, stat)
            actor = str(semantic_roll.get("acting_companion") or "NONE") if isinstance(semantic_roll, dict) else "NONE"
            roll = resolve_d20(
                state,
                stat,
                dc,
                reason,
                situational_modifier=assist,
                situational_source=source,
                manual_roll=manual_roll,
                actor=actor,
            )
            resource = resolve_resource_action(state, semantic_roll, roll_success=bool(roll.get("success")))
            combined = _attach_take_movement(
                state, text, semantic_roll, resource, roll=roll
            )
            if combined is not None:
                return combined
            return {"type": "resource_roll_resolution", "roll": roll, "resource": resource}
        resource = resolve_resource_action(state, semantic_roll)
        if resource is not None:
            combined = _attach_take_movement(state, text, semantic_roll, resource)
            if combined is not None:
                return combined
            return resource

    risk: tuple[str, int, str] | None = None
    if semantic_roll is not None:
        if semantic_roll.get("requires_roll") is True:
            risk = (
                str(semantic_roll.get("stat") or "AGI"),
                int(semantic_roll.get("dc") or 13),
                str(semantic_roll.get("reason") or "resolve the uncertain action"),
            )
    elif allow_regex_fallback:
        risk = recognize_risky_action(text)
    if risk is not None:
        stat, dc, reason = risk
        assist, source = equipment_assist(state, text, stat)
        actor = str(semantic_roll.get("acting_companion") or "NONE") if isinstance(semantic_roll, dict) else "NONE"
        roll = resolve_d20(
            state,
            stat,
            dc,
            reason,
            situational_modifier=assist,
            situational_source=source,
            manual_roll=manual_roll,
            actor=actor,
        )
        apply_general_critical_failure_harm(
            state,
            roll,
            int(semantic_roll.get("critical_failure_harm", 0) or 0)
            if isinstance(semantic_roll, dict)
            else 0,
        )
        apply_general_failure_affliction(
            state,
            roll,
            str(semantic_roll.get("harm_affliction") or "NONE")
            if isinstance(semantic_roll, dict)
            else "NONE",
        )
        destination_hint = str(semantic_roll.get("destination") or "").strip() if semantic_roll else ""
        destination_scope = str(semantic_roll.get("destination_scope") or "NONE") if semantic_roll else "NONE"
        movement_authorized = _semantic_movement_authorized(semantic_roll)
        movement_independent = bool(
            movement_authorized
            and semantic_roll
            and (
                (
                    destination_hint
                    and str(semantic_roll.get("movement_dependency") or "ROLL")
                    == "INDEPENDENT"
                )
                or (
                    not destination_hint
                    and _explicit_move_before_perceptive_followup(text, semantic_roll)
                )
            )
        )
        movement = (
            resolve_movement(
                state,
                text,
                destination_hint=destination_hint or None,
                destination_scope=destination_scope,
                semantic_commitment=_explicit_semantic_commitment(semantic_roll),
                roll_success=(bool(roll.get("success")) if not movement_independent else None),
            )
            if movement_authorized and (roll["success"] or movement_independent)
            else None
        )
        if movement is None and movement_authorized and not roll["success"]:
            movement = resolve_route_span_failure(
                state,
                text,
                severe=str(roll.get("outcome") or "") == "critical_failure",
            )
        if isinstance(movement, dict) and movement.get("committed"):
            sync_stealth_location(state)
            return {
                "type": "compound_resolution",
                "roll": roll,
                "movement": movement,
                "movement_independent": movement_independent,
                "route_span_failure": bool(movement.get("route_span_failure")),
            }
        return roll

    item_use = resolve_direct_item_use(state, text)
    if item_use is not None:
        return item_use

    destination_hint = str(semantic_roll.get("destination") or "").strip() if semantic_roll else ""
    destination_scope = str(semantic_roll.get("destination_scope") or "NONE") if semantic_roll else "NONE"
    if not _semantic_movement_authorized(semantic_roll):
        return None
    movement = resolve_movement(
        state,
        text,
        destination_hint=destination_hint or None,
        destination_scope=destination_scope,
        semantic_commitment=_explicit_semantic_commitment(semantic_roll),
    )
    if movement is not None:
        sync_stealth_location(state)
        return movement

    return None


def resolve_player_action(
    state: dict[str, Any],
    text: str,
    *,
    semantic_roll: dict[str, Any] | None = None,
    world_beat: dict[str, Any] | None = None,
    allow_regex_fallback: bool = True,
    manual_roll: int | None = None,
    manual_rolls: list[int] | None = None,
) -> dict[str, Any] | None:
    """Resolve substantive actions alongside chase pressure using one die.

    Movement, resource, magic and combat ownership stays with the primary
    resolver. Attach a chase consequence using its resolved roll, or advance
    yielded time for an unrelated action. Pursuer and quarry roles retain
    their respective distance and escape-clock polarity.
    """

    # Uncertain boarding/disembarkation still belongs to the player's ordinary
    # roll. Defer only its transport effect so the generic movement layer cannot
    # strand a successful boarder on a dock micro-position.
    from .voyage import current as current_voyage, BOARD, resolve as resolve_voyage
    voyage = current_voyage(state)
    advice = semantic_roll or {}
    transport = str(advice.get('voyage_action') or 'NONE')
    # Keyword fallback only for legacy payloads without a semantic voyage field;
    # a classifier NONE (e.g. 'read the notice board') is authoritative.
    if transport == 'NONE' and 'voyage_action' not in advice and BOARD.search(text): transport = 'BOARD'
    if (voyage and advice.get('requires_roll') and advice.get('acting_companion', 'NONE') == 'NONE'
            and transport in {'BOARD','DISEMBARK'}
            and (state.get('combat') or {}).get('status') != 'active'):
        deferred = {**advice, '_deferred_voyage_transport':True, 'destination':'',
                    'destination_scope':'NONE', 'movement_commitment':'NONE', 'movement_dependency':'NONE'}
        result = _resolve_player_action_core(state, text, semantic_roll=deferred,
            world_beat=world_beat, allow_regex_fallback=allow_regex_fallback, manual_roll=manual_roll, manual_rolls=manual_rolls)
        roll = result.get('roll', result) if isinstance(result, dict) else {}
        if roll.get('success') is True:
            event = resolve_voyage(state, text, {**advice,'requires_roll':False,'voyage_action':transport})
            if event and event.get('movement'):
                return {'type':'compound_resolution','committed':True,'roll':result,
                        'movement':event['movement'],'voyage':event}
        return result

    chase_advice = (
        semantic_roll.get("chase")
        if isinstance(semantic_roll, dict)
        and isinstance(semantic_roll.get("chase"), dict)
        else None
    )
    chase_action = str((chase_advice or {}).get("action") or "NONE")
    advice = semantic_roll or {}
    substantive = bool(
        _explicit_semantic_commitment(semantic_roll) is True
        or str(resource_advice(semantic_roll).get("kind") or "NONE") != "NONE"
        or resource_bundle_advice(semantic_roll)
        or (advice.get("magic") or {}).get("is_magic")
        or str((advice.get("combat") or {}).get("action") or "NONE") != "NONE"
        or str((advice.get("party_action") or {}).get("action") or "NONE") != "NONE"
    )
    compose_chase = chase_action == "yield" or (
        chase_action in {"start", "pursue", "intercept", "capture"} and substantive
    )
    if not compose_chase:
        result = _resolve_player_action_core(
            state,
            text,
            semantic_roll=semantic_roll,
            world_beat=world_beat,
            allow_regex_fallback=allow_regex_fallback,
            manual_roll=manual_roll,
            manual_rolls=manual_rolls,
        )
        from .voyage import note_resolution
        note_resolution(state, semantic_roll, result)
        return result

    start_chase_from_semantic(state, semantic_roll)
    primary_semantic = copy.deepcopy(semantic_roll)
    primary_semantic["chase"] = {
        "action": "NONE",
        "quarry": "",
        "stake": "",
        "escape": "",
        "anchor": "",
    }
    primary = _resolve_player_action_core(
        state,
        text,
        semantic_roll=primary_semantic,
        world_beat=world_beat,
        allow_regex_fallback=allow_regex_fallback,
        manual_roll=manual_roll,
        manual_rolls=manual_rolls,
    )
    # Reuse the primary action's die; never charge a second roll or replace
    # movement/resource ownership with the chase result.
    primary_roll = primary if isinstance(primary, dict) and primary.get("type") == "d20_resolution" else None
    if isinstance(primary, dict) and isinstance(primary.get("roll"), dict):
        primary_roll = primary["roll"]
    if chase_action != "yield" and advice.get("requires_roll") and primary_roll is None:
        return primary  # blocked/denied actions cannot create a successful chase beat
    chase_consequence = resolve_active_situation_action(
        state,
        text,
        semantic_roll=semantic_roll,
        manual_roll=manual_roll,
        resolved_roll=primary_roll,
    )
    if chase_consequence is None:
        return primary
    if not isinstance(primary, dict):
        return chase_consequence
    # Prevent circular reference when primary IS the roll object itself
    stored_consequence = dict(chase_consequence)
    if stored_consequence.get("roll") is primary:
        stored_consequence["roll"] = {
            k: v for k, v in primary.items() if k != "active_situation_consequence"
        }
    primary["active_situation_consequence"] = stored_consequence
    return primary


def commit_world_beat(
    state: dict[str, Any], beat: dict[str, Any] | None
) -> dict[str, Any] | None:
    """Commit one Qwen-chosen advance of an already-grounded world pressure.

    A hostile beat begins the existing ping-pong combat at its defense phase.
    It does not roll, touch HP, or decide whether the incoming action connects.
    """

    if not isinstance(beat, dict) or beat.get("advance") is not True:
        return None
    actor = " ".join(str(beat.get("actor") or "the active figure").split())[:100]
    action = " ".join(str(beat.get("action") or "").split())[:320]
    if not action:
        return None
    hostile = beat.get("hostile_attack") is True
    event: dict[str, Any] = {
        "type": "world_pressure_resolution",
        "committed": True,
        "actor": actor,
        "action": action,
        "hostile_attack": hostile,
        "combat_started": False,
    }
    if hostile:
        opponent = begin_enemy_initiative(
            state,
            opponent_name=actor,
            weapon_name=str(beat.get("weapon_name") or ""),
            weapon_mode=str(beat.get("weapon_mode") or "NONE"),
            weapon_bonus=int(beat.get("weapon_bonus", 0) or 0),
            weapon_natural=beat.get("weapon_natural") is True,
            opponent_profile=(
                beat.get("opponent_profile")
                if isinstance(beat.get("opponent_profile"), dict)
                else None
            ),
        )
        event["combat_started"] = True
        opponent_weapon = (
            opponent.get("weapon") if isinstance(opponent.get("weapon"), dict) else {}
        )
        event["opponent"] = {
            "name": str(opponent.get("name") or actor),
            "weapon": str(opponent_weapon.get("name") or ""),
        }
    return event


def preview_player_action(
    state: dict[str, Any],
    text: str,
    *,
    semantic_roll: dict[str, Any] | None = None,
    world_beat: dict[str, Any] | None = None,
    allow_regex_fallback: bool = True,
) -> dict[str, Any] | None:
    """Resolve against a disposable state so the player can own the actual roll.

    The preview discovers only whether a die is required and which die/stat/DC
    applies. Its disposable random sample is never committed. Nothing in the
    live campaign changes until the player submits a physical die result.
    """

    return resolve_player_action(
        copy.deepcopy(state),
        text,
        semantic_roll=semantic_roll,
        world_beat=world_beat,
        allow_regex_fallback=allow_regex_fallback,
    )


def preview_pending_combat_defense(state: dict[str, Any]) -> dict[str, Any] | None:
    """Preview the opponent's queued attack without touching live RNG or HP."""

    if not combat_defense_pending(state):
        return None
    return resolve_pending_combat_defense(copy.deepcopy(state))


def pending_roll_prompt(event: dict[str, Any] | None) -> dict[str, Any] | None:
    """Return a compact UI prompt when an event contains an uncommitted roll."""

    if not isinstance(event, dict):
        return None
    event_type = str(event.get("type") or "")
    roll: dict[str, Any] | None = None
    label = "Roll"
    if event_type == "d20_resolution":
        roll = event
    elif event_type == "compound_resolution":
        roll = event.get("roll") if isinstance(event.get("roll"), dict) else None
    elif event_type in {"resource_roll_resolution", "party_roll_resolution"}:
        roll = event.get("roll") if isinstance(event.get("roll"), dict) else None
    elif event_type in {"stealth_resolution", "magic_resolution", "magic_learning", "active_situation_resolution"}:
        roll = event.get("roll") if isinstance(event.get("roll"), dict) else None
    elif event_type == "combat_resolution":
        flee_roll = event.get("flee_roll")
        exchanges = event.get("exchanges") if isinstance(event.get("exchanges"), list) else []
        has_random_exchange = any(
            isinstance(exchange, dict)
            and not exchange.get("automatic")
            and exchange.get("manual_roll_owner", "Player") == "Player"
            and (exchange.get("attacker_raw") is not None or exchange.get("defender_raw") is not None)
            for exchange in exchanges
        )
        if isinstance(flee_roll, dict):
            return {"button": "Roll D20", "detail": "Escape check", "die": "D20", "maximum": 20}
        if has_random_exchange:
            defenses = [ex for ex in exchanges if isinstance(ex, dict)
                        and not ex.get("automatic") and not ex.get("attacker_is_player")
                        and ex.get("manual_roll_owner", "Player") == "Player"]
            if len(defenses) > 1 and any(ex.get("mode") == "magic" for ex in defenses):
                dice = [20 if ex.get("mode") == "magic" else 10 for ex in defenses]
                dice_label = ", ".join(f"D{die}" for die in dice)
                return {"button": f"Defend {dice_label}", "die": dice_label,
                        "detail": "vs " + ", ".join(str(ex.get("attacker")) for ex in defenses),
                        "maximum": max(dice), "roll_count": len(dice), "roll_dice": dice}
            magic_ex = next(
                (
                    ex for ex in exchanges
                    if isinstance(ex, dict)
                    and not ex.get("automatic")
                    and ex.get("mode") == "magic"
                    and ex.get("manual_roll_owner", "Player") == "Player"
                    and (ex.get("attacker_raw") is not None or ex.get("defender_raw") is not None)
                ),
                None,
            )
            if magic_ex is not None:
                spell_name = magic_ex.get("spell_name") or "Spell"
                stat = magic_ex.get("stat") or "AGI"
                return {
                    "button": "Defend D20",
                    "detail": f"vs {spell_name} · {stat}",
                    "die": "D20",
                    "maximum": 20,
                    "roll_count": 1,
                }

            attackers = [
                ex.get("attacker")
                for ex in exchanges
                if isinstance(ex, dict) and not ex.get("automatic") and not ex.get("attacker_is_player")
                and ex.get("manual_roll_owner", "Player") == "Player"
            ]
            if attackers:
                count = len(attackers)
                if count > 1:
                    return {
                        "button": f"Defend {count}x D10",
                        "detail": f"vs {', '.join(str(a) for a in attackers)}",
                        "die": "D10",
                        "maximum": 10,
                        "roll_count": count,
                    }
                return {
                    "button": "Defend D10",
                    "detail": f"vs {attackers[0]}",
                    "die": "D10",
                    "maximum": 10,
                    "roll_count": 1,
                }
            exchange = next(
                exchange
                for exchange in exchanges
                if isinstance(exchange, dict)
                and not exchange.get("automatic")
                and exchange.get("manual_roll_owner", "Player") == "Player"
                and (exchange.get("attacker_raw") is not None or exchange.get("defender_raw") is not None)
            )
            if exchange.get("attacker_is_player"):
                return {
                    "button": "Attack D10",
                    "detail": f"vs {exchange.get('defender') or 'opponent'}",
                    "die": "D10",
                    "maximum": 10,
                    "roll_count": 1,
                }
            return {
                "button": "Defend D10",
                "detail": f"vs {exchange.get('attacker') or 'opponent'}",
                "die": "D10",
                "maximum": 10,
                "roll_count": 1,
            }
        return None
    if not isinstance(roll, dict):
        return None
    if str(roll.get("actor") or "Player") != "Player":
        return None
    die = str(roll.get("die") or "D20")
    stat = str(roll.get("stat") or "").strip()
    modifier = roll.get("modifier")
    label = f"Roll {die}"
    detail_parts = [stat] if stat else []
    if isinstance(modifier, int):
        detail_parts.append(f"{modifier:+d}")
    maximum = 10 if die.upper() == "D10" else 20
    return {
        "button": label,
        "detail": " · ".join(detail_parts),
        "die": die.upper(),
        "maximum": maximum,
    }
