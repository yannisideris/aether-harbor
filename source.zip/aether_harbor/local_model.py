from __future__ import annotations

import json
import logging
import os
import sys
import threading
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable

_SDK_VENDOR = Path(__file__).resolve().parent.parent / "vendor" / "lmstudio_sdk"
# Append (not prepend): the vendored SDK ships an old typing_extensions that
# must never shadow the site-packages copy needed by pydantic/FastAPI.
if str(_SDK_VENDOR) not in sys.path:
    sys.path.append(str(_SDK_VENDOR))

try:
    import lmstudio as lms
except Exception as exc:  # pragma: no cover - installation integrity failure
    lms = None

from .cascading_model import CascadingModelClient, ModelQuotaExhaustedError

logger = logging.getLogger("aether_harbor.local_model")

NARRATOR_XTC_PROBABILITY = 0.05
NARRATOR_XTC_THRESHOLD = 0.10


class LocalModelError(RuntimeError):
    pass


class LocalQwen:
    def __init__(
        self,
        *,
        model_id: str | None = None,
        base_url: str = "http://127.0.0.1:1234",
        request_lock: Any | None = None,
        cascade_config: dict[str, Any] | None = None,
    ):
        self.requested_model_id = str(model_id or "auto")
        self.server_url = str(base_url).rstrip("/")
        self.base_url: str | None = None
        self.model_id: str | None = None
        self.display_model_id: str | None = None
        self._sdk_client: Any | None = None
        self._sdk_model: Any | None = None
        self._lock = request_lock if request_lock is not None else threading.Lock()

        # Cascading client for multi-provider fallback
        settings = cascade_config
        if settings is None:
            settings_path = Path(__file__).resolve().parent.parent / "settings.json"
            if settings_path.exists():
                try:
                    settings = json.loads(settings_path.read_text(encoding="utf-8"))
                except Exception:
                    settings = {}
            else:
                settings = {}

        self.cascade = CascadingModelClient(config=settings, request_lock=self._lock)

    def _first_loaded_model(self, timeout: float = 3.0) -> tuple[str, str] | None:
        """Return (model key, loaded instance id) for LM Studio's first loaded LLM."""
        request = urllib.request.Request(f"{self.server_url}/api/v1/models", method="GET")
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
        for model in payload.get("models", []):
            if not isinstance(model, dict):
                continue
            instances = model.get("loaded_instances") or []
            if not instances or not isinstance(instances[0], dict):
                continue
            key = str(model.get("key") or "").strip()
            instance_id = str(instances[0].get("id") or key).strip()
            if key and instance_id:
                return key, instance_id
        return None

    def ensure_ready(self, status: Callable[[str], None] | None = None) -> None:
        status = status or (lambda _message: None)

        # First, attempt to bind to LM Studio if available
        loaded = None
        try:
            loaded = self._first_loaded_model()
        except Exception:
            pass

        if loaded is not None and lms is not None:
            loaded_key, loaded_instance_id = loaded
            self.display_model_id = loaded_key
            self.model_id = loaded_instance_id

            try:
                native_host = lms.Client.find_default_local_api_host()
                if native_host is not None:
                    sdk_client = lms.Client(native_host)
                    loaded_sdk_models = list(sdk_client.llm.list_loaded())
                    sdk_model = next(
                        (
                            model
                            for model in loaded_sdk_models
                            if str(getattr(model, "identifier", "")).casefold() == loaded_key.casefold()
                        ),
                        None,
                    )
                    if sdk_model is None and len(loaded_sdk_models) == 1:
                        sdk_model = loaded_sdk_models[0]
                    if sdk_model is not None:
                        self._sdk_client = sdk_client
                        self._sdk_model = sdk_model
                        self.base_url = self.server_url
                        status(f"Connected to {self.display_model_id} in LM Studio · narrator XTC active")
                        return
            except Exception:
                pass

        # If LM Studio wasn't found or SDK failed, check if remote cascade is available
        self.cascade.ensure_ready(status)
        self.base_url = self.cascade.base_url
        self.model_id = self.cascade.model_id
        self.display_model_id = self.cascade.display_model_id

    def stream_chat(
        self,
        messages: list[dict[str, str]],
        *,
        on_token: Callable[[str], None],
    ) -> str:
        # Prefer native LM Studio SDK if loaded and active
        if self._sdk_model is not None and self.base_url:
            history = lms.Chat.from_history(
                {
                    "messages": [
                        {"role": str(message["role"]), "content": str(message["content"])}
                        for message in messages
                    ]
                }
            )
            config = {
                "temperature": 0.8,
                "topPSampling": 0.95,
                "xtcProbability": NARRATOR_XTC_PROBABILITY,
                "xtcThreshold": NARRATOR_XTC_THRESHOLD,
            }
            pieces: list[str] = []
            with self._lock:
                try:
                    stream = self._sdk_model.respond_stream(history, config=config)
                    for fragment in stream:
                        if fragment.reasoning_type != "none" or not fragment.content:
                            continue
                        text = str(fragment.content)
                        pieces.append(text)
                        on_token(text)
                    return "".join(pieces).strip()
                except Exception as exc:
                    logger.warning("Local SDK error: %s. Falling back to cascade...", exc)

        # Fallback to cascading provider pipeline
        if self.cascade is not None:
            return self.cascade.stream_chat(messages, on_token=on_token)

        raise LocalModelError("No model provider is ready.")

    def chat_json(
        self,
        messages: list[dict[str, str]],
        *,
        schema: dict[str, Any],
        temperature: float = 0.1,
    ) -> dict[str, Any]:
        # Try local HTTP endpoint if bound to LM Studio
        if self.base_url and self.model_id and self.base_url.rstrip('/') == self.server_url.rstrip('/'):
            payload = {
                "model": self.model_id,
                "messages": messages,
                "temperature": float(temperature),
                "stream": False,
                "chat_template_kwargs": {"enable_thinking": False},
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "aether_helper",
                        "strict": True,
                        "schema": schema,
                    },
                },
            }
            request = urllib.request.Request(
                f"{self.base_url}/v1/chat/completions",
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            try:
                with self._lock:
                    with urllib.request.urlopen(request, timeout=240) as response:
                        body = json.loads(response.read().decode("utf-8"))
                raw = str(body["choices"][0]["message"]["content"]).strip()
                if raw.startswith("```"):
                    raw = raw.strip("`").strip()
                    if raw.casefold().startswith("json"):
                        raw = raw[4:].strip()
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    return parsed
            except Exception as exc:
                logger.warning("Local chat_json failed: %s. Attempting cascade...", exc)

        # Fallback to cascading provider pipeline
        if self.cascade is not None:
            return self.cascade.chat_json(messages, schema=schema, temperature=temperature)

        raise LocalModelError("No model provider is ready.")

    def close(self) -> None:
        client = self._sdk_client
        self._sdk_client = None
        self._sdk_model = None
        if client is not None:
            try:
                client.close()
            except Exception:
                pass
        if self.cascade is not None:
            self.cascade.close()
