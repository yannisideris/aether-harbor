from __future__ import annotations

import re
from typing import Any


AFFLICTION_SPECS: dict[str, dict[str, Any]] = {
    "untreated_wound": {
        "name": "Untreated Wound",
        "family": "physical",
        "interval": 4,
        "first_tick_grace": 2,
        "ticks": None,
        "effect": "May worsen by 1 HP every four turns until treated (with initial grace period).",
    },
    "poisoned": {
        "name": "Poisoned",
        "family": "toxic",
        "interval": 3,
        "ticks": 4,
        "effect": "Loses 1 HP every three turns until cured or the poison runs its course.",
    },
    "arcane_drain": {
        "name": "Lingering Arcane Harm",
        "family": "arcane",
        "interval": 3,
        "ticks": 3,
        "effect": "Loses 1 HP every three turns until treated or the effect expires.",
    },
}

_INJURY_CUE = re.compile(
    r"\b(?:pain|wound|injur\w*|bleed\w*|blood|bruise\w*|sprain\w*|scrape\w*|"
    r"cut|cuts|burn\w*|throb\w*|ache\w*|impact|jarr\w*|fractur\w*|broken|"
    r"twist\w*|buckl\w*|stab\w*|slash\w*|bite|bitten|sting|swoll\w*|gash|hurt\w*)\b",
    re.I,
)


def _conditions(state: dict[str, Any]) -> list[dict[str, Any]]:
    player = state.setdefault("player", {})
    raw = player.setdefault("conditions", [])
    if not isinstance(raw, list):
        raw = []
        player["conditions"] = raw
    return raw


def active_afflictions(state: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        row for row in _conditions(state)
        if isinstance(row, dict) and row.get("condition_type") == "affliction"
    ]


def add_affliction(
    state: dict[str, Any],
    kind: str,
    *,
    source: str = "",
) -> dict[str, Any] | None:
    """Commit one grounded persistent condition without stacking duplicates."""

    spec = AFFLICTION_SPECS.get(str(kind or ""))
    if not isinstance(spec, dict):
        return None
    conditions = _conditions(state)
    existing = next(
        (
            row for row in conditions
            if isinstance(row, dict)
            and row.get("condition_type") == "affliction"
            and row.get("affliction_kind") == kind
        ),
        None,
    )
    turn_no = int(state.get("turn_no", 0) or 0)
    if isinstance(existing, dict):
        # Re-exposure may refresh a finite poison/spell course, but never stacks
        # another simultaneous drain with the same identity.
        if spec.get("ticks") is not None:
            existing["ticks_remaining"] = max(
                int(existing.get("ticks_remaining", 0) or 0),
                int(spec["ticks"]),
            )
        existing["source"] = str(source or existing.get("source") or "")[:160]
        # The condition is still singular.  Returning None prevents a later
        # hit from being announced as a newly added wound or replacing the
        # anatomical detail established by its first narration.
        return None

    grace = int(spec.get("first_tick_grace", 0) or 0)
    record: dict[str, Any] = {
        "name": str(spec["name"]),
        "condition_type": "affliction",
        "affliction_kind": kind,
        "family": str(spec["family"]),
        "effect": str(spec["effect"]),
        "source": str(source or "")[:160],
        "added_at_turn": turn_no,
        "next_tick_turn": turn_no + int(spec["interval"]) + grace,
        "tick_interval": int(spec["interval"]),
    }
    if spec.get("ticks") is not None:
        record["ticks_remaining"] = int(spec["ticks"])
    conditions.append(record)
    return record


def cure_afflictions(
    state: dict[str, Any],
    *,
    families: set[str] | None = None,
) -> list[str]:
    """Remove active afflictions only; Fate's temporary boons/penalties remain."""

    removed: list[str] = []
    kept: list[dict[str, Any]] = []
    for row in _conditions(state):
        if not isinstance(row, dict) or row.get("condition_type") != "affliction":
            kept.append(row)
            continue
        family = str(row.get("family") or "")
        if families is not None and family not in families:
            kept.append(row)
            continue
        removed.append(str(row.get("name") or "Affliction"))
    state["player"]["conditions"] = kept
    return removed


def advance_afflictions(
    state: dict[str, Any],
    resolved_event: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Advance at most one due affliction after a foreground turn resolves."""

    turn_no = int(state.get("turn_no", 0) or 0)
    in_combat = (
        isinstance(state.get("combat"), dict)
        and state["combat"].get("status") == "active"
    )

    # In active combat, physical wounds (bleeding) are held in check by adrenaline
    # and combat focus. Defer physical afflictions so they don't tick mid-skirmish,
    # and ensure a full post-combat grace interval when combat concludes.
    if in_combat:
        for row in active_afflictions(state):
            if str(row.get("family") or "") == "physical":
                interval = max(1, int(row.get("tick_interval", 4) or 4))
                if int(row.get("next_tick_turn", 0) or 0) <= turn_no:
                    row["next_tick_turn"] = turn_no + interval

    due = sorted(
        (
            row for row in active_afflictions(state)
            if turn_no >= int(row.get("next_tick_turn", turn_no + 1) or turn_no + 1)
            and not (in_combat and str(row.get("family") or "") == "physical")
        ),
        key=lambda row: (
            int(row.get("next_tick_turn", turn_no) or turn_no),
            int(row.get("added_at_turn", turn_no) or turn_no),
        ),
    )
    if not due:
        return resolved_event

    condition = due[0]
    player = state.setdefault("player", {})
    before = max(0, int(player.get("hp", 0) or 0))
    # Ambient deterioration cannot silently kill at 1 HP without defeat resolution.
    after = max(1, before - 1) if before > 0 else 0
    player["hp"] = after
    interval = max(1, int(condition.get("tick_interval", 3) or 3))
    condition["next_tick_turn"] = turn_no + interval

    expired = False
    if "ticks_remaining" in condition:
        remaining = max(0, int(condition.get("ticks_remaining", 0) or 0) - 1)
        condition["ticks_remaining"] = remaining
        if remaining <= 0:
            state["player"]["conditions"] = [
                row for row in _conditions(state) if row is not condition
            ]
            expired = True

    tick = {
        "kind": str(condition.get("affliction_kind") or "affliction"),
        "name": str(condition.get("name") or "Affliction"),
        "hp_before": before,
        "hp_after": after,
        "hp_lost": before - after,
        "expired": expired,
    }
    event = resolved_event if isinstance(resolved_event, dict) else {
        "type": "affliction_progression",
        "committed": True,
    }
    event["affliction_tick"] = tick
    return event


def affliction_added_from_event(event: dict[str, Any] | None) -> dict[str, Any] | None:
    """Find the single affliction a mechanic may have attached to this beat."""

    if not isinstance(event, dict):
        return None
    direct = event.get("affliction_added")
    if isinstance(direct, dict):
        return direct
    roll = event.get("roll")
    if isinstance(roll, dict) and isinstance(roll.get("affliction_added"), dict):
        return roll["affliction_added"]
    for exchange in event.get("exchanges", []):
        if isinstance(exchange, dict) and isinstance(exchange.get("affliction_added"), dict):
            return exchange["affliction_added"]
    return None


def note_affliction_narration(
    state: dict[str, Any],
    event: dict[str, Any] | None,
    narration: str,
) -> bool:
    """Let prose name anatomy only after mechanics already committed a wound."""

    added = affliction_added_from_event(event)
    if not isinstance(added, dict) or added.get("affliction_kind") != "untreated_wound":
        return False
    candidates: list[tuple[int, int, str]] = []
    for sentence in re.split(r"(?<=[.!?])\s+|[;\n]+", str(narration or "")):
        cues = list(_INJURY_CUE.finditer(sentence))
        if not cues:
            continue
        detail = " ".join(sentence.split())[:240]
        # The narrator authored the injury as a whole sentence. Prefer a
        # concrete sentence over a generic pain clause, but do not parse or
        # manufacture an anatomical label in Python.
        specificity = len(_meaningful_injury_words(detail))
        candidates.append((specificity, len(detail), detail))
    if not candidates:
        return False
    _specificity, _length, injury_detail = max(candidates)
    if not injury_detail:
        return False
    target = next(
        (
            row for row in active_afflictions(state)
            if row.get("affliction_kind") == "untreated_wound"
        ),
        None,
    )
    if not isinstance(target, dict):
        return False
    target["injury_detail"] = injury_detail
    added["injury_detail"] = injury_detail
    return True


def _meaningful_injury_words(text: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[a-z]+", str(text or "").casefold())
        if len(token) >= 5
    }
