from __future__ import annotations

import copy
import hashlib
import json
import re
from typing import Any, TYPE_CHECKING

from .canon import AETHER_HARBOR_LOCAL_LOCATION_IDS, AETHER_HARBOR_REGIONAL_LOCATION_IDS
if TYPE_CHECKING:
    from .local_model import LocalQwen
from .movement import active_site_root_id
from .sealed_layout import validate_complete_plan, topology_hash, reveal_delta
from .spatial_scope import site_scope, BOUNDED_NAME
from .site_links import MAX_CHILD_SITES_PER_SUB_AREA, remember_child_site


MAX_OPEN_REGION_AREAS = 12


SPATIAL_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "plan_complete": {"type": "boolean"},
        "site_scope": {"type": "string", "enum": ["bounded", "open"]},
        "change": {
            "type": "string",
            "enum": ["none", "new_position", "new_site"],
        },
        "site_name": {"type": "string"},
        "site_summary": {"type": "string"},
        "site_scale": {
            "type": "string",
            "enum": ["compact", "modest", "large"],
        },
        "material_baseline": {
            "type": "string",
            "enum": ["scarce", "ordinary", "rich"],
        },
        "position_name": {"type": "string"},
        "position_summary": {"type": "string"},
        "entry_relation": {"type": "string"},
        "areas": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "placement": {"type": "string"},
                    "physical_character": {"type": "string"},
                    "status": {
                        "type": "string",
                        "enum": ["observed", "latent"],
                    },
                },
                "required": ["name", "placement", "physical_character", "status"],
                "additionalProperties": False,
            },
            "maxItems": 24,
        },
        "connections": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "from": {"type": "string"},
                    "to": {"type": "string"},
                    "via": {"type": "string"},
                    "status": {
                        "type": "string",
                        "enum": ["observed", "latent"],
                    },
                },
                "required": ["from", "to", "via", "status"],
                "additionalProperties": False,
            },
            "maxItems": 40,
        },
        "uncertainties": {
            "type": "array",
            "items": {"type": "string"},
            "maxItems": 2,
        },
        "exterior_facts": {
            "type": "array",
            "items": {"type": "string"},
            "maxItems": 6,
        },
    },
    "required": [
        "plan_complete", "change", "site_name", "site_summary", "site_scale", "material_baseline",
        "position_name", "position_summary", "entry_relation", "areas",
        "connections", "uncertainties", "exterior_facts",
    ],
    "additionalProperties": False,
}


SYSTEM = """
You are a private spatial architect, not a narrator. Return JSON only.
site_scope describes ownership, not whether the player is indoors. Respect the
request's known site_scope; classify an unknown target as bounded or open in
site_scope. A bounded site includes its own yards and gardens. An open district,
coast or countryside stays extensible; include only established/discovered local
areas and connections, never a complete whitelist or neighbouring interiors.
For open scope set plan_complete false. An incidental building or notice-board
noun does not establish entry or determine the target of the plan.
For a NEW bounded site, plan its ENTIRE meaningful playable structure now,
including all floors, functional rooms, circulation, stairs, exits, gardens,
yards, terraces and outbuildings appropriate to its established scale. Keep
ordinary small sites small. site_scale does not impose a minimum room count;
preserve the naturally chosen functional spaces without adding filler areas.
Use at most 24 areas and 40 connections, with short
concrete descriptions. Group genuinely equivalent minor storage spaces when
needed; never leave an unplanned floor, generic 'Main Interior', or unresolved
endpoint. Every planned endpoint must be a named area; the graph is connected.
State relative placement and floor in each area. Put physical access surfaces,
doorways, directions, stairs and their established constraints (closed, locked,
barred, height, etc.) in connections.via. A physical connection does NOT grant
access. Do not invent a usable entrance or contradict an established wall.
Preserve all separately established branches. Ascending stairs go above,
descending stairs below. Mark plan_complete true only after checking coverage,
endpoints, directions and access consistency. This whole graph is committed
BEFORE the server allocates hidden interest, danger and material opportunities.

planning_mode is authoritative. In exterior mode the player stays outside;
change is none. Only actually seen/entered areas are observed. All unseen
interiors, rear spaces and upper floors are latent, never player knowledge.
In interior mode use new_position only for an actually committed transition,
new_site only for entering a distinct site, otherwise none. A successful roll
allows only the attempted action. position_name must exactly match an area.

If authoritative_geometry has plan_lock, it is sealed. Return ONLY exact
existing area/connection records whose status becomes observed; no added rooms,
renames, rewritten placements, new doors, or rerolled opportunities. Empty
arrays are valid. Repeat the existing position if the player did not move.
If existing geometry is legacy and unsealed, preserve its facts and return an
additive delta; do not retroactively claim it was fully planned or redraw it.
Put contradictions in uncertainties. Genuine new construction/extensions need
an explicit later world change, never spontaneous expansion while exploring.

Preserve the site's established identity, local architecture and exterior
constraints. Structural descriptions only: no inhabitants, atmosphere, treasure,
clues, threats, traps, secrets or plot. The server's existing seeded allocation
policy owns those slots. Classify material_baseline scarce/ordinary/rich from
actual use and condition, not name keywords; repeat an existing baseline.
""".strip()

EXTERIOR_CONTRACT = """
EXTERIOR MODE OUTPUT CONTRACT:
Plan the whole bounded site now, not just its facade or a latent structural
core. Include the player's exterior position and the site's own grounds and
access routes; exclude neighbouring buildings and the surrounding district.
Record stable external constraints in exterior_facts. Show physical connections
to the complete latent interior with the actual access constraints in via;
latent connectivity does not mean a door is open, unlocked or even discovered.
Player position and observed knowledge do not change during this planning.
""".strip()


ISLAND_MACRO_CONTRACT = """
ISLAND MACRO MODE OUTPUT CONTRACT:
- This overrides the bounded-building contract. Set plan_complete false; macro geography remains extensible.
- You are surveying an entire island or world-scale geography upon landfall.
- Read the Island Spine carefully. Divide the island into 3 to 6 broad Macro Regions.
- If no authored spine exists, preserve established island identity and freely plan its remaining geography; do not substitute a catalogue island.
- Generate areas only for these large geographic or thematic zones. Do not model micro-rooms.
- Keep every fact and the identity of the spine and of any island_authored_places; name regions after those places where they fit, never replace them with generic ones.
- Plan inhabited and wild land in proportion to the island: where people live, gather, trade or worship, its countryside, and one deeper, hidden or dangerous place. These may be denser, sparser, stranger or absent as the spine and its planetary current suggest; a town or port with quarters is one possible pattern, not a template.
- Connect these macro regions plausibly in connections to form the island's map.
- The position_name should be the macro-region the player just arrived at (usually a coast, dock, or shore).
""".strip()


AREA_INTEREST_BRIEFS: dict[str, str] = {
    "point_of_interest": (
        "On first reveal, show one concrete, inspectable point of interest that offers a choice or line of inquiry. "
        "It need not be useful or important beyond this place."
    ),
    "active_situation": (
        "REQUIRED on first reveal: introduce one directly visible person, animal, or physical process currently "
        "doing or changing something, with an explicit immediate effect. The player may engage, ignore, or exploit "
        "it. Do not substitute atmosphere, an ajar door, offstage sound, mystery, hidden agent, omen, fixed outcome, "
        "or event centered on the player."
    ),
    "material_opportunity": (
        "On this area's first reveal, establish one specific plausible material opportunity or concrete searchable "
        "locus. Its nature, ownership, visibility, and accessibility must fit the place; do not grant it automatically."
    ),
    "local_danger": (
        "On first reveal, show one local physical hazard through concrete signs that let the player notice and "
        "avoid it. Narrate those signs naturally; do not label it a hazard, inflict immediate harm, or add a "
        "creature, plot, hidden passage, or new connection."
    ),
    "misleading_salience": (
        "On first reveal, show one conspicuous but mundane physical irregularity and reveal its ordinary local "
        "cause in the same response. It is not supernatural, prophetic, personalized, valuable, evidence of an "
        "unseen agent, or a future plot hook."
    ),
}

_INTEREST_WEIGHTS: tuple[tuple[str, int], ...] = (
    ("local_danger", 38),
    ("active_situation", 31),
    ("point_of_interest", 24),
    ("misleading_salience", 7),
)
_INTEREST_SITE_GATE = 205  # 80.1% of sites are eligible; about one in five remains entirely unseeded.
_INTEREST_AREA_GATE = 141  # 55.1% of eligible latent areas, before the site cap.
_INTEREST_SITE_CAP = 2


_MATERIAL_SEARCH_CUE = re.compile(
    r"\b(?:search(?:es|ed|ing)?|rummag(?:e|es|ed|ing)|ransack(?:s|ed|ing)?|loot(?:s|ed|ing)?|"
    r"rifl(?:e|es|ed|ing)\s+through|go(?:es|ing|ne)?\s+through)\b|"
    r"\b(?:look|hunt)(?:s|ed|ing)?\s+for\s+(?:anything|something|valuables?|money|coins?|loot|"
    r"supplies|tools?|weapons?|items?|objects?|resources?|anything\s+useful)\b|"
    r"\b(?:check|open|inspect|examine)(?:s|ed|ing)?\s+(?:the\s+|a\s+|an\s+)?"
    r"(?:drawers?|cupboards?|cabinets?|chests?|boxes?|crates?|desks?|wardrobes?|containers?|"
    r"lockers?|shelves|sacks?|pouches?|trunks?|strongboxes?)\b",
    re.I,
)


_ACTION_CUE = re.compile(
    r"\b(?:enter|board(?=\s+(?:the\s+|a\s+)?(?:ship|vessel|boat|ferry)\b)|leave|exit|go\s+in|get\s+in|move(?:s|d|ing)?\s+(?:in|inside|into|through|out|within)|climb|descend|ascend|cross|"
    r"walk(?:s|ed|ing)?\s+(?:in|inside|into|through|within)|step\s+through|squeeze\s+through|open|unlock|pick\s*(?:the\s+)?lock|"
    r"rush\s+out|get\s+lost|explore|continue|follow|turn\s+into|go\s+deeper|"
    r"walk\s+until|door|gate|hatch|skylight|ladder|stairs?|shaft)\b",
    re.I,
)
_RESULT_CUE = re.compile(
    r"\b(?:inside|outside|aboard|through|enters?|boards?|exits?|emerges?|lands?|arrives?|"
    r"leads?\s+(?:to|into)|opens?\s+(?:onto|into)|reveals?|roof|room|house|"
    r"building|door|gate|hatch|skylight|ladder|stairs?|shaft|corridor|passage|"
    r"gallery|courtyard|entrance|junction|deck|gangplank|hull)\b",
    re.I,
)
_BOUNDED_CORE = re.compile(
    r"\b(?:inside|interior|room|chamber|hall|house|building|storeroom|warehouse|"
    r"shop|tavern|palace|temple|ship|vessel|deck|cabin|hold|cave|crypt|tower|museum|shaft|corridor|"
    r"gallery|loft|attic|cellar|workshop|office|library|sanctuary|balcony|window|"
    r"stairs?|staircase|stairwell|landing|terrace)\b",
    re.I,
)
_OBSERVE_CUE = re.compile(
    r"\b(?:look|inspect|examine|study|survey|observe|what|which|where|can\s+(?:i|we)\s+see)\b",
    re.I,
)
_BRANCH_CUE = re.compile(
    r"\b(?:branch(?:es|ing)?|forks?|junction|crossroads?|two\s+ways?|three\s+ways?|"
    r"door(?:way)?s?|arches|passages|corridors|stairs?|gates?|hatches|entrances|paths?)\b",
    re.I,
)
_EXPLICIT_BRANCH = re.compile(
    r"\b(?:branch(?:es|ing)?|forks?|junction|crossroads?|"
    r"(?:two|three|four|several)\s+(?:doors?|arches|passages|corridors|stairs?|gates?|paths?))\b",
    re.I,
)
_BOUNDED_SITE_NAME = BOUNDED_NAME
_EXTERIOR_ACTION = re.compile(
    r"\b(?:approach|head\s+to|go\s+to|walk\s+to|move\s+(?:to|toward|towards|closer\s+to)|"
    r"draw\s+near|make\s+(?:my|our)\s+way\s+to|"
    r"walk\s+around|go\s+around|circle|inspect|examine|survey|study|"
    r"look\s+for|find)\b|\b(?:way\s+in|entry|entrance|rear|back\s+entry|perimeter)\b",
    re.I,
)
_EXTERIOR_RESULT = re.compile(
    r"\b(?:outside|exterior|fa[cç]ades?|frontages?|walls?|flanks?|rear|back|perimeter|"
    r"roofs?|eaves?|gutters?|windows?|shutters?|doors?|gates?|yards?|dockyards?|alleys?|"
    r"terraces?|courtyards?|gardens?|balcon(?:y|ies)|grounds|patios?|verandas?|parapets?|"
    r"hull|gangplank|moorings?|anchors?|stern|bow|port\s+side|starboard|"
    r"cliff\s+faces?|cave\s+mouths?|cavern\s+mouths?|entrances?)\b",
    re.I,
)
_CLEAR_INTERIOR_ARRIVAL = re.compile(
    r"\b(?:steps?|moves?|passes?|crosses?|climbs?|squeezes?|enters?|emerges?)\s+"
    r"(?:inside|into|through)\b|\b(?:now|stands?|lands?|arrives?)\s+inside\b|"
    r"\b(?:boards?(?=\s+(?:the\s+|a\s+)?(?:ship|vessel|boat|ferry)\b)|climbs?\s+aboard|steps?\s+aboard|go(?:es)?\s+aboard|aboard|interior|foyer|vestibule)\b",
    re.I,
)


def _movement_part(event: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(event, dict):
        return None
    if str(event.get("type") or "") in {"movement", "local_movement"}:
        return event
    movement = event.get("movement")
    return movement if isinstance(movement, dict) else None


def _matching_location_id(state: dict[str, Any], name: str) -> str:
    wanted = _normalized(name)
    if not wanted:
        return ""
    for location_id, location in state.get("locations", {}).items():
        if not isinstance(location, dict):
            continue
        names = [location.get("name"), *(location.get("aliases") or [])]
        if wanted in {_normalized(value) for value in names if str(value or "").strip()}:
            return str(location_id)
    return ""


def _selected_exterior_position(state: dict[str, Any]) -> dict[str, Any] | None:
    """Return a player-selected bounded micro-location while play remains outside."""

    position = state.get("scene_position")
    if not isinstance(position, dict) or position.get("site_area"):
        return None
    if str(position.get("spatial_relation") or "") == "interior" and not position.get("exterior_of_site_id"):
        return None
    anchor_id = active_site_root_id(state)
    if str(position.get("anchor_location_id") or "") != anchor_id:
        return None
    existing_target = str(position.get("exterior_of_site_id") or "")
    if existing_target and existing_target in state.get("locations", {}):
        return position
    label = str(position.get("label") or "").strip()
    if not label or not _BOUNDED_SITE_NAME.search(label):
        return None
    return position


def reserve_selected_exterior_site(state: dict[str, Any], narration: str = "") -> str:
    """Create the selected site's private root without moving the player inside.

    This synchronous reservation gives a slow background plan a stable identity.
    The visible scene remains the exterior micro-location above its broad atlas
    anchor; only a later committed entry changes current_location_id.
    """

    position = _selected_exterior_position(state)
    if not isinstance(position, dict):
        return ""
    origin_id = active_site_root_id(state)
    site_name = str(position.get("label") or "").strip()
    target_id = str(position.get("exterior_of_site_id") or "")
    if target_id not in state.get("locations", {}):
        target_id = _matching_location_id(state, site_name) or _location_id(site_name)
    origin = state.get("locations", {}).get(origin_id, {})
    target = state.setdefault("locations", {}).setdefault(
        target_id,
        {
            "name": site_name,
            "region": str(origin.get("region") or "Emergent site"),
            "summary": str(position.get("summary") or "A selected bounded site, seen from outside."),
            "aliases": [site_name],
            "provisional": False,
            "defining_excerpt": str(position.get("defining_excerpt") or narration)[:1800] or None,
            "visit_count": 0,
            "parent_hint": origin_id,
            "aether_geography_scope": _geography_scope(state, origin_id),
        },
    )
    target.setdefault("site_root_id", target_id)
    target.setdefault("parent_hint", origin_id)
    position["exterior_of_site_id"] = target_id
    position["selected_site"] = True
    state["scene_position"] = position
    _remember_edge(state, origin_id, target_id)
    return target_id


def _event_commits_movement(event: dict[str, Any] | None) -> bool:
    if not isinstance(event, dict):
        return False
    event_type = str(event.get("type") or "")
    if event_type in {"movement", "local_movement"}:
        return bool(event.get("committed"))
    if event_type in {"compound_resolution", "voyage_resolution"}:
        movement = event.get("movement")
        return isinstance(movement, dict) and bool(movement.get("committed"))
    if event_type == "resource_movement_resolution":
        movement = event.get("movement")
        return isinstance(movement, dict) and bool(movement.get("committed"))
    if event_type == "hidden_access_opened":
        return isinstance(event.get("movement"), dict)
    return False


def _event_succeeded(event: dict[str, Any] | None) -> bool:
    if not isinstance(event, dict):
        return False
    # A successful generic D20 can cross a threshold even when its semantic
    # destination was omitted. Other successful systems (recovery, commerce,
    # treatment, combat) are not spatial transitions merely because the text
    # also mentions a door, room, or similar noun.
    if str(event.get("type") or "") != "d20_resolution":
        return False
    if event.get("success") is True:
        return True
    return str(event.get("outcome") or "") in {
        "marginal_success", "success", "strong_success", "critical_success"
    }


def _interior_survey_due(
    *,
    state: dict[str, Any] | None,
    player_text: str,
    narration: str,
    resolved_event: dict[str, Any] | None,
) -> bool:
    """Run only on a credible crossing or newly exposed spatial connection."""

    if isinstance(state, dict):
        location_id = active_site_root_id(state)
        location = state.get("locations", {}).get(location_id, {})
        if isinstance(location.get("site_memory"), dict) and location["site_memory"].get("plan_lock"):
            # Movement commits observation; a sealed site needs no architect
            # call just because another preplanned room became visible.
            return False
        position = (
            state.get("scene_position")
            if isinstance(state.get("scene_position"), dict)
            else None
        )
        # A broad atlas arrival must not become the site root merely because
        # its narration points out a building. Wait until play commits a local
        # threshold/position (or actually arrives at a named bounded site).
        broad_unentered_anchor = bool(
            isinstance(location, dict)
            and not isinstance(location.get("site_memory"), dict)
            and not _BOUNDED_SITE_NAME.search(str(location.get("name") or ""))
            and position is None
        )
        if broad_unentered_anchor and not _CLEAR_INTERIOR_ARRIVAL.search(player_text):
            return False
        if site_scope(location) == "open":
            # Only the selected structural position (or a committed interior entry)
            # can establish a child site; nouns in surrounding narration cannot turn
            # a district indoors.
            pos_bounded = bool(
                position
                and (
                    site_scope({"name": position.get("label")}) == "bounded"
                    or str(position.get("spatial_relation") or "") == "interior"
                )
            )
            entered_bounded = bool(
                (_event_commits_movement(resolved_event) or _event_succeeded(resolved_event))
                and (_CLEAR_INTERIOR_ARRIVAL.search(player_text) or _CLEAR_INTERIOR_ARRIVAL.search(narration))
                and _BOUNDED_SITE_NAME.search(f"{player_text} {narration}")
            )
            if not (pos_bounded or entered_bounded):
                return False

    committed_site_delta = False
    if isinstance(state, dict):
        movement = _movement_part(resolved_event)
        if isinstance(movement, dict) and movement.get("committed"):
            root_id = str(movement.get("site_root_id") or active_site_root_id(state))
            root = state.get("locations", {}).get(root_id, {})
            committed_site_delta = bool(
                str(movement.get("type") or "") == "local_movement"
                and isinstance(root, dict)
                and isinstance(root.get("site_memory"), dict)
                and str(movement.get("from_name") or "").strip()
                and str(movement.get("to_name") or "").strip()
            )

    crossed = bool(
        (_event_commits_movement(resolved_event) or _event_succeeded(resolved_event))
        and _ACTION_CUE.search(player_text)
    )
    observed_branch = bool(
        _OBSERVE_CUE.search(player_text)
        and (_EXPLICIT_BRANCH.search(narration) or len(_BRANCH_CUE.findall(narration)) >= 2)
    )
    if committed_site_delta:
        # The mechanical local transition is stronger evidence than a verb
        # regex.  This covers natural phrases such as "move inside" and
        # endpoints such as balconies without calling the architect every turn.
        return bool(narration.strip())
    return bool(
        (crossed or observed_branch)
        and _RESULT_CUE.search(narration)
        and _BOUNDED_CORE.search(narration)
    )


def _exterior_survey_due(
    *,
    state: dict[str, Any],
    player_text: str,
    narration: str,
    resolved_event: dict[str, Any] | None,
) -> bool:
    """Adopt only a player-targeted bounded site, never incidental buildings."""

    location_id = active_site_root_id(state)
    location = state.get("locations", {}).get(location_id, {})
    selected_position = _selected_exterior_position(state)
    selected_site = isinstance(selected_position, dict)
    if selected_site:
        site_name = str(selected_position.get("label") or "")
        target_id = str(selected_position.get("exterior_of_site_id") or "")
        if not target_id:
            target_id = _matching_location_id(state, site_name)
        target = state.get("locations", {}).get(target_id, {}) if target_id else {}
        if isinstance(target, dict) and isinstance(target.get("site_memory"), dict):
            return False
        aliases = list(target.get("aliases") or []) if isinstance(target, dict) else []
    elif not isinstance(location, dict) or isinstance(location.get("site_memory"), dict):
        return False
    else:
        site_name = str(location.get("name") or "")
        aliases = list(location.get("aliases") or [])
    if not _BOUNDED_SITE_NAME.search(site_name):
        return False
    engaged = bool(
        # A committed arrival at this bounded target already proves engagement.
        # Do not require a second matching English movement verb.
        _event_commits_movement(resolved_event)
        or (_EXTERIOR_ACTION.search(player_text) and (
            selected_site
            or _normalized(site_name) in _normalized(player_text)
            or any(
                _normalized(alias) in _normalized(player_text)
                for alias in aliases
                if len(_normalized(alias)) >= 5
            )
        ))
    )
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    already_inside = bool(
        isinstance(position, dict)
        and str(position.get("spatial_relation") or "") == "interior"
        and not position.get("exterior_of_site_id")
    )
    return bool(
        engaged
        and not already_inside
        and _EXTERIOR_RESULT.search(narration)
        and not _CLEAR_INTERIOR_ARRIVAL.search(narration)
    )


def _committed_boarding(state, player_text, resolved_event):
    if not _event_commits_movement(resolved_event):
        return False
    if (resolved_event or {}).get("boarding_site") is True:
        return True
    position = state.get("scene_position") if isinstance(state, dict) else None
    return bool(isinstance(position, dict)
        and re.search(r"\b(?:board|embark|go\s+aboard|step\s+aboard)\b", player_text, re.I)
        and re.search(r"\b(?:deck|ship|vessel|boat|ferry)\b", str(position.get("label") or ""), re.I))


def survey_mode(
    *,
    state: dict[str, Any] | None,
    player_text: str,
    narration: str,
    resolved_event: dict[str, Any] | None,
) -> str | None:
    if isinstance(state, dict) and _committed_boarding(state, player_text, resolved_event):
        return "interior"
    voyage_event = (resolved_event or {}).get('voyage') or resolved_event or {}
    if isinstance(state, dict) and voyage_event.get('action') == 'boarded':
        ship = state.get('locations', {}).get(state.get('current_location_id'), {})
        if ship.get('kind') == 'vessel' and not isinstance(ship.get('site_memory'), dict):
            return 'interior'
    if isinstance(state, dict) and _island_survey_due(
        state=state,
    ):
        return "island_macro"
    if isinstance(state, dict) and _exterior_survey_due(
        state=state,
        player_text=player_text,
        narration=narration,
        resolved_event=resolved_event,
    ):
        return "exterior"
    if _interior_survey_due(
        state=state,
        player_text=player_text,
        narration=narration,
        resolved_event=resolved_event,
    ):
        return "interior"
    if isinstance(state, dict):
        root_id = active_site_root_id(state)
        root = state.get("locations", {}).get(root_id, {})
        open_areas = (root.get("site_memory") or {}).get("areas") if isinstance(root.get("site_memory"), dict) else []
        if site_scope(root) == "open" and len(open_areas or []) < MAX_OPEN_REGION_AREAS and (
            (isinstance(root.get("site_memory"), dict)
             and (_movement_part(resolved_event) or {}).get("type") == "local_movement"
             and _event_commits_movement(resolved_event))
            or re.search(r"\b(?:explore|survey)\b", player_text, re.I)
            or (_geography_scope(state, root_id) == "regional" and not isinstance(root.get("site_memory"), dict) and _event_commits_movement(resolved_event))
        ):
            return "open_region"
    return None

def _island_survey_due(state: dict[str, Any]) -> bool:
    """Trigger the macro planner if the player arrives at an island."""
    location_id = str(state.get("current_location_id") or "")
    if not location_id:
        return False
    location = state.get("locations", {}).get(location_id, {})
    if not isinstance(location, dict):
        return False
    # If the site memory is already generated, we don't need to survey
    if isinstance(location.get("site_memory"), dict):
        return False
    
    # Geography must also be planned for an established improvised island.
    from .island_context import is_island
    return is_island(state, location_id)


def survey_due(
    *,
    player_text: str,
    narration: str,
    resolved_event: dict[str, Any] | None,
    state: dict[str, Any] | None = None,
) -> bool:
    """Compatibility predicate; callers that run the planner use survey_mode."""

    return survey_mode(
        state=state,
        player_text=player_text,
        narration=narration,
        resolved_event=resolved_event,
    ) is not None


def _transition_allowed(event: dict[str, Any] | None) -> bool:
    return _event_commits_movement(event) or _event_succeeded(event)


def _geography_scope(state: dict[str, Any], location_id: str) -> str:
    if location_id in AETHER_HARBOR_LOCAL_LOCATION_IDS:
        return "local"
    if location_id in AETHER_HARBOR_REGIONAL_LOCATION_IDS:
        return "regional"
    location = state.get("locations", {}).get(location_id, {})
    stored = str(location.get("aether_geography_scope") or "")
    return stored if stored in {"local", "visible", "regional", "distant"} else "distant"


def _arrival_context_chain(state: dict[str, Any], location_id: str) -> list[dict[str, str]]:
    """Retrieve at most two same-world arrival anchors, not a world template."""

    scope = _geography_scope(state, location_id)
    seen = {location_id}
    cursor = location_id
    result: list[dict[str, str]] = []
    for _ in range(2):
        location = state.get("locations", {}).get(cursor, {})
        parent_id = str(location.get("parent_hint") or location.get("last_arrival_from") or "")
        parent = state.get("locations", {}).get(parent_id)
        if not parent_id or parent_id in seen or not isinstance(parent, dict):
            break
        seen.add(parent_id)
        # Do not pull Aether Harbor into a distant island merely because the
        # island was first reached directly from the port.
        if (_geography_scope(state, parent_id) == "distant") != (scope == "distant"):
            break
        result.append(
            {
                "name": str(parent.get("name") or parent_id)[:100],
                "region": str(parent.get("region") or "")[:100],
                "summary": " ".join(str(parent.get("summary") or "").split())[:260],
                "defining_excerpt": " ".join(str(parent.get("defining_excerpt") or "").split())[:450],
            }
        )
        cursor = parent_id
    return result


def _approach_exchange(
    recent_turns: list[dict[str, Any]],
    *,
    player_text: str,
    narration: str,
) -> list[dict[str, str]]:
    """Keep four prior exchanges; current action/result have dedicated fields."""

    rows = [row for row in recent_turns if isinstance(row, dict)]

    def same_text(left: Any, right: Any) -> bool:
        return " ".join(str(left or "").split()) == " ".join(str(right or "").split())

    if rows and same_text(rows[-1].get("text"), narration):
        rows.pop()
    if rows and same_text(rows[-1].get("text"), player_text):
        rows.pop()
    return [
        {
            "speaker": str(row.get("speaker") or ""),
            "text": str(row.get("text") or "")[:650],
        }
        for row in rows[-8:]
    ]


def build_spatial_request(
    *, state: dict[str, Any], recent_turns: list[dict[str, Any]],
    player_text: str, narration: str, resolved_event: dict[str, Any] | None,
    planning_mode: str = "interior",
) -> list[dict[str, str]]:
    """Build the same private architect request for local and foreground callers."""
    if planning_mode not in {"exterior", "interior", "island_macro", "open_region"}:
        planning_mode = "interior"
    origin_location_id = active_site_root_id(state)
    location_id = origin_location_id
    location = state.get("locations", {}).get(location_id, {})
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    planning_target_from_scene = False
    if planning_mode == "exterior":
        selected_position = _selected_exterior_position(state)
        if isinstance(selected_position, dict):
            selected_name = str(selected_position.get("label") or "").strip()
            selected_id = str(selected_position.get("exterior_of_site_id") or "")
            if selected_id not in state.get("locations", {}):
                selected_id = _matching_location_id(state, selected_name) or _location_id(selected_name)
            selected_location = state.get("locations", {}).get(selected_id)
            if not isinstance(selected_location, dict):
                origin = location if isinstance(location, dict) else {}
                selected_location = {
                    "name": selected_name,
                    "region": str(origin.get("region") or "Emergent site"),
                    "summary": str(selected_position.get("summary") or ""),
                    "aliases": [selected_name],
                    "parent_hint": origin_location_id,
                    "aether_geography_scope": _geography_scope(state, origin_location_id),
                }
            location_id = selected_id
            location = selected_location
            planning_target_from_scene = True
    if not isinstance(location, dict):
        raise ValueError("Spatial anchor must be a location record.")
    target_scope = site_scope(location)
    if planning_mode in {"island_macro", "open_region"}:
        target_scope = "open"
    elif planning_mode == "interior" and _committed_boarding(state, player_text, resolved_event):
        target_scope = "bounded"
    elif (planning_mode == "interior" and isinstance(position, dict)
          and not position.get("site_area")
          and str(position.get("anchor_location_id") or "") == location_id
          and (
              site_scope({"name": position.get("label")}) == "bounded"
              or str(position.get("spatial_relation") or "") == "interior"
          )
          and target_scope != "bounded"):
        target_scope = "bounded"  # A selected child structure, not its open parent.
    elif (planning_mode == "interior"
          and target_scope != "bounded"
          and (_event_commits_movement(resolved_event) or _event_succeeded(resolved_event))
          and (_CLEAR_INTERIOR_ARRIVAL.search(player_text) or _CLEAR_INTERIOR_ARRIVAL.search(narration))
          and _BOUNDED_SITE_NAME.search(f"{player_text} {narration}")):
        target_scope = "bounded"
    if target_scope == "open" and planning_mode != "island_macro":
        planning_mode = "open_region"
    geography_id = origin_location_id if planning_target_from_scene else location_id
    local_aether_context = _geography_scope(state, geography_id) == "local"
    architectural_context = (
        "Within Aether Harbor: a vague early-17th-century fused maritime culture; "
        "practical mercantile and craft architecture, predominantly stone with tiled roofs. "
        "Render it as local design without naming real-world source cultures."
        if local_aether_context
        else "Use only the local identity already established by this place, its arrival-context anchors, and the transcript. If terrain, settlement scale, livelihood, or culture is still undefined, leave it open rather than selecting a template. Do not import Aether Harbor's architecture."
    )
    island_spine = ""
    island_places: list[str] = []
    if planning_mode == "island_macro":
        island_bank = state.get("island_bank", {})
        bindings = island_bank.get("bindings", {})
        if location_id in bindings:
            from aether_harbor.island_bank import ISLANDS_BY_ID
            binding = bindings[location_id]
            horizon_id = binding.get("entry_id") if isinstance(binding, dict) else binding
            if horizon_id in ISLANDS_BY_ID:
                island_spine = ISLANDS_BY_ID[horizon_id].get("spine", "")
                island_places = [
                    str(layer.get("capsule") or "")[:400]
                    for layer in ISLANDS_BY_ID[horizon_id].get("layers", [])
                    if isinstance(layer, dict) and layer.get("kind") in {"settlement", "district"}
                ][:6]

    context = {
        "planning_mode": planning_mode,
        "site_scope": target_scope,
        "island_spine": island_spine,
        **({"island_authored_places": island_places} if island_places else {}),
        "current_atlas_anchor": {
            "id": location_id,
            "name": location.get("name"),
            "summary": location.get("summary"),
            "aliases": list(location.get("aliases") or [])[:8],
        },
        "arrival_context": _arrival_context_chain(
            state,
            origin_location_id if planning_target_from_scene else location_id,
        ),
        "current_local_position": position,
        "architectural_context": architectural_context,
        "authoritative_geometry": _geometry_for_planner(location.get("site_memory")),
        "geometry_update_mode": (
            "reveal_only" if location.get("site_memory", {}).get("plan_lock") else
            "additive_delta_only" if isinstance(location.get("site_memory"), dict)
            else "establish_site"
        ),
        "existing_material_baseline": (
            str(location.get("site_memory", {}).get("material_baseline") or "")
            if isinstance(location.get("site_memory"), dict)
            else ""
        ),
        "recent_approach_exchange": _approach_exchange(
            recent_turns,
            player_text=player_text,
            narration=narration,
        ),
        "player_action": player_text,
        "resolved_event": resolved_event,
        "new_narration": narration[:1800],
    }

    system_msg = SYSTEM
    if planning_mode == "exterior":
        system_msg = f"{SYSTEM}\n\n{EXTERIOR_CONTRACT}"
    elif planning_mode == "open_region":
        system_msg = f"{SYSTEM}\n\nOPEN REGION: Return an additive map of established local geography (approaches, roads, paths, terrain vantages, and open sub-areas). Ground the entry position in arrival_context (for example a coastal path from the docks versus an inland thoroughfare from the city) and connect observed or clearly implied open sub-areas with descriptive via links. Keep at most {MAX_OPEN_REGION_AREAS} stable, broad sub-areas in total; reuse established names and leave minor landmarks as scene detail. Use one concise access description; do not invent exact distances or compass bearings. Do not turn individual enclosed buildings or villas into rooms of the open region, and do not seal the district: set plan_complete false and preserve known routes and positions."
    elif planning_mode == "island_macro":
        system_msg = f"{SYSTEM}\n\n{ISLAND_MACRO_CONTRACT}"
        
    request_messages = [
        {
            "role": "system",
            "content": system_msg,
        },
        {"role": "user", "content": json.dumps(context, ensure_ascii=False)},
    ]
    return request_messages


SPATIAL_REFINEMENT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["site_name", "connections_to_add", "passage_lock_updates"],
    "properties": {
        "site_name": {"type": "string"},
        "connections_to_add": {
            "type": "array",
            "maxItems": 16,
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["from", "to", "via", "status"],
                "properties": {
                    "from": {"type": "string"},
                    "to": {"type": "string"},
                    "via": {"type": "string"},
                    "status": {"type": "string", "enum": ["observed", "latent"]},
                },
            },
        },
        "passage_lock_updates": {
            "type": "array",
            "maxItems": 4,
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["from", "to", "via"],
                "properties": {
                    "from": {"type": "string"},
                    "to": {"type": "string"},
                    "via": {"type": "string"},
                },
            },
        },
    },
}

REFINEMENT_SYSTEM = """You are the Spatial Inspector & Locksmith for Aether Harbor. Return JSON only.
You receive a freshly drafted organic bounded site plan (areas and connections) plus structural diagnostics.
Your three targeted jobs:
1. GRAPH REPAIR (`connections_to_add`):
   - Every connection endpoint MUST be an exact area name from `valid_area_names`. Never invent new area names or placeholders.
   - For any `invalid_connections_to_replace`, provide a connection in `connections_to_add` linking that room to the most logical existing area name on the appropriate floor.
   - For every room in `disconnected_areas_to_connect`, add a logical connection in `connections_to_add` linking it to the appropriate existing circulation area (e.g. landing, gallery, hallway, corridor) so the entire site forms one connected graph.
   - If `disconnected_areas_to_connect` and `invalid_connections_to_replace` are both empty, return `[]` for `connections_to_add`.
2. TARGETED LOCK AUDIT (`passage_lock_updates`, 1 to 4 items max):
   - Select the 1 to 4 latent passages where a door, hatch, or gate should realistically be LOCKED, PADLOCKED, or BARRED (e.g. cellar, vault, private study/master suite, or rear exterior service door). Leave ordinary closed doors out of `passage_lock_updates`.
   - NEVER lock or alter an already observed connection (`status="observed"`).
   - Keep `via` concise (e.g. `"heavy oak door, locked"`, `"iron-bound cellar door, padlocked"`, `"heavy service door, barred from inside"`).
3. SITE NAME (`site_name`):
   - If the draft `site_name` is a generic doorway/connector label (like `"Oak Door"` or `"Inside the building"`) or just repeats the player's spot inside it (`current_position`, like `"Behind a stack of crates"`), replace it with a proper, concrete name for the building itself (e.g. `"Merchant's Residence"`). Otherwise keep `site_name` unchanged."""

SPATIAL_HARMONIZER_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["connections_to_add"],
    "properties": {
        "connections_to_add": {
            "type": "array",
            "maxItems": 16,
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["from", "to", "via", "status"],
                "properties": {
                    "from": {"type": "string"},
                    "to": {"type": "string"},
                    "via": {"type": "string"},
                    "status": {"type": "string", "enum": ["observed", "latent"]},
                },
            },
        },
        "position_name": {"type": "string"},
    },
}

HARMONIZER_SYSTEM = """You are the Spatial Harmonizer for Aether Harbor. Return JSON only.
You receive a bounded site plan that was refined by the Spatial Inspector but still has structural topology errors (such as disconnected rooms or graph gaps).
Your sole task is a MINIMAL targeted topology completion pass:
1. PREFER ADDING CONNECTIONS (NEVER CUT ROOMS):
   - Every single area in `valid_area_names` must remain part of the site. Do NOT drop, cut, or remove any area.
   - For every area listed in `disconnected_areas_to_connect`, provide a connection in `connections_to_add` linking it to an appropriate area in `valid_area_names` so the entire site forms one single connected graph.
   - Mechanical connectivity is paramount: ensure all areas are physically linked. Do not reject or cut connections for subjective semantic reasons (e.g. an unusual room pairing is completely acceptable as long as it forms a valid physical path).
2. ENDPOINT INTEGRITY:
   - Every endpoint (`from`, `to`) MUST be an exact string from `valid_area_names`. Never invent new area names or placeholders.
3. PRESERVE ESTABLISHED LOCKS:
   - Do not alter or overwrite existing locked passages from `existing_connections`.
   - Keep new `via` descriptions brief and physical (e.g. "wooden door", "stone archway", "corridor", "rocky passage", "connecting hallway").
4. POSITION INTEGRITY:
   - If `position_error` is flagged, set `position_name` to the exact name of the entrance area from `valid_area_names`."""



def _deduplicate_raw_connections(connections: list[dict[str, Any]]) -> list[dict[str, Any]]:
    deduped: list[dict[str, Any]] = []
    seen_pairs: dict[tuple[str, str], int] = {}
    for row in connections:
        if not isinstance(row, dict):
            continue
        left = " ".join(str(row.get("from") or "").split())[:80]
        right = " ".join(str(row.get("to") or "").split())[:80]
        left_key = _normalized(left)
        right_key = _normalized(right)
        if not left_key or not right_key or left_key == right_key:
            continue
        pair = (min(left_key, right_key), max(left_key, right_key))
        status = "observed" if row.get("status") == "observed" else "latent"
        entry = {
            "from": left,
            "to": right,
            "via": " ".join(str(row.get("via") or "doorway").split())[:180],
            "status": status,
        }
        if pair in seen_pairs:
            idx = seen_pairs[pair]
            if status == "observed" and deduped[idx].get("status") != "observed":
                deduped[idx] = entry
            continue
        seen_pairs[pair] = len(deduped)
        deduped.append(entry)
    return deduped


def _analyze_bounded_draft(
    payload: dict[str, Any],
) -> tuple[dict[str, str], list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    area_map = {
        _normalized(row.get("name")): str(row.get("name")).strip()
        for row in payload.get("areas", [])
        if isinstance(row, dict) and _normalized(row.get("name"))
    }
    valid_conns: list[dict[str, Any]] = []
    invalid_conns: list[dict[str, Any]] = []
    seen_pairs: set[tuple[str, str]] = set()
    adj: dict[str, set[str]] = {k: set() for k in area_map}
    for row in payload.get("connections", []):
        if not isinstance(row, dict):
            continue
        lk = _normalized(row.get("from"))
        rk = _normalized(row.get("to"))
        if not lk or not rk or lk == rk:
            continue
        if lk not in area_map or rk not in area_map:
            invalid_conns.append(row)
            continue
        pair = (min(lk, rk), max(lk, rk))
        if pair in seen_pairs:
            for prev in valid_conns:
                if (min(_normalized(prev["from"]), _normalized(prev["to"])), max(_normalized(prev["from"]), _normalized(prev["to"]))) == pair:
                    if row.get("status") == "observed":
                        prev["status"] = "observed"
                    break
            continue
        seen_pairs.add(pair)
        valid_conns.append(
            {
                "from": area_map[lk],
                "to": area_map[rk],
                "via": " ".join(str(row.get("via") or "doorway").split())[:180],
                "status": "observed" if row.get("status") == "observed" else "latent",
            }
        )
        adj[lk].add(rk)
        adj[rk].add(lk)

    start = _normalized(payload.get("position_name"))
    if start not in area_map and area_map:
        start = next(iter(area_map))
    reached: set[str] = set()
    todo = [start] if start else []
    while todo:
        curr = todo.pop()
        if curr in reached:
            continue
        reached.add(curr)
        todo.extend(adj.get(curr, set()) - reached)

    disconnected = [area_map[k] for k in area_map if k not in reached]
    return area_map, valid_conns, invalid_conns, disconnected


def _separate_site_identity_from_position(payload: dict[str, Any], narration: str) -> None:
    """Keep a whole new site distinct from the player's spot inside it.

    A cover or vantage label ("Behind a stack of crates") can leak into
    ``site_name`` when it is also the entry area of a multi-area plan; the
    site then inherits the hiding place as its identity. The plan's own
    structure is the evidence: same name as the position, with other areas
    around it. Prefer the building noun already established by the narration;
    if none exists the name is kept and the conflict is only traced.
    """

    areas = [row for row in payload.get("areas") or [] if isinstance(row, dict)]
    site_key = _normalized(payload.get("site_name"))
    if not site_key or len(areas) < 2:
        return
    if site_key != _normalized(payload.get("position_name")):
        return
    if site_key not in {_normalized(row.get("name")) for row in areas}:
        return
    match = _BOUNDED_SITE_NAME.search(str(narration or ""))
    original = str(payload.get("site_name") or "")
    if match:
        payload["site_name"] = " ".join(match.group(0).split()).title()
        payload["site_identity_repaired"] = {"from": original, "to": payload["site_name"]}
    else:
        payload["site_identity_conflict"] = original


def _refine_bounded_site_plan(
    *,
    model: LocalQwen,
    payload: dict[str, Any],
    errors: list[str],
    planning_mode: str,
    player_text: str,
    narration: str,
) -> dict[str, Any]:
    """Run a fast, focused second pass (~3.5s) to repair topology and add realistic locks."""
    area_map, valid_conns, invalid_conns, disconnected = _analyze_bounded_draft(payload)
    if not area_map:
        return payload

    inspector_input = {
        "planning_mode": planning_mode,
        "site_name": payload.get("site_name"),
        "site_summary": payload.get("site_summary"),
        "current_position": payload.get("position_name"),
        "valid_area_names": list(area_map.values()),
        "areas": [
            {
                "name": str(row.get("name") or "").strip(),
                "placement": str(row.get("placement") or "").strip(),
                "physical_character": str(row.get("physical_character") or "").strip(),
                "status": str(row.get("status") or "latent"),
            }
            for row in payload.get("areas", [])
            if isinstance(row, dict) and _normalized(row.get("name"))
        ],
        "valid_connections": valid_conns,
        "invalid_connections_to_replace": invalid_conns,
        "disconnected_areas_to_connect": disconnected,
        "validation_errors_to_fix": errors,
        "plan_complete": payload.get("plan_complete"),
        "exterior_facts": payload.get("exterior_facts", []),
        "player_action": player_text[:1200],
        "new_narration": narration[:3500],
    }
    try:
        refined = model.chat_json(
            [
                {"role": "system", "content": REFINEMENT_SYSTEM},
                {"role": "user", "content": json.dumps(inspector_input, ensure_ascii=False)},
            ],
            schema=SPATIAL_REFINEMENT_SCHEMA,
            temperature=0.2,
        )
        if not isinstance(refined, dict):
            return payload
        updated = dict(payload)
        if str(refined.get("site_name") or "").strip():
            updated["site_name"] = str(refined["site_name"]).strip()
        if str(refined.get("position_name") or "").strip():
            updated["position_name"] = str(refined["position_name"]).strip()

        if isinstance(refined.get("connections"), list) and refined["connections"]:
            updated["connections"] = refined["connections"]
            return updated

        merged_conns = [dict(c) for c in valid_conns]
        seen_pairs = {
            (min(_normalized(c["from"]), _normalized(c["to"])), max(_normalized(c["from"]), _normalized(c["to"])))
            for c in merged_conns
        }
        for add in refined.get("connections_to_add", []) or []:
            if not isinstance(add, dict):
                continue
            lk = _normalized(add.get("from"))
            rk = _normalized(add.get("to"))
            if lk in area_map and rk in area_map and lk != rk:
                pair = (min(lk, rk), max(lk, rk))
                if pair not in seen_pairs:
                    seen_pairs.add(pair)
                    merged_conns.append(
                        {
                            "from": area_map[lk],
                            "to": area_map[rk],
                            "via": " ".join(str(add.get("via") or "doorway").split())[:180],
                            "status": "observed" if add.get("status") == "observed" else "latent",
                        }
                    )

        for upd in refined.get("passage_lock_updates", []) or []:
            if not isinstance(upd, dict):
                continue
            lk = _normalized(upd.get("from"))
            rk = _normalized(upd.get("to"))
            new_via = " ".join(str(upd.get("via") or "").split())[:180]
            if not lk or not rk or not new_via:
                continue
            pair = (min(lk, rk), max(lk, rk))
            for conn in merged_conns:
                c_pair = (
                    min(_normalized(conn["from"]), _normalized(conn["to"])),
                    max(_normalized(conn["from"]), _normalized(conn["to"])),
                )
                if c_pair == pair and conn.get("status") != "observed":
                    conn["via"] = new_via

        updated["connections"] = merged_conns
        return updated
    except Exception:
        pass
    return payload


def _harmonize_bounded_site_plan(
    *,
    model: LocalQwen,
    final_plan: dict[str, Any],
    errors: list[str],
    planning_mode: str,
    player_text: str,
    narration: str,
    plan_errors_fn: Any,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Run a minimal 3rd pass to mechanically connect remaining disconnected areas and resolve topology errors."""
    area_map, valid_conns, invalid_conns, disconnected = _analyze_bounded_draft(final_plan)
    if not area_map:
        return final_plan, {"triggered": False, "resolved": False, "added": []}

    harmonizer_input = {
        "planning_mode": planning_mode,
        "site_name": final_plan.get("site_name"),
        "site_summary": final_plan.get("site_summary"),
        "current_position": final_plan.get("position_name"),
        "valid_area_names": list(area_map.values()),
        "existing_connections": [
            {
                "from": str(c.get("from") or ""),
                "to": str(c.get("to") or ""),
                "via": str(c.get("via") or ""),
                "status": str(c.get("status") or "latent"),
            }
            for c in valid_conns
        ],
        "disconnected_areas_to_connect": disconnected,
        "validation_errors_to_resolve": errors,
        "position_error": any("position" in str(e).lower() for e in errors),
        "player_action": player_text[:1200],
        "new_narration": narration[:3500],
    }

    audit = {
        "triggered": True,
        "initial_errors": list(errors),
        "disconnected_target": list(disconnected),
        "resolved": False,
        "added": [],
        "error": None,
    }

    try:
        response = model.chat_json(
            [
                {"role": "system", "content": HARMONIZER_SYSTEM},
                {"role": "user", "content": json.dumps(harmonizer_input, ensure_ascii=False)},
            ],
            schema=SPATIAL_HARMONIZER_SCHEMA,
            temperature=0.15,
        )
        if not isinstance(response, dict):
            audit["error"] = "Response was not a JSON dictionary"
            return final_plan, audit

        new_plan = copy.deepcopy(final_plan)
        if str(response.get("position_name") or "").strip():
            candidate_pos = str(response["position_name"]).strip()
            if _normalized(candidate_pos) in area_map:
                new_plan["position_name"] = area_map[_normalized(candidate_pos)]

        merged_conns = [dict(c) for c in valid_conns]
        seen_pairs = {
            (min(_normalized(c["from"]), _normalized(c["to"])), max(_normalized(c["from"]), _normalized(c["to"])))
            for c in merged_conns
            if _normalized(c.get("from")) and _normalized(c.get("to"))
        }

        added_connections = []
        for add in response.get("connections_to_add", []) or []:
            if not isinstance(add, dict):
                continue
            lk = _normalized(add.get("from"))
            rk = _normalized(add.get("to"))
            if lk in area_map and rk in area_map and lk != rk:
                pair = (min(lk, rk), max(lk, rk))
                if pair not in seen_pairs:
                    seen_pairs.add(pair)
                    conn_entry = {
                        "from": area_map[lk],
                        "to": area_map[rk],
                        "via": " ".join(str(add.get("via") or "connecting passage").split())[:180],
                        "status": "observed" if add.get("status") == "observed" else "latent",
                    }
                    merged_conns.append(conn_entry)
                    added_connections.append(conn_entry)

        new_plan["connections"] = merged_conns
        audit["added"] = added_connections

        new_errors = plan_errors_fn(new_plan)
        if not new_errors:
            audit["resolved"] = True
            return new_plan, audit
        else:
            audit["remaining_errors"] = new_errors
            return (new_plan if len(new_errors) < len(errors) else final_plan), audit
    except Exception as exc:
        audit["error"] = str(exc)
        return final_plan, audit


def run(
    *,
    model: LocalQwen,
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
    narration: str,
    resolved_event: dict[str, Any] | None,
    planning_mode: str = "interior",
) -> dict[str, Any]:
    if planning_mode not in {"exterior", "interior", "island_macro", "open_region"}:
        planning_mode = "interior"
    request_messages = build_spatial_request(
        state=state, recent_turns=recent_turns, player_text=player_text,
        narration=narration, resolved_event=resolved_event, planning_mode=planning_mode,
    )
    context = json.loads(request_messages[1]["content"])
    planning_mode = context["planning_mode"]
    target_scope = context["site_scope"]
    location_id = str(context["current_atlas_anchor"]["id"])
    origin_location_id = active_site_root_id(state)
    planning_target_from_scene = planning_mode == "exterior" and isinstance(_selected_exterior_position(state), dict)
    location = state.get("locations", {}).get(location_id, {})
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    existing_memory = location.get("site_memory")
    def candidate_scope(candidate):
        if target_scope != "unknown":
            if (
                planning_mode == "interior"
                and isinstance(candidate, dict)
                and candidate.get("change") == "new_site"
                and site_scope({"name": candidate.get("site_name")}) == "bounded"
            ):
                return "bounded"
            return target_scope
        return candidate.get("site_scope", "bounded")

    def plan_errors(candidate):
        required = candidate_scope(candidate) == "bounded" and not isinstance(existing_memory, dict)
        return validate_complete_plan(candidate) if required else []

    payload = model.chat_json(
        request_messages,
        schema=SPATIAL_SCHEMA,
        temperature=0.25,
    )
    if isinstance(payload, dict) and isinstance(payload.get("connections"), list):
        payload["connections"] = _deduplicate_raw_connections(payload["connections"])
    if isinstance(payload, dict) and isinstance(payload.get("areas"), list):
        raw_site_key = _normalized(payload.get("site_name") or location.get("name"))
        raw_pos_key = _normalized(payload.get("position_name"))
        raw_area_keys = {
            _normalized(r.get("name")): str(r.get("name")).strip()
            for r in payload["areas"]
            if isinstance(r, dict) and _normalized(r.get("name"))
        }
        if raw_pos_key and raw_pos_key not in raw_area_keys and raw_pos_key == raw_site_key:
            observed_candidates = [
                str(r.get("name")).strip()
                for r in payload["areas"]
                if isinstance(r, dict)
                and r.get("status") == "observed"
                and _normalized(r.get("name")) != raw_site_key
            ]
            if len(observed_candidates) == 1:
                payload["position_name"] = observed_candidates[0]

    is_live_llm = bool(getattr(model, "base_url", None))
    if candidate_scope(payload) == "bounded" and not isinstance(existing_memory, dict):
        if is_live_llm:
            # Always run the dedicated back-to-back Spatial Inspector & Locksmith pass
            # on live bounded plans to repair topology and enrich latent door locks
            # while preserving the organic first creation.
            payload = _refine_bounded_site_plan(
                model=model,
                payload=payload,
                errors=plan_errors(payload),
                planning_mode=planning_mode,
                player_text=player_text,
                narration=narration,
            )
            # An unsuccessful semantic repair stays invalid. Do not invent
            # arbitrary doorways or move the player to make a graph pass.
        elif plan_errors(payload):
            # Unit-test / mock compatibility path: retry once with SPATIAL_SCHEMA.
            payload = model.chat_json(
                [
                    *request_messages,
                    {"role": "assistant", "content": json.dumps(payload, ensure_ascii=False)},
                    {
                        "role": "user",
                        "content": (
                            "Correct this complete-site plan without changing established facts: " + "; ".join(plan_errors(payload))
                        ),
                    },
                ],
                schema=SPATIAL_SCHEMA,
                temperature=0.15,
            )
            if isinstance(payload, dict) and isinstance(payload.get("connections"), list):
                payload["connections"] = _deduplicate_raw_connections(payload["connections"])
    if (
        isinstance(payload, dict)
        and candidate_scope(payload) == "bounded"
        and not isinstance(existing_memory, dict)
    ):
        _separate_site_identity_from_position(payload, narration)
    target_scope = candidate_scope(payload)
    complete_required = target_scope == "bounded" and not isinstance(existing_memory, dict)
    exterior_core_valid = (
        not plan_errors(payload)
    )

    if isinstance(existing_memory, dict) and existing_memory.get("plan_lock"):
        valid = reveal_delta(copy.deepcopy(existing_memory), payload)
        return {**payload, "plan_complete": False,
            "plan_errors": [] if valid else ["Sealed topology permits only exact observation promotions."],
            "planning_mode": planning_mode, "planning_target_location_id": location_id,
            "planning_target_from_scene": planning_target_from_scene,
            "transition_allowed": False, "observed_excerpt": narration[:1400]}

    def clean(value: Any, limit: int) -> str:
        compact = " ".join(str(value or "").split())
        if len(compact) <= limit:
            return compact
        clipped = compact[:limit].rsplit(" ", 1)[0].rstrip(" ,;:-")
        return clipped if len(clipped) >= limit // 2 else compact[:limit]

    change = str(payload.get("change") or "none")
    if change not in {"none", "new_position", "new_site"}:
        change = "none"

    areas: list[dict[str, str]] = []
    seen_areas: set[str] = set()
    for row in payload.get("areas", [])[:24]:
        if not isinstance(row, dict):
            continue
        name = clean(row.get("name"), 80)
        key = _normalized(name)
        if not key or key in seen_areas:
            continue
        seen_areas.add(key)
        status = "observed" if row.get("status") == "observed" else "latent"
        placement = clean(row.get("placement"), 180)
        if _normalized(placement) in {"observed", "latent"}:
            placement = (
                "At the player's established exterior position."
                if planning_mode == "exterior" and status == "observed"
                else "Within the site's anticipated interior."
                if planning_mode == "exterior"
                else "At the player's current position."
                if status == "observed"
                else "Within the site."
            )
        areas.append(
            {
                "name": name,
                "placement": placement,
                "physical_character": clean(row.get("physical_character"), 220),
                "status": status,
            }
        )

    position_name = clean(payload.get("position_name"), 80)
    position_summary = clean(payload.get("position_summary"), 300)
    if position_name and _normalized(position_name) not in seen_areas:
        observed_area = next(
            (row["name"] for row in areas if row.get("status") == "observed"),
            None,
        )
        if (observed_area and _normalized(position_name) in {
                _normalized(payload.get("site_name")),
                _normalized(location.get("name")),
            } and sum(row.get('status') == 'observed' for row in areas) == 1):
            position_name = observed_area
        else:
            if len(areas) >= 24:
                latent_index = next(
                    (index for index in range(len(areas) - 1, -1, -1) if areas[index]["status"] == "latent"),
                    len(areas) - 1,
                )
                del areas[latent_index]
            areas.append(
                {
                    "name": position_name,
                    "placement": "The player's current position within the site.",
                    "physical_character": position_summary,
                    "status": "observed",
                }
            )
            seen_areas = {_normalized(row["name"]) for row in areas}

    existing_geometry = location.get("site_memory") if isinstance(location.get("site_memory"), dict) else {}
    canonical_names = {
        _normalized(row.get("name")): str(row.get("name"))
        for row in existing_geometry.get("areas", [])
        if isinstance(row, dict) and _normalized(row.get("name"))
    }
    canonical_names.update({_normalized(row["name"]): row["name"] for row in areas})
    connections: list[dict[str, str]] = []
    seen_connections: set[tuple[str, str, str]] = set()
    for row in payload.get("connections", [])[:40]:
        if not isinstance(row, dict):
            continue
        left = clean(row.get("from"), 80)
        right = clean(row.get("to"), 80)
        left_key = _normalized(left)
        right_key = _normalized(right)
        via = clean(row.get("via"), 180)
        unresolved_far_side = right_key.startswith("unresolved beyond")
        if (
            left_key not in canonical_names
            or (right_key not in canonical_names and not unresolved_far_side)
            or left_key == right_key
        ):
            continue
        pair = tuple(sorted((left_key, right_key)))
        key = (pair[0], pair[1], _normalized(via))
        if key in seen_connections:
            continue
        seen_connections.add(key)
        if right_key == "unresolved beyond":
            right = f"Unresolved beyond {via}"[:80]
        connections.append(
            {
                "from": canonical_names[left_key],
                "to": canonical_names.get(right_key, right),
                "via": via,
                "status": "observed" if row.get("status") == "observed" else "latent",
            }
        )

    referenced_areas = {
        _normalized(endpoint)
        for row in connections
        for endpoint in (row["from"], row["to"])
        if not _normalized(endpoint).startswith("unresolved beyond")
    }
    if not complete_required:
        areas = [row for row in areas
                 if row["status"] == "observed" or _normalized(row["name"]) in referenced_areas]

    site_scale = str(payload.get("site_scale") or "compact")
    if site_scale not in {"compact", "modest", "large"}:
        site_scale = "compact"
    material_baseline = str(payload.get("material_baseline") or "ordinary")
    if material_baseline not in {"scarce", "ordinary", "rich"}:
        material_baseline = "ordinary"
    reserved_name = clean(location.get("name"), 80)
    if (
        planning_target_from_scene
        and reserved_name
        and _BOUNDED_SITE_NAME.search(reserved_name)
        and not re.search(r"\b(?:door|doorway|window|gate|hatch|arch|threshold)\b", reserved_name, re.I)
    ):
        site_name = reserved_name
    else:
        site_name = clean(payload.get("site_name") or reserved_name, 80)
    # The exterior label can name a boundary rather than the whole site.
    # Ownership comes from the reserved ID; retain the accepted site's name.
    final_plan = {
        **payload,
        "site_scope": target_scope,
        "site_name": site_name,
        "areas": areas,
        "connections": connections,
        "position_name": position_name,
    }
    # Areas are no longer dropped for complete plans, so the normalized plan
    # itself exposes a failed topology repair. Validating the raw payload too
    # would also reject cosmetic issues that normalization already fixed.
    final_errors = plan_errors(final_plan)

    # V36: 3rd Pass - Spatial Harmonizer (Topology Finalizer)
    audit_trace = {
        "pass1_status": "ok",
        "pass2_status": "ok" if not final_errors else "incomplete",
        "pass2_errors": list(final_errors),
        "pass3_triggered": False,
        "pass3_resolved": False,
        "pass3_connections_added": [],
    }

    if complete_required and final_errors and is_live_llm:
        final_plan, harmonizer_audit = _harmonize_bounded_site_plan(
            model=model,
            final_plan=final_plan,
            errors=final_errors,
            planning_mode=planning_mode,
            player_text=player_text,
            narration=narration,
            plan_errors_fn=plan_errors,
        )
        audit_trace["pass3_triggered"] = True
        audit_trace["pass3_resolved"] = harmonizer_audit.get("resolved", False)
        audit_trace["pass3_connections_added"] = harmonizer_audit.get("added", [])
        if harmonizer_audit.get("error"):
            audit_trace["pass3_error"] = harmonizer_audit["error"]
        final_errors = plan_errors(final_plan)
        areas = final_plan.get("areas", areas)
        connections = final_plan.get("connections", connections)
        position_name = final_plan.get("position_name", position_name)
        site_name = final_plan.get("site_name", site_name)
        if (
            _normalized(position_name) != _normalized(site_name)
            and any(
                _normalized(r.get("name")) == _normalized(site_name)
                and r.get("placement") == "The player's current position within the site."
                for r in areas
                if isinstance(r, dict)
            )
        ):
            areas = [
                r for r in areas
                if not (
                    isinstance(r, dict)
                    and _normalized(r.get("name")) == _normalized(site_name)
                    and r.get("placement") == "The player's current position within the site."
                )
            ]
            connections = [
                c for c in connections
                if isinstance(c, dict)
                and _normalized(c.get("from")) != _normalized(site_name)
                and _normalized(c.get("to")) != _normalized(site_name)
            ]
            final_plan["areas"] = areas
            final_plan["connections"] = connections
            final_errors = plan_errors(final_plan)

    return {
        "plan_complete": complete_required and not final_errors,
        "plan_errors": final_errors,
        "complete_plan_required": complete_required,
        "spatial_audit": audit_trace,
        "site_scope": target_scope,
        "change": "none" if planning_mode == "exterior" else change,
        "site_name": site_name,
        "site_summary": clean(payload.get("site_summary"), 300),
        "site_scale": site_scale,
        "material_baseline": material_baseline,
        "position_name": position_name,
        "position_summary": position_summary,
        "entry_relation": clean(payload.get("entry_relation"), 220),
        "areas": areas,
        "connections": connections,
        "uncertainties": [clean(value, 220) for value in payload.get("uncertainties", [])[:3] if clean(value, 220)],
        "exterior_facts": [
            clean(value, 220)
            for value in payload.get("exterior_facts", [])[:6]
            if clean(value, 220)
        ],
        "planning_mode": planning_mode,
        "planning_target_location_id": location_id,
        "planning_origin_location_id": origin_location_id,
        "planning_target_from_scene": planning_target_from_scene,
        "exterior_core_valid": exterior_core_valid,
        "transition_allowed": (
            False if planning_mode == "exterior" else _transition_allowed(resolved_event)
        ),
        "movement_committed": _event_commits_movement(resolved_event),
        # A vessel's proper name need not contain 'ship'. Carry the committed
        # boarding evidence into ownership resolution instead of trusting change.
        "boarding_site": bool(
            planning_mode == "interior"
            and _event_commits_movement(resolved_event)
            and (
                (resolved_event or {}).get("boarding_site") is True
                or (re.search(r"\b(?:board|embark|go\s+aboard|step\s+aboard)\b", player_text, re.I)
                    and isinstance(position, dict)
                    and re.search(r"\b(?:deck|ship|vessel|boat|ferry)\b", str(position.get("label") or ""), re.I))
            )
        ),
        "awaiting_spatial_position": bool(
            isinstance(resolved_event, dict) and resolved_event.get("awaiting_spatial_position")
        ),
        "observed_excerpt": narration[:1400],
    }


def _normalized(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").casefold()).strip()


def _interest_digest(state: dict[str, Any], location_id: str, suffix: str) -> bytes:
    material = (
        f"{state.get('campaign_id', '')}:{state.get('rng_seed', '')}:"
        f"{location_id}:area-interest-v1:{suffix}"
    ).encode("utf-8")
    return hashlib.sha256(material).digest()


def _interest_kind(byte_value: int) -> str:
    point = byte_value * 100 // 256
    running = 0
    for kind, weight in _INTEREST_WEIGHTS:
        running += weight
        if point < running:
            return kind
    return _INTEREST_WEIGHTS[-1][0]


def _material_profile(byte_value: int, baseline: str = "ordinary") -> str:
    """Combine Qwen's site-relative baseline with one stable Python fortune byte."""

    byte_value = max(0, min(255, int(byte_value)))
    if baseline == "scarce":
        if byte_value < 205:
            return "barren"
        if byte_value < 246:
            return "lean"
        if byte_value < 254:
            return "promising"
        return "notable"
    if baseline == "rich":
        if byte_value < 90:
            return "lean"
        if byte_value < 213:
            return "promising"
        return "notable"
    if byte_value < 141:
        return "barren"
    if byte_value < 213:
        return "lean"
    if byte_value < 249:
        return "promising"
    return "notable"


def _material_authorial_function(profile: str) -> str:
    base = AREA_INTEREST_BRIEFS["material_opportunity"]
    bounds = {
        "lean": "Keep it mundane or situationally useful, not a coin windfall or conspicuous treasure.",
        "promising": "Keep it a modest, bounded resource or item of value, not major treasure.",
        "notable": "It may be distinctive or rare, but is not automatically costly, powerful, or easy to take.",
    }
    return f"{base} {bounds.get(profile, bounds['promising'])}"


def _upgrade_material_lifecycle(memory: dict[str, Any], policy: dict[str, Any]) -> None:
    """Migrate the one-shot site material fate without rerolling it.

    Version 4 separates *where/what tier* the opportunity is from whether its
    special reveal has already happened.  Older saves migrate in place without
    rerolling; an explicit legacy realization marker is preserved as revealed.
    """

    if int(policy.get("version", 0) or 0) >= 4:
        return
    profile = str(policy.get("material_profile") or "barren")
    material_area = _normalized(policy.get("material_area"))
    status = "barren" if profile == "barren" else "latent"
    if status != "barren" and material_area:
        area = next(
            (
                row for row in memory.get("areas", [])
                if isinstance(row, dict) and _normalized(row.get("name")) == material_area
            ),
            None,
        )
        if isinstance(area, dict) and area.get("interest_realized_at_turn") is not None:
            # Older builds had no lifecycle field, but patched/repair states may
            # already carry this explicit marker.  Observation alone is not
            # enough to prove the material seed was actually realized.
            status = "revealed"
            policy.setdefault("material_revealed_at_turn", area.get("interest_realized_at_turn"))
    policy["version"] = 4
    policy.setdefault("material_status", status)


def _material_policy(memory: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(memory, dict):
        return None
    policy = memory.get("interest_allocation")
    if not isinstance(policy, dict) or int(policy.get("version", 0) or 0) < 3:
        return None
    _upgrade_material_lifecycle(memory, policy)
    return policy


def _material_area_record(memory: dict[str, Any], material_area: str) -> dict[str, Any] | None:
    wanted = _normalized(material_area)
    return next(
        (
            row for row in memory.get("areas", [])
            if isinstance(row, dict) and _normalized(row.get("name")) == wanted
        ),
        None,
    )


def _compact_realization_excerpt(narration: str) -> str:
    return " ".join(str(narration or "").split())[:900]


def _resolved_roll_success(resolved_event: dict[str, Any] | None) -> bool | None:
    if not isinstance(resolved_event, dict):
        return None
    if resolved_event.get("type") == "d20_resolution":
        return resolved_event.get("success") is True
    roll = resolved_event.get("roll")
    if isinstance(roll, dict) and "success" in roll:
        return roll.get("success") is True
    return None


def note_material_reveal_from_narration(
    state: dict[str, Any],
    player_text: str,
    narration: str,
    resolved_event: dict[str, Any] | None = None,
) -> bool:
    """Commit a material opportunity's single reveal after visible narration.

    No new extraction call is needed: the prompt already carried the private
    material seed.  This function merely records that the seed has now been
    spent, plus a compact excerpt so a later return preserves the same realized
    object/cache rather than inventing a replacement.
    """

    if _MATERIAL_SEARCH_CUE.search(str(player_text or "")) and _resolved_roll_success(resolved_event) is False:
        return False

    location_id = active_site_root_id(state)
    location = state.get("locations", {}).get(location_id, {})
    memory = location.get("site_memory") if isinstance(location, dict) else None
    policy = _material_policy(memory)
    if not isinstance(memory, dict) or not isinstance(policy, dict):
        generic = location.get("material_search_fate") if isinstance(location, dict) else None
        if not isinstance(generic, dict) or str(generic.get("status") or "") != "pending_reveal":
            return False
        excerpt = _compact_realization_excerpt(narration)
        if not excerpt:
            return False
        generic["status"] = "revealed"
        generic["revealed_at_turn"] = int(state.get("turn_no", 0) or 0)
        generic["realization_excerpt"] = excerpt
        scene = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
        generic["scene_position_id"] = str(scene.get("id") or "") or None
        generic["scene_position_label"] = str(scene.get("label") or "") or None
        return True
    material_status = str(policy.get("material_status") or "")
    if material_status not in {"latent", "revealed"}:
        return False
    material_area = str(policy.get("material_area") or "").strip()
    if not material_area:
        return False
    scene = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    current_area = str(scene.get("label") or memory.get("current_position") or memory.get("site_name") or "")
    if _normalized(current_area) != _normalized(material_area):
        return False
    area = _material_area_record(memory, material_area)
    explicit_search = bool(_MATERIAL_SEARCH_CUE.search(str(player_text or "")))
    excerpt = _compact_realization_excerpt(narration)

    if material_status == "revealed":
        # A first reveal may have established a *searchable locus* rather than
        # handing over an item (a locked chest, cabinet, niche, etc.).  A later
        # explicit search is allowed to resolve that same locus.  Record the
        # resolution so taking its contents can deplete the original one-shot
        # opportunity instead of looking like unrelated loot.
        if explicit_search and excerpt:
            policy["material_resolution_excerpt"] = excerpt
            policy["material_resolved_at_turn"] = int(state.get("turn_no", 0) or 0)
            return True
        return False

    # First arrival into a still-latent seeded area or an explicit material
    # search are the two routes that actually spend the private opportunity.
    seeded_first_reveal = bool(
        isinstance(area, dict)
        and str(area.get("interest_seed") or "") == "material_opportunity"
        and area.get("status") != "observed"
    )
    if not seeded_first_reveal and not explicit_search:
        return False
    policy["material_status"] = "revealed"
    policy["material_revealed_at_turn"] = int(state.get("turn_no", 0) or 0)
    if excerpt:
        policy["material_realization_excerpt"] = excerpt
    if isinstance(area, dict):
        area["interest_realized_at_turn"] = int(state.get("turn_no", 0) or 0)
    return True


def _name_matches_realization(item_name: str, excerpt: str) -> bool:
    item = _normalized(item_name)
    text = _normalized(excerpt)
    if not item or not text:
        return False
    if item in text:
        return True
    stop = {"small", "large", "heavy", "fine", "plain", "piece", "with", "from"}
    tokens = {token for token in item.split() if len(token) >= 4 and token not in stop}
    return bool(tokens and any(token in text.split() for token in tokens))


def note_material_take(state: dict[str, Any], item_name: str) -> bool:
    """Deplete the one-shot site opportunity when its realized object is taken.

    An unrelated object in the same room does not consume the opportunity: the
    taken name must match the stored realization excerpt.
    """

    location_id = active_site_root_id(state)
    location = state.get("locations", {}).get(location_id, {})
    memory = location.get("site_memory") if isinstance(location, dict) else None
    policy = _material_policy(memory)
    if not isinstance(memory, dict) or not isinstance(policy, dict):
        generic = location.get("material_search_fate") if isinstance(location, dict) else None
        if not isinstance(generic, dict) or str(generic.get("status") or "") != "revealed":
            return False
        excerpt = str(generic.get("realization_excerpt") or "")
        if excerpt and not _name_matches_realization(item_name, excerpt):
            return False
        generic["status"] = "depleted"
        generic["depleted_at_turn"] = int(state.get("turn_no", 0) or 0)
        generic["extracted_as"] = " ".join(str(item_name or "").split())[:140]
        return True
    if str(policy.get("material_status") or "") != "revealed":
        return False
    material_area = str(policy.get("material_area") or "").strip()
    scene = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    current_area = str(scene.get("label") or memory.get("current_position") or memory.get("site_name") or "")
    if not material_area or _normalized(current_area) != _normalized(material_area):
        return False
    excerpt = " ".join(
        value for value in [
            str(policy.get("material_realization_excerpt") or "").strip(),
            str(policy.get("material_resolution_excerpt") or "").strip(),
        ]
        if value
    )
    if excerpt and not _name_matches_realization(item_name, excerpt):
        return False
    # Legacy saves may lack an excerpt.  In that narrow case the first grounded
    # take from the already-revealed allocated area is the best available fact.
    policy["material_status"] = "depleted"
    policy["material_depleted_at_turn"] = int(state.get("turn_no", 0) or 0)
    policy["material_depleted_by"] = "extracted"
    policy["material_extracted_as"] = " ".join(str(item_name or "").split())[:140]
    area = _material_area_record(memory, material_area)
    if isinstance(area, dict):
        area["interest_depleted_at_turn"] = int(state.get("turn_no", 0) or 0)
    return True


def _allocate_area_interest(
    state: dict[str, Any],
    location_id: str,
    memory: dict[str, Any],
) -> None:
    """Sparsely tag planner areas while giving material existence one site authority."""

    policy = memory.get("interest_allocation")
    if not isinstance(policy, dict) or int(policy.get("version", 0) or 0) < 3:
        baseline = str(memory.get("material_baseline") or "ordinary")
        if baseline not in {"scarce", "ordinary", "rich"}:
            baseline = "ordinary"
        fortune_byte = _interest_digest(state, location_id, "site-material-v1")[0]
        profile = _material_profile(fortune_byte, baseline)
        policy = {
            "version": 4,
            "enabled": _interest_digest(state, location_id, "site")[0] < _INTEREST_SITE_GATE,
            "max_seeded_areas": _INTEREST_SITE_CAP,
            "material_baseline": baseline,
            "material_fortune": fortune_byte,
            "material_profile": profile,
            "material_area": None,
            "material_status": "barren" if profile == "barren" else "latent",
        }
        memory["interest_allocation"] = policy
    else:
        _upgrade_material_lifecycle(memory, policy)

    enabled = bool(policy.get("enabled"))
    cap = max(0, min(_INTEREST_SITE_CAP, int(policy.get("max_seeded_areas", _INTEREST_SITE_CAP) or 0)))
    areas = [area for area in memory.get("areas", []) if isinstance(area, dict)]

    # Material opportunity is decided once for the whole site. It is not one
    # more roll in the generic room lottery, so a barren site can never grow
    # treasure merely because a later room was added or searched again.
    profile = str(policy.get("material_profile") or "barren")
    material_area = str(policy.get("material_area") or "").strip()
    existing_material = next(
        (
            area for area in areas
            if str(area.get("interest_seed") or "") == "material_opportunity"
        ),
        None,
    )
    if existing_material is not None:
        material_area = str(existing_material.get("name") or material_area).strip()
        policy["material_area"] = material_area or None
        existing_material["material_tier"] = profile if profile != "barren" else "lean"
    elif profile != "barren" and not material_area and cap > 0:
        material_candidates: list[tuple[bytes, dict[str, Any]]] = []
        for area in areas:
            if (
                area.get("status") == "observed"
                or area.get("interest_decided") is True
                or str(area.get("interest_seed") or "")
            ):
                continue
            name = str(area.get("name") or "").strip()
            if name:
                priority = _interest_digest(
                    state, location_id, f"material-area-v1:{_normalized(name)}"
                )[2:10]
                material_candidates.append((priority, area))
        if material_candidates:
            material_candidates.sort(key=lambda row: row[0])
            chosen = material_candidates[0][1]
            chosen["interest_seed"] = "material_opportunity"
            chosen["material_tier"] = profile
            chosen["interest_decided"] = True
            material_area = str(chosen.get("name") or "").strip()
            policy["material_area"] = material_area or None

    seeded = sum(
        1
        for area in areas
        if isinstance(area, dict) and str(area.get("interest_seed") or "") in AREA_INTEREST_BRIEFS
    )
    candidates: list[tuple[bytes, dict[str, Any], str]] = []
    for area in areas:
        if not isinstance(area, dict) or area.get("interest_decided") is True:
            continue
        # Already narrated/visible space gets no retroactive payload. Seeds
        # belong only to planner-created, still-unexplored areas.
        area["interest_decided"] = True
        if area.get("status") == "observed" or not enabled or seeded >= cap:
            continue
        name = str(area.get("name") or "").strip()
        if not name:
            continue
        digest = _interest_digest(state, location_id, _normalized(name))
        if digest[0] >= _INTEREST_AREA_GATE:
            continue
        candidates.append((digest[2:10], area, _interest_kind(digest[1])))
    # Random priority, not Qwen's array order, decides which eligible records
    # survive the cap. Python never ranks them by room name or meaning.
    candidates.sort(key=lambda row: row[0])
    for _priority, area, kind in candidates[: max(0, cap - seeded)]:
        area["interest_seed"] = kind
        seeded += 1


def _geometry_for_planner(memory: dict[str, Any] | None) -> dict[str, Any] | None:
    """Give the architect all geometry while withholding later authorial payloads."""

    if not isinstance(memory, dict):
        return None
    return {
        "plan_lock": memory.get("plan_lock"),
        "site_name": memory.get("site_name"),
        "site_summary": memory.get("site_summary"),
        "site_scale": memory.get("site_scale"),
        "current_position": memory.get("current_position"),
        "entry_relation": memory.get("entry_relation"),
        "entry_relations": list(memory.get("entry_relations") or []),
        "exterior_facts": list(memory.get("exterior_facts") or []),
        "areas": [
            {
                "name": area.get("name"),
                "placement": area.get("placement"),
                "physical_character": area.get("physical_character"),
                "status": area.get("status"),
            }
            for area in memory.get("areas", [])
            if isinstance(area, dict)
        ],
        "connections": [
            {
                "from": row.get("from"),
                "to": row.get("to"),
                "via": row.get("via"),
                "status": row.get("status"),
            }
            for row in memory.get("connections", [])
            if isinstance(row, dict)
        ],
        "uncertainties": list(memory.get("uncertainties") or []),
    }


def private_area_interests(
    memory: dict[str, Any] | None,
    current_position: str | None,
    *,
    include_site_candidates: bool = False,
) -> list[dict[str, str]]:
    """Retrieve first-reveal biases without exposing them as geometry or player knowledge."""

    if not isinstance(memory, dict):
        return []
    focus = _normalized(current_position)
    seeded = [
        area for area in memory.get("areas", [])
        if isinstance(area, dict)
        and area.get("status") != "observed"
        and str(area.get("interest_seed") or "") in AREA_INTEREST_BRIEFS
    ]
    exact = next((area for area in seeded if _normalized(area.get("name")) == focus), None)
    selected = [exact] if exact is not None else (seeded if include_site_candidates else [])
    result: list[dict[str, str]] = []
    policy = _material_policy(memory)
    for area in selected[:_INTEREST_SITE_CAP]:
        kind = str(area.get("interest_seed") or "")
        if (
            kind == "material_opportunity"
            and isinstance(policy, dict)
            and str(policy.get("material_status") or "latent") != "latent"
        ):
            continue
        authorial_function = (
            _material_authorial_function(str(area.get("material_tier") or "promising"))
            if kind == "material_opportunity"
            else AREA_INTEREST_BRIEFS[kind]
        )
        result.append(
            {
                "area": str(area.get("name") or "")[:80],
                "authorial_function": authorial_function,
            }
        )
    return result


def private_material_search_fate(
    state: dict[str, Any],
    player_text: str,
    resolved_event: dict[str, Any] | None = None,
) -> dict[str, str] | None:
    """Retrieve one fixed material fate for an explicit loot/resource search."""

    if not _MATERIAL_SEARCH_CUE.search(player_text):
        return None
    location_id = active_site_root_id(state)
    location = state.get("locations", {}).get(location_id, {})
    memory = location.get("site_memory") if isinstance(location, dict) else None
    if not isinstance(memory, dict):
        if not isinstance(location, dict):
            return None
        policy = location.get("material_search_fate")
        if not isinstance(policy, dict):
            fortune = _interest_digest(state, location_id, "unmapped-material-v1")[0]
            profile = _material_profile(fortune, "ordinary")
            policy = {
                "version": 1,
                "fortune": fortune,
                "profile": profile,
                "status": "barren" if profile == "barren" else "latent",
            }
            location["material_search_fate"] = policy
        status = str(policy.get("status") or "barren")
        if status == "depleted":
            return {"rule": "This location's one material opportunity was already extracted. Do not respawn or replace it."}
        if status == "revealed":
            excerpt = str(policy.get("realization_excerpt") or "").strip()
            return {
                "rule": (
                    "This location's one material search has already been resolved. Do not create a second cache, "
                    "item, resource, currency source, or replacement find. Preserve the same established find"
                    + (f": {excerpt}" if excerpt else ".")
                )
            }
        if status == "missed":
            return {
                "rule": (
                    "The material search at this location has already been resolved without a discovery. Do not "
                    "reroll it into loot or an alternative reward on a repeated general search."
                )
            }
        roll_success = _resolved_roll_success(resolved_event)
        policy["attempted_at_turn"] = int(state.get("turn_no", 0) or 0)
        if roll_success is False:
            policy["status"] = "missed"
            return {
                "rule": (
                    "The PER search failed. Reveal no new special loot, resource, currency, or portable value, and "
                    "do not compensate with an alternate reward. This location's fixed material fate does not reroll."
                )
            }
        profile = str(policy.get("profile") or "barren")
        if profile == "barren":
            policy["status"] = "barren"
            return {
                "rule": (
                    "This location's fixed material result is barren: the search reveals no special loot or "
                    "resource. Ordinary environmental detail may remain, but do not convert it into portable value."
                )
            }
        policy["status"] = "pending_reveal"
        return {
            "rule": (
                "MATERIAL SEARCH RESULT: reveal exactly one coherent material find at this location and leave it "
                "where it lies; do not narrate taking or inventory change. "
                + _material_authorial_function(profile)
            )
        }
    policy = _material_policy(memory)
    if not isinstance(policy, dict):
        return None

    profile = str(policy.get("material_profile") or "barren")
    material_area = str(policy.get("material_area") or "").strip()
    material_status = str(policy.get("material_status") or ("barren" if profile == "barren" else "latent"))
    scene = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    current_area = str(scene.get("label") or memory.get("current_position") or memory.get("site_name") or "")
    ordinary_clause = (
        "Ordinary furnishings and context may remain, so do not declare the whole area empty; but do not turn "
        "them into an alternative reward, clue, useful resource, currency, or portable value."
    )
    if profile == "barren":
        return {
            "rule": (
                "This site's fixed material result is barren: this search reveals no new special loot or resource. "
                + ordinary_clause
            )
        }
    if not material_area or _normalized(current_area) != _normalized(material_area):
        return {
            "rule": (
                "This site's one material opportunity is not allocated to the current area: this search reveals "
                "no new special loot or resource here. " + ordinary_clause
            )
        }
    exhausted_areas = [
        _normalized(value) for value in policy.get("material_search_exhausted_areas", [])
        if str(value).strip()
    ]
    current_key = _normalized(current_area)
    if current_key in exhausted_areas:
        return {
            "rule": (
                "This area's general material search has already been resolved without a discovery. Do not reroll "
                "it into loot or an alternative reward; a separately established container or obstacle may still "
                "be interacted with on its own terms."
            )
        }
    roll_success = _resolved_roll_success(resolved_event)
    if roll_success is False:
        policy["material_search_exhausted_areas"] = [*exhausted_areas, current_key]
        policy["material_search_failed_at_turn"] = int(state.get("turn_no", 0) or 0)
        return {
            "rule": (
                "The PER search failed. Reveal no new special loot, resource, currency, or portable value and do "
                "not substitute an alternate reward. The site's fixed material fate remains unchanged but this "
                "general search does not reroll."
            )
        }
    if material_status == "revealed":
        excerpt = str(policy.get("material_realization_excerpt") or "").strip()
        resolution = str(policy.get("material_resolution_excerpt") or "").strip()
        established = (
            f" Preserve the already established realization: {excerpt}"
            if excerpt else
            " Preserve whatever material find or searchable locus was already established here; do not replace or multiply it."
        )
        if resolution:
            established += f" Its later established resolution is: {resolution}"
        return {
            "rule": (
                "This site's one material opportunity has already been REVEALED in this area. Do not generate a "
                "second independent special object, cache, reward, clue, currency source, or replacement find. "
                "If the established realization is itself a searchable container/locus and the player is now actually "
                "searching or opening it, you may resolve the contents of THAT SAME opportunity within its original "
                "material tier; do not add a separate opportunity. If an established portable find was left here and no "
                "later authoritative state says it was removed, it remains the same find."
                + established
            )
        }
    if material_status == "depleted":
        extracted = str(policy.get("material_extracted_as") or "").strip()
        suffix = f" It was extracted as: {extracted}." if extracted else ""
        return {
            "rule": (
                "This site's one material opportunity has already been DEPLETED/EXTRACTED. It does not respawn, "
                "move to another room, or reroll into a replacement reward on later searches. Ordinary non-reward "
                "furnishings and incidental objects may still exist." + suffix
            )
        }

    area = next(
        (
            row for row in memory.get("areas", [])
            if isinstance(row, dict) and _normalized(row.get("name")) == _normalized(material_area)
        ),
        {},
    )
    return {
        "rule": (
            "MATERIAL SEARCH RESULT: reveal no more than ONE newly discovered material object or one coherent "
            "cache. Do not add a second object, alternative reward, valuable information, or clue elsewhere in "
            "the search. The player is only searching: "
            "leave the find where it lies and do not narrate taking, pocketing, carrying, or inventory change. "
            + _material_authorial_function(str(area.get("material_tier") or profile))
        )
    }


def private_material_first_reveal_fate(
    memory: dict[str, Any] | None,
    current_position: str | None,
) -> dict[str, str] | None:
    """Keep a wrong/barren latent room from spontaneously rerolling material fate."""

    if not isinstance(memory, dict):
        return None
    policy = _material_policy(memory)
    if not isinstance(policy, dict):
        return None
    focus = _normalized(current_position)
    area = next(
        (
            row for row in memory.get("areas", [])
            if isinstance(row, dict) and _normalized(row.get("name")) == focus
        ),
        None,
    )
    if not isinstance(area, dict) or area.get("status") == "observed":
        return None
    profile = str(policy.get("material_profile") or "barren")
    material_area = _normalized(policy.get("material_area"))
    if profile != "barren" and material_area and focus == material_area:
        return None
    return {
        "rule": (
            "This first reveal is not the site's allocated material find. Do not feature new loot, currency, a "
            "useful resource, portable value, or a valuable clue here. Ordinary furnishings and place-specific "
            "objects may still give the area character; do not portray it as generically empty."
        )
    }


def _location_id(name: str) -> str:
    digest = hashlib.sha1(_normalized(name).encode("utf-8")).hexdigest()[:12]
    return f"emergent_{digest}"


def _remember_edge(state: dict[str, Any], left: str, right: str) -> None:
    if left == right:
        return
    pair = frozenset((left, right))
    if not any(
        isinstance(edge, (list, tuple)) and len(edge) == 2
        and frozenset((str(edge[0]), str(edge[1]))) == pair
        for edge in state.get("edges", [])
    ):
        state.setdefault("edges", []).append([left, right])


def _merge_areas(memory: dict[str, Any], incoming: list[dict[str, Any]], *, max_areas: int | None = None) -> None:
    """Append areas and promote observations without rewriting established facts."""

    areas = [row for row in memory.get("areas", []) if isinstance(row, dict)]
    by_name = {_normalized(row.get("name")): row for row in areas if _normalized(row.get("name"))}
    for row in incoming:
        if not isinstance(row, dict):
            continue
        name = str(row.get("name") or "").strip()
        key = _normalized(name)
        if not key:
            continue
        status = "observed" if row.get("status") == "observed" else "latent"
        existing = by_name.get(key)
        if existing is None:
            if max_areas is not None and len(areas) >= max_areas:
                continue
            existing = {
                "name": name,
                "placement": str(row.get("placement") or "").strip(),
                "physical_character": str(row.get("physical_character") or "").strip(),
                "status": status,
            }
            excerpt = str(row.get("defining_excerpt") or "").strip()
            if excerpt:
                existing["defining_excerpt"] = excerpt[:1400]
            areas.append(existing)
            by_name[key] = existing
            continue

        if status == "observed":
            existing["status"] = "observed"
        # Empty legacy fields may be completed, but an anticipated physical
        # fact is already authoritative and cannot be silently redesigned.
        for field in ("placement", "physical_character"):
            value = str(row.get(field) or "").strip()
            if value and not existing.get(field):
                existing[field] = value
        excerpt = str(row.get("defining_excerpt") or "").strip()
        if excerpt and not existing.get("defining_excerpt"):
            existing["defining_excerpt"] = excerpt[:1400]

    observed = [row for row in areas if row.get("status") == "observed"]
    latent = [row for row in areas if row.get("status") != "observed"]
    memory["areas"] = observed + latent


def _merge_connections(memory: dict[str, Any], incoming: list[dict[str, Any]]) -> None:
    """Append connections; observation may promote but never rewrite a connector."""

    connections = [row for row in memory.get("connections", []) if isinstance(row, dict)]

    def pair_key(row: dict[str, Any]) -> tuple[str, str]:
        return tuple(sorted((_normalized(row.get("from")), _normalized(row.get("to")))))

    def full_key(row: dict[str, Any]) -> tuple[str, str, str]:
        left, right = pair_key(row)
        return left, right, _normalized(row.get("via"))

    for row in incoming:
        if not isinstance(row, dict) or not all(str(row.get(key) or "").strip() for key in ("from", "to")):
            continue
        status = "observed" if row.get("status") == "observed" else "latent"
        exact = next((old for old in connections if full_key(old) == full_key(row)), None)
        same_pair = next((old for old in connections if pair_key(old) == pair_key(row)), None)
        if exact is None and status == "observed":
            exact = same_pair
        if exact is None:
            connections.append(
                {
                    "from": str(row.get("from") or "").strip(),
                    "to": str(row.get("to") or "").strip(),
                    "via": str(row.get("via") or "").strip(),
                    "status": status,
                }
            )
        elif status == "observed":
            exact["status"] = "observed"

    observed = [row for row in connections if row.get("status") == "observed"]
    latent = [row for row in connections if row.get("status") != "observed"]
    memory["connections"] = observed + latent


def apply(
    state: dict[str, Any],
    survey: dict[str, Any] | None,
    *,
    narration: str = "",
) -> bool:
    """Append a survey delta to one stable site root without redrawing it."""

    if not isinstance(survey, dict):
        return False
    if survey.get("plan_errors") or (survey.get("complete_plan_required") and validate_complete_plan(survey)):
        return False
    narration = narration or str(survey.get("observed_excerpt") or "")
    site_name = str(survey.get("site_name") or "").strip()
    if not site_name:
        return False
    change = str(survey.get("change") or "none")
    transition_allowed = bool(survey.get("transition_allowed"))
    origin_id = str(state.get("current_location_id") or "")
    location_id = active_site_root_id(state, origin_id)
    location = state.get("locations", {}).get(location_id)
    if not isinstance(location, dict):
        return False

    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    planning_mode = str(survey.get("planning_mode") or "interior")
    if (
        planning_mode == "exterior"
        and survey.get("planning_target_from_scene")
        and survey.get("exterior_core_valid") is False
    ):
        return False
    selected_exterior_target = bool(
        planning_mode == "exterior"
        and survey.get("planning_target_from_scene")
        and isinstance(position, dict)
        and not position.get("site_area")
        and str(position.get("anchor_location_id") or "") == location_id
        and (
            (
                str(position.get("exterior_of_site_id") or "") in state.get("locations", {})
                and str(survey.get("planning_target_location_id") or position["exterior_of_site_id"])
                    == str(position["exterior_of_site_id"])
            )
            or (
                not position.get("exterior_of_site_id")
                and _normalized(position.get("label")) == _normalized(site_name)
            )
        )
    )
    if selected_exterior_target:
        target_id = str(position.get("exterior_of_site_id") or "")
        if target_id not in state.get("locations", {}):
            target_id = _matching_location_id(state, site_name) or _location_id(site_name)
        parent = location
        target = state.setdefault("locations", {}).setdefault(
            target_id,
            {
                "name": site_name,
                "region": str(parent.get("region") or "Emergent site"),
                "summary": str(survey.get("site_summary") or position.get("summary") or "A selected bounded site."),
                "aliases": [site_name],
                "provisional": False,
                "defining_excerpt": str(position.get("defining_excerpt") or narration)[:1800] or None,
                "visit_count": 0,
                "parent_hint": location_id,
                "aether_geography_scope": _geography_scope(state, location_id),
            },
        )
        target.setdefault("site_root_id", target_id)
        target.setdefault("parent_hint", location_id)
        position["exterior_of_site_id"] = target_id
        position["selected_site"] = True
        state["scene_position"] = position
        _remember_edge(state, location_id, target_id)
        location_id, location = target_id, target

    sealed_memory = location.get("site_memory")
    if isinstance(sealed_memory, dict) and sealed_memory.get("plan_lock"):
        updated = copy.deepcopy(sealed_memory)
        if not reveal_delta(updated, survey):
            return False
        location["site_memory"] = updated
        updated["surveyed_at_turn"] = int(state.get("turn_no", 0) or 0)
        return True

    # A roof/landing tracked against broad public geography may reveal a new
    # bounded building. A named atlas site (for example the Palazzo) remains
    # its own root rather than acquiring a duplicate child record.
    location_names = {
        _normalized(value)
        for value in [location.get("name"), *(location.get("aliases") or [])]
        if str(value or "").strip()
    }
    distinct_bounded_position = bool(
        position
        and str(position.get("anchor_location_id") or "") == location_id
        and not position.get("site_area")
        and (_BOUNDED_SITE_NAME.search(site_name) or survey.get("boarding_site") is True)
        and _normalized(site_name) not in location_names
    )
    # The planner occasionally returns ``none`` or ``new_position`` after the
    # player has plainly crossed from a broad atlas area into a newly named
    # bounded site.  The committed transition plus the already tracked local
    # position is enough to promote that site without overwriting the parent
    # district.  Exterior surveys never reach this path because they are not
    # transition_allowed.
    needs_site_root = bool(
        transition_allowed
        and planning_mode not in {"island_macro", "open_region"}
        and survey.get("site_scope") != "open"
        and not isinstance(location.get("site_memory"), dict)
        and not location_id.startswith(("emergent_", "generated_"))
        and (
            change == "new_site"
            or distinct_bounded_position
        )
        and position
        and str(position.get("anchor_location_id") or "") == location_id
    )
    if needs_site_root:
        if survey.get("boarding_site") is True:
            from .voyage import vessel_site_id
            try:
                # boarding_site is an explicit semantic judgement: reuse an
                # existing same-name site at this mooring instead of forking
                # a second ship identity. Retyping happens below, after the
                # ambiguity/mooring checks have passed.
                destination_id = vessel_site_id(state, site_name, embarkation_id=location_id,
                                                allow_untyped=True)
            except ValueError:
                return False
        else:
            destination_id = _location_id(site_name)
        destination = state.setdefault("locations", {}).setdefault(
            destination_id,
            {
                "name": site_name,
                "region": "Emergent place",
                "summary": survey.get("site_summary") or "A newly entered bounded site.",
                "aliases": [site_name],
                "provisional": False,
                "visit_count": 0,
                "aether_geography_scope": location.get("aether_geography_scope", "local"),
                "parent_hint": location_id,
            },
        )
        destination["visit_count"] = int(destination.get("visit_count", 0) or 0) + 1
        destination["last_arrival_from"] = origin_id
        if survey.get("boarding_site") is True:
            destination["kind"] = "vessel"
            destination["vessel_location"] = {"status": "moored", "location_id": location_id}
        else:
            _remember_edge(state, origin_id, destination_id)
        state["current_location_id"] = destination_id
        # Promotion re-identifies the spot the player already occupies; it is
        # not a fresh arrival. Keep concealment, edge and alert with the player.
        stealth = state.get("stealth")
        if isinstance(stealth, dict) and str(stealth.get("location_id") or "") == origin_id:
            stealth["location_id"] = destination_id
        location_id, location = destination_id, destination
        change = "new_site"

    target_scope = site_scope(location)
    if target_scope == "unknown":
        target_scope = str(survey.get("site_scope") or "bounded")
    if planning_mode in {"island_macro", "open_region"}:
        target_scope = "open"
    location["site_scope"] = target_scope
    had_memory = isinstance(location.get("site_memory"), dict)
    old_name = str(location.get("name") or "")
    if (
        not had_memory
        and location_id.startswith(("emergent_", "generated_"))
        and _normalized(site_name) != _normalized(old_name)
    ):
        aliases = location.setdefault("aliases", [])
        for alias in (old_name, site_name):
            if alias and _normalized(alias) not in {_normalized(value) for value in aliases}:
                aliases.append(alias)
        location["name"] = site_name

    location["site_root_id"] = location_id
    site_summary = str(survey.get("site_summary") or "").strip()
    if not had_memory and 20 <= len(site_summary) <= 300:
        location["summary"] = site_summary
        location["summary_source"] = "spatial"

    memory = location.setdefault(
        "site_memory",
        {
            "site_name": site_name,
            "areas": [],
            "connections": [],
            "uncertainties": [],
            "entry_relations": [],
            "exterior_facts": [],
        },
    )
    memory["site_scope"] = target_scope
    memory.setdefault("site_name", site_name)
    memory["surveyed_at_turn"] = int(state.get("turn_no", 0) or 0)
    memory.setdefault("site_summary", site_summary or location.get("summary"))
    baseline = str(survey.get("material_baseline") or "ordinary")
    if baseline not in {"scarce", "ordinary", "rich"}:
        baseline = "ordinary"
    memory.setdefault("material_baseline", baseline)
    scale = str(survey.get("site_scale") or "compact")
    scale_rank = {"compact": 0, "modest": 1, "large": 2}
    old_scale = str(memory.get("site_scale") or "compact")
    memory["site_scale"] = scale if scale_rank.get(scale, 0) >= scale_rank.get(old_scale, 0) else old_scale
    entry = str(survey.get("entry_relation") or "").strip()
    entries = memory.setdefault("entry_relations", [])
    legacy_entry = str(memory.get("entry_relation") or "").strip()
    if legacy_entry and _normalized(legacy_entry) not in {_normalized(value) for value in entries}:
        entries.append(legacy_entry)
    if entry and _normalized(entry) not in {_normalized(value) for value in entries}:
        entries.append(entry)
    if entry and not memory.get("entry_relation"):
        memory["entry_relation"] = entry

    area_limit = MAX_OPEN_REGION_AREAS if planning_mode == "open_region" else None
    incoming_areas = list(survey.get("areas") or [])
    if area_limit is not None:
        # Reserve scarce map capacity for the actual endpoint, not latent scenery.
        focus = _normalized(survey.get("position_name"))
        if focus and not any(_normalized(row.get("name")) == focus for row in incoming_areas):
            incoming_areas.insert(0, {
                "name": str(survey["position_name"]), "status": "observed",
                "physical_character": str(survey.get("position_summary") or ""),
            })
        incoming_areas.sort(key=lambda row: (
            _normalized(row.get("name")) != focus,
            row.get("status") != "observed",
        ))
    _merge_areas(memory, incoming_areas, max_areas=area_limit)
    incoming_connections = list(survey.get("connections") or [])
    if area_limit is not None:
        retained = {_normalized(row.get("name")) for row in memory["areas"]}
        incoming_connections = [row for row in incoming_connections
                                if _normalized(row.get("from")) in retained
                                and _normalized(row.get("to")) in retained]
    _merge_connections(memory, incoming_connections)
    if site_scope(location) == "open":
        for child_id, child_loc in (state.get("locations") or {}).items():
            if isinstance(child_loc, dict) and child_loc.get("parent_hint") == location_id and child_loc.get("parent_area_name"):
                remember_child_site(memory, {
                    "site_id": child_id,
                    "site_name": str(child_loc.get("name") or child_id),
                    "at_area": str(child_loc["parent_area_name"]),
                })
    uncertainties = memory.setdefault("uncertainties", [])
    for value in survey.get("uncertainties", []):
        if value and _normalized(value) not in {_normalized(existing) for existing in uncertainties}:
            uncertainties.append(value)

    exterior_facts = memory.setdefault("exterior_facts", [])
    known_exterior = {_normalized(value) for value in exterior_facts}
    for value in survey.get("exterior_facts", []):
        fact = " ".join(str(value or "").split())[:220]
        fact_key = _normalized(fact)
        if fact and fact_key not in known_exterior and len(exterior_facts) < 12:
            exterior_facts.append(fact)
            known_exterior.add(fact_key)

    for legacy_field in ("positions", "relations", "latent_relations"):
        memory.pop(legacy_field, None)

    position_name = str(survey.get("position_name") or "").strip()
    position_summary = str(survey.get("position_summary") or "").strip()
    if position_name:
        _merge_areas(
            memory,
            [
                {
                    "name": position_name,
                    "placement": "The player's current position within the site.",
                    "physical_character": position_summary,
                    "status": "observed",
                    "defining_excerpt": narration,
                }
            ],
            max_areas=area_limit,
        )

    # The immediate card starts with a lightweight narration-derived summary.
    # Replace it as soon as the background architect returns a stable place
    # sentence, even when Qwen correctly reports no additional position change.
    if (
        transition_allowed
        and position_name
        and isinstance(position, dict)
        and str(position.get("anchor_location_id") or "") == location_id
        and _normalized(position.get("label")) == _normalized(position_name)
        and position_summary
    ):
        position["summary"] = position_summary
        position["summary_source"] = "spatial"
        position["provisional"] = False
        position["site_area"] = True
        state["scene_position"] = position

    _allocate_area_interest(state, location_id, memory)
    if survey.get("plan_complete") and target_scope == "bounded":
        memory["plan_lock"] = {
            "version": 1, "topology_sha256": topology_hash(memory),
            "entry_area": position_name,
            "seed_fingerprint": _interest_digest(state, location_id, "sealed-site-v1").hex(),
            "created_at_turn": int(state.get("turn_no", 0) or 0),
            "allocation_version": memory.get("interest_allocation", {}).get("version"),
        }

    refined_movement_endpoint = bool(
        survey.get("movement_committed")
        and (
            position is None
            or (
                isinstance(position, dict)
                and str(position.get("anchor_location_id") or "") == location_id
                and _normalized(position.get("label")) != _normalized(position_name)
            )
        )
    )
    set_position = bool(
        transition_allowed
        and position_name
        and (
            change in {"new_position", "new_site"}
            or survey.get("awaiting_spatial_position")
            or refined_movement_endpoint
        )
    )
    if set_position:
        if _normalized(position_name) != _normalized(str(memory.get("site_name") or site_name)):
            area = next(
                (
                    row for row in memory.get("areas", [])
                    if isinstance(row, dict) and _normalized(row.get("name")) == _normalized(position_name)
                ),
                {},
            )
            canonical_position = str(area.get("name") or position_name)
            digest = hashlib.sha1(
                f"{location_id}:{_normalized(canonical_position)}".encode("utf-8")
            ).hexdigest()[:10]
            state["scene_position"] = {
                "id": f"scene_{digest}",
                "label": canonical_position,
                "anchor_location_id": location_id,
                "summary": str(position_summary or area.get("physical_character") or ""),
                "defining_excerpt": str(area.get("defining_excerpt") or narration)[:1400] or None,
                "provisional": False,
                "set_at_turn": int(state.get("turn_no", 0) or 0),
                "site_area": True,
                "summary_source": "spatial",
            }
        else:
            state["scene_position"] = None

    current_position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    memory["current_position"] = (
        str(current_position.get("label") or memory.get("site_name") or site_name)
        if current_position and str(current_position.get("anchor_location_id") or "") == location_id
        else str(memory.get("site_name") or site_name)
    )
    site_names = {
        _normalized(value)
        for value in [location.get("name"), *(location.get("aliases") or []), memory.get("site_name")]
        if str(value or "").strip()
    }
    state["hidden_currents"] = [
        current
        for current in state.get("hidden_currents", [])
        if not (
            isinstance(current, dict)
            and str(current.get("kind") or "") == "site_layout"
            and any(
                _normalized(value) in site_names
                for value in [current.get("subject"), *(current.get("target_aliases") or [])]
                if str(value or "").strip()
            )
        )
    ]
    return True


def apply_for_anchor(
    state: dict[str, Any],
    survey: dict[str, Any] | None,
    *,
    anchor_location_id: str,
    anchor_scene_position: dict[str, Any] | None,
    narration: str = "",
) -> bool:
    """Apply a background survey without pulling play back to an older scene."""

    live_location_id = str(state.get("current_location_id") or "")
    live_position = copy.deepcopy(
        state.get("scene_position")
        if isinstance(state.get("scene_position"), dict)
        else None
    )

    def identity(position: dict[str, Any] | None) -> tuple[str, str]:
        if not isinstance(position, dict):
            return "", ""
        return (
            str(position.get("anchor_location_id") or ""),
            str(position.get("id") or _normalized(position.get("label"))),
        )

    context_unchanged = (
        live_location_id == str(anchor_location_id or "")
        and identity(live_position) == identity(anchor_scene_position)
    )
    state["current_location_id"] = str(anchor_location_id or live_location_id)
    state["scene_position"] = copy.deepcopy(anchor_scene_position)
    try:
        changed = apply(state, survey, narration=narration)
    except Exception:
        state["current_location_id"] = live_location_id
        state["scene_position"] = live_position
        raise
    if not context_unchanged:
        state["current_location_id"] = live_location_id
        state["scene_position"] = live_position
    return changed
