"""Off-screen clock for an engaged undertaking (background, one current at most).

The rolling recap remembers the past and deliberately rarely authors hidden
currents, so an undertaking used to wait for the player forever. This narrow
helper keeps a single practical "what happens next if the player does
nothing" step for the active or recently paused undertaking. It never touches
rolls, movement, resources or the recap's own hidden currents; the narrator
receives it through the existing private hidden-current channel, which only
shows its outward tell and never its truth before the reveal condition.
"""
from __future__ import annotations

import json
from typing import Any

from .scenarios import _last_touch_turn, _scenario_definition_for_record, ensure_scenario_state

CLOCK_CADENCE_TURNS = 3
RECENT_UNDERTAKING_TURNS = 8
URGENCY_ORDER = ("stirring", "imminent")

CLOCK_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "update": {"type": "string", "enum": ["none", "new", "advance", "resolve"]},
        "subject": {"type": "string", "maxLength": 100},
        "truth": {"type": "string", "maxLength": 360},
        "outward_tell": {"type": "string", "maxLength": 240},
        "reveal_if": {"type": "string", "maxLength": 240},
        "urgency": {"type": "string", "enum": ["stirring", "imminent"]},
    },
    "required": ["update", "subject", "truth", "outward_tell", "reveal_if", "urgency"],
    "additionalProperties": False,
}

CLOCK_SYSTEM = """
You keep the off-screen clock of one undertaking in an improvised fantasy RPG.
You are not the narrator. Return JSON only.

Decide what the off-stage people or process most directly involved in the
undertaking do NEXT if the player does not intervene, given its private truth,
the recap and the newest scene.
- new: only when no clock step exists. One practical next step that follows
  directly from established facts: someone notices, moves, hides, sells,
  leaves, returns, asks around, raises a price, sends for help. It must change
  what will happen if the player waits.
- advance: the existing step progressed because time passed, the player ignored
  it or the player's own action provoked it. Raise urgency by at most one step.
- resolve: the step has happened openly in the narration, the player prevented
  it, or it no longer matters.
- none: nothing changes yet, or the undertaking is finished or abandoned.

Prefer people or processes NOT in the player's current scene; anyone present
already reacts through the narration. Use only actors, places and objects from
the transcript, recap or private truth. Do not add conspiracies, cults, gods or monsters, and no violence unless
it is already established. Never undo a player's success. truth is the private
next step. outward_tell is one small concrete sign the player could later notice
(a sound, a rumor, a moved object, a figure seen), never the truth itself.
reveal_if is the concrete condition that makes the truth visible. Use empty
strings with update none or resolve.
""".strip()


def _undertaking(state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]] | None:
    store = ensure_scenario_state(state)
    turn = int(state.get("turn_no", 0) or 0)
    active = store.get("active")
    candidates = []
    if isinstance(active, dict) and active.get("status") == "engaged":
        candidates.append(active)
    records = store.get("records") if isinstance(store.get("records"), dict) else {}
    candidates.extend(
        row for row in records.values()
        if isinstance(row, dict) and row.get("status") == "dormant"
        and turn - _last_touch_turn(row) <= RECENT_UNDERTAKING_TURNS
    )
    for record in candidates:
        scenario = _scenario_definition_for_record(state, record)
        if isinstance(scenario, dict):
            return record, scenario
    return None


def clock_state(state: dict[str, Any]) -> dict[str, Any]:
    clock = state.setdefault("world_clock", {})
    clock.setdefault("current", None)
    clock.setdefault("last_run_turn", -999)
    clock.setdefault("history", [])
    return clock


def _time_skipped(state: dict[str, Any]) -> bool:
    turn = int(state.get("turn_no", 0) or 0)
    recovery = state.get("recovery") if isinstance(state.get("recovery"), dict) else {}
    return int(recovery.get("last_ordinary_rest_turn", -999) or -999) == turn


def due(state: dict[str, Any]) -> bool:
    if state.get("campaign_status") == "game_over":
        return False
    if isinstance(state.get("combat"), dict) and state["combat"].get("status") == "active":
        return False
    if _undertaking(state) is None:
        return False
    clock = state.get("world_clock") if isinstance(state.get("world_clock"), dict) else {}
    turn = int(state.get("turn_no", 0) or 0)
    last = int(clock.get("last_run_turn", -999) or -999)
    if last == turn:
        return False
    return turn - last >= CLOCK_CADENCE_TURNS or _time_skipped(state)


def build_messages(state: dict[str, Any], rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    found = _undertaking(state)
    record, scenario = found if found else ({}, {})
    clock = clock_state(state)
    transcript = [
        {"speaker": str(row.get("speaker") or ""), "text": str(row.get("text") or "")[-1200:]}
        for row in rows[-6:] if isinstance(row, dict) and str(row.get("text") or "").strip()
    ]
    context = {
        "undertaking": {
            "objective": scenario.get("objective"),
            "private_truth": record.get("hidden_variant") or scenario.get("hidden"),
            "progress_flags": record.get("flags"),
            "status": record.get("status"),
        },
        "recap": str((state.get("campaign_recap") or {}).get("text") or "")[:1600],
        "existing_clock_step": clock.get("current"),
        "time_passed_this_turn": _time_skipped(state),
        "newest_scene": transcript,
    }
    return [
        {"role": "system", "content": CLOCK_SYSTEM},
        {"role": "user", "content": json.dumps(context, ensure_ascii=False)},
    ]


def apply_clock_result(state: dict[str, Any], payload: Any) -> str:
    clock = clock_state(state)
    turn = int(state.get("turn_no", 0) or 0)
    clock["last_run_turn"] = turn
    if not isinstance(payload, dict):
        return "none"
    update = str(payload.get("update") or "none")
    current = clock.get("current") if isinstance(clock.get("current"), dict) else None
    fields = {
        key: " ".join(str(payload.get(key) or "").split())
        for key in ("subject", "truth", "outward_tell", "reveal_if")
    }
    urgency = str(payload.get("urgency") or "stirring")
    if urgency not in URGENCY_ORDER:
        urgency = "stirring"
    if fields["subject"] and not fields["reveal_if"]:
        # Gemma often leaves this empty; a direct look is the natural reveal.
        fields["reveal_if"] = f"The player directly observes or investigates {fields['subject']}."
    complete = all(fields.values())
    if update == "resolve" and current is not None:
        clock["history"] = (clock.get("history") or [])[-7:] + [{**current, "resolved_at_turn": turn}]
        clock["current"] = None
        return "resolve"
    if update == "new" and current is None and complete:
        clock["current"] = {"kind": "world_pressure", "source": "world_clock", **fields,
                            "target_aliases": [], "required_item": "", "urgency": "stirring",
                            "created_at_turn": turn, "updated_at_turn": turn}
        return "new"
    if update == "advance" and current is not None:
        before = URGENCY_ORDER.index(current.get("urgency")) if current.get("urgency") in URGENCY_ORDER else 0
        wanted = URGENCY_ORDER.index(urgency)
        current["urgency"] = URGENCY_ORDER[min(wanted, before + 1)]
        for key, value in fields.items():
            if value:
                current[key] = value
        current["updated_at_turn"] = turn
        return "advance"
    return "none"


def run(*, model: Any, store: Any, state: dict[str, Any], save_state: bool = True) -> dict[str, Any]:
    rows = store.recent_turns(str(state.get("campaign_id") or ""), limit=8)
    payload = model.chat_json(build_messages(state, rows), schema=CLOCK_SCHEMA, temperature=0.2)
    outcome = apply_clock_result(state, payload)
    if save_state:
        store.save_state(state)
    return {"outcome": outcome, "payload": payload}


def prompt_current(state: dict[str, Any]) -> dict[str, Any] | None:
    """The clock step offered to the narrator's private hidden-current channel."""

    clock = state.get("world_clock") if isinstance(state.get("world_clock"), dict) else {}
    current = clock.get("current")
    if not isinstance(current, dict) or not current.get("truth") or not current.get("subject"):
        return None
    if _undertaking(state) is None:
        return None
    return current
