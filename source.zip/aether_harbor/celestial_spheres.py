from __future__ import annotations

import hashlib
import json
import random
import re
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .local_model import LocalQwen


PLANETS = ("Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn")
FACES = (*PLANETS, "Falling Star")
ADJACENT = {
    frozenset((PLANETS[index], PLANETS[(index + 1) % len(PLANETS)]))
    for index in range(len(PLANETS))
}
_GAME = re.compile(r"\b(?:celestial\s+spheres|spheres\s+game|planetary\s+(?:table|board|spheres|marks?|glyphs?|game))\b", re.I)
_GAME_BROWSE = re.compile(
    r"\b(?:(?:board|dice|tavern|gambling|planetary|stone|circular)\s+(?:game|table|board)|"
    r"play\s+a\s+game|games?\s+of\s+chance|any\s+(?:gambling|games?)|"
    r"(?:where|anywhere)\b[^.!?]{0,30}\b(?:gamble|wager|bet|play)|"
    r"\bgambl(?:e|ing)\b|"
    r"(?:see|watch|check|join|approach|sit\s+(?:at|by)|pull\s+up\s+(?:a\s+stool\s+to|to)|"
    r"step\s+(?:up\s+to|between))\s+(?:the\s+)?(?:game|table|board)|what\s+game)\b",
    re.I,
)
_TAVERN = re.compile(r"\b(?:tavern|inn|gambling\s+den|alehouse|public\s+house)\b", re.I)
_SCENE_GAMBLING_TABLE = re.compile(r"\bgambling\s+(?:table|board|den)\b", re.I)
_RULES = re.compile(r"\b(?:rules?|how\s+(?:do|does|to)|explain|learn|play)\b", re.I)
_BET = re.compile(r"\bbet\s+(?P<amount>\d{1,5})\s+silver\s+(?:on\s+)?(?P<target>[^,.;!?]+)", re.I)
_BET_NATURAL = re.compile(
    r"\b(?:bet|wager|place|put|stake|lay|drop|set|toss|slide|push|throw|play|spin)\s+"
    r"(?:another\s+|more\s+)?"
    r"(?P<amount>\d{1,5}|a|an|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|twenty-five|thirty|fifty|hundred)\s*"
    r"(?:(?:silver|coins?|pieces?)\s+(?:coins?\s+)?)?"
    r"(?:on|for|at|in|into|upon|toward|towards)\s+(?P<target>[^,.;!?]+)",
    re.I,
)
_BET_SHORTHAND = re.compile(
    r"^\s*(?:i\s+|let'?s\s+)?(?:another\s+)?"
    r"(?P<amount>\d{1,5}|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|twenty-five|thirty|fifty|hundred)\s+"
    r"(?:(?:silver|coins?|pieces?)\s+)?"
    r"(?:on|for)\s+(?P<target>[^,.;!?]+)",
    re.I,
)
_BET_REPEAT = re.compile(
    r"\b(?:same\s+(?:bet|wager|stake)|repeat\s+(?:my\s+|the\s+)?(?:bet|wager|stake)|bet\s+the\s+same|let\s+it\s+ride)\b",
    re.I,
)
_BET_NUMBERS = {
    "a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11,
    "twelve": 12, "fifteen": 15, "twenty": 20, "twenty-five": 25, "thirty": 30,
    "fifty": 50, "hundred": 100,
}
_PRESS = re.compile(r"\b(?:press|double\s+(?:it|the\s+bet)|press\s+the\s+attack)\b", re.I)
_COLLECT = re.compile(r"\b(?:collect|take\s+the\s+winnings|do\s+not\s+press|don't\s+press|dont\s+press)\b", re.I)

CELESTIAL_SPHERES_ACTION_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "action": {
            "type": "string",
            "enum": ["NONE", "BET", "PRESS", "COLLECT", "RULES"],
        },
        "stake": {"type": "integer", "minimum": 0, "maximum": 10000},
        "selection": {"type": "string", "maxLength": 60},
    },
    "required": ["action", "stake", "selection"],
    "additionalProperties": False,
}

CELESTIAL_SPHERES_ACTION_SYSTEM = """
You are the dedicated semantic action classifier for the Celestial Spheres tavern gambling table.
Return JSON only.
Board marks:
- Single spheres: Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn
- Sectors/arcs: Heavens, Underworld, Falling Star
- Adjacent pairs: Sun and Moon, Moon and Mercury, Mercury and Venus, Venus and Mars, Mars and Jupiter, Jupiter and Saturn, Saturn and Sun

Classify the player's action at the table:
- "BET": The player places or commits a silver wager on a board mark now (regardless of phrasing, e.g. "I place 10 on Heavens", "five coins on the red planet" -> Mars, "same bet again" -> reuse last_bet, "half my purse on Jupiter").
- "PRESS": pending_mars_press is true and the player chooses to press/double the winning Mars-7 bet.
- "COLLECT": pending_mars_press is true and the player chooses to collect/take their winnings without pressing.
- "RULES": The player asks how the game works, asks about rules, payouts, or special planetary influences without placing a bet yet.
- "NONE": Any other action (merely approaching/observing the table without betting, talking to someone else, ordering food/drink, or stepping away).

Questions, negations, hypothetical wagers and quotations are NONE (or RULES), not commitments. Cheating, theft, attacks, and a wager combined with a separate risky action are NONE; the normal action resolver owns those turns. Never infer an unpaid wager from narration or replay a spin because the player asks what the dice show. A fresh BET requires a current explicit wager or repeat instruction.
When action is "BET", set stake to the integer silver amount and selection to the canonical board mark (or the exact invalid mark name if the player explicitly tried to bet on a non-existent mark like "Neptune"). Otherwise set stake to 0 and selection to "".
""".strip()


def classify_celestial_spheres_action(
    *,
    model: LocalQwen,
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> dict[str, Any] | None:
    """Run a tiny, isolated semantic classifier ONLY when Celestial Spheres is offered."""

    if not is_celestial_spheres_offered(state):
        return None
    store = ensure_celestial_state(state)
    history = _local_history(state)
    last_bet = history[-1] if history else None
    pending = store.get("pending_press")
    recent = [
        {"speaker": str(row.get("speaker") or ""), "text": str(row.get("text") or "")[:450]}
        for row in recent_turns[-4:]
        if isinstance(row, dict) and str(row.get("text") or "").strip()
    ]
    request = {
        "player_silver": int(state.get("player", {}).get("silver", 0) or 0),
        "last_bet": last_bet,
        "pending_mars_press": _pending_here(state, pending),
        "recent_scene": recent,
        "player_action": str(player_text or "")[:300],
    }
    payload = model.chat_json(
        [
            {"role": "system", "content": CELESTIAL_SPHERES_ACTION_SYSTEM},
            {"role": "user", "content": json.dumps(request, ensure_ascii=False)},
        ],
        schema=CELESTIAL_SPHERES_ACTION_SCHEMA,
        temperature=0.0,
    )
    return _validated_action(payload)


def _validated_action(payload: Any) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None
    action = payload.get("action")
    stake = payload.get("stake")
    selection = payload.get("selection")
    if (not isinstance(action, str) or action not in {"NONE", "BET", "PRESS", "COLLECT", "RULES"}
            or type(stake) is not int or not 0 <= stake <= 10000
            or not isinstance(selection, str) or len(selection) > 60):
        return None
    return {"action": action, "stake": stake, "selection": selection.strip()}


def _pending_here(state, pending):
    location_id = str(state.get("current_location_id") or "")
    return bool(isinstance(pending, dict) and location_id
                and str(pending.get("locus") or "").startswith(f"{location_id}|"))


def _local_history(state):
    location_id = str(state.get("current_location_id") or "")
    return [row for row in ensure_celestial_state(state).get("history", [])
            if isinstance(row, dict) and (not row.get("locus")
                or str(row["locus"]).startswith(f"{location_id}|"))]


def _table_leader(state):
    purses = {"Player": int(state.get("player", {}).get("silver", 0) or 0),
              **ensure_celestial_state(state).get("opponents_purse", {})}
    name = max(purses, key=purses.get)
    return f"{name} ({purses[name]} silver)"


def ensure_celestial_state(state: dict[str, Any]) -> dict[str, Any]:
    store = state.setdefault("celestial_spheres", {})
    store.setdefault("loci", {})
    store.setdefault("history", [])
    store.setdefault("pending_press", None)
    return store


def _locus(state: dict[str, Any]) -> str:
    location_id = str(state.get("current_location_id") or "")
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    return f"{location_id}|{' '.join(str(position.get('id') or position.get('label') or 'whole-place').casefold().split())}"


def _find_location_record(store: dict[str, Any], state: dict[str, Any]) -> dict[str, Any] | None:
    locus = _locus(state)
    record = store.get("loci", {}).get(locus)
    if isinstance(record, dict):
        return record
    location_id = str(state.get("current_location_id") or "")
    if not location_id:
        return None
    prefix = f"{location_id}|"
    for key, val in (store.get("loci") or {}).items():
        if str(key).startswith(prefix) and isinstance(val, dict) and val.get("offered") is True:
            return val
    for key, val in (store.get("loci") or {}).items():
        if str(key).startswith(prefix) and isinstance(val, dict) and "offered" in val:
            return val
    return None


def is_celestial_spheres_offered(state: dict[str, Any]) -> bool:
    store = ensure_celestial_state(state)
    record = _find_location_record(store, state)
    return bool(isinstance(record, dict) and record.get("offered"))


def _scene_text(state: dict[str, Any], recent_turns: list[dict[str, Any]]) -> str:
    location = state.get("locations", {}).get(str(state.get("current_location_id") or ""), {})
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    return " ".join(
        [
            str(location.get("name") or ""),
            str(location.get("summary") or ""),
            str(location.get("defining_excerpt") or ""),
            str(position.get("label") or ""),
            str(position.get("summary") or ""),
            *[
                str(row.get("text") or "")
                for row in recent_turns[-3:]
                if isinstance(row, dict)
            ],
        ]
    )


def _digest(state: dict[str, Any], suffix: str) -> bytes:
    material = (
        f"{state.get('campaign_id', '')}:{state.get('rng_seed', 0)}:"
        f"{_locus(state)}:celestial-spheres-v1:{suffix}"
    ).encode("utf-8")
    return hashlib.sha256(material).digest()


def private_celestial_spheres_context(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> dict[str, Any] | None:
    store = ensure_celestial_state(state)
    locus = _locus(state)
    scene = _scene_text(state, recent_turns)
    in_tavern = bool(_TAVERN.search(scene))
    scene_has_table = bool(_GAME.search(scene) or _SCENE_GAMBLING_TABLE.search(scene))
    explicit_player = bool(_GAME.search(player_text))
    deliberate_browse = bool(_GAME_BROWSE.search(player_text) and in_tavern)
    # Spontaneous tavern discovery: when the scene is a tavern/inn, give a natural 40%
    # deterministic chance that a Celestial Spheres table is present. In the remaining
    # 60% of taverns, Celestial Spheres is absent even if the player explicitly asks.
    spontaneous_tavern = bool(in_tavern and (_digest(state, "spontaneous_spheres")[0] * 100 // 256) < 40)
    record = _find_location_record(store, state)
    if record is None:
        if scene_has_table:
            record = {"offered": True, "turn": int(state.get("turn_no", 0) or 0)}
            store["loci"][locus] = record
        elif in_tavern:
            record = {"offered": bool(spontaneous_tavern), "turn": int(state.get("turn_no", 0) or 0)}
            store["loci"][locus] = record
        elif explicit_player:
            record = {"offered": True, "turn": int(state.get("turn_no", 0) or 0)}
            store["loci"][locus] = record
    else:
        store["loci"][locus] = record
    if not isinstance(record, dict) or not record.get("offered"):
        if isinstance(record, dict) and (deliberate_browse or explicit_player):
            return {
                "offered": False,
                "instruction": (
                    "No Celestial Spheres board or organized house gambling table operates in this establishment; "
                    "do not introduce one even if asked. The barkeep or patrons may either say no games are run here "
                    "or offer a simple game of ordinary bone dice (stating a single clear silver stake, e.g. 2 to 5 silver, over 3 rounds)."
                ),
            }
        return None
    rules_inquiry = bool(
        _RULES.search(player_text)
        or store.get("last_rules_turn") == int(state.get("turn_no", 0) or 0)
    )
    instruction = (
        "This is an optional ordinary tavern game, never an island key or mission. Keep it present only when "
        "the player attends to it. Do not change silver or dice results unless a resolved Celestial Spheres event does so. "
        "When the player first observes or approaches the table, have the table-keeper or an onlooker speak a crisp in-character call "
        "inviting a wager that explicitly names the seven spheres and main bets: e.g. "
        "\"Seven spheres ring the stone: Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn, with the Falling Star at the zenith. "
        "Five-to-one on any single sphere—with Jupiter paying a heavy seven-to-one jackpot!—two-to-one on an adjacent pair, "
        "ten-to-one on the Falling Star, or even money on Heavens or Underworld. Place your coin on a mark to spin, traveler.\" "
        "Never deliver a dry rulebook essay."
    )
    if rules_inquiry:
        instruction += (
            " The player is explicitly asking how the game is played or inquiring about the rules and special bets. "
            "Have the table-keeper or an experienced gambler explain the table clearly and colorfully in dialogue: "
            "reiterate the 7 spheres and basic payouts (5:1 single, 7:1 Jupiter Jackpot, 2:1 adjacent pair, 1:1 on Heavens 8-12 or Underworld 2-6, "
            "and 10:1 on Falling Star). Then explain the planetary influences: Mercury Insurance (50% refund if neighbor planet wins), "
            "Venus Charity (+5 silver aid if purse is under 15), Hubris (Falling Star loss halves your next win), and Rebellion "
            "(betting both Mars & Saturn sparks 7:1 payout plus a 30% tax from the table leader!)."
        )
    context: dict[str, Any] = {
        "instruction": instruction,
        "surface": (
            "A circular seven-sector stone board with polished brass inlays displaying the seven classical planetary marks: "
            "Sun, Moon, Mercury, Venus, Mars, Jupiter, and Saturn, alongside an eighth sigil for the Falling Star. "
            "Played with two six-sided magnitude dice and one eight-sided celestial die. "
            "The table-keeper—a stoic, quick-fingered croupier with calipers and a coin tray—presides over the board, "
            "while a few tavern patrons linger around the brass rim watching each spin. Portray the table-keeper and onlookers authentically in keeping with this island's local culture and setting."
        ),
        "rules": (
            "Board order: Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn, with Saturn adjacent to Sun. "
            "Celestial d8 selects planet or Falling Star; 2d6 give magnitude (2-12). "
            "Bets & Payouts: Single planet 5:1 (Jupiter Jackpot pays 7:1!); Adjacent pair 2:1; Heavens (8-12) or Underworld (2-6) 1:1; Falling Star 10:1 (lose = Hubris penalty). "
            "Planetary Influences: Sun+12 & Moon+2 pay 10:1; Mars+7 may double/press; Saturn+3 reduces payout; "
            "Mercury Insurance gives 50% refund if neighbor planet wins; Venus Charity gives +5 silver to poor players (<15 silver); "
            "Rebellion (if Mars & Saturn bets active) pays 7:1 to winner + taxes 30% from the table leader; "
            "Hubris halves next winning payout."
        ),
    }
    opps = _get_table_opponents(state)
    if isinstance(opps, list) and opps:
        opp_names = ", ".join(f"{o.get('name')} ({o.get('title')})" for o in opps if isinstance(o, dict) and o.get("name"))
        if opp_names:
            context["opponents_at_table"] = opp_names
            context["surface"] += f" Seated at the table placing wagers are: {opp_names}."
    arch = store.get("architect")
    if isinstance(arch, dict) and arch.get("croupier_desc"):
        context["croupier"] = str(arch.get("croupier_desc"))
    pending = store.get("pending_press")
    if _pending_here(state, pending):
        context["pending_mars_press"] = {
            "stake": pending.get("stake"),
            "instruction": "The winning Mars-seven bet awaits the player's choice to collect or press.",
        }
    return context


def _roll(state: dict[str, Any], sides: int) -> int:
    counter = int(state.get("rng_counter", 0) or 0)
    material = f"{state.get('rng_seed', 0)}:{counter}:{sides}".encode("utf-8")
    derived = int.from_bytes(hashlib.sha256(material).digest()[:8], "big")
    state["rng_counter"] = counter + 1
    return random.Random(derived).randint(1, sides)


def _target(value: str) -> tuple[str, Any] | None:
    folded = " ".join(str(value or "").strip().split())
    folded = re.sub(
        r"^(?:on\s+|for\s+|at\s+|in\s+|into\s+|upon\s+|toward\s+|towards\s+)*"
        r"(?:the\s+)?"
        r"(?:(?:mark|arc|sector|symbol|sigil|sphere|sign)\s+(?:of|for)\s+)?"
        r"(?:the\s+)?",
        "",
        folded,
        flags=re.I,
    ).strip()
    folded = re.sub(
        r"\s+(?:to\s+spin|and\s+spin|again|please|now|for\s+me|this\s+time|next)$",
        "",
        folded,
        flags=re.I,
    ).strip()
    folded = re.sub(
        r"\s+(?:mark|arc|sector|symbol|sigil|sphere|sign)$",
        "",
        folded,
        flags=re.I,
    ).strip()
    for planet in PLANETS:
        if folded.casefold() == planet.casefold():
            return "single", planet
    if folded.casefold() in {"falling star", "the falling star", "comet"}:
        return "falling_star", "Falling Star"
    if folded.casefold() in {"heavens", "the heavens", "high numbers"}:
        return "heavens", "Heavens"
    if folded.casefold() in {"underworld", "the underworld", "low numbers"}:
        return "underworld", "Underworld"
    parts = [part.strip() for part in re.split(r"[/+&]|\band\b", folded, flags=re.I) if part.strip()]
    if len(parts) == 2:
        planets = []
        for part in parts:
            match = next((planet for planet in PLANETS if part.casefold() == planet.casefold()), None)
            if match is None:
                return None
            planets.append(match)
        pair = frozenset(planets)
        if len(pair) == 2 and pair in ADJACENT:
            return "pair", tuple(planets)
    return None


def _parse_bet(state: dict[str, Any], text: str) -> tuple[int, str] | None:
    match = _BET.search(text)
    if match:
        return int(match.group("amount")), match.group("target")
    for pattern in (_BET_NATURAL, _BET_SHORTHAND):
        m = pattern.search(text)
        if not m:
            continue
        raw_amount = m.group("amount").casefold()
        stake = int(raw_amount) if raw_amount.isdigit() else _BET_NUMBERS.get(raw_amount, 0)
        if stake <= 0:
            continue
        raw_target = m.group("target")
        if _target(raw_target) is not None or re.search(r"\b(?:bet|wager|stake)\b", m.group(0), re.I):
            return stake, raw_target
    if _BET_REPEAT.search(text):
        store = ensure_celestial_state(state)
        history = _local_history(state)
        if history:
            last = history[-1]
            if isinstance(last, dict) and last.get("stake") and last.get("selection"):
                sel = last["selection"]
                target_str = " and ".join(sel) if isinstance(sel, (list, tuple)) else str(sel)
                return int(last["stake"]), target_str
    return None


def _settle_pending_press(state: dict[str, Any], text: str) -> dict[str, Any] | None:
    store = ensure_celestial_state(state)
    pending = store.get("pending_press")
    if not _pending_here(state, pending):
        return None
    player = state.setdefault("player", {})
    silver = int(player.get("silver", 0) or 0)
    stake = int(pending.get("stake", 0) or 0)
    odds = int(pending.get("odds", 5))
    def winnings(amount):
        payout = amount * (odds + 1)
        return max(amount, payout // 2) if pending.get("hubris_penalty") else payout
    if _COLLECT.search(text):
        payout = winnings(stake)
        player["silver"] = silver + payout
        store["pending_press"] = None
        return {
            "type": "celestial_spheres_resolution",
            "committed": True,
            "action": "collect",
            "won": True,
            "stake": stake,
            "payout": payout,
            "net": payout - stake,
            "silver_after": player["silver"],
            "special": "Mars seven collected without pressing",
        }
    if _PRESS.search(text):
        if silver < stake:
            return {
                "type": "celestial_spheres_resolution",
                "committed": False,
                "reason": "Not enough silver remains to press the Mars bet.",
                "pending_press": True,
            }
        player["silver"] = silver - stake
        total_stake = stake * 2
        payout = winnings(total_stake)
        player["silver"] += payout
        store["pending_press"] = None
        return {
            "type": "celestial_spheres_resolution",
            "committed": True,
            "action": "press",
            "won": True,
            "stake": total_stake,
            "payout": payout,
            "net": payout - total_stake,
            "silver_after": player["silver"],
            "special": "Mars presses the attack",
        }
    return None


def _get_table_opponents(state: dict[str, Any]) -> list[dict[str, Any]]:
    store = ensure_celestial_state(state)
    arch = store.get("architect")
    if isinstance(arch, dict) and isinstance(arch.get("opponents"), list) and arch.get("opponents"):
        opps = [o for o in arch.get("opponents") if isinstance(o, dict) and o.get("name")]
        if opps:
            return opps
    return [
        {"name": "Thalric 'The Barnacle' Vane", "title": "weathered boatman", "bet_style": "cautious"},
        {"name": "Sela of the Low Tide", "title": "docks runner", "bet_style": "bold"},
    ]


BET_CHOICES = (
    "Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn",
    "Heavens", "Underworld",
)


def _resolve_table_participants(
    state: dict[str, Any],
    player_selection: str,
    player_kind: str,
    player_stake: int,
    player_won: bool,
    face: str,
    magnitude: int,
) -> tuple[list[dict[str, Any]], str, str, str, bool, int, str | None]:
    """Deterministically simulates other gamblers at the table, tracks their purses,
    evaluates organic Rebellion clash and leader tax, and maintains running history.
    """
    store = ensure_celestial_state(state)
    opponents = _get_table_opponents(state)
    purses = store.setdefault("opponents_purse", {})
    player = state.setdefault("player", {})
    turn_no = int(state.get("turn_no", 0) or 0)

    # 1. Initialize opponent purses if missing
    for opp in opponents:
        name = str(opp.get("name") or "Gambler")
        if name not in purses:
            seed_offset = _digest(state, f"init_purse:{name}")[0] % 25
            purses[name] = 35 + seed_offset

    # 2. Determine who the table leader was before this spin's resolution
    leader_name = "Player"
    leader_purse = int(player.get("silver", 0) or 0)
    for opp in opponents:
        name = str(opp.get("name") or "Gambler")
        p_val = purses.get(name, 0)
        if p_val > leader_purse:
            leader_purse = p_val
            leader_name = name

    # 3. Simulate wagers for each opponent
    opp_records: list[dict[str, Any]] = []
    mars_bettors: list[str] = ["Player"] if (player_kind == "single" and player_selection == "Mars") else []
    saturn_bettors: list[str] = ["Player"] if (player_kind == "single" and player_selection == "Saturn") else []

    for opp in opponents:
        name = str(opp.get("name") or "Gambler")
        style = str(opp.get("bet_style") or "ordinary").lower()
        h = _digest(state, f"opp_bet:{turn_no}:{name}")

        # Choose bet target
        if "bold" in style and h[1] < 70:
            sel = "Jupiter"
        elif "cautious" in style and h[1] < 140:
            sel = "Heavens" if (h[2] % 2 == 0) else "Underworld"
        else:
            sel = BET_CHOICES[h[0] % len(BET_CHOICES)]

        # Track rebel wagers
        # Choose stake
        stake = 2 + (h[3] % 5)  # 2-6 silver
        cur_purse = purses.get(name, 20)
        stake = min(stake, max(0, cur_purse))
        purses[name] = max(0, cur_purse - stake)
        if stake and sel == "Mars":
            mars_bettors.append(name)
        elif stake and sel == "Saturn":
            saturn_bettors.append(name)

        opp_records.append({
            "name": name,
            "title": opp.get("title", ""),
            "selection": sel,
            "stake": stake,
        })

    # 4. Check organic Rebellion
    rebellion_active = bool(mars_bettors and saturn_bettors)

    # 5. Settle opponents' bets
    summary_parts = []
    spin_winners = []
    leader_tax_deducted = 0
    leader_tax_target = None

    for rec in opp_records:
        name = rec["name"]
        sel = rec["selection"]
        stk = rec["stake"]
        won = False
        odds = 5

        if face == "Falling Star":
            won = sel == "Falling Star"
            odds = 10
        elif sel in PLANETS:
            won = (face == sel)
            if sel == "Jupiter" and won:
                odds = 7
            elif rebellion_active and sel in ("Mars", "Saturn") and won:
                odds = 7
            else:
                odds = 5
        elif sel == "Heavens":
            won = (8 <= magnitude <= 12)
            odds = 1
        elif sel == "Underworld":
            won = (2 <= magnitude <= 6)
            odds = 1

        won = won and stk > 0
        if won and sel == "Sun" and face == "Sun" and magnitude == 12:
            odds = 10
        elif won and sel == "Moon" and face == "Moon" and magnitude == 2:
            odds = 10
        elif won and face == "Saturn" and magnitude == 3 and not rebellion_active:
            odds = max(1, odds - 2)
        payout = 0
        if won:
            payout = stk * (odds + 1)
            purses[name] += payout
            spin_winners.append(f"{name} (+{payout - stk}s on {sel})")
            verdict = f"Won +{payout - stk}s"
        else:
            # Mercury Insurance
            if sel == "Mercury" and face in ("Moon", "Venus"):
                payout = stk // 2
                purses[name] += payout
                verdict = f"Refunded {payout}s (Mercury)"
            else:
                verdict = "Lost"

        # Venus Charity
        if face == "Venus" and purses[name] < 15:
            purses[name] += 5
            verdict += " + Venus Charity"

        rec["won"] = won
        rec["payout"] = payout
        rec["net"] = payout - stk
        rec["purse"] = purses[name]
        summary_parts.append(f"{name} bet {stk}s on {sel} ({verdict})")

    # If rebellion hit Mars or Saturn, levy 30% tax from table leader
    if rebellion_active and face in ("Mars", "Saturn"):
        if leader_name == "Player":
            tax = int(player.get("silver", 0) * 0.3)
            player["silver"] = max(0, int(player.get("silver", 0) or 0) - tax)
            leader_tax_deducted = tax
            leader_tax_target = "Player"
        else:
            tax = int(purses.get(leader_name, 0) * 0.3)
            purses[leader_name] = max(0, purses.get(leader_name, 0) - tax)
            leader_tax_deducted = tax
            leader_tax_target = leader_name

    # 6. Retrieve previous spin winner description before updating it
    previous_winner_desc = store.get("previous_winner_desc", "None (table just opened)")

    # 7. Update store with this spin's winners
    if player_won:
        spin_winners.insert(0, f"Player on {player_selection}")
    if spin_winners:
        store["previous_winner_desc"] = ", ".join(spin_winners)
    else:
        store["previous_winner_desc"] = "The House swept the table (all lost)"

    # 8. Determine current table leader after all payouts
    final_leader_name = "Player"
    final_leader_silver = int(player.get("silver", 0) or 0)
    for opp_name, p_val in purses.items():
        if p_val > final_leader_silver:
            final_leader_silver = p_val
            final_leader_name = opp_name
    current_table_leader = f"{final_leader_name} ({final_leader_silver} silver)"

    table_summary = ", ".join(summary_parts)
    return opp_records, table_summary, previous_winner_desc, current_table_leader, rebellion_active, leader_tax_deducted, leader_tax_target


def resolve_celestial_spheres_action(
    state: dict[str, Any],
    text: str,
    *,
    semantic_roll: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    cs_semantic = (
        semantic_roll.get("celestial_spheres")
        if isinstance(semantic_roll, dict) and isinstance(semantic_roll.get("celestial_spheres"), dict)
        else None
    )
    parsed: tuple[int, str] | None = None
    if cs_semantic is not None:
        advice = _validated_action(cs_semantic)
        # An explicit semantic NONE/RULES must never fall through to text betting.
        if advice is None or advice["action"] == "NONE":
            return None
        if not is_celestial_spheres_offered(state):
            return None
        sem_action = advice["action"]
        if sem_action == "RULES":
            ensure_celestial_state(state)["last_rules_turn"] = int(state.get("turn_no", 0) or 0)
            return {"type": "celestial_spheres_resolution", "committed": False,
                    "action": "rules", "reason": "Explain the table rules; no wager was placed."}
        if sem_action in {"PRESS", "COLLECT"}:
            return _settle_pending_press(state, sem_action.lower())
        parsed = (advice["stake"], advice["selection"])
    else:
        pending = _settle_pending_press(state, text)
        if pending is not None:
            return pending
        parsed = _parse_bet(state, text)
    if not parsed:
        return None
    store = ensure_celestial_state(state)
    locus = _locus(state)
    record = _find_location_record(store, state)
    if not isinstance(record, dict) or not record.get("offered"):
        return None
    if isinstance(store.get("pending_press"), dict):
        return {"type": "celestial_spheres_resolution", "committed": False,
                "reason": "Collect or press the pending Mars winnings at their original table before placing a new wager."}
    store["loci"][locus] = record
    stake, raw_target = parsed
    player = state.setdefault("player", {})
    silver = int(player.get("silver", 0) or 0)
    if stake <= 0 or stake > silver:
        return {
            "type": "celestial_spheres_resolution",
            "committed": False,
            "reason": "The declared stake is not available.",
            "stake": stake,
            "silver": silver,
        }
    target = _target(raw_target)
    if target is None:
        return {
            "type": "celestial_spheres_resolution",
            "committed": False,
            "reason": "That mark is not on the board. The sectors are Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn (or Heavens, Underworld, Falling Star).",
        }

    kind, selection = target
    player["silver"] = silver - stake
    die_one, die_two = _roll(state, 6), _roll(state, 6)
    magnitude = die_one + die_two
    face = FACES[_roll(state, 8) - 1]
    if face == "Falling Star":
        won = kind == "falling_star"
    elif kind == "single":
        won = selection == face
    elif kind == "pair":
        won = face in selection
    elif kind == "heavens":
        won = 8 <= magnitude <= 12
    elif kind == "underworld":
        won = 2 <= magnitude <= 6
    else:
        won = False

    (
        opp_records,
        table_summary,
        previous_winner,
        table_leader,
        rebellion_active,
        leader_tax_deducted,
        leader_tax_target,
    ) = _resolve_table_participants(state, selection, kind, stake, won, face, magnitude)

    odds = {"single": 5, "pair": 2, "heavens": 1, "underworld": 1, "falling_star": 10}[kind]
    special = None
    refund = 0

    # 1. Jupiter Jackpot (7:1 payout)
    if won and kind == "single" and face == "Jupiter":
        odds, special = 7, "Jupiter Jackpot (7:1 payout)"

    # 2. Sun Zenith (10:1 payout)
    elif won and kind == "single" and face == "Sun" and magnitude == 12:
        odds, special = 10, "The Sun in its Zenith (10:1 payout)"

    # 3. Hidden Moon (10:1 payout)
    elif won and kind == "single" and face == "Moon" and magnitude == 2:
        odds, special = 10, "The Hidden Moon (10:1 payout)"

    # 4. Saturn Constraint (Sum 3 reduces multiplier by 2)
    elif won and face == "Saturn" and magnitude == 3:
        odds, special = max(1, odds - 2), "Saturn constrains fortune (-2 to odds)"

    # 5. Rebellion Check:
    # If Mars & Saturn were both bet on across the table:
    if won and kind == "single" and selection in ("Mars", "Saturn") and rebellion_active:
        odds = 7
        special = "Rebellion! Mars & Saturn clash (7:1 payout + 30% leader tax)"

    if leader_tax_deducted > 0:
        if leader_tax_target == "Player":
            special = (special + " · " if special else "") + f"Rebellion Tax! You were taxed {leader_tax_deducted} silver as table leader"
        elif leader_tax_target:
            special = (special + " · " if special else "") + f"Rebellion Tax! {leader_tax_target} was taxed {leader_tax_deducted} silver as table leader"

    # 6. Mercury Insurance:
    # If a single Mercury bet lost, but an adjacent planet (Moon or Venus) won:
    if not won and kind == "single" and selection == "Mercury" and face in ("Moon", "Venus"):
        refund = stake // 2
        special = "Mercury Insurance (50% refund on neighbor planet win)"

    # 7. Venus Charity:
    # When Venus wins, any player whose purse is below 15 receives +5 silver
    charity = 0
    if face == "Venus" and player["silver"] < 15:
        charity = 5
        player["silver"] += charity
        special = (special + " · " if special else "") + "Venus Charity (+5 silver aid to depleted purse)"

    # 8. Hubris (Falling Star):
    hubris_penalty = False
    if kind == "falling_star" and not won:
        store["hubris"] = True
        special = (special + " · " if special else "") + "Hubris marks you (next win halved)"
    elif won and store.get("hubris"):
        store["hubris"] = False
        hubris_penalty = True
        special = (special + " · " if special else "") + "Hubris penalty applied (winnings halved)"

    event = {
        "type": "celestial_spheres_resolution",
        "committed": True,
        "action": "bet",
        "selection_kind": kind,
        "selection": selection,
        "stake": stake,
        "dice": [die_one, die_two],
        "magnitude": magnitude,
        "celestial_face": face,
        "won": won,
        "odds": odds,
        "special": special,
        "table_wagers": opp_records,
        "table_wagers_summary": table_summary,
        "previous_winner": previous_winner,
        "table_leader": table_leader,
    }
    if won and kind == "single" and face == "Mars" and magnitude == 7:
        store["pending_press"] = {
            "locus": locus,
            "stake": stake,
            "created_turn": int(state.get("turn_no", 0) or 0),
            "odds": odds,
            "hubris_penalty": hubris_penalty,
        }
        event["pending_press"] = True
        event["payout"] = 0
        event["silver_after"] = player["silver"]
    elif refund > 0:
        payout = refund
        player["silver"] += payout
        event["won"] = False
        event["payout"] = payout
        event["net"] = refund - stake
        event["silver_after"] = player["silver"]
    elif won:
        payout = stake * (odds + 1)
        if hubris_penalty:
            payout = max(stake, payout // 2)
        player["silver"] += payout
        event["won"] = True
        event["payout"] = payout
        event["net"] = payout - stake
        event["silver_after"] = player["silver"]
    else:
        event["won"] = False
        event["payout"] = 0
        event["net"] = -stake
        event["silver_after"] = player["silver"]
    event["table_leader"] = _table_leader(state)
    for row in opp_records:
        row["purse"] = store.get("opponents_purse", {}).get(row["name"], row.get("purse", 0))
    store["history"].append(
        {
            "locus": locus,
            "turn": int(state.get("turn_no", 0) or 0),
            "stake": stake,
            "selection": selection,
            "face": face,
            "magnitude": magnitude,
            "won": won,
            "net": event.get("net"),
        }
    )
    store["history"] = store["history"][-20:]
    return event
