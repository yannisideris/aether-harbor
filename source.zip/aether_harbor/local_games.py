from __future__ import annotations

import re
import copy
import json
from typing import Any

from .celestial_spheres import is_celestial_spheres_offered
from .items import silver_amounts
from .mechanics import _roll


DICE_ACTIONS = {"NONE", "ACCEPT", "ACCEPT_ROLL", "ROLL", "RULES", "DECLINE", "FORFEIT", "REMATCH"}
DICE_ACTION_SCHEMA = {
    "type": "object", "properties": {
        "action": {"type": "string", "enum": sorted(DICE_ACTIONS)},
        "stake": {"type": "integer", "minimum": 0, "maximum": 1000},
    }, "required": ["action", "stake"], "additionalProperties": False,
}
DICE_ACTION_SYSTEM = """Classify ONLY the player's current action in the supplied ordinary dice match.
Return JSON action and stake. This is not Celestial Spheres.
NONE: questions about capability, hypothetical/negated/quoted commitments, unrelated
conversation, purchases, movement, cheating, theft, threats, or mixed risky actions.
ACCEPT: explicitly accept the offered terms or pay the offered stake now.
ACCEPT_ROLL: explicitly accept/pay AND roll the first round now.
ROLL: explicitly roll or take the next turn in an ACTIVE match. Mere waiting,
watching dice or asking for a previous result is NONE, never a new roll.
RULES: ask rules, stake, payout, or current score; no mutation or dice.
DECLINE: decline an unpaid offer. FORFEIT: explicitly concede/abandon an ACTIVE
match, losing the already-paid stake. Leaving the room alone is NONE, not forfeiture.
REMATCH: explicitly start another match on the same terms after finished/forfeited/declined.
Stake is the exact amount explicitly offered by the player, or 0 if accepting the
stored terms without naming an amount. Never invent/convert another amount to fit.
Do not infer a wager from older narration. Do not change rules or invent results.
""".strip()


def _validated_action(payload):
    if not isinstance(payload, dict):
        return None
    action, stake = payload.get("action"), payload.get("stake")
    if (not isinstance(action, str) or action not in DICE_ACTIONS
            or type(stake) is not int or not 0 <= stake <= 1000):
        return None
    return {"action": action, "stake": stake}


def classify_local_game_action(*, model, state, recent_turns, player_text):
    context = local_game_prompt_context(state)
    if context is None:
        return None
    payload = model.chat_json([
        {"role": "system", "content": DICE_ACTION_SYSTEM},
        {"role": "user", "content": json.dumps({
            "match": context, "player_silver": state.get("player", {}).get("silver", 0),
            "player_action": str(player_text or "")[:1200],
        }, ensure_ascii=False)},
    ], schema=DICE_ACTION_SCHEMA, temperature=0.0)
    result = _validated_action(payload)
    if result is None:
        raise ValueError("Invalid ordinary-dice action classification")
    return result


_NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
}
_DICE_RULES = re.compile(r"\b(?:die|dice|bones?)\b", re.I)
_CELESTIAL_HALLMARKS = re.compile(
    r"\b(?:celestial\s+spheres|celestial\s+die|magnitude\s+dice|seven\s+spheres|"
    r"falling\s+star|brass\s+sigils|croupier|calipers|arc\s+of\s+the\s+heavens)\b",
    re.I,
)
_ROUND_RULES = re.compile(
    r"\b(?:after|over|best\s+of)\s+(?P<count>\d+|one|two|three|four|five)\s+rounds?\b",
    re.I,
)
_WIN_RULE = re.compile(r"\b(?:highest|higher|most|wins?|takes?\s+the\s+(?:lot|pot))\b", re.I)
_ACCEPT_STAKE = re.compile(
    r"\b(?:place|put|stake|wager|bet|pay|drop|lay)\b.{0,45}\b(?:silver|coins?)\b",
    re.I,
)
_PLAY_BEAT = re.compile(
    r"\b(?:roll|throw|toss|shake|play|take\s+my\s+turn|my\s+turn|wait(?:\s+for\s+my\s+turn)?)\b",
    re.I,
)
_DECLINE = re.compile(r"\b(?:decline|refuse|not\s+play|won'?t\s+play|walk\s+away)\b", re.I)


def _round_count(text: str) -> int | None:
    match = _ROUND_RULES.search(text)
    if not match:
        return None
    token = match.group("count").casefold()
    value = int(token) if token.isdigit() else _NUMBER_WORDS.get(token)
    return value if value and 1 <= value <= 5 else None


def _extract_opponent(text: str) -> tuple[str, str]:
    """Extract named opponent from narration if specifically introduced by the GM."""
    m = re.search(r"\b(?:named|called)\s+([A-Z][a-z]+)\b", text)
    if m:
        name = m.group(1)
        role_m = re.search(rf"\b([a-z]+(?:\s+[a-z]+)?)\s+(?:named|called)\s+{name}\b", text, re.I)
        role = role_m.group(1).lower() if role_m else "gambler"
        return name, f"{name}, the {role}"

    m2 = re.search(r"\b([A-Z][a-z]+)\s+(?:shakes|rolls|throws|cups|barks|slaps|sets)\b", text)
    if m2 and m2.group(1) not in {"The", "He", "She", "They", "Someone", "Aether", "Dice", "House"}:
        name = m2.group(1)
        return name, f"{name}, the tavern gambler"

    return "", ""


def capture_local_game_offer(state: dict[str, Any], narration: str) -> bool:
    """Remember only an exact, ordinary dice offer stated by the narration."""

    existing = state.get("local_game")
    if isinstance(existing, dict) and (existing.get("status") == "active" or _same_game_locus(state, existing)):
        # Narration of the current match must not reset its offer or settlement.
        return False
    text = " ".join(str(narration or "").split())
    if (
        not text
        or is_celestial_spheres_offered(state)
        or _CELESTIAL_HALLMARKS.search(text)
        or not _DICE_RULES.search(text)
    ):
        return False

    amounts = silver_amounts(text)
    if len(set(amounts)) != 1 or not _WIN_RULE.search(text):
        return False  # Multiple amounts are ambiguous; never guess the smallest.

    stake = amounts[0]
    if not 1 <= stake <= 1000:
        return False

    rounds = _round_count(text) or 3  # Default to 3 rounds if not explicitly stated
    opponent_name, opponent_desc = _extract_opponent(text)

    state["local_game"] = {
        "kind": "ordinary_dice",
        "name": "a game of dice",
        "status": "offered",
        "opponent_name": opponent_name,
        "opponent_desc": opponent_desc,
        "stake": stake,
        "rounds_total": rounds,
        "round": 0,
        "dice_per_side": 2,
        "player_score": 0,
        "opponent_score": 0,
        "location_id": str(state.get("current_location_id") or ""),
        "scene_position_id": (
            str(state.get("scene_position", {}).get("id") or "")
            if isinstance(state.get("scene_position"), dict)
            else ""
        ),
        "scene_position_label": str((state.get("scene_position") or {}).get("label") or ""),
        "rules_version": 1,
        "rules_excerpt": text[:360],
        "created_at_turn": int(state.get("turn_no", 0) or 0),
    }
    return True


def _same_game_locus(state: dict[str, Any], game: dict[str, Any]) -> bool:
    if str(game.get("location_id") or "") != str(state.get("current_location_id") or ""):
        return False
    game_pos = str(game.get("scene_position_id") or "")
    cur_pos = (
        str(state.get("scene_position", {}).get("id") or "")
        if isinstance(state.get("scene_position"), dict)
        else ""
    )
    if game_pos and cur_pos and game_pos != cur_pos:
        saved_label = str(game.get("scene_position_label") or "").strip().casefold()
        current_label = str((state.get("scene_position") or {}).get("label") or "").strip().casefold()
        if not saved_label or saved_label != current_label:
            return False
    return True


def local_game_prompt_context(state: dict[str, Any]) -> dict[str, Any] | None:
    game = state.get("local_game")
    if not isinstance(game, dict) or game.get("status") not in {"offered", "active", "finished", "declined", "forfeited"}:
        return None
    if game.get("status") == "offered" and is_celestial_spheres_offered(state):
        return None
    if not _same_game_locus(state, game):
        return None
    return {
        "name": game.get("name"),
        "status": game.get("status"),
        "rules": "Each side pays the agreed stake once, then rolls two d6 per round. Add all dice totals across the agreed rounds (not best-of-round wins). Higher cumulative score takes twice the stake; a tie returns the player's stake. No intermediate payouts. Explicit forfeiture loses the paid stake. Only the engine rolls or settles coins.",
        "opponent": game.get("opponent_desc") or game.get("opponent_name") or "a local gambler fitting the cultural setting of this island/region",
        "opponent_name": game.get("opponent_name") or "",
        "stake": game.get("stake"),
        "round": game.get("round"),
        "rounds_total": game.get("rounds_total"),
        "player_score": game.get("player_score"),
        "opponent_score": game.get("opponent_score"),
        "dice_per_side": game.get("dice_per_side"),
        "rules_excerpt": game.get("rules_excerpt", ""),
        "instruction": (
            f"An ordinary dice match is offered for {game.get('stake', 5)} silver over {game.get('rounds_total', 3)} rounds. "
            f"The challenger invites the player concisely in-character (e.g. 'place {game.get('stake', 5)} silver on the table to roll' or 'accept')."
            if game.get("status") == "offered"
            else "The match is over. Do not restart or charge again unless the player explicitly requests a rematch."
            if game.get("status") in {"finished", "declined", "forfeited"}
            else (
                f"Round {game.get('round', 0)}/{game.get('rounds_total', 3)} of the dice match. "
                "Do NOT move coins from the pot in intermediate rounds. Prompt the next roll naturally."
            )
        ),
    }


def _record(state: dict[str, Any], *, kind: str, silver_delta: int) -> None:
    history = state.setdefault("resource_history", [])
    history.append(
        {
            "turn": int(state.get("turn_no", 0) or 0),
            "kind": kind,
            "item": "House Dice",
            "quantity": 1,
            "silver_delta": int(silver_delta),
            "success": True,
        }
    )
    state["resource_history"] = history[-12:]


_NON_GAME_PURCHASE = re.compile(
    r"\b(?:for\s+(?:a|an|the|my|some|one|two)?\s*(?:[a-z]+\s+of\s+)?"
    r"(?:ale|drink|beer|wine|rum|mead|grog|meal|food|bread|stew|room|bed|lodging|stay|passage|ticket|berth)"
    r"|\b(?:mug|tankard|bottle|cup|glass|pitcher|loaf|bowl|plate)\s+of\s+(?:ale|beer|wine|rum|mead|grog|stew|soup|food))\b",
    re.I,
)


def resolve_local_game_action(state: dict[str, Any], text: str, *, semantic_roll: dict[str, Any] | None = None) -> dict[str, Any] | None:
    game = state.get("local_game")
    if not isinstance(game, dict) or game.get("kind") != "ordinary_dice":
        return None
    if game.get("status") == "offered" and is_celestial_spheres_offered(state):
        return None
    if not _same_game_locus(state, game):
        return None
    raw = semantic_roll.get("local_game") if isinstance(semantic_roll, dict) else None
    advice = _validated_action(raw) if raw is not None else None
    if raw is not None and (advice is None or advice["action"] == "NONE"):
        return None
    action = advice["action"] if advice else None
    if action == "RULES":
        return {"type": "local_game_rules", "committed": False,
                "rules": local_game_prompt_context(state), "name": game.get("name")}
    if action == "FORFEIT" and game.get("status") == "active":
        game["status"], game["result"], game["payout"] = "forfeited", "loss", 0
        return {"type": "local_game_forfeit", "committed": True, "stake": game["stake"],
                "silver_after": state.get("player", {}).get("silver", 0)}
    if action == "REMATCH" and game.get("status") in {"finished", "declined", "forfeited"}:
        stake = int(game.get("stake", 0) or 0)
        if advice["stake"] not in {0, stake} or state.get("player", {}).get("silver", 0) < stake:
            return {"type": "local_game_start", "committed": False, "success": False,
                    "reason": "Accept the stored stake and have enough silver before starting a rematch."}
        archive = state.setdefault("local_game_history", [])
        archive.append(copy.deepcopy(game))
        state["local_game_history"] = archive[-5:]
        for field in ("stake_paid", "started_at_turn", "result", "payout", "history"):
            game.pop(field, None)
        game.update(status="offered", round=0, player_score=0, opponent_score=0)
        action = "ACCEPT"
    if game.get("status") not in {"offered", "active"}:
        return None
    if action is not None:
        allowed = {"ACCEPT", "ACCEPT_ROLL", "DECLINE"} if game["status"] == "offered" else {"ROLL"}
        if action not in allowed:
            return None
        if game["status"] == "offered" and advice["stake"] not in {0, int(game["stake"])}:
            return {"type": "local_game_start", "committed": False, "success": False,
                    "reason": "That amount differs from the agreed stake; no coins were taken."}

    if game.get("status") == "offered":
        if action == "DECLINE" or (action is None and _DECLINE.search(text)):
            game["status"] = "declined"
            return {"type": "local_game_declined", "committed": True, "name": game.get("name")}
        stake = int(game.get("stake", 0) or 0)
        if action is None:
            if _NON_GAME_PURCHASE.search(text):
                return None
            mentioned = silver_amounts(text)
            if mentioned and stake not in mentioned:
                return None
            pays_generic_stake = bool(
                re.search(
                    r"\b(?:pay|put|drop|give|place|wager|bet)\b.{0,25}\b(?:stake|wager|bet|pot|table)\b",
                    text,
                    re.I,
                )
            )
            accepts_generically = bool(
                re.search(
                    r"\b(?:i'm in|i am in|let'?s\s*play|let us play|you're on|i'?ll play|"
                    r"(?:accept|agree|join)(?:\s+(?:the\s+)?(?:game|wager|bet|challenge|match|toss|table))?)\b",
                    text,
                    re.I,
                )
            )
            if not _ACCEPT_STAKE.search(text) and not pays_generic_stake and not accepts_generically:
                return None
            if not pays_generic_stake and not accepts_generically and stake not in mentioned:
                return None
        before = int(state.get("player", {}).get("silver", 0) or 0)
        if before < stake:
            return {
                "type": "local_game_start",
                "committed": False,
                "success": False,
                "reason": "Insufficient silver for the exact stake.",
                "stake": stake,
                "silver_after": before,
            }
        state["player"]["silver"] = before - stake
        game["status"] = "active"
        game["stake_paid"] = True
        game["started_at_turn"] = int(state.get("turn_no", 0) or 0)
        _record(state, kind="local_game_stake", silver_delta=-stake)
        if action == "ACCEPT_ROLL":
            event = resolve_local_game_action(state, text, semantic_roll={"local_game": {"action": "ROLL", "stake": 0}})
            event["stake_paid_this_turn"] = stake
            return event
        return {
            "type": "local_game_start",
            "committed": True,
            "success": True,
            "name": game.get("name"),
            "opponent_name": game.get("opponent_name", ""),
            "opponent_desc": game.get("opponent_desc", ""),
            "stake": stake,
            "rounds_total": int(game.get("rounds_total", 3) or 3),
            "silver_before": before,
            "silver_after": before - stake,
        }

    if action is None and not _PLAY_BEAT.search(text):
        return None

    dice_count = max(1, min(4, int(game.get("dice_per_side", 2) or 2)))
    player_dice = [_roll(state, 6) for _ in range(dice_count)]
    opponent_dice = [_roll(state, 6) for _ in range(dice_count)]
    player_total = sum(player_dice)
    opponent_total = sum(opponent_dice)
    game["round"] = int(game.get("round", 0) or 0) + 1
    game["player_score"] = int(game.get("player_score", 0) or 0) + player_total
    game["opponent_score"] = int(game.get("opponent_score", 0) or 0) + opponent_total
    game.setdefault("history", []).append(
        {
            "round": game["round"],
            "player_dice": player_dice,
            "opponent_dice": opponent_dice,
            "player_total": player_total,
            "opponent_total": opponent_total,
        }
    )
    round_winner = "player" if player_total > opponent_total else ("opponent" if opponent_total > player_total else "tie")
    overall_leader = "player" if game["player_score"] > game["opponent_score"] else ("opponent" if game["opponent_score"] > game["player_score"] else "tied")
    event: dict[str, Any] = {
        "type": "local_game_round",
        "committed": True,
        "success": True,
        "name": game.get("name"),
        "opponent_name": game.get("opponent_name", ""),
        "opponent_desc": game.get("opponent_desc", ""),
        "round": game["round"],
        "rounds_total": int(game.get("rounds_total", 3) or 3),
        "player_dice": player_dice,
        "opponent_dice": opponent_dice,
        "player_total": player_total,
        "opponent_total": opponent_total,
        "player_score": game["player_score"],
        "opponent_score": game["opponent_score"],
        "round_winner": round_winner,
        "overall_leader": overall_leader,
        "finished": False,
        "silver_delta": 0,
    }
    if game["round"] < int(game.get("rounds_total", 3) or 3):
        return event

    stake = int(game.get("stake", 0) or 0)
    before = int(state.get("player", {}).get("silver", 0) or 0)
    if game["player_score"] > game["opponent_score"]:
        result, payout = "win", stake * 2
    elif game["player_score"] == game["opponent_score"]:
        result, payout = "tie", stake
    else:
        result, payout = "loss", 0
    state["player"]["silver"] = before + payout
    game["status"] = "finished"
    game["result"] = result
    game["payout"] = payout
    if payout:
        _record(state, kind="local_game_payout", silver_delta=payout)
    event.update(
        {
            "finished": True,
            "result": result,
            "payout": payout,
            "silver_delta": payout,
            "silver_after": before + payout,
        }
    )
    return event
