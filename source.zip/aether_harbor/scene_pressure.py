from __future__ import annotations

from typing import Any

from .stealth import sync_stealth_location


_ALERT_RANK = {"none": 0, "low": 1, "elevated": 2, "high": 3}


def _event_roll(event: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(event, dict):
        return None
    if str(event.get("type") or "") == "d20_resolution":
        return event
    roll = event.get("roll")
    return roll if isinstance(roll, dict) else None


def _raise_local_attention(
    state: dict[str, Any],
    *,
    level: str,
) -> dict[str, Any]:
    """Commit a small, cumulative attention consequence without inventing combat."""

    stealth = sync_stealth_location(state)
    wanted = level if level in _ALERT_RANK else "low"
    suspicion_floor = 2 if wanted in {"elevated", "high"} else 1
    stealth["concealed"] = False
    stealth["edge"] = None
    stealth["suspicion"] = max(
        suspicion_floor,
        int(stealth.get("suspicion", 0) or 0),
    )
    current = str(stealth.get("local_alert") or "none")
    if _ALERT_RANK.get(wanted, 1) > _ALERT_RANK.get(current, 0):
        stealth["local_alert"] = wanted
    return stealth


def _pressure_payload(semantic_roll: dict[str, Any] | None) -> dict[str, str] | None:
    if not isinstance(semantic_roll, dict):
        return None
    raw = semantic_roll.get("visible_pressure")
    if not isinstance(raw, dict) or str(raw.get("status") or "NONE") != "POISED":
        return None
    actor = " ".join(str(raw.get("actor") or "").split())[:100]
    action = " ".join(str(raw.get("action") or "").split())[:260]
    relation = str(raw.get("relation") or "NONE")
    consequence = str(raw.get("consequence") or "other")
    if not action or relation not in {"CONTESTED", "PARALLEL", "YIELDED"}:
        return None
    if consequence not in {"alert", "route_closure", "withdrawal", "other"}:
        consequence = "other"
    return {
        "actor": actor,
        "action": action,
        "relation": relation,
        "consequence": consequence,
    }


def apply_action_consequences(
    state: dict[str, Any],
    semantic_roll: dict[str, Any] | None,
    resolved_event: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Advance immediate attention and one already-visible poised world action.

    This is deliberately downstream of the ordinary resolver.  It never changes
    the player's roll or destination: a parallel alarm action can complete behind
    a successful escape, while a directly contested action is interrupted by that
    success. No extra model call is introduced.
    """

    event = resolved_event
    roll = _event_roll(event)
    outcome = str((roll or {}).get("outcome") or "")
    attention = (
        str(semantic_roll.get("critical_failure_attention") or "NONE")
        if isinstance(semantic_roll, dict)
        else "NONE"
    )
    attention_result: dict[str, Any] | None = None
    if outcome == "critical_failure" and attention in {"noise", "alert"}:
        stealth = _raise_local_attention(
            state,
            level="elevated" if attention == "alert" else "low",
        )
        attention_result = {
            "kind": attention,
            "local_alert": str(stealth.get("local_alert") or "none"),
            "suspicion": int(stealth.get("suspicion", 0) or 0),
        }

    pressure = _pressure_payload(semantic_roll)
    pressure_result: dict[str, Any] | None = None
    if pressure is not None:
        relation = pressure["relation"]
        success = bool((roll or {}).get("success")) if roll is not None else True
        interrupted = relation == "CONTESTED" and success
        result = "interrupted" if interrupted else "completed"
        pressure_result = {
            **pressure,
            "result": result,
            "resolved_at_turn": int(state.get("turn_no", 0) or 0),
        }
        state["scene_pressure"] = dict(pressure_result)
        history = state.setdefault("scene_pressure_history", [])
        if isinstance(history, list):
            history.append(dict(pressure_result))
            del history[:-8]
        if result == "completed" and pressure["consequence"] == "alert":
            stealth = _raise_local_attention(state, level="elevated")
            pressure_result["local_alert"] = str(stealth.get("local_alert") or "elevated")

    if attention_result is None and pressure_result is None:
        return event
    if not isinstance(event, dict):
        event = {"type": "scene_pressure_resolution", "committed": True}
    if attention_result is not None:
        event["attention_consequence"] = attention_result
    if pressure_result is not None:
        event["foreground_pressure"] = pressure_result
    return event
