from __future__ import annotations

from .spatial_scope import has_bounded_geometry
from .party import PARTY_ACTION_SCHEMA, party_advice, roster_context

import hashlib
import json
import re
from typing import Any, TYPE_CHECKING

from .economy import service_kind_for_item
from .items import (
    matching_inventory_item,
    pending_commerce_offer,
    silver_amounts,
    stated_amounts,
)
if TYPE_CHECKING:
    from .local_model import LocalQwen
from .movement import active_site_root_id, is_capability_question
from .scenarios import semantic_scenario_context
from .state import current_location
from .active_situations import risk_context as active_situation_risk_context


ENABLE_ADJUDICATION_REVIEW: bool = True


_DIFFICULTY_BANDS = {
    "easy": (10, 11),
    "standard": (12, 13, 14),
    "hard": (15, 16, 17),
    "extreme": (18, 19),
}
_DIFFICULTY_DEFAULTS = {"easy": 10, "standard": 13, "hard": 15, "extreme": 18}

_EXPLICIT_OFFER_ACCEPTANCE = re.compile(
    r"(?:^\s*(?:yes|agreed|deal|done)\b|"
    r"\b(?:i\s+(?:accept|agree|pay|will\s+(?:pay|take)|take\s+it)|"
    r"i['’]ll\s+(?:pay|take)|"
    r"pay\s+(?:him|her|them|the\b)))",
    re.I,
)
_EXPLICIT_OFFER_REFUSAL = re.compile(
    r"\b(?:not|never|don'?t|do\s+not|won'?t|will\s+not|refuse|decline)\b",
    re.I,
)

_MALFORMED_DESTINATION_LEAD = re.compile(
    r"^(?:(?:let'?s|i|we)\s+)?(?:get|go|walk|move|travel|head|reach|enter|approach|"
    r"climb|descend|follow|sail|ride|run|cross|jump|leap|vault|scramble|flee|escape)\b",
    re.I,
)
_MALFORMED_DESTINATION_CLAUSE = re.compile(
    r"(?:[()]|\b(?:one|any)\s+of\b|\b(?:if\s+possible|though|because|so\s+that|"
    r"in\s+order\s+to)\b)",
    re.I,
)
_MALFORMED_DESTINATION_END = re.compile(
    r"\b(?:to|into|onto|towards?|through|inside|outside|for|at|in|on|up|down)$",
    re.I,
)
_MALFORMED_ACTOR_POSITION = re.compile(
    r"(?:'s|\b(?:his|her|their|its)\b).{0,40}\b(?:position|location|side)\b$",
    re.I,
)


def _difficulty_dc(value: Any, draw: int | None = None) -> tuple[str, int]:
    difficulty = str(value or "standard")
    if difficulty not in _DIFFICULTY_BANDS:
        difficulty = "standard"
    if draw is None:
        return difficulty, _DIFFICULTY_DEFAULTS[difficulty]
    band = _DIFFICULTY_BANDS[difficulty]
    return difficulty, band[max(0, int(draw)) % len(band)]


def _difficulty_draw(state: dict[str, Any], player_text: str) -> int:
    """Stable per campaign beat/action; never advances the gameplay RNG."""

    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else {}
    action = " ".join(str(player_text or "").casefold().split())
    material = (
        f"{state.get('campaign_id', '')}:{state.get('rng_seed', '')}:"
        f"{state.get('turn_no', 0)}:{state.get('current_location_id', '')}:"
        f"{position.get('id', '')}:{action}:d20-difficulty-v1"
    ).encode("utf-8")
    return hashlib.sha256(material).digest()[0]


OPPONENT_PROFILE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "max_hp": {"type": "integer", "minimum": 4, "maximum": 24},
        "STR": {"type": "integer", "minimum": 6, "maximum": 20},
        "AGI": {"type": "integer", "minimum": 6, "maximum": 20},
        "SOC": {"type": "integer", "minimum": 6, "maximum": 20},
        "ARC": {"type": "integer", "minimum": 6, "maximum": 20},
        "PER": {"type": "integer", "minimum": 6, "maximum": 20},
        "armor_name": {"type": "string", "maxLength": 80},
        "armor_value": {"type": "integer", "minimum": 0, "maximum": 4},
        "humanoid": {"type": "boolean"},
        "authority": {"type": "boolean"},
        "basis": {"type": "string", "maxLength": 180},
        "enemy_count": {"type": "integer", "minimum": 1, "maximum": 5, "description": "Number of distinct enemies in this group (e.g. 2 for 'two guards'). Defaults to 1."},
        "is_caster": {
            "type": "boolean",
            "description": "True ONLY if this opponent actively wields magic or spells in the scene; false for ordinary soldiers, guards, brawlers, beasts.",
        },
        "spells": {
            "type": "array",
            "items": {"type": "string", "maxLength": 30},
            "maxItems": 3,
            "description": "1 to 3 canonical spell names if is_caster is true (e.g. Flamma, Aqua, Terra, Aero, Aegis, Metus, Caligo, Vitae Drain); empty list [] if false.",
        },
    },
    "required": [
        "max_hp", "STR", "AGI", "SOC", "ARC", "PER", "armor_name", "armor_value",
        "humanoid", "authority", "basis", "enemy_count", "is_caster", "spells"
    ],
    "additionalProperties": False,
}
OPPONENT_ASSESSMENT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        **OPPONENT_PROFILE_SCHEMA["properties"],
        "weapon_name": {"type": "string", "maxLength": 80},
        "weapon_mode": {"type": "string", "enum": ["melee", "ranged"]},
        "weapon_bonus": {"type": "integer", "minimum": -1, "maximum": 4},
        "weapon_natural": {"type": "boolean"},
        "affliction": {"type": "string", "enum": ["NONE", "poisoned", "arcane_drain"]},
    },
    "required": [
        *OPPONENT_PROFILE_SCHEMA["required"],
        "weapon_name", "weapon_mode", "weapon_bonus", "weapon_natural", "affliction",
    ],
    "additionalProperties": False,
}
ITEM_ASSESSMENT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "kind": {
            "type": "string",
            "enum": ["weapon", "armor", "tool", "consumable", "valuable", "clothing", "document", "misc"],
        },
        "weapon_mode": {"type": "string", "enum": ["NONE", "melee", "ranged"]},
        "weapon_bonus": {"type": "integer", "minimum": 0, "maximum": 4},
        "armor_value": {"type": "integer", "minimum": 0, "maximum": 4},
        "bulk": {"type": "number", "minimum": 0.1, "maximum": 8.0},
        "is_magical": {"type": "boolean"},
        "stat_assist": {
            "type": "string",
            "enum": ["NONE", "STR", "AGI", "SOC", "ARC", "PER"],
        },
        "affordances": {
            "type": "array",
            "items": {"type": "string", "maxLength": 30},
            "maxItems": 4,
        },
        "charges": {"type": "integer", "minimum": 0, "maximum": 10},
        "basis": {"type": "string", "maxLength": 160},
    },
    "required": [
        "kind", "weapon_mode", "weapon_bonus", "armor_value", "bulk",
        "is_magical", "stat_assist", "affordances", "charges", "basis"
    ],
    "additionalProperties": False,
}
COMPANION_PROFILE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "name": {
            "type": "string",
            "maxLength": 60,
            "description": "The companion's proper name. Use existing name if established; otherwise invent an authentic setting-appropriate first name.",
        },
        "max_hp": {"type": "integer", "minimum": 6, "maximum": 20},
        "STR": {"type": "integer", "minimum": 6, "maximum": 20},
        "AGI": {"type": "integer", "minimum": 6, "maximum": 20},
        "SOC": {"type": "integer", "minimum": 6, "maximum": 20},
        "ARC": {"type": "integer", "minimum": 6, "maximum": 20},
        "PER": {"type": "integer", "minimum": 6, "maximum": 20},
        "armor_name": {"type": "string", "maxLength": 80},
        "armor_value": {"type": "integer", "minimum": 0, "maximum": 4},
        "weapon_name": {"type": "string", "maxLength": 80},
        "weapon_mode": {"type": "string", "enum": ["melee", "ranged"]},
        "weapon_bonus": {"type": "integer", "minimum": -1, "maximum": 3},
        "silver": {"type": "integer", "minimum": 0, "maximum": 30},
        "appearance": {
            "type": "string",
            "maxLength": 220,
            "description": "Physical description including specific facial traits and general physique.",
        },
        "character_trait": {"type": "string", "maxLength": 120},
    },
    "required": [
        "name", "max_hp", "STR", "AGI", "SOC", "ARC", "PER",
        "armor_name", "armor_value", "weapon_name", "weapon_mode", "weapon_bonus",
        "silver", "appearance", "character_trait",
    ],
    "additionalProperties": False,
}

CHASE_ADVICE_SCHEMA: dict[str, Any] = {
    "type": "string",
    "enum": ["NONE", "START", "PURSUE", "INTERCEPT", "CAPTURE", "YIELD", "ABANDON"],
    "description": "START when the player now pursues a visibly fleeing figure or flees an established pursuer. When the quarry is the player, PURSUE means an active escape tactic (including hiding), not chasing the pursuer; YIELD means neglecting the threat. When active_situation is an active chase, do not use NONE: use PURSUE, INTERCEPT (cutting off/shortcutting), CAPTURE (grabbing/tackling/taking the stake at contact), ABANDON, or YIELD.",
}
CHASE_SETUP_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "quarry": {"type": "string", "maxLength": 80},
        "stake": {"type": "string", "maxLength": 100},
        "escape": {"type": "string", "maxLength": 100},
        "anchor": {"type": "string", "maxLength": 120},
    },
    "required": ["quarry", "stake", "escape", "anchor"],
    "additionalProperties": False,
}

RISK_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "intent": {"type": "string"},
        "voyage_action": {"type":"string", "enum":["NONE","BOARD","WAIT_DEPARTURE","WAIT","FINISH","DISEMBARK","RESOLVE_INCIDENT"],
            "description":"Optional paid-voyage intent. FINISH skips to the next incident or arrival; payment alone is NONE. RESOLVE_INCIDENT is only a substantive tactic that can settle the recorded hazard: judge its ordinary player roll, never use it for mere waiting/hiding. Brief actions/questions are NONE. The engine alone draws travel danger."},
        "passage_details": {"type":"object", "properties":{
            "destination_name":{"type":"string","maxLength":100},
            "vessel_name":{"type":"string","maxLength":120},
            "departure_label":{"type":"string","maxLength":120},
            "duration_label":{"type":"string","maxLength":120}},
            "required":["destination_name","vessel_name","departure_label","duration_label"], "additionalProperties":False},
        "requires_roll": {"type": "boolean"},
        "stat": {"type": "string", "enum": ["NONE", "STR", "AGI", "SOC", "ARC", "PER"]},
        "acting_companion": {"type": "string", "maxLength": 80, "description": "Use the canonical name from companions for the character actually acting; NONE for the player. A person being recruited or spoken to is not the acting companion."},
        "party_action": PARTY_ACTION_SCHEMA,
        "difficulty": {
            "type": "string",
            "enum": ["NONE", "easy", "standard", "hard", "extreme"],
        },
        "reason": {"type": "string"},
        "movement_commitment": {
            "type": "string",
            "enum": ["NONE", "COMMITTED"],
        },
        "destination": {
            "type": "string",
            "maxLength": 80,
        },
        "destination_scope": {"type": "string", "enum": ["NONE", "LOCAL", "WORLD"]},
        "mass_combat_active": {
            "type": "boolean",
            "description": "True if the GM narrative or player action implies a large-scale battle (more than 5 combatants, sieges, boarding actions, etc.) is currently ongoing around the player."
        },
        "pending_voyage_destination": {
            "type": "string",
            "description": "If the player is CURRENTLY in transit (via ship, carriage, caravan, or any long journey) to a distant region, island, or city (even if not arriving this turn), output the destination name here. Otherwise output NONE.",
            "maxLength": 80
        },
        "movement_dependency": {
            "type": "string", "enum": ["NONE", "ROLL", "INDEPENDENT"]
        },
        "recovery_intent": {
            "type": "string", "enum": ["NONE", "SEEK", "REST"]
        },
        "npc_scene_occupied": {"type": "boolean"},
        "npc_seed_density": {"type": "string", "enum": ["ordinary", "sparse"]},
        "harm_affliction": {
            "type": "string",
            "enum": ["NONE", "untreated_wound", "poisoned", "arcane_drain"],
        },
        "critical_failure_harm": {"type": "integer", "minimum": 0, "maximum": 2},
        "critical_failure_attention": {
            "type": "string",
            "enum": ["NONE", "noise", "alert"],
        },
        "pressure_completion": {"type": "string", "maxLength": 260},
        "pressure_relation": {
            "type": "string",
            "enum": ["NONE", "CONTESTED", "PARALLEL", "YIELDED"],
        },
        "pressure_alert": {"type": "boolean"},
        "combat": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["NONE", "attack", "defend", "flee", "surrender"]},
                "target": {"type": "string"},
                "attack_mode": {"type": "string", "enum": ["NONE", "melee", "ranged"]},
                "situational": {
                    "type": "object",
                    "properties": {
                        "scope": {"type": "string", "enum": ["NONE", "player_attack", "player_defense", "flee"]},
                        "modifier": {"type": "integer", "minimum": -2, "maximum": 2},
                        "reason": {"type": "string"},
                    },
                    "required": ["scope", "modifier", "reason"],
                    "additionalProperties": False,
                },
                "opponent_weapon": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "mode": {"type": "string", "enum": ["NONE", "melee", "ranged"]},
                    },
                    "required": ["name", "mode"],
                    "additionalProperties": False,
                },
            },
            "required": ["action", "target", "attack_mode", "situational", "opponent_weapon"],
            "additionalProperties": False,
        },
        "resource_action": {
            "type": "object",
            "properties": {
                "kind": {
                    "type": "string",
                    "enum": [
                        "NONE", "browse", "take", "drop", "give_item", "consume",
                        "equip", "unequip", "purchase", "sell", "pay",
                        "receive_item", "receive_money", "haggle"
                    ],
                },
                "status": {
                    "type": "string",
                    "enum": ["NONE", "inquiry", "offered", "confirmed", "refused", "ambiguous"],
                },
                "item": {"type": "string"},
                "service_type": {"type": "string", "enum": ["NONE", "passage"],
                    "description": "passage only for buying/paying passenger transport. NONE for other goods/services, including supplies for a ship."},
                "item_kind": {
                    "type": "string",
                    "enum": [
                        "NONE", "misc", "food", "drink", "tool", "key", "document",
                        "weapon", "armor", "clothing", "consumable", "valuable", "service"
                    ],
                },
                "other_pickup": {"type": "string", "maxLength": 100,
                    "description": "A second distinct item or currency taken alongside item. Empty if none."},
                "quantity": {"type": "integer", "minimum": 1, "maximum": 20},
                "amount": {"type": "integer", "minimum": 0, "maximum": 100000},
                "counterparty": {"type": "string"},
                "timing": {"type": "string", "enum": ["none", "immediate", "on_success"]},
                "reason": {"type": "string"},
            },
            "required": [
                "kind", "status", "item", "item_kind", "quantity", "amount",
                "counterparty", "timing", "reason", "service_type", "other_pickup"
            ],
            "additionalProperties": False,
        },
        "magic": {
            "type": "object",
            "properties": {
                "is_magic": {"type": "boolean"},
                "intent": {"type": "string", "enum": ["cast", "learn", "NONE"]},
                "actor": {"type": "string", "maxLength": 80},
                "spell_name": {"type": "string", "maxLength": 40},
                "power_tier": {"type": "string", "enum": ["NONE", "minor", "standard", "major", "extreme"]},
                "target": {"type": "string", "maxLength": 80},
                "hostile": {"type": "boolean"},
                "intended_effect": {"type": "string", "maxLength": 240},
            },
            "required": ["is_magic", "spell_name", "power_tier", "target", "hostile", "intended_effect"],
            "additionalProperties": False,
        },
        "chase": CHASE_ADVICE_SCHEMA,
        "scenario_flags": {
            "type": "array",
            "items": {"type": "string", "maxLength": 80},
            "maxItems": 3,
        },
    },
    "required": [
        "intent", "requires_roll", "stat", "difficulty", "reason", "movement_commitment",
        "destination", "destination_scope",
        "movement_dependency", "recovery_intent",
        "npc_scene_occupied", "npc_seed_density",
        "harm_affliction",
        "critical_failure_harm", "critical_failure_attention",
        "pressure_completion", "pressure_relation", "pressure_alert",
        "combat", "resource_action", "party_action", "acting_companion", "chase", "scenario_flags", "magic", "mass_combat_active"
    ],

    "additionalProperties": False,
}

DESTINATION_REPAIR_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "movement_commitment": {
            "type": "string", "enum": ["NONE", "COMMITTED"]
        },
        "destination": {"type": "string", "maxLength": 80},
        "destination_scope": {
            "type": "string", "enum": ["NONE", "LOCAL", "WORLD"]
        },
    },
    "required": ["movement_commitment", "destination", "destination_scope"],
    "additionalProperties": False,
}

WORLD_BEAT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "advance": {"type": "boolean"},
        "actor": {"type": "string"},
        "action": {"type": "string"},
        "hostile_attack": {"type": "boolean"},
        "weapon_name": {"type": "string"},
        "weapon_mode": {"type": "string", "enum": ["NONE", "melee", "ranged"]},
    },
    "required": [
        "advance", "actor", "action", "hostile_attack", "weapon_name", "weapon_mode"
    ],
    "additionalProperties": False,
}

ADJUDICATION_REVIEW_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "approved": {"type": "boolean"},
        "review_note": {"type": "string", "maxLength": 300},
        "corrections": {
            "type": "object",
            "properties": {
                "intent": {"type": "string", "maxLength": 240},
                "requires_roll": {"type": "boolean"},
                "stat": {"type": "string", "enum": ["NONE", "AGI", "STR", "SOC", "ARC", "PER"]},
                "difficulty": {"type": "string", "enum": ["NONE", "easy", "standard", "hard", "extreme"]},
                "reason": {"type": "string", "maxLength": 300},
                "movement_commitment": {"type": "string", "enum": ["NONE", "COMMITTED"]},
                "destination": {"type": "string", "maxLength": 80},
                "destination_scope": {"type": "string", "enum": ["NONE", "LOCAL", "WORLD"]},
                "acting_companion": {"type": "string", "maxLength": 80},
                "recovery_intent": {"type": "string", "enum": ["NONE", "SEEK", "REST"]},
                "combat": RISK_SCHEMA["properties"]["combat"],
                "resource_action": {k: v for k, v in RISK_SCHEMA["properties"]["resource_action"].items() if k != "required"},
                "voyage_action": RISK_SCHEMA['properties']['voyage_action'],
                "critical_failure_harm": {"type": "integer", "minimum": 0, "maximum": 2},
            },
            "additionalProperties": True,
        },
    },
    "required": ["approved"],
    "additionalProperties": False,
}

ADJUDICATION_REVIEW_SYSTEM = """
You are the senior adjudicator and referee for an open-ended tabletop RPG.
Your task is to independently review a proposed draft adjudication of the player's newest action.
Compare the draft against the recent scene, environment, established state, and the player's exact declared action.

Audit for common semantic omissions or misclassifications across all domains:
1. Rolls & Action Risk:
   - Does the action face genuine uncertainty, passive/active resistance, environmental obstacles, or meaningful stakes that the draft missed? (e.g. attempting to overhear private/hushed talk without detection -> PER; pressing or deceiving guarded/wary people -> SOC; covert movement or navigating hazards -> AGI; forced obstacles -> STR; arcane interpretation -> ARC).
   - Conversely, did the draft mistakenly demand a roll for a routine, safe, unpressured action or casual conversation? If so, requires_roll should be false.
2. Movement & Space:
   - Did the draft overlook or invent a physical destination, or misjudge whether it is LOCAL (within current site) or WORLD (leaving to a new building/district)? Preserve the chosen landing place, including during flight.
3. Resources, Party, Combat & Magic:
   - Was a transfer, recruitment, attack, or magical effect overlooked? For a mixed pickup, name the additional object or currency in other_pickup. Repeated copies only affect quantity.
4. Recorded voyage incident:
   - Use authoritative_state, not narrated success, to determine whether the hazard remains unresolved.
   - A concrete attempt to overcome the recorded storm/boarding threat needs its ordinary uncertain-action roll even without the words test, roll, or a stat name. Set voyage_action=RESOLVE_INCIDENT only if the tactic can settle that hazard, and choose stat/difficulty from the actual tactic and stakes.
   - Waiting, watching, sheltering, unrelated checks, and merely claiming success do not resolve it. Do not force rolls on those actions just because a storm exists.
   - For concrete bodily exposure use the existing critical_failure_harm bounds (0-2); do not invent extra damage or a weather roll.

If the draft adjudication is accurate, faithful, and fair:
Return: {"approved": true}

If anything was overlooked, misclassified, or misjudged:
Return: {"approved": false, "review_note": "Concise explanation of the oversight", "corrections": { ...only the corrected fields... }}
""".strip()

RISK_SYSTEM = """
Paid voyage fields are optional for backwards compatibility. With an authoritative
voyage in context, set voyage_action: BOARD for actual embarkation, WAIT_DEPARTURE
for waiting for the sailing time, WAIT for sustained waiting/sleep aboard, FINISH
for skipping the crossing until an incident or arrival, DISEMBARK for going ashore.
Use NONE for ordinary brief actions, questions, negated actions and short waits.
RESOLVE_INCIDENT means a substantive tactic that can actually settle the recorded
voyage hazard, not merely waiting, hiding from it, or saying it is over. Judge
its risk normally and require the player's ordinary roll when uncertain. Do not
invent a new hazard die: the engine draws it. Pending voyage pressure prevents
unearned recovery/time skipping. Payment is only booking, never a WORLD arrival.
For resource_action use service_type=passage for a passenger fare, regardless of
the player's wording; NONE for all other purchases/payments. Confirm only an actual
acceptance, not a question, refusal, or undecided action. Matching silver alone is
not consent. passage_details.destination_name identifies the destination in the
quoted offer (empty if unresolved); preserve exact vessel/departure/duration wording.
passage_details may repeat exact vessel/departure/duration wording from the grounded
quote; use empty strings for unknown details. Do not invent timings or vessels.
You are the semantic action-risk judge for an open-ended tabletop RPG. Return
the small JSON object only. Judge what the player is actually attempting in
the current scene, not isolated keywords.

A general D20 roll is required only when both are true:
1. success is genuinely uncertain; and
2. failure would have a meaningful immediate consequence.

CHASE CHECK FIRST: chase is normally NONE. If recent_scene says a figure is actively fleeing and the
player now follows, runs after, pursues, intercepts or tries to catch that same
figure, return START. Also return START when the player flees an established
pursuer: the player is then the quarry, identified as Visitor in chase setup. Example:
a courier bolts through a market with a stolen case toward a gate, then the
player sprints after the courier -> START. During an active_situation chase use
PURSUE, INTERCEPT or CAPTURE;
use ABANDON only when explicitly stopped and YIELD for a substantive unrelated
action. When the player is the quarry, PURSUE means actively escaping, hiding
from pursuers, or breaking line of sight; never classify an escape tactic as
YIELD merely because the player is not pursuing someone. Keep movement and
resource fields independent so entering a building or handling an item is
resolved alongside the chase. One success changes one beat; capture requires contact.

mass_combat_active is true only if the exact scene or player action describes an ongoing large-scale battle, siege, or ship boarding action with multiple combatants fighting around the player; otherwise false.

Questions, looking at plainly visible things, remembering, harmless
preparation, ordinary walking or running without pressure, and casual
conversation require no roll. Do not make routine actions uncertain merely to
add drama. Conversely, never grant a risky action merely because the player
states it confidently.

A feasibility question such as "Can I climb that tree?" asks only whether the
action looks possible; it does not attempt the climb, move the player, or roll.
Only a later committed action such as "I climb it" can do that.

Being witnessed, illegal, insulting, destructive, or likely to provoke later
consequences does not by itself make the immediate physical act uncertain. If
an ordinary act can plainly be completed before anyone reacts, require no roll
and let the narrator handle the aftermath. Require a roll only when someone is
already able and likely to interrupt it or another concrete obstacle makes
completion uncertain. Do not invent a hidden goal such as "without being seen"
when the player explicitly acts openly or in front of witnesses.

Typical rolls: dangerous climbing or jumping, fleeing immediate pursuit,
stealth, lockpicking, consequential persuasion/deception/intimidation,
eavesdropping without detection, searching for a genuinely hidden significant
detail, forcing resistance, and difficult arcane interpretation.

Stat guide: AGI for climbing, jumping, stealth, locks and escape; STR for
force; SOC for consequential social pressure; PER for concealed clues,
tracking and eavesdropping; ARC for difficult magic or occult interpretation.
Choose a qualitative difficulty from concrete conditions, not from the action
verb or habit: easy for an advantageous but consequential attempt, standard
for one ordinary source of uncertainty, hard for strong resistance or multiple
serious compounding hazards, and extreme only for exceptional difficulty.
Improvised or freeform magic (e.g. arcane imbuement on items, or invocation of deities)
is a valid ARC action. Escalate the difficulty (Hard/Extreme) for broad or powerful effects.
If the action is a Social (SOC) interaction and the target NPC's established
attitude is hostile, suspicious, or unfriendly, strictly escalate the difficulty
by at least one band (e.g. standard -> hard) to reflect mechanical resistance.
Compare height, footing, resistance, visibility, tools and immediate failure
cost; do not default to standard merely because a roll is required. Three
independent serious hazards with no stated mitigation should not remain
standard; an unlit vertical descent on visibly failing supports is hard unless
precautions materially reduce it. If no roll is required, return stat NONE and
difficulty NONE. Do not narrate or resolve the action.
For combat, set combat.action to 'attack' if the player attacks OR organically prepares a hostile ambush/aggressive threat (e.g. "I draw my dagger and wait behind the door"). Do not wait for a literal "I attack" command.
Formal spells and transactions have separate Python systems; classify their risk
normally, but do not invent their mechanics.
When an action involves magic, spellcasting, or arcane intent, optionally output the magic object:
- is_magic: true.
- intent: "cast" for casting or invoking, or "learn" for studying, deciphering, or learning an arcane spell.
- actor: canonical name of the caster ("player", or companion name).
- spell_name: closest canonical spell name (Flamma, Aqua, Terra, Aero, Praecognitio, Retrocognitio, Revelatio, Communico, Firmitas, Celeritas, Lucis, Umbra, Sanus, Purifico, Restituo, Fallacia, Persuadeo, Metus, Caligo, Umbrae, Exanimus, Spiritus, Vitae Drain, Aegis, Warda, Reflecto, Virentia, Loquor Bestia, Dominus Naturae) or "NONE".
- power_tier: "minor" (spark/candle/subtle), "standard" (focused scene working), "major" (wall/wave/barrier/powerful), "extreme" (vast/cataclysmic/island-wide), or "NONE".
- target: concrete target person, object, or space (e.g. "dock guard", "oil wagon", "self"), or "NONE".
- hostile: true if combative/harmful/offensive; false if utility, defensive, healing, or peaceful.
- intended_effect: concise summary of the intended magical result.


Treat an explicit end-to-end movement such as "run all the way outside by the
route I entered" as one intention and one roll, not one roll per room. Price its
combined exposure: a known clear route with one active danger uses the critical
danger's normal band; raise one band only when multiple independent obstacles
or hostile interception points genuinely compound the attempt. On success the
destination is the stated final endpoint, not the first intermediate room.

Also classify movement_commitment: COMMITTED when the player is physically
changing position now, asks to fast-forward during a journey, OR clearly
expresses a collaborative or direct intention to approach, enter, or walk toward
a specific building, space, or location immediately (e.g. "Let's approach the estate").
Use NONE for future plans, agreeing to meet somewhere later, mentioning a destination
in dialogue, vague questions, pure surveys from a distance, or searches for
whether a possible destination exists without intending to go there yet.
For an object/person approach inside a planned site, use its exact established
parent area as destination; keep the object detail in narration. Do not mint a
room for a desk, counter or person. If the parent area is not established, leave
the endpoint unresolved rather than inventing access or guessing a room.
An open region's existing map is extensible, not a bounded room whitelist.
Approaching a moored ship stays ashore; BOARD requires actual boarding intent.
Closing distance only to speak with, inspect or use an already-present person
or object is not a new spatial destination unless the player actually changes
to a distinct stable local place.
With COMMITTED, destination is the short physical place where the player ends,
never an action, request, qualifier, or purpose clause: "climb up a roof" ->
"Roof"; "vault onto the balcony" -> "Balcony". Surveying whether any two-storey
building is easy to enter is NONE with an empty destination. Committing to one
of the richer houses, unguarded if possible, may be "Affluent Residence". A
bare UI-like phrase such as "Travel To" is NONE. When approaching or entering an unplanned structure or vessel from outside, name the structure itself (e.g. "Weathered Boathouse") without appending "Interior".

Also classify destination_scope. Use LOCAL when the endpoint remains within the
current physical site or is only a local vantage/micro-position (a floor,
landing, roof, corridor, room, balcony, nearby alcove, etc.). If the context
names a bounded_site, a newly phrased internal endpoint such as "Upper Levels"
stays LOCAL unless the player is actually leaving that site. Use WORLD when the
movement leaves the current bounded site or travels to another building,
district, street system, island, settlement, or broader place. Use NONE when
there is no committed movement. This is spatial ownership, not distance: a
farther room in the same building is LOCAL; stepping outside that building is
WORLD. When leaving a bounded site, derive the exterior landing name from the
chosen endpoint in the action and current scene. Preserve a named district when fleeing there.

Also classify movement_dependency. Use NONE with no destination. Use ROLL when
reaching the destination is itself uncertain (climbing, fleeing, sneaking in,
or finding a route). Use INDEPENDENT when ordinary movement is completed before
a separate uncertain follow-up: for example, entering a hold and then searching
its cargo. That arrival remains real even if the follow-up roll fails.

recovery_intent: REST when the player explicitly rests, OR organically engages in
restorative downtime (e.g. sitting in a tavern, binding wounds, eating, or
relaxing in a safe space). SEEK when finding or arranging somewhere to rest
later; otherwise NONE. SEEK never heals.
Accepting an already offered room/service price is confirmed purchase and NONE.

Resolve a clear "do it" or "try again" from the immediately preceding exchange.
If a committed combat action also physically changes the player's position --
for example dropping from a roof onto a guard below -- return the landing/end
place, not the target person. For a stationary strike or shot, leave destination
empty. For a multi-stage departure, return the intended final place, not an
intermediate door, skylight or roof. A broad but explicit endpoint such as
getting lost in the city is still movement; normalize it to a useful physical
label such as "Aether Harbor Streets" rather than leaving it empty. Otherwise
return an empty string. If the player says another, next, or adjacent rooftop,
room, deck, or similar local position, preserve that distinction instead of
returning the broader current site.

Combat is resolved separately but needs a compact semantic reading. Set combat
action to attack, defend, flee, or surrender only when that is the player's
actual present action; otherwise NONE. Give a concise target and melee/ranged
mode when applicable. An instruction or threat inside the player's speech that
tells someone else to cut, strike, or harm a target is dialogue, not the
player's attack. You may propose one situational modifier from -2 to +2:
+/-1 for a modest concrete edge or hindrance, +/-2 only when it dominates this
single roll. It must be grounded in a currently visible fact such as footing,
cover, reach, surprise, restraint, darkness, crowding, height, a condition, or
the player's described tactic. Stats, class, training, general competence,
eloquence alone, or speculative facts are not situational modifiers. Scope it
only to player_attack, player_defense, or flee; otherwise use NONE and 0.
Opponent weapon may name a manufactured weapon only if recent narration
explicitly established that this opponent holds or uses it. Otherwise leave
its name empty and mode NONE. A separate relevant-only assessment owns a new
opponent's lasting stats and natural anatomy; do not invent those here or
decide combat results.

If active_scenario is present, scenario_flags contains only exact allowed flag
ids whose described accomplishment the player actually completes now. A mere
attempt that requires a roll may be listed because Python commits it only after
success. Questions, plans, mentions and partial setup do not earn a flag. Use
an empty list when nothing is completed.

Party relationships use party_action independently of resource_action. Use
party_action.action NONE unless the player is presently recruiting a companion
to join the party or dismissing an existing companion (leave target empty and
status NONE when action is NONE). Buying ship passage, paying a clerk/merchant,
boarding a vessel, or ordinary dialogue with an NPC is NEVER a party_action.
Recruit means agreeing to accompany/work with the player as companion or
accomplice, even for one job or a share of loot; dismiss means parting ways.
Use offered for a proposal awaiting the NPC's reply, confirmed when both sides
already accept. Preserve the exact NPC name/descriptor as target. amount is only
an agreed immediate silver fee (0 for unpaid cooperation or a future share).
timing is on_success for a contested agreement, immediate for an accepted one,
none otherwise. Mere questions, hypotheticals and rejected proposals do not
recruit. A person's recruitment is never an inventory item, purchase or generic
pay. The party has room for one companion. Never assume someone has already joined.

Roll ownership: companions lists the active party. When the player delegates
the actual attempt to a listed companion, acting_companion is their canonical
name (resolve descriptors/pronouns from the scene). Judge that actor's risk.
When the player acts or when the player/party ('I', 'we') moves or acts together—even following a companion's lead or talking to/about a companion—use NONE.
Routine companion actions need no roll. For an actual companion attack use
combat.action attack; the engine rolls for the companion. Do not invent NPC rolls.

Resource actions are semantic bookkeeping advice, never narration. Use NONE
unless the player is presently doing or explicitly asking about one of these:
- browse means inspecting goods or asking generally what is available;
- take means physically taking and keeping an accessible object;
  item names the first object, quantity counts its copies. In other_pickup name a second distinct object or currency actually acquired alongside it; otherwise leave it empty.
- drop includes putting down, discarding, or throwing away a carried object;
- give_item and consume physically remove a carried inventory item (never silver/coins);
- equip means wear, don, draw, ready, or wield; unequip means remove but keep;
- purchase/sell distinguish asking for a price from accepting/paying an active offer;
- pay includes an exact bribe, fee, wager, gift of money, or non-purchase payment;
- receive_item/receive_money require a concrete offered gift, reward, or payment;
- haggle is an attempt to alter an established price;

Set status inquiry for a question or requested quote, offered when the player
merely proposes terms, and confirmed only for an explicit present handover or
acceptance. Looking at, mentioning, showing, or using a reusable object does
not remove or acquire it. A quote, appraisal, promise, future reward, or stated
intention is not a transfer. Preserve the exact established item, quantity,
silver amount, and counterparty when known; never invent them. If possession,
availability, or an accepted price is unclear, use ambiguous. A contested
take or conditional handover uses timing on_success when the same action requires
a roll. Money physically released now (tossed, flicked, handed over, or paid)
uses pay + confirmed + timing immediate with the exact amount, even when the
separate SOC persuasion/bribery roll fails. A mere offer, promise or display of
coins is not payment; use offered and timing none. Never omit resource_action
just because the main action is social. Otherwise a confirmed transfer is immediate. Do not allow the player to
conjure an unestablished rare, magical, royal, or precious object simply by
saying they take it.

Manipulating a nearby scene prop without keeping or transferring it -- pouring
out a cup, moving a chair, opening a book -- is ordinary action, not resource
bookkeeping.

Also observe the resulting immediate scene. Set npc_scene_occupied true when a
specific NPC remains there or accompanies the player; otherwise false. Ignore
generic crowds, a distant figure, a mere mention, and an NPC left behind. When
genuinely uncertain, use true. Do not introduce anyone for this field.

Set npc_seed_density sparse only for a genuinely remote, uninhabited arrival
such as open wilderness, lonely ruins or open water; ordinary for settlements,
roads, buildings and inhabited sites. Judge the scene, not place-name keywords.

Set critical_failure_harm to 0 unless this general D20 attempt exposes the
player to a concrete immediate bodily hazard. Use 1 for a minor likely injury
and 2 only for severe falling, fire, collapse, drowning, or comparable danger.
Social actions, ordinary searches, stealth, and lock work use 0 unless the
scene establishes such a physical hazard.

Set harm_affliction only for a directly grounded lingering consequence:
untreated_wound for an exceptional serious physical wound; poisoned for explicit
toxin or venom exposure; arcane_drain only for an explicitly damaging lingering
spell, curse, or magical drain. A magical drain is not an untreated wound. This
is only potential: Python commits it after the relevant damaging failure. Use
NONE for ordinary hazards or when no such lasting consequence is established.

critical_failure_attention: noise for a noticeable disturbance, alert for a
witnessed failure/established alarm, otherwise NONE; independent of HP.

For at most one action visibly underway in the exact recent scene, give its
immediate completed outcome as a short subject-verb pressure_completion.
CONTESTED only if the player directly stops its actor/device/route; YIELDED for
wait/watch; otherwise PARALLEL. Use NONE, blank, false if none is pending or
last_resolved_visible_pressure resolved it. Never invent pressure.
pressure_alert is true only if completion itself raises local attention.

Always fill resource_action independently of requires_roll. In particular:
- "How much for that rope?" is purchase + inquiry + Rope, with no transfer;
- "What is the exact price of a bed for the night?" is purchase + inquiry +
  service; lodging is not inventory;
- when asking for or paying a ship fare/berth to a destination, include the
  destination in resource_action.item (e.g. "passage to Aiantindus on the Himeros")
  with item_kind service;
- after a supplied pending buy offer, "Agreed, I pay and take it" is purchase
  + confirmed using that offer's item and amount, not a generic pay action;
- "I snatch the customs seal before the watchman stops me" is both a risky
  action and take + confirmed + on_success. The roll and transfer fields must
  coexist whenever both apply.
""".strip()

DESTINATION_REPAIR_SYSTEM = """
You repair only malformed movement metadata from an RPG semantic judge. Return
JSON only. Decide whether the player's newest action commits to physically
changing position now. A question, survey, or search for whether any suitable
destination exists is NONE, even when it mentions entering or reaching one.

With COMMITTED, destination must be a short self-contained physical place noun
phrase. Preserve the specific chosen landing place, including when fleeing to a district.
For a generic selection, name the physical kind concisely: for example, "get
into one of the richer houses, unguarded if possible" becomes "Affluent
Residence". Never return an action label, an instruction, player wording with
parentheses, or a conditional/purpose clause. Use LOCAL for a position inside
the current bounded site; WORLD for another building, district, vessel, island,
settlement, or broader place. With NONE, destination is empty and scope is NONE.
For combat movement, never use an actor-relative label such as "Carrier's
Position"; use a stable physical landing place, or NONE if no new stable place
was reached.
""".strip()

WORLD_BEAT_SYSTEM = """
You are a sparse world-turn arbiter for an open-ended tabletop RPG, not its
narrator. Return JSON only. The supplied private current and exact recent scene
may describe an already visible pressure. Decide whether the player's newest
action genuinely yields time or initiative to that pressure.

Do not invent a threat, motive, actor, weapon, or consequence. If the pressure
is not visibly active, the actor is absent, the player is taking another
substantive action, or ordinary quiet can simply continue, set advance false.

If one clear warning or poised threat has already been ignored and the player
again waits, watches, or asks what the actor now does, advance the world by one
concrete state-changing action. Do not choose another warning, countdown,
threatening posture, approach, weapon touch, or partial draw. The actor may
begin an attack, summon aid, physically close or leave a route, withdraw, or
de-escalate according to the established drive. Choose freely from the fiction;
violence is never mandatory.

action is one concise author-side description of only what the world actor now
attempts. It must not decide the player's response or the result of an opposed
action. Set hostile_attack true only when the actor now initiates a physical
strike, shot, grapple, shove, or similarly immediate attack. Name a weapon only
if the recent scene explicitly established it. A separate relevant-only
assessment assigns natural weapons and combat statistics after this decision.
An attack stops before contact or injury because the combat engine will request
the player's defense separately.

""".strip()

OPPONENT_ASSESSMENT_SYSTEM = """
Assign one stable combat profile for a newly encountered RPG opponent from the
exact scene, then stop. Return JSON only. Calibrate against a 12--15 HP player.
Untrained person: HP 6--9, stats 8--12, weapon 0 or -1, armor 0. Armed ordinary
person: HP 8--11, stats 10--13, weapon 1, armor 0--1. Trained guard/veteran:
HP 10--14, stats 12--16, weapon 1--2, armor 1--2. Large dangerous creature or
elite: HP 13--18, stats 13--18, weapon 2--3, armor 0--3. Do not be artificially
mild. HP 20+, weapon 4 or armor 4 require a visibly extraordinary singular foe.

Manufactured equipment must be explicit in the exact scene. Infer claws,
fangs, horns, shell, scales and thick hide from an established nonhuman kind or
body; anatomy is a natural weapon and body protection is armor. Use Unarmed,
melee, -1 when a humanoid has no established weapon. authority means a lawful
official able to take custody. affliction must be NONE by default; use poisoned
only for explicit venom or toxin established in the scene, and arcane_drain
only for explicit lingering harmful magic. Ordinary weapons, guards, and
unarmed strikes must use NONE. basis is one terse grounded sentence.
enemy_count indicates how many distinct combatants of this exact profile are
present (e.g. 2 for "a pair of guards", max 5). Never invent a boss tier or
decide a combat result.

Magic and spells: is_caster is false and spells is [] by default for all ordinary foes,
guards, beasts, brawlers, and soldiers. Set is_caster true and list 1 to 3 canonical
spells ONLY if the opponent is established in the scene as practicing magic or sorcery
(e.g. pyromancer, witch, cultist ritualist, necromancer, arcane entity). Set ARC 14--18.
Official spells: Flamma (fire blast), Aqua (water/cold), Terra (earth/immobilize),
Aero (wind/push), Aegis (damage shield barrier), Metus (fear/panic/broken guard),
Caligo (confusion/wild strikes), Vitae Drain (life siphon), Umbra (darkness),
Lucis (blinding light), Sanus (healing), Purifico (cure poison/affliction).
""".strip()

COMPANION_PROFILE_SYSTEM = """
Assign a complete RPG character sheet for an NPC who is joining the player's party or crew.
Return JSON only.
Calibrate stats on a standard 6--20 scale (10 is average human, 14+ is skilled specialist, 16+ is exceptional):
- max_hp: typical human ally is 8--14 HP.
- STR, AGI, SOC, ARC, PER: reflect their trade, background and the current scene.
- weapon_name, weapon_mode (melee/ranged), weapon_bonus (-1 to +2): realistic weapon from their trade or scene.
- armor_name, armor_value (0 to 3): realistic clothing or armor.
- silver: modest pocket coins (0--15).
- name: The character's proper first name. If the character already has a proper name in the scene, use that exact name. If the character was only referred to by a descriptor or occupation (e.g. 'scarred dockworker', 'old sailor', 'guard'), invent one authentic, culturally fitting setting name for this person based on the island's culture and current scene (e.g. Bram, Theron, Kaelen, Lycus, Nikos, Kassandra, Soran, Amina).
- character_trait: One concise grounded trait or background detail.
""".strip()

CHASE_SETUP_SYSTEM = """
Extract one just-started RPG chase from the exact scene. Return only the fleeing
quarry, any known carried stake, the route or destination through which it may
escape, and the current physical route/terrain as anchor. Use "none known" for
an absent stake and a short concrete phrase for uncertain escape. Do not add a
plot, motive, outcome or new detail. When the fleeing quarry is the player,
use the stable quarry identifier "Visitor".
""".strip()

ITEM_ASSESSMENT_SYSTEM = """
Assign mechanics once to one newly acquired RPG item from its exact established identity and scene. Return JSON only. Do not use a fixed catalog.
- For a weapon choose melee/ranged and damage bonus: 1 ordinary, 2 military/quality, 3 exceptional, 4 extraordinary/masterwork.
- Armor is 1 light, 2 substantial, 3 heavy/plate, 4 extraordinary. Weapons have armor 0; armor has weapon mode NONE/bonus 0.
- bulk is abstract carried load: 0.1-0.5 small/light (amulet, ring, key, vial), 1 compact, 2 typical weapon, 2.5 typical armor, 4+ heavy.
- is_magical: true only if the established scene or description reveals magical/enchanted/arcane nature or relic status; false for mundane items.
- stat_assist: if the item grants a concrete edge when used (e.g. astrolabe for ARC, lockpicks for AGI, crowbar for STR, fine noble silks for SOC, spyglass/lantern for PER), specify that stat; otherwise NONE.
- affordances: list 1-3 useful mechanical action tags when applicable (e.g. light, climb, pick_lock, heal, cure_poison, detect_magic, ward, decipher); otherwise empty list.
- charges: 0 for permanent items or ordinary gear; 1-5 only if the magic/relic has limited uses.
- basis: ground the choice in one terse sentence based on scene evidence. Do not invent unmentioned enchantments.
""".strip()


_GROUND_STOPWORDS = {
    "about", "against", "being", "could", "from", "have", "into", "player", "their",
    "there", "these", "this", "through", "with", "would", "because", "while", "using",
}
_PROFILE_ONLY_WORDS = re.compile(
    r"\b(?:skilled|trained|experienced|strong|agile|fighter|thief|mage|competent|expert)\b",
    re.I,
)


def _meaningful_tokens(text: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[a-z0-9]+", text.casefold())
        if len(token) >= 4 and token not in _GROUND_STOPWORDS
    }


def _bounded_int(value: Any, minimum: int, maximum: int, default: int) -> int:
    try:
        return max(minimum, min(maximum, int(value)))
    except (TypeError, ValueError):
        return default


def _normalize_opponent_profile(payload: Any) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None
    basis = " ".join(str(payload.get("basis") or "").split())[:180]
    if not basis:
        return None
    armor_value = _bounded_int(payload.get("armor_value"), 0, 4, 0)
    armor_name = " ".join(str(payload.get("armor_name") or "None").split())[:80] or "None"
    if armor_value <= 0:
        armor_name = "None"

    is_caster = payload.get("is_caster") is True
    known_spells: list[str] = []
    if is_caster:
        from .magic import SPELLS
        raw_spells = payload.get("spells") or payload.get("known_spells") or []
        if isinstance(raw_spells, list):
            for s in raw_spells:
                s_clean = str(s).strip()
                s_key = s_clean.casefold().replace(" ", "_")
                for spell_id, spell_def in SPELLS.items():
                    if s_key in (spell_id, str(spell_def["name"]).casefold().replace(" ", "_")):
                        canonical_name = spell_def["name"]
                        if canonical_name not in known_spells:
                            known_spells.append(canonical_name)
                        break
        if not known_spells:
            known_spells = ["Flamma", "Caligo"]

    arc_default = 15 if is_caster else 10
    arc_stat = _bounded_int(payload.get("ARC"), 6, 20, arc_default)
    if is_caster and arc_stat < 14:
        arc_stat = 14

    return {
        "max_hp": _bounded_int(payload.get("max_hp"), 4, 24, 9),
        "STR": _bounded_int(payload.get("STR"), 6, 20, 11),
        "AGI": _bounded_int(payload.get("AGI"), 6, 20, 11),
        "SOC": _bounded_int(payload.get("SOC"), 6, 20, 10),
        "ARC": arc_stat,
        "PER": _bounded_int(payload.get("PER"), 6, 20, 10),
        "armor_name": armor_name,
        "armor_value": armor_value,
        "humanoid": payload.get("humanoid") is True,
        "authority": payload.get("authority") is True,
        "enemy_count": _bounded_int(payload.get("enemy_count"), 1, 5, 1),
        "is_caster": is_caster,
        "known_spells": known_spells,
        "basis": basis,
        "source": "gemma_semantic",
    }


def _normalize_chase_advice(payload: Any) -> dict[str, str]:
    empty = {"action": "NONE", "quarry": "", "stake": "", "escape": "", "anchor": ""}
    if isinstance(payload, str):
        parts = [" ".join(value.replace("\n", " ").split()) for value in payload.split("|", 4)]
        action = (parts[0] if parts else "NONE").upper()
        action_map = {
            "START": "start", "PURSUE": "pursue", "INTERCEPT": "intercept",
            "CAPTURE": "capture", "YIELD": "yield", "ABANDON": "abandon",
        }
        normalized = action_map.get(action, "NONE")
        values = (parts[1:] + ["", "", "", ""])[:4]
        result = {
            "action": normalized,
            "quarry": values[0][:80],
            "stake": values[1][:100],
            "escape": values[2][:100],
            "anchor": values[3][:120],
        }
        return result
    if not isinstance(payload, dict):
        return empty
    action = str(payload.get("action") or "NONE")
    if action not in {"NONE", "start", "pursue", "intercept", "capture", "yield", "abandon"}:
        action = "NONE"
    result = {
        "action": action,
        "quarry": " ".join(str(payload.get("quarry") or "").split())[:80],
        "stake": " ".join(str(payload.get("stake") or "").split())[:100],
        "escape": " ".join(str(payload.get("escape") or "").split())[:100],
        "anchor": " ".join(str(payload.get("anchor") or "").split())[:120],
    }
    if action == "start" and not result["quarry"]:
        return empty
    return result


def _normalize_scenario_flags(payload: Any, context: dict[str, Any] | None) -> list[str]:
    if not isinstance(context, dict) or not isinstance(payload, list):
        return []
    allowed = {
        str(row.get("flag") or "")
        for row in context.get("allowed_updates", [])
        if isinstance(row, dict) and str(row.get("flag") or "")
    }
    result: list[str] = []
    for value in payload:
        flag = str(value or "")
        if flag in allowed and flag not in result:
            result.append(flag)
    return result[:3]


def classify_chase_setup(
    *,
    model: LocalQwen,
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> dict[str, str] | None:
    recent = [
        {"speaker": str(row.get("speaker") or ""), "text": str(row.get("text") or "")[:700]}
        for row in recent_turns[-3:]
        if isinstance(row, dict) and str(row.get("text") or "").strip()
    ]
    payload = model.chat_json(
        [
            {"role": "system", "content": CHASE_SETUP_SYSTEM},
            {
                "role": "user",
                "content": json.dumps(
                    {"exact_recent_scene": recent, "player_action": str(player_text or "")[:500]},
                    ensure_ascii=False,
                ),
            },
        ],
        schema=CHASE_SETUP_SCHEMA,
        temperature=0.0,
    )
    quarry = " ".join(str(payload.get("quarry") or "").split())[:80]
    if not quarry:
        return None
    return {
        "action": "start",
        "quarry": quarry,
        "stake": " ".join(str(payload.get("stake") or "none known").split())[:100],
        "escape": " ".join(str(payload.get("escape") or "a route out of sight").split())[:100],
        "anchor": " ".join(str(payload.get("anchor") or "the current route").split())[:120],
    }


def classify_new_opponent(
    *,
    model: LocalQwen,
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
    opponent_name: str,
) -> dict[str, Any] | None:
    """Run one compact assessment only at the boundary of a new encounter."""

    if isinstance(state.get("combat"), dict) and state["combat"].get("status") == "active":
        return None
    target = " ".join(str(opponent_name or "").split())[:80]
    if not target:
        return None
    recent = [
        {"speaker": str(row.get("speaker") or ""), "text": str(row.get("text") or "")[:700]}
        for row in recent_turns[-4:]
        if isinstance(row, dict) and str(row.get("text") or "").strip()
    ]
    request = {
        "opponent": target,
        "exact_recent_scene": recent,
        "opening_action": str(player_text or "")[:500],
    }
    payload = model.chat_json(
        [
            {"role": "system", "content": OPPONENT_ASSESSMENT_SYSTEM},
            {"role": "user", "content": json.dumps(request, ensure_ascii=False)},
        ],
        schema=OPPONENT_ASSESSMENT_SCHEMA,
        temperature=0.1,
    )
    profile = _normalize_opponent_profile(payload)
    if profile is None:
        return None
    name = " ".join(str(payload.get("weapon_name") or "").split())[:80]
    mode = str(payload.get("weapon_mode") or "melee")
    natural = payload.get("weapon_natural") is True
    grounding = " ".join([target, str(player_text or ""), *(row["text"] for row in recent)])
    manufactured_grounded = bool(
        name and _meaningful_tokens(name) and _meaningful_tokens(name).issubset(_meaningful_tokens(grounding))
    )
    unarmed = name.casefold() == "unarmed" and profile.get("humanoid") is True
    natural_grounded = bool(name and natural and profile.get("humanoid") is False)
    weapon_grounded = mode in {"melee", "ranged"} and (
        manufactured_grounded or unarmed or natural_grounded
    )
    weapon = {
        "name": name if weapon_grounded else "",
        "mode": mode if weapon_grounded else "NONE",
        "bonus": _bounded_int(payload.get("weapon_bonus"), -1, 4, 1),
        "natural": natural_grounded,
        "grounded": weapon_grounded,
        "affliction": (
            str(payload.get("affliction") or "NONE")
            if str(payload.get("affliction") or "NONE") in {"poisoned", "arcane_drain"}
            else "NONE"
        ),
    }
    return {"opponent_profile": profile, "opponent_weapon": weapon}


def classify_new_item_profile(
    *,
    model: LocalQwen,
    recent_turns: list[dict[str, Any]],
    player_text: str,
    item_name: str,
    item_kind: str,
) -> dict[str, Any] | None:
    kind = str(item_kind or "")
    name = " ".join(str(item_name or "").split())[:100]
    allowed_kinds = {"weapon", "armor", "tool", "consumable", "valuable", "clothing", "document", "misc"}
    if kind not in allowed_kinds or not name:
        return None
    recent = [
        {"speaker": str(row.get("speaker") or ""), "text": str(row.get("text") or "")[:600]}
        for row in recent_turns[-3:]
        if isinstance(row, dict) and str(row.get("text") or "").strip()
    ]
    payload = model.chat_json(
        [
            {"role": "system", "content": ITEM_ASSESSMENT_SYSTEM},
            {
                "role": "user",
                "content": json.dumps(
                    {
                        "item": name,
                        "kind": kind,
                        "exact_recent_scene": recent,
                        "acquisition_action": str(player_text or "")[:400],
                    },
                    ensure_ascii=False,
                ),
            },
        ],
        schema=ITEM_ASSESSMENT_SCHEMA,
        temperature=0.0,
    )
    resulting_kind = str(payload.get("kind") or kind)
    if resulting_kind not in allowed_kinds:
        resulting_kind = kind
    mode = str(payload.get("weapon_mode") or "NONE")
    stat_assist = str(payload.get("stat_assist") or "NONE")
    if stat_assist not in {"NONE", "STR", "AGI", "SOC", "ARC", "PER"}:
        stat_assist = "NONE"
    raw_affordances = payload.get("affordances")
    affordances = [
        str(a).strip().casefold()
        for a in (raw_affordances if isinstance(raw_affordances, list) else [])
        if str(a).strip()
    ][:4]
    try:
        charges = max(0, min(10, int(payload.get("charges") or 0)))
    except (TypeError, ValueError):
        charges = 0
    return {
        "source": "gemma_semantic",
        "kind": resulting_kind,
        "weapon_mode": mode if resulting_kind == "weapon" and mode in {"melee", "ranged"} else "NONE",
        "weapon_bonus": _bounded_int(payload.get("weapon_bonus"), 0, 4, 1) if resulting_kind == "weapon" else 0,
        "armor_value": _bounded_int(payload.get("armor_value"), 0, 4, 1) if resulting_kind == "armor" else 0,
        "bulk": max(0.1, min(8.0, float(payload.get("bulk") or 1.0))),
        "is_magical": bool(payload.get("is_magical")),
        "stat_assist": stat_assist,
        "affordances": affordances,
        "charges": charges,
        "basis": " ".join(str(payload.get("basis") or "").split())[:160],
    }


def classify_new_companion_profile(
    *,
    model: LocalQwen,
    recent_turns: list[dict[str, Any]],
    player_text: str,
    companion_name: str,
) -> dict[str, Any] | None:
    name = " ".join(str(companion_name or "").split())[:100]
    if not name:
        return None
    recent = [
        {"speaker": str(row.get("speaker") or ""), "text": str(row.get("text") or "")[:600]}
        for row in recent_turns[-3:]
        if isinstance(row, dict) and str(row.get("text") or "").strip()
    ]
    payload = model.chat_json(
        [
            {"role": "system", "content": COMPANION_PROFILE_SYSTEM},
            {
                "role": "user",
                "content": json.dumps(
                    {
                        "candidate_description_or_name": name,
                        "exact_recent_scene": recent,
                        "player_recruitment_action": str(player_text or "")[:400],
                    },
                    ensure_ascii=False,
                ),
            },
        ],
        schema=COMPANION_PROFILE_SCHEMA,
        temperature=0.3,
    )
    assigned_name = " ".join(str(payload.get("name") or name).split())[:60]
    if not assigned_name:
        assigned_name = name
    weapon_mode = str(payload.get("weapon_mode") or "melee")
    weapon_name = str(payload.get("weapon_name") or "Unarmed")
    weapon_bonus = _bounded_int(payload.get("weapon_bonus"), -1, 3, 0)
    return {
        "name": assigned_name,
        "max_hp": _bounded_int(payload.get("max_hp"), 6, 20, 10),
        "STR": _bounded_int(payload.get("STR"), 6, 20, 10),
        "AGI": _bounded_int(payload.get("AGI"), 6, 20, 10),
        "SOC": _bounded_int(payload.get("SOC"), 6, 20, 10),
        "ARC": _bounded_int(payload.get("ARC"), 6, 20, 10),
        "PER": _bounded_int(payload.get("PER"), 6, 20, 10),
        "armor_name": " ".join(str(payload.get("armor_name") or "Clothes").split())[:80],
        "armor_value": _bounded_int(payload.get("armor_value"), 0, 4, 0),
        "weapon": {
            "name": weapon_name,
            "mode": weapon_mode if weapon_mode in {"melee", "ranged"} else "melee",
            "weapon_bonus": weapon_bonus,
        },
        "silver": _bounded_int(payload.get("silver"), 0, 30, 0),
        "appearance": " ".join(str(payload.get("appearance") or "").split())[:220],
        "character_trait": " ".join(str(payload.get("character_trait") or "A new ally").split())[:120],
    }


def _normalize_combat_advice(
    payload: Any,
    *,
    grounding_text: str,
    harm_affliction: str = "NONE",
    allow_new_profile: bool = True,
) -> dict[str, Any]:
    empty = {
        "action": "NONE",
        "target": "",
        "attack_mode": "NONE",
        "situational": {"scope": "NONE", "modifier": 0, "reason": ""},
        "opponent_weapon": {
            "name": "", "mode": "NONE", "bonus": 0, "natural": False,
            "grounded": False, "affliction": "NONE"
        },
        "opponent_profile": None,
    }
    if not isinstance(payload, dict):
        return empty
    action = str(payload.get("action") or "NONE")
    if action not in {"NONE", "attack", "defend", "flee", "surrender"}:
        action = "NONE"
    attack_mode = str(payload.get("attack_mode") or "NONE")
    if attack_mode not in {"NONE", "melee", "ranged"}:
        attack_mode = "NONE"
    target = " ".join(str(payload.get("target") or "").split())[:80]

    expected_scope = {
        "attack": "player_attack",
        "defend": "player_defense",
        "flee": "flee",
    }.get(action, "NONE")
    raw_situation = payload.get("situational")
    situation = empty["situational"].copy()
    if isinstance(raw_situation, dict):
        scope = str(raw_situation.get("scope") or "NONE")
        try:
            modifier = max(-2, min(2, int(raw_situation.get("modifier") or 0)))
        except (TypeError, ValueError):
            modifier = 0
        reason = " ".join(str(raw_situation.get("reason") or "").split())[:160]
        speculative = bool(re.search(r"\b(?:maybe|perhaps|possibly|probably|assum)\w*\b", reason, re.I))
        if (
            scope == expected_scope
            and expected_scope != "NONE"
            and modifier
            and reason
            and not speculative
            and not _PROFILE_ONLY_WORDS.search(reason)
        ):
            situation = {"scope": scope, "modifier": modifier, "reason": reason}

    profile = (
        _normalize_opponent_profile(payload.get("opponent_profile"))
        if allow_new_profile and action == "attack"
        else None
    )
    raw_weapon = payload.get("opponent_weapon")
    weapon = empty["opponent_weapon"].copy()
    if isinstance(raw_weapon, dict):
        name = " ".join(str(raw_weapon.get("name") or "").split())[:80]
        mode = str(raw_weapon.get("mode") or "NONE")
        natural = raw_weapon.get("natural") is True
        bonus = _bounded_int(raw_weapon.get("bonus"), -1, 4, 1 if name else 0)
        weapon_tokens = _meaningful_tokens(name)
        source_tokens = _meaningful_tokens(grounding_text)
        natural_grounded = bool(
            natural and profile is not None and profile.get("humanoid") is False and name
        )
        grounded = bool(
            natural_grounded
            or (name and weapon_tokens and weapon_tokens.issubset(source_tokens))
        )
        if grounded and mode in {"melee", "ranged"}:
            weapon = {
                "name": name,
                "mode": mode,
                "bonus": bonus,
                "natural": natural_grounded,
                "grounded": True,
                "affliction": (
                    harm_affliction
                    if harm_affliction in {"poisoned", "arcane_drain"}
                    else "NONE"
                ),
            }
    return {
        "action": action,
        "target": target,
        "attack_mode": attack_mode,
        "situational": situation,
        "opponent_weapon": weapon,
        "opponent_profile": profile,
    }


_RESOURCE_KINDS = {
    "NONE", "browse", "take", "drop", "give_item", "consume", "equip",
    "unequip", "purchase", "sell", "pay", "receive_item", "receive_money", "haggle",
}
_RESOURCE_STATUSES = {"NONE", "inquiry", "offered", "confirmed", "refused", "ambiguous"}
_ITEM_KINDS = {
    "NONE", "misc", "food", "drink", "tool", "key", "document", "weapon",
    "armor", "clothing", "consumable", "valuable", "service", "companion",
}
_EXCEPTIONAL_ITEM = re.compile(
    r"\b(?:artifact|relic|enchanted|magical|mythic|royal|crown|diadem|sceptre|scepter|"
    r"gold(?:en)?|silver(?:ed)?|gem(?:stone)?|diamond|ruby|emerald|sapphire|treasure)\b",
    re.I,
)
_EXPLICIT_TAKE = re.compile(
    r"\b(?:take|grab|seize|snatch|steal|pocket|collect|keep|claim|pick\s+up|"
    r"lift\s+away|carry\s+off)\b",
    re.I,
)
_PURE_CURRENCY_ITEM = re.compile(
    r"(?:the\s+)?(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)?\s*"
    r"(?:loose\s+)?(?:silver\s+)?(?:coins?|pieces?(?:\s+of\s+silver)?)|(?:the\s+)?silver",
    re.I,
)
def _same_named_thing(left: str, right: str) -> bool:
    # Preserve short but complete item names such as "bed" and "key"; the
    # broader grounding token filter intentionally drops them elsewhere.
    stop = {"the", "a", "an", "of", "for", "and"}
    left_words = {word for word in re.findall(r"[a-z0-9]+", left.casefold()) if word not in stop}
    right_words = {word for word in re.findall(r"[a-z0-9]+", right.casefold()) if word not in stop}
    if left_words and right_words and (
        left_words.issubset(right_words) or right_words.issubset(left_words)
    ):
        return True
    left_tokens, right_tokens = _meaningful_tokens(left), _meaningful_tokens(right)
    if not left_tokens or not right_tokens:
        return False
    return left_tokens.issubset(right_tokens) or right_tokens.issubset(left_tokens) or bool(left_tokens & right_tokens)


def _item_grounded(item: str, text: str) -> bool:
    tokens = _meaningful_tokens(item)
    source = _meaningful_tokens(text)
    return bool(tokens and (tokens.issubset(source) or len(tokens & source) >= min(2, len(tokens))))


def _inferred_item_kind(item: str) -> str:
    folded = item.casefold()
    if any(
        word in folded
        for word in (
            "inn stay", "lodging", "physician", "doctor", "healer", "treatment",
            "passage", "sea passage", "berth", "ticket", "fare", "charter", "ferry",
        )
    ):
        return "service"
    if any(word in folded for word in ("bread", "meal", "fruit", "cheese", "fish")):
        return "food"
    if any(word in folded for word in ("ale", "wine", "water", "drink")):
        return "drink"
    if any(word in folded for word in ("sword", "dagger", "knife", "bow", "spear", "axe", "pistol", "musket")):
        return "weapon"
    if any(word in folded for word in ("armor", "armour", "jerkin", "brigandine", "breastplate")):
        return "armor"
    if any(word in folded for word in ("cloak", "coat", "hat", "boots", "shirt", "dress", "robe")):
        return "clothing"
    if "key" in folded:
        return "key"
    if any(word in folded for word in ("map", "letter", "book", "chart", "document", "scroll")):
        return "document"
    if any(word in folded for word in ("potion", "salve", "medicine", "antidote")):
        return "consumable"
    if any(word in folded for word in ("rope", "lamp", "lantern", "hammer", "kit", "tool")):
        return "tool"
    if _EXCEPTIONAL_ITEM.search(item):
        return "valuable"
    return "misc"


def _normalize_resource_advice(
    payload: Any,
    *,
    player_text: str,
    scene_grounding: str,
    state: dict[str, Any],
    requires_roll: bool,
) -> dict[str, Any]:
    empty = {
        "kind": "NONE", "status": "NONE", "item": "", "item_kind": "NONE",
        "quantity": 1, "amount": 0, "counterparty": "", "timing": "none",
        "reason": "", "offer_grounded": False,
    }
    if not isinstance(payload, dict):
        return empty
    kind = str(payload.get("kind") or "NONE")
    status = str(payload.get("status") or "NONE")
    item_kind = str(payload.get("item_kind") or "NONE")
    if kind not in _RESOURCE_KINDS:
        kind = "NONE"
    if status not in _RESOURCE_STATUSES:
        status = "NONE"
    if item_kind not in _ITEM_KINDS:
        item_kind = "misc"
    try:
        quantity = max(1, min(20, int(payload.get("quantity") or 1)))
    except (TypeError, ValueError):
        quantity = 1
    try:
        amount = max(0, min(100000, int(payload.get("amount") or 0)))
    except (TypeError, ValueError):
        amount = 0
    item = " ".join(str(payload.get("item") or "").split())[:100]
    if item.casefold() in {"none", "null", "n/a", "unknown", "ambiguous", "unspecified"}:
        item = ""
    counterparty = " ".join(str(payload.get("counterparty") or "").split())[:100]
    if counterparty.casefold() in {"none", "null", "n/a", "unknown"}:
        counterparty = ""
    reason = " ".join(str(payload.get("reason") or "").split())[:220]
    timing = str(payload.get("timing") or "none")
    if timing not in {"none", "immediate", "on_success"}:
        timing = "none"

    from .voyage import is_passage_resource
    passage = is_passage_resource({**payload, 'kind': kind, 'item': item})
    if passage:
        offer = state.get('pending_passage_offer') or {}
        price = int(offer.get('price', 0) or 0)
        # Preserve semantic consent; price agreement never promotes status.
        if status == 'confirmed' and amount == 0 and price > 0:
            amount = price
        grounded = status == 'confirmed' and amount == price and 5 <= price <= 30
        return {'kind': kind, 'status': status, 'item': item, 'item_kind': 'service',
                'service_type': 'passage', 'quantity': 1, 'amount': amount,
                'counterparty': counterparty, 'timing': timing if grounded else 'none',
                'reason': reason, 'offer_grounded': grounded}

    pending = pending_commerce_offer(state)
    if kind == "NONE":
        return empty
    if kind == "haggle" and not isinstance(pending, dict):
        # Haggling is a price-changing mechanic, not a synonym for any bargain,
        # promise, or persuasive line. Without an established offer there is
        # nothing for the economy engine to replace; leave the speech to fiction.
        return empty
    # A take is unilateral: nobody "offers" it. When the judge pairs take with
    # "offered" but still schedules the transfer (immediate / on_success), the
    # timing field is the explicit semantic commitment, so reconcile the
    # contradiction to "confirmed" instead of silently erasing the attempt.
    # Without a scheduled transfer the old guard still applies.
    if kind == "take" and status == "offered" and timing in {"immediate", "on_success"}:
        status = "confirmed"
    # A door/lock interaction is a scene action, not an acquisition. A model
    # false positive here used to swallow the real action as "Take not committed".
    if kind in {"take", "receive_item"} and status in {"offered", "refused", "inquiry"}:
        return empty
    if kind == "take" and "other_pickup" not in payload and not _EXPLICIT_TAKE.search(player_text):
        return empty
    player_amounts = stated_amounts(player_text)
    if kind == "give_item" and matching_inventory_item(state, item) is None:
        # When the player says "I give the man 3 coins", a model may choose
        # give_item because of the verb "give". Coins/silver live in player.silver,
        # not inventory. Normalize coin handovers to pay before checking owned items.
        coin_cue = bool(
            re.search(r"\b(?:silver|coins?|pieces?|money|fare|fee|price|payment)\b", f"{item} {player_text}", re.I)
        )
        if amount > 0 or coin_cue:
            kind = "pay"
            if amount == 0 and len(player_amounts) == 1:
                amount = player_amounts[0]
            if re.fullmatch(
                r"(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)?\s*(?:silver\s*)?(?:coins?|pieces?|silver|money)?",
                item.strip(),
                re.I,
            ):
                item = ""
    inferred_kind = _inferred_item_kind(item)
    if item and item_kind in {"NONE", "misc"} and inferred_kind != "misc":
        item_kind = inferred_kind
    elif inferred_kind == "armor" and re.search(
        r"\b(?:armor|armour|breastplate|brigandine|cuirass)\b", item, re.I
    ):
        # Hard equipment taxonomy, not an intent rewrite: an obvious armor noun
        # must produce armor mechanics even if Qwen labels it as clothing.
        item_kind = "armor"
    owned_kinds = {"drop", "give_item", "consume", "equip", "unequip", "sell"}
    if kind in owned_kinds:
        owned = matching_inventory_item(state, item)
        if owned is None:
            status = "ambiguous"
        else:
            item = str(owned.get("name") or item)
            item_kind = str(owned.get("type") or item_kind or "misc")

    offer_grounded = False
    # Scene nouns such as "room" describe geography too. Only normalize a
    # recovery purchase when its explicit item names the same recovery service.
    scene_service = service_kind_for_item(scene_grounding, item_kind="service")
    item_service = service_kind_for_item(item, item_kind=item_kind)
    explicit_service_amount = player_amounts[0] if len(player_amounts) == 1 else 0
    grounded_service_acceptance = bool(
        kind in {"pay", "purchase"}
        and explicit_service_amount > 0
        and explicit_service_amount in stated_amounts(scene_grounding)
        and scene_service
        and item_service == scene_service
        and _EXPLICIT_OFFER_ACCEPTANCE.search(player_text)
        and not _EXPLICIT_OFFER_REFUSAL.search(player_text)
        and "?" not in player_text
    )
    if grounded_service_acceptance:
        kind = "purchase"
        status = "confirmed"
        amount = explicit_service_amount
        item = {
            "lodging": "Inn Stay",
            "treatment": "Physician Treatment",
        }.get(str(scene_service), item or "Service")
        item_kind = "service"
        quantity = 1
        timing = "immediate"
        offer_grounded = True
    if kind == "pay":
        # A model may call an explicit service acceptance "pay" because that is
        # the player's verb. Repair only when the selected amount appears both
        # in the player's text and in a recent exact service quote.
        explicit_amount = amount > 0 and amount in stated_amounts(player_text)
        if not explicit_amount:
            scene_coins = stated_amounts(scene_grounding)
            if len(scene_coins) == 1 and re.search(r"\b(?:pay|paid|give|hand|stake|bet|put\s+(?:down|in)|deal|agreed)\b", player_text, re.I):
                amount = scene_coins[0]
                explicit_amount = True
        grounded_service = bool(
            explicit_amount
            and amount in stated_amounts(scene_grounding)
            and scene_service
            and item_service == scene_service
            and not _EXPLICIT_OFFER_REFUSAL.search(player_text)
        )
        if grounded_service:
            kind = "purchase"
            status = "confirmed"
            item = {
                "lodging": "Inn Stay",
                "treatment": "Physician Treatment",
            }.get(str(scene_service), item or "Service")
            item_kind = "service"
            quantity = 1
            timing = "immediate"
            offer_grounded = True
    if (
        kind == "pay"
        and not offer_grounded
        and isinstance(pending, dict)
        and pending.get("direction") == "buy"
        and "?" not in player_text
        and not _EXPLICIT_OFFER_REFUSAL.search(player_text)
    ):
        # When an exact merchant quote is pending ("pending_offer"), saying
        # "Ok, I pay" or "I give him 3 coins" is an acceptance of that purchase
        # offer, not an unattached gift of money that leaves the item behind.
        pending_amount = int(pending.get("amount", 0) or 0)
        pending_item = str(pending.get("item") or "")
        amount_matches = (
            amount == pending_amount
            or (len(player_amounts) == 1 and player_amounts[0] == pending_amount)
            or (
                not player_amounts
                and (
                    _EXPLICIT_OFFER_ACCEPTANCE.search(player_text)
                    or bool(re.search(r"\b(?:pay|paid|buy|take|hand|give)\b", player_text, re.I))
                )
            )
        )
        item_compatible = (
            not item
            or _same_named_thing(item, pending_item)
            or bool(re.search(r"\b(?:silver|coins?|pieces?|money|price|it|them)\b", item, re.I))
        )
        if pending_amount > 0 and pending_item and amount_matches and item_compatible:
            kind = "purchase"
            status = "confirmed"
            item = pending_item
            item_kind = str(pending.get("item_kind") or item_kind or "misc")
            quantity = max(1, min(20, int(pending.get("quantity", quantity) or quantity)))
            amount = pending_amount
            counterparty = counterparty or str(pending.get("counterparty") or "")
            timing = "immediate"
            offer_grounded = True
    if kind in {"purchase", "sell"}:
        direction = "buy" if kind == "purchase" else "sell"
        # The model still owns transaction meaning. This only repairs a status
        # omission when it already chose the correct transaction and an exact
        # engine-stored offer makes the player's explicit acceptance unambiguous.
        if (
            isinstance(pending, dict)
            and pending.get("direction") == direction
            and status in {"inquiry", "offered"}
            and (not item or _same_named_thing(item, str(pending.get("item") or "")))
            and "?" not in player_text
            and _EXPLICIT_OFFER_ACCEPTANCE.search(player_text)
            and not _EXPLICIT_OFFER_REFUSAL.search(player_text)
        ):
            status = "confirmed"
        if (
            isinstance(pending, dict)
            and pending.get("direction") == direction
            and status == "confirmed"
        ):
            pending_item = str(pending.get("item") or "")
            if not item or _same_named_thing(item, pending_item):
                item = pending_item
                item_kind = str(pending.get("item_kind") or item_kind or "misc")
                quantity = max(1, min(20, int(pending.get("quantity", quantity) or quantity)))
                amount = int(pending.get("amount", 0) or 0)
                counterparty = counterparty or str(pending.get("counterparty") or "")
                offer_grounded = bool(item and amount > 0)
        if status == "confirmed" and not offer_grounded:
            # An exact offer can also be accepted in the same recent exchange,
            # but the item and price both have to be present in scene evidence.
            exact_scene_offer = bool(
                item and amount > 0 and _item_grounded(item, scene_grounding)
                and amount in silver_amounts(scene_grounding)
            )
            offer_grounded = exact_scene_offer
        if status == "confirmed" and not offer_grounded:
            status = "inquiry" if kind == "purchase" else "offered"
        if status in {"inquiry", "offered"}:
            amount = amount if status == "offered" else 0

    if kind == "take" and amount == 0 and _PURE_CURRENCY_ITEM.fullmatch(item.strip()):
        # Loose coins are the purse, not an inventory object. The judge may
        # report "two silver coins" as item+quantity; credit them only when
        # the scene states that exact silver amount. Unknown contents (a
        # pouch, "some coins") stay unchanged for the grounding auditor.
        scene_silver = silver_amounts(scene_grounding)
        counted = quantity if quantity > 1 else (scene_silver[0] if len(set(scene_silver)) == 1 else 0)
        turn_no = int(state.get("turn_no", 0) or 0)
        already_credited = any(
            isinstance(row, dict)
            and int((row.get("changes") or {}).get("gained_silver", 0) or 0) == counted
            and turn_no - int(row.get("turn_no", 0) or 0) <= 2
            for row in (state.get("grounding_audit_history") or [])[-3:]
        )
        if counted > 0 and counted in scene_silver and not already_credited:
            kind = "receive_money"
            amount = counted
            item = ""
            item_kind = "misc"
            quantity = 1
            if status == "NONE":
                status = "confirmed"
    if kind == "take" and status in {"NONE", "confirmed", "ambiguous"}:
        if not item or not _item_grounded(item, scene_grounding):
            status = "ambiguous"
        elif status != "ambiguous":
            status = "confirmed"
        timing = "on_success" if requires_roll else "immediate"
    elif kind in {"give_item", "pay", "receive_item", "receive_money"} and requires_roll:
        # Preserve a judged physical payment independent of persuasion success.
        if not (kind == "pay" and status == "confirmed" and timing == "immediate"):
            timing = "on_success"
    elif status == "confirmed":
        timing = "immediate"

    if kind == "pay":
        # A payment is a new irreversible transfer.  An amount repeated by the
        # recent scene is evidence for an offer, never evidence that a later
        # "I wait" or unrelated action pays it again.  Passage and commerce
        # acceptances have their own engine-stored pending offers above.
        explicit_amount = amount > 0 and amount in silver_amounts(player_text)
        if not explicit_amount:
            scene_coins = silver_amounts(scene_grounding)
            if len(scene_coins) == 1 and re.search(r"\b(?:pay|paid|give|hand|stake|bet|put\s+(?:down|in)|deal|agreed)\b", player_text, re.I):
                amount = scene_coins[0]
                explicit_amount = True

        if not explicit_amount:
            # A classifier false-positive on a yielded beat ("I wait", "I
            # listen") should disappear rather than produce a misleading
            # "Pay not committed" banner.  Explicit but underspecified payment
            # language remains visible as ambiguous.
            if not re.search(r"\b(?:pay|paid|give|hand|stake|bet|put\s+(?:down|in))\b", player_text, re.I):
                return empty
            status = "ambiguous"
    elif kind == "receive_money":
        grounded_reward = amount > 0 and amount in silver_amounts(scene_grounding)
        if not grounded_reward:
            status = "ambiguous"
    elif kind == "receive_item":
        if not item or not _item_grounded(item, scene_grounding):
            status = "ambiguous"

    if status != "confirmed":
        timing = "none"
    return {
        "kind": kind,
        "status": status,
        "item": item,
        "item_kind": item_kind if item_kind != "NONE" else "misc",
        "quantity": quantity,
        **({"other_pickup": payload["other_pickup"]} if isinstance(payload.get("other_pickup"), str) else {}),
        "amount": amount,
        "counterparty": counterparty,
        "timing": timing,
        "reason": reason,
        "offer_grounded": offer_grounded,
        "service_type": "NONE",
    }


def _active_pressure_candidate(
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
) -> dict[str, Any] | None:
    combat = state.get("combat")
    if isinstance(combat, dict) and combat.get("status") == "active":
        return None
    recent_text = " ".join(
        str(row.get("text") or "")
        for row in recent_turns[-6:]
        if isinstance(row, dict)
    ).casefold()
    for current in state.get("hidden_currents", [])[:2]:
        if not isinstance(current, dict):
            continue
        if str(current.get("kind") or "") not in {"npc_plan", "world_pressure"}:
            continue
        if str(current.get("urgency") or "") != "imminent":
            continue
        names = [current.get("subject"), *(current.get("target_aliases") or [])]
        grounded = False
        for value in names:
            name = " ".join(str(value or "").casefold().split())
            if not name:
                continue
            variants = {name, name[4:] if name.startswith("the ") else name}
            if any(len(variant) >= 4 and variant in recent_text for variant in variants):
                grounded = True
                break
        if grounded:
            return current
    return None


def classify_world_beat(
    *,
    model: LocalQwen,
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
    semantic_roll: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Let Qwen advance one already-visible pressure on a yielded player beat."""

    if not isinstance(semantic_roll, dict) or semantic_roll.get("requires_roll") is True:
        return None
    if str(
        (semantic_roll.get("visible_pressure") or {}).get("status")
        if isinstance(semantic_roll.get("visible_pressure"), dict)
        else "NONE"
    ) == "POISED":
        return None
    combat_advice = semantic_roll.get("combat") if isinstance(semantic_roll.get("combat"), dict) else {}
    resource_advice = (
        semantic_roll.get("resource_action")
        if isinstance(semantic_roll.get("resource_action"), dict)
        else {}
    )
    if (
        str(semantic_roll.get("destination") or "").strip()
        or str(combat_advice.get("action") or "NONE") != "NONE"
        or str(resource_advice.get("kind") or "NONE") != "NONE"
    ):
        return None
    current = _active_pressure_candidate(state, recent_turns)
    if current is None:
        return None
    recent = [
        {
            "speaker": str(row.get("speaker") or ""),
            "text": str(row.get("text") or "")[:700],
        }
        for row in recent_turns[-6:]
        if isinstance(row, dict) and str(row.get("text") or "").strip()
    ]
    request = {
        "private_current": {
            "kind": str(current.get("kind") or "world_pressure"),
            "subject": str(current.get("subject") or "")[:100],
            "target_aliases": list(current.get("target_aliases") or [])[:3],
            "truth": str(current.get("truth") or "")[:360],
            "outward_tell": str(current.get("outward_tell") or "")[:240],
            "urgency": "imminent",
        },
        "exact_recent_scene": recent,
        "player_action": player_text,
    }
    payload = model.chat_json(
        [
            {"role": "system", "content": WORLD_BEAT_SYSTEM},
            {"role": "user", "content": json.dumps(request, ensure_ascii=False)},
        ],
        schema=WORLD_BEAT_SCHEMA,
        temperature=0.2,
    )
    if payload.get("advance") is not True:
        return None
    action = " ".join(str(payload.get("action") or "").split())[:320]
    if not action:
        return None
    subject = " ".join(str(current.get("subject") or "the active pressure").split())[:100]
    actor = " ".join(str(payload.get("actor") or subject).split())[:100] or subject
    grounding = " ".join(
        [
            str(current.get("subject") or ""),
            *(str(value or "") for value in current.get("target_aliases", [])),
            str(current.get("truth") or ""),
            str(current.get("outward_tell") or ""),
            *(str(row.get("text") or "") for row in recent),
        ]
    )
    if not _meaningful_tokens(actor).issubset(_meaningful_tokens(grounding)):
        actor = subject
    hostile_attack = payload.get("hostile_attack") is True
    weapon_name = " ".join(str(payload.get("weapon_name") or "").split())[:80]
    weapon_mode = str(payload.get("weapon_mode") or "NONE")
    name_is_grounded = bool(
        weapon_name
        and _meaningful_tokens(weapon_name)
        and _meaningful_tokens(weapon_name).issubset(_meaningful_tokens(grounding))
    )
    if hostile_attack and name_is_grounded and weapon_mode == "NONE":
        # Qwen sometimes names the established weapon correctly but leaves its
        # mode blank. Infer only the broad combat axis from the chosen action;
        # no item catalog or weapon statistics are guessed here.
        weapon_mode = (
            "ranged"
            if re.search(r"\b(?:shoot|shot|fire|fires|loose|looses|arrow|bolt|hurl|throw)\b", action, re.I)
            else "melee"
        )
    weapon_grounded = bool(
        name_is_grounded and weapon_mode in {"melee", "ranged"}
    )
    return {
        "advance": True,
        "actor": actor,
        "action": action,
        "hostile_attack": hostile_attack,
        "weapon_name": weapon_name if hostile_attack and weapon_grounded else "",
        "weapon_mode": weapon_mode if hostile_attack and weapon_grounded else "NONE",
        "weapon_bonus": 0,
        "weapon_natural": False,
        "opponent_profile": None,
        "source": "qwen_world_beat",
    }


def _destination_label_needs_repair(value: Any) -> bool:
    """Reject metadata shapes that cannot be a concise physical endpoint.

    This is only a semantic-output invariant. It never extracts a destination
    from player prose or decides movement with a verb dictionary.
    """

    clean = " ".join(str(value or "").strip(" \t\r\n\"'").split())
    if not clean:
        return False
    words = re.findall(r"[A-Za-z0-9'-]+", clean)
    return bool(
        len(words) > 8
        or _MALFORMED_DESTINATION_LEAD.search(clean)
        or _MALFORMED_DESTINATION_CLAUSE.search(clean)
        or _MALFORMED_DESTINATION_END.search(clean)
        or _MALFORMED_ACTOR_POSITION.search(clean)
        or re.search(r"[?!;:]", clean)
    )


def _normalize_visible_pressure(value: Any, *, player_text: str = "") -> dict[str, str]:
    empty = {
        "status": "NONE",
        "actor": "",
        "action": "",
        "relation": "NONE",
        "consequence": "NONE",
    }
    if not isinstance(value, dict):
        return empty
    action = " ".join(str(value.get("pressure_completion") or "").split())[:260]
    relation = str(value.get("pressure_relation") or "NONE")
    consequence = "alert" if value.get("pressure_alert") is True else "other"
    if not action or relation not in {"CONTESTED", "PARALLEL", "YIELDED"}:
        return empty
    if re.search(r"\b(?:wait|watch|do\s+nothing|hesitate|see\s+what|ask\s+what)\b", player_text, re.I):
        relation = "YIELDED"
    elif relation == "CONTESTED" and not re.search(
        r"\b(?:stop|prevent|interrupt|grab|seize|hold|block|"
        r"cut|strike|hit|push|tackle|restrain|disable|break)\b",
        player_text,
        re.I,
    ):
        relation = "PARALLEL"
    return {
        "status": "POISED",
        "actor": "",
        "action": action,
        "relation": relation,
        "consequence": consequence,
    }


def _repair_destination_metadata(
    *,
    model: LocalQwen,
    current_place: dict[str, Any],
    recent_scene: list[dict[str, str]],
    player_text: str,
    payload: dict[str, Any],
) -> dict[str, str]:
    request = {
        "current_place": current_place,
        "recent_scene": [
            {
                "speaker": str(row.get("speaker") or ""),
                "text": str(row.get("text") or "")[:420],
            }
            for row in recent_scene[-4:]
        ],
        "player_action": player_text,
        "original_movement_metadata": {
            "movement_commitment": payload.get("movement_commitment"),
            "destination": payload.get("destination"),
            "destination_scope": payload.get("destination_scope"),
        },
    }
    repaired = model.chat_json(
        [
            {"role": "system", "content": DESTINATION_REPAIR_SYSTEM},
            {"role": "user", "content": json.dumps(request, ensure_ascii=False)},
        ],
        schema=DESTINATION_REPAIR_SCHEMA,
        temperature=0.0,
    )
    commitment = str(repaired.get("movement_commitment") or "NONE")
    destination = " ".join(str(repaired.get("destination") or "").split())[:80]
    scope = str(repaired.get("destination_scope") or "NONE")
    if (
        commitment != "COMMITTED"
        or not destination
        or scope not in {"LOCAL", "WORLD"}
        or _destination_label_needs_repair(destination)
    ):
        return {
            "movement_commitment": "NONE",
            "destination": "",
            "destination_scope": "NONE",
        }
    return {
        "movement_commitment": "COMMITTED",
        "destination": destination,
        "destination_scope": scope,
    }


def _review_action_adjudication(
    *,
    model: LocalQwen,
    recent_scene: list[dict[str, str]],
    player_text: str,
    payload: dict[str, Any],
    authoritative_state: dict[str, Any] | None = None,
) -> dict[str, Any]:
    review_context = {
        "authoritative_state": authoritative_state or {},
        "recent_scene": recent_scene,
        "player_action": player_text,
        "draft_adjudication": {
            "intent": payload.get("intent"),
            "requires_roll": payload.get("requires_roll"),
            "stat": payload.get("stat"),
            "difficulty": payload.get("difficulty"),
            "reason": payload.get("reason"),
            "destination": payload.get("destination"),
            "destination_scope": payload.get("destination_scope"),
            "movement_commitment": payload.get("movement_commitment"),
            "acting_companion": payload.get("acting_companion"),
            "recovery_intent": payload.get("recovery_intent"),
            "combat": payload.get("combat"),
            "resource_action": payload.get("resource_action"),
            "magic": payload.get("magic"),
            "voyage_action": payload.get("voyage_action"),
            "critical_failure_harm": payload.get("critical_failure_harm"),
        },
    }
    try:
        messages = [
            {"role": "system", "content": ADJUDICATION_REVIEW_SYSTEM},
            {"role": "user", "content": json.dumps(review_context, ensure_ascii=False)},
        ]
        try:
            review = model.chat_json(messages, schema=ADJUDICATION_REVIEW_SCHEMA, temperature=0.1)
        except json.JSONDecodeError:
            review = model.chat_json(messages, schema=ADJUDICATION_REVIEW_SCHEMA, temperature=0.0)
        updated_payload = dict(payload)
        updated_payload["_adjudication_review"] = review
        if review.get("approved") is False and isinstance(review.get("corrections"), dict):
            for k, v in review["corrections"].items():
                if v is not None:
                    if k == "resource_action" and isinstance(payload.get(k), dict) and isinstance(v, dict):
                        updated_payload[k] = {**payload[k], **v}
                    else:
                        updated_payload[k] = v
            # Normalization: if a valid stat was assigned by referee, requires_roll must be True unless explicitly set to False
            corr = review["corrections"]
            if str(corr.get("stat") or "NONE") in {"AGI", "STR", "SOC", "ARC", "PER"}:
                if "requires_roll" not in corr:
                    updated_payload["requires_roll"] = True
                if str(updated_payload.get("difficulty") or "NONE") in {"NONE", ""}:
                    updated_payload["difficulty"] = "standard"
            elif updated_payload.get("requires_roll") is False and "stat" not in corr:
                updated_payload["stat"] = "NONE"
                updated_payload["difficulty"] = "NONE"
        return updated_payload
    except Exception as exc:
        return {**payload, "_adjudication_review": {"error": str(exc)[:200]}}



def _normalized_voyage_action(payload: dict[str, Any]) -> str:
    """Explicit semantic voyage decision; missing/invalid values mean NONE.

    The key is always present on classifier output so voyage.py can tell a
    semantic NONE apart from a legacy payload and skip keyword fallbacks.
    """
    action = str(payload.get('voyage_action') or 'NONE')
    return action if action in RISK_SCHEMA['properties']['voyage_action']['enum'] else 'NONE'


def _risk_schema_for(context: dict[str, Any]) -> dict[str, Any]:
    """During an open paid voyage the classifier must state voyage_action."""
    voyage = context.get('voyage') if isinstance(context.get('voyage'), dict) else None
    if not voyage or voyage.get('phase') == 'completed':
        return RISK_SCHEMA
    schema = dict(RISK_SCHEMA)
    schema['required'] = list(dict.fromkeys([*RISK_SCHEMA.get('required', []), 'voyage_action']))
    return schema


def classify_action_risk(
    *,
    model: LocalQwen,
    state: dict[str, Any],
    recent_turns: list[dict[str, Any]],
    player_text: str,
) -> dict[str, Any]:
    if is_capability_question(player_text):
        return {
            "intent": "ask about capability",
            "requires_roll": False,
            "stat": "NONE",
            "dc": 0,
            "difficulty": "NONE",
            "reason": "The player asked whether the action is feasible but did not attempt it.",
            "movement_commitment": "NONE",
            "destination": "",
            "destination_scope": "NONE",
            "movement_dependency": "NONE",
            "recovery_intent": "NONE",
            "npc_scene_occupied": False,
            "npc_seed_density": "ordinary",
            "harm_affliction": "NONE",
            "critical_failure_harm": 0,
            "critical_failure_attention": "NONE",
            "visible_pressure": _normalize_visible_pressure(None),
            "combat": _normalize_combat_advice(None, grounding_text=""),
            "chase": _normalize_chase_advice(None),
            "scenario_flags": [],
            "resource_action": {
                "kind": "NONE", "status": "NONE", "item": "", "item_kind": "NONE",
                "quantity": 1, "amount": 0, "counterparty": "", "timing": "none",
                "reason": "", "offer_grounded": False,
            },
            "source": "python_capability_question",
        }
    # V12 restores V9's foreground semantic authority: every player action
    # that is not a pure capability question is interpreted by the model.
    location = current_location(state)
    position = state.get("scene_position") if isinstance(state.get("scene_position"), dict) else None
    location_id = str(state.get("current_location_id") or "")
    position_id = str(position.get("id")) if position else None
    site_root_id = active_site_root_id(state, location_id)
    site_root = state.get("locations", {}).get(site_root_id, {})
    position_establishes_interior = bool(
        position
        and (
            str(position.get("spatial_relation") or "").casefold() == "interior"
            or "interior" in str(position.get("label") or "").casefold()
        )
    )
    bounded_site = (
        str(site_root.get("name") or site_root_id)
        if isinstance(site_root, dict)
        and (
            has_bounded_geometry(site_root)
            or (not isinstance(site_root.get("site_memory"), dict)
                and site_root_id == location_id and position_establishes_interior)
        )
        else None
    )
    recent = [
        {
            "speaker": str(row.get("speaker") or ""),
            "text": str(row.get("text") or "")[:700],
        }
        for row in recent_turns[-6:]
        if isinstance(row, dict) and str(row.get("text") or "").strip()
    ]
    context = {
        "current_place": {
            "name": location.get("name"),
            "region": location.get("region"),
            "summary": location.get("summary"),
            "local_scene_position": (
                state.get("scene_position", {}).get("label")
                if isinstance(state.get("scene_position"), dict)
                else None
            ),
            "emergent": str(state.get("current_location_id") or "").startswith("emergent_"),
            "bounded_site": bounded_site,
        },
        "active_combat": (
            {
                "round": state["combat"].get("round"),
                "phase": state["combat"].get("phase", "player_action"),
                "opponent": {
                    "name": (state["combat"].get("opponents", [])[0].get("name") if state["combat"].get("opponents") else None),
                    "established_weapon": (state["combat"].get("opponents", [])[0].get("weapon", {}).get("name") if state["combat"].get("opponents") else None),
                },
            }
            if isinstance(state.get("combat"), dict)
            and state["combat"].get("status") == "active"
            else None
        ),
        "companions": roster_context(state),
        "player_resources": {
            "silver": int(state.get("player", {}).get("silver", 0) or 0),
            "inventory": [
                {
                    "name": str(item.get("name") or ""),
                    "quantity": int(item.get("quantity", 1) or 1),
                    "kind": str(item.get("type") or "misc"),
                    "equipped": bool(item.get("equipped")),
                }
                for item in state.get("player", {}).get("inventory", [])
                if isinstance(item, dict) and str(item.get("name") or "").strip()
            ],
        },
        "available_objects_here": [
            {"name": row.get("name"), "quantity": int(row.get("quantity", 1) or 1)}
            for row in state.get("scene_objects", [])
            if isinstance(row, dict)
            and row.get("status") == "available"
            and row.get("location_id") == location_id
            and row.get("scene_position_id") == position_id
        ],
        "pending_commerce_offer": pending_commerce_offer(state),
        "pending_passage_offer": state.get("pending_passage_offer"),
        "recent_mechanical_ledger": [
            {
                "turn": int(row.get("turn_no", 0) or 0),
                "text": str(row.get("text") or "")[:300],
            }
            for row in list(state.get("mechanics_history") or [])[-6:]
            if isinstance(row, dict) and str(row.get("text") or "").strip()
        ],
        "recent_scene": recent,
        "last_resolved_visible_pressure": (
            state.get("scene_pressure")
            if isinstance(state.get("scene_pressure"), dict)
            and int(state.get("turn_no", 0) or 0)
            - int(state.get("scene_pressure", {}).get("resolved_at_turn", 0) or 0) <= 3
            else None
        ),
        "player_action": player_text,
    }
    active_situation = active_situation_risk_context(state)
    from .voyage import context as voyage_context
    context['voyage'] = voyage_context(state)
    if active_situation:
        context["active_situation"] = active_situation
    active_scenario = semantic_scenario_context(state)
    if active_scenario:
        context["active_scenario"] = active_scenario
    payload = model.chat_json(
        [
            {"role": "system", "content": RISK_SYSTEM},
            {"role": "user", "content": json.dumps(context, ensure_ascii=False)},
        ],
        schema=_risk_schema_for(context),
        temperature=0.1,
    )
    if ENABLE_ADJUDICATION_REVIEW:
        payload = _review_action_adjudication(
            model=model,
            recent_scene=recent,
            player_text=player_text,
            payload=payload,
            authoritative_state={
                'voyage': {key: (context.get('voyage') or {}).get(key)
                           for key in ('id', 'phase', 'vessel_id', 'risk')},
                'active_situation': active_situation,
                'current_location_id': state.get('current_location_id'),
                'bounded_site': bounded_site,
                'combat': {'status': (state.get('combat') or {}).get('status')},
            },
        )
    destination = " ".join(str(payload.get("destination") or "").split())[:80]
    destination_scope = str(payload.get("destination_scope") or "NONE")
    pending_voyage = str(payload.get("pending_voyage_destination") or "NONE")
    if pending_voyage == "NONE":
        pending_voyage = ""
    else:
        pending_voyage = " ".join(pending_voyage.split())[:80]
    if destination_scope not in {"NONE", "LOCAL", "WORLD"}:
        destination_scope = "NONE"
    movement_commitment = str(payload.get("movement_commitment") or "")
    if movement_commitment not in {"NONE", "COMMITTED"}:
        # Compatibility for old saves/tests and technical schema fallbacks.
        movement_commitment = "COMMITTED" if destination else "NONE"
    metadata_incoherent = bool(
        (movement_commitment == "NONE" and (destination or destination_scope != "NONE"))
        or (
            movement_commitment == "COMMITTED"
            and (not destination or destination_scope not in {"LOCAL", "WORLD"})
        )
    )
    destination_repaired = False
    if metadata_incoherent or _destination_label_needs_repair(destination):
        destination_repaired = True
        try:
            repaired = _repair_destination_metadata(
                model=model,
                current_place=context["current_place"],
                recent_scene=recent,
                player_text=player_text,
                payload=payload,
            )
        except Exception:
            # A malformed endpoint must never mint a location merely because
            # its small semantic correction call failed.
            repaired = {
                "movement_commitment": "NONE",
                "destination": "",
                "destination_scope": "NONE",
            }
        movement_commitment = repaired["movement_commitment"]
        destination = repaired["destination"]
        destination_scope = repaired["destination_scope"]
    elif movement_commitment == "NONE":
        destination = ""
        destination_scope = "NONE"
    scene_grounding = " ".join(
        [
            str(location.get("summary") or ""),
            str(position.get("summary") or "") if position else "",
            (state.get("combat", {}).get("opponents", [])[0].get("weapon", {}).get("name") or "")
            if isinstance(state.get("combat"), dict) and state.get("combat", {}).get("opponents")
            else "",
            *(str(row.get("name") or "") for row in context["available_objects_here"]),
            *(str(row.get("text") or "") for row in recent),
            (
                f"Passage to {state.get('pending_passage_offer', {}).get('destination_name')} "
                f"costs {state.get('pending_passage_offer', {}).get('price')} silver."
                if isinstance(state.get("pending_passage_offer"), dict)
                else ""
            ),
        ]
    )
    grounding_text = f"{player_text} {scene_grounding}"
    recovery_intent = str(payload.get("recovery_intent") or "NONE")
    # Compatibility for saved/test semantic payloads from before V22.  The
    # constrained production schema always supplies recovery_intent; only an
    # actually rest-like legacy intent is allowed to stand in for it.
    if "recovery_intent" not in payload and str(payload.get("intent") or "").casefold() in {
        "rest", "sleep", "recover",
    }:
        recovery_intent = "REST"
    if recovery_intent not in {"NONE", "SEEK", "REST"}:
        recovery_intent = "NONE"
    harm_affliction = str(payload.get("harm_affliction") or "NONE")
    if harm_affliction not in {"NONE", "untreated_wound", "poisoned", "arcane_drain"}:
        harm_affliction = "NONE"
    combat = _normalize_combat_advice(
        payload.get("combat"),
        grounding_text=grounding_text,
        harm_affliction=harm_affliction,
        allow_new_profile=not bool(context.get("active_combat")),
    )
    chase = _normalize_chase_advice(payload.get("chase"))
    if active_situation:
        if chase["action"] == "start":
            chase = _normalize_chase_advice(None)
    elif chase["action"] not in {"NONE", "start"}:
        chase = _normalize_chase_advice(None)
    scenario_flags = _normalize_scenario_flags(payload.get("scenario_flags"), active_scenario)
    requires_roll = payload.get("requires_roll") is True
    party_action = party_advice(payload)
    resource_action = _normalize_resource_advice(
        payload.get("resource_action"),
        player_text=player_text,
        scene_grounding=scene_grounding,
        state=state,
        requires_roll=requires_roll,
    )
    acting_comp = " ".join(str(payload.get("acting_companion") or "NONE").split())[:80] or "NONE"
    if acting_comp.upper() in {"NONE", "PLAYER"} or not requires_roll:
        acting_comp = "NONE"

    if not requires_roll:
        return {
            "intent": str(payload.get("intent") or "ordinary action")[:240],
            "requires_roll": False,
            "stat": "NONE",
            "dc": 0,
            "difficulty": "NONE",
            "reason": str(payload.get("reason") or "No meaningful uncertainty and consequence.")[:300],
            "acting_companion": acting_comp,
            "movement_commitment": movement_commitment,
            "destination": destination,
            "destination_scope": destination_scope,
            "pending_voyage_destination": pending_voyage,
            "voyage_action": _normalized_voyage_action(payload),
            "passage_details": payload.get('passage_details', {}),
            "movement_dependency": "INDEPENDENT" if destination else "NONE",
            "recovery_intent": recovery_intent,
            "npc_scene_occupied": payload.get("npc_scene_occupied") is True,
            "npc_seed_density": (
                "sparse" if payload.get("npc_seed_density") == "sparse" else "ordinary"
            ),
            "harm_affliction": harm_affliction,
            "critical_failure_harm": 0,
            "critical_failure_attention": "NONE",
            "visible_pressure": _normalize_visible_pressure(
                payload, player_text=player_text
            ),
            "combat": combat,
            "chase": chase,
            "scenario_flags": scenario_flags,
            "resource_action": resource_action,
            "party_action": party_action,
            "magic": payload.get("magic") if isinstance(payload.get("magic"), dict) else None,
            "mass_combat_active": payload.get("mass_combat_active") is True,
            "source": "qwen_semantic",
            "destination_repaired": destination_repaired,
            "adjudication_review": payload.get("_adjudication_review"),
        }

    stat = str(payload.get("stat") or "AGI")
    if stat not in {"STR", "AGI", "SOC", "ARC", "PER"}:
        stat = "AGI"
    difficulty, dc = _difficulty_dc(
        payload.get("difficulty"),
        _difficulty_draw(state, player_text),
    )
    movement_dependency = str(payload.get("movement_dependency") or "ROLL")
    if not destination:
        movement_dependency = "NONE"
    elif movement_dependency not in {"ROLL", "INDEPENDENT"}:
        movement_dependency = "ROLL"
    return {
        "intent": str(payload.get("intent") or "risky action")[:240],
        "requires_roll": True,
        "stat": stat,
        "dc": dc,
        "difficulty": difficulty,
        "reason": str(payload.get("reason") or "The uncertain action has meaningful consequences.")[:300],
        "acting_companion": acting_comp,
        "movement_commitment": movement_commitment,
        "destination": destination,
        "destination_scope": destination_scope,
        "pending_voyage_destination": pending_voyage,
        "voyage_action": _normalized_voyage_action(payload),
        "passage_details": payload.get('passage_details', {}),
        "movement_dependency": movement_dependency,
        "recovery_intent": recovery_intent,
        "npc_scene_occupied": payload.get("npc_scene_occupied") is True,
        "npc_seed_density": (
            "sparse" if payload.get("npc_seed_density") == "sparse" else "ordinary"
        ),
        "harm_affliction": harm_affliction,
        "critical_failure_harm": max(
            0, min(2, int(payload.get("critical_failure_harm", 0) or 0))
        ),
        "critical_failure_attention": (
            str(payload.get("critical_failure_attention") or "NONE")
            if str(payload.get("critical_failure_attention") or "NONE") in {"NONE", "noise", "alert"}
            else "NONE"
        ),
        "visible_pressure": _normalize_visible_pressure(
            payload, player_text=player_text
        ),
        "combat": combat,
        "chase": chase,
        "scenario_flags": scenario_flags,
        "resource_action": resource_action,
        "party_action": party_action,
        "magic": payload.get("magic") if isinstance(payload.get("magic"), dict) else None,
        "mass_combat_active": payload.get("mass_combat_active") is True,
        "source": "qwen_semantic",
        "destination_repaired": destination_repaired,
        "adjudication_review": payload.get("_adjudication_review"),
    }


