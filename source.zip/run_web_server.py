from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
import uvicorn

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

def main() -> None:
    parser = argparse.ArgumentParser(description="Aether Harbor Public Play Web Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host interface to bind (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8000")), help="Port to listen on (default: PORT environment variable or 8000)")
    parser.add_argument("--reload", action="store_true", help="Auto-reload on code change")
    args = parser.parse_args()

    print("=================================================================")
    print("      AETHER HARBOR — ONLINE PUBLIC PLAY SERVER (v.42)          ")
    print("=================================================================")
    print(f"Server starting on http://127.0.0.1:{args.port} (and http://{args.host}:{args.port})")
    print("Cascading Model Pipeline: Cloudflare Workers AI -> Google AI Studio -> OpenRouter -> Local LM Studio")
    print("=================================================================")

    uvicorn.run("aether_harbor.web_server:app", host=args.host, port=args.port, reload=args.reload)

if __name__ == "__main__":
    main()
