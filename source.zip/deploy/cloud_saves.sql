-- Run once in a dedicated FREE Supabase project. No public read/write policies.
create table if not exists public.aether_saves (
  session_id text primary key check (session_id ~ '^ah_sess_[0-9a-f]{24}$'),
  revision bigint not null check (revision > 0),
  write_id text not null,
  snapshot text not null check (length(snapshot) <= 16777216),
  updated_at timestamptz not null default now()
);
alter table public.aether_saves enable row level security;
revoke all on public.aether_saves from anon, authenticated;
grant select, insert, update on public.aether_saves to service_role;

create or replace function public.aether_load_save(p_session_id text)
returns jsonb language sql security invoker set search_path = '' as $$
  select jsonb_build_object('revision', revision, 'snapshot', snapshot)
  from public.aether_saves where session_id = p_session_id;
$$;

create or replace function public.aether_write_save(
  p_session_id text, p_expected_revision bigint, p_write_id text, p_snapshot text
) returns bigint language plpgsql security invoker set search_path = '' as $$
declare result bigint;
begin
  if p_expected_revision = 0 then
    insert into public.aether_saves(session_id, revision, write_id, snapshot)
      values(p_session_id, 1, p_write_id, p_snapshot)
      on conflict(session_id) do nothing;
  else
    update public.aether_saves
      set revision = revision + 1, write_id = p_write_id,
          snapshot = p_snapshot, updated_at = now()
      where session_id = p_session_id and revision = p_expected_revision;
  end if;
  -- Idempotent retries also succeed if the response to the first write was lost.
  select revision into result from public.aether_saves
    where session_id = p_session_id and write_id = p_write_id
      and revision = p_expected_revision + 1;
  if result is null then raise exception 'Save revision conflict'; end if;
  return result;
end;
$$;
revoke all on function public.aether_load_save(text) from public, anon, authenticated;
revoke all on function public.aether_write_save(text,bigint,text,text) from public, anon, authenticated;
grant execute on function public.aether_load_save(text) to service_role;
grant execute on function public.aether_write_save(text,bigint,text,text) to service_role;
